package com.aptonline.kcrkit;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.aptonline.kcrkit.server.RequestServer;
import com.aptonline.kcrkit.server.ServerResponseListener;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

@SuppressLint("NewApi")
public class LoginPage extends AppCompatActivity implements ServerResponseListener 
{

	public static final float SWIPE_MIN_DISTANCE = 0;
	public static final float SWIPE_THRESHOLD_VELOCITY = 0;
	EditText usernameEt,passwordEt;
	Button signIn_button;
	private ViewFlipper mViewFlipper;
	public static String UserName,Password;
	//ViewFlipper vf;
	TextView login_version_Tv;

	LinearLayout login_galary;

	PendingIntent pendingIntent;
	AlarmManager manager;
	public void scheduleAlarm() 
	{
		Intent alarmIntent = new Intent(this, AlarmReceiver.class);
		pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);
		manager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
		int interval = 1800000; // 30 minutes
		manager.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntent);
	} 

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);

		try 
		{
			setContentView(R.layout.login_page);

			usernameEt=(EditText)findViewById(R.id.usernameEt);
			passwordEt=(EditText)findViewById(R.id.passwordEt);
			mViewFlipper=(ViewFlipper)findViewById(R.id.view_flipper);

			if (Build.VERSION.SDK_INT >= 23)
			{
				requestPermissions();
			}
			else
			{
				Check_Login();
			}

			if(Build.VERSION.SDK_INT>=24)
			{
				try
				{
					Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
					m.invoke(null);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
		catch (Exception e) 
		{
			CommonFunctions.writeLog("MainActivity", "oncreate", e.getMessage());
			e.printStackTrace();
		}

	}
	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;


	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("Write enternal Contacts");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("camera");
		if (!addPermission(permissionsList, Manifest.permission.GET_ACCOUNTS))
			permissionsNeeded.add("get Accounts");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
			permissionsNeeded.add("Access Fine Location");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
			permissionsNeeded.add("Access Coarse Location");

		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				ActivityCompat.requestPermissions(LoginPage.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}
		Check_Login();
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		switch (requestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.GET_ACCOUNTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			// Fill with results
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			// Check for ACCESS_FINE_LOCATION
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
			{
				Check_Login();
			}
			else
			{
				// Permission Denied
				Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
				.show();
			}
		}
		break;
		default:
			super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		}
	}
	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}
		return true;
	}

	Context mContext;
	public AnimationListener mAnimationListener;
	private void Check_Login() 
	{
		HomeData.readDeviceDetails(this);
		scheduleAlarm();
		mContext=this;
		try 
		{
			((TextView)findViewById(R.id.login_version_Tv)).setText("V"+HomeData.sAppVersionName);
			signIn_button=(Button)findViewById(R.id.signIn_button);
			usernameEt=(EditText)findViewById(R.id.usernameEt);
			passwordEt=(EditText)findViewById(R.id.passwordEt);

			mViewFlipper=(ViewFlipper) findViewById(R.id.view_flipper);
			mViewFlipper.startFlipping();

			signIn_button.setOnClickListener(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					try 
					{
						((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(passwordEt.getWindowToken(), 0);
						UserName=usernameEt.getText().toString();
						Password=passwordEt.getText().toString();
						if(UserName.equals(""))
						{
							usernameEt.setError("Enter User Name");
							usernameEt.requestFocus();
							return;
						}
						else if(Password.equals(""))
						{
							passwordEt.setError("Enter Password"); 
							passwordEt.requestFocus();
							return; 
						}

						HomeData.UserID=UserName;
						HomeData.Password=Password;

						RequestServer request=new RequestServer(LoginPage.this);
						request.addParam("UserID", HomeData.UserID);
						request.addParam("Password", HomeData.Password);
						request.addParam("AuthCode", "KCRKIT");
						request.addParam("AuthKey", "kcrkit@123");
						request.addParam("VersionID", HomeData.sAppVersion);
						request.ProccessRequest(LoginPage.this, "ValidateUser");

					} 
					catch (Exception e)
					{
						CommonFunctions.writeLog("MainActivity", "ValidateUser", e.getMessage());
						e.printStackTrace();
					}
				}
			});
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	class SwipeGestureDetector extends SimpleOnGestureListener
	{
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) 
		{
			try 
			{
				// right to left swipe
				if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY)
				{
					mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.left_in));
					mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext, R.anim.left_out));
					// controlling animation
					mViewFlipper.getInAnimation().setAnimationListener(mAnimationListener);
					mViewFlipper.showNext();
					return true;
				} 
				else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) 
				{
					mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.right_in));
					mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext,R.anim.right_out));
					// controlling animation
					mViewFlipper.getInAnimation().setAnimationListener(mAnimationListener);
					mViewFlipper.showPrevious();
					return true;
				}
				else if(e1.getY() - e2.getY() > SWIPE_MIN_DISTANCE && Math.abs(velocityY) > SWIPE_THRESHOLD_VELOCITY)
				{
					mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.slid_down_middle));
					mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext, R.anim.slid_middle_up));
					// controlling animation
					mViewFlipper.getInAnimation().setAnimationListener(mAnimationListener);
					mViewFlipper.showNext();
				}
				else if(e2.getY() - e1.getY() > SWIPE_MIN_DISTANCE && Math.abs(velocityY) > SWIPE_THRESHOLD_VELOCITY)
				{
					mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.slid_up_middle));
					mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext, R.anim.slid_middle_down));
					// controlling animation
					mViewFlipper.getInAnimation().setAnimationListener(mAnimationListener);
					mViewFlipper.showNext();
				}

			} catch (Exception e)
			{

				e.printStackTrace();
			}

			return false;
		}
	}
	@Override
	protected void onResume()
	{
		super.onResume();
		mViewFlipper.setAutoStart(true);
		mViewFlipper.setFlipInterval(2000);
		mViewFlipper.startFlipping();

		mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.slid_left_middle));
		mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext, R.anim.slid_middle_left));
	  //controlling animation
		mViewFlipper.getInAnimation().setAnimationListener(mAnimationListener);
		mViewFlipper.showNext();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	@Override
	public void Success(String response) 
	{
		startActivity(new Intent(LoginPage.this,Homepage.class));
	}

	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this, response);
	}

	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this, "Network Not Available, Please try Again!!");
	}

	@Override
	public void AppUpdate() 
	{

	}

}
