package com.aptonline.kcrkit;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.os.Handler;
import android.os.Message;

@SuppressLint("NewApi")
public class JSONParser extends Thread implements ErrorCodes 
{
	Handler mUIHandler;
	Context mContext;
	String methodName;
	String response;
	public static String Error, Data, msg;

	public JSONParser(Context mContext,Handler handler,String methodName,String response) 
	{
		this.mContext = mContext;
		this.mUIHandler=handler;
		this.methodName=methodName;
		this.response=response;

	}
	public JSONParser(Context mContext)
	{
		this.mContext = mContext;

	}

	public void run()
	{
		Error="";
		msg="";
		Message localMessage = new Message();
		int resCode=mFailure;
		try 
		{
			if (methodName.equalsIgnoreCase("ValidateUser")) 
			{
				resCode = ValidateUser(new JSONObject(response));

			}

		}
		catch (JSONException e) 
		{
			e.printStackTrace();
			resCode=mJSONException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			resCode=mException;
		}
		finally 
		{
			localMessage.what = resCode;
			mUIHandler.sendMessage(localMessage);
		}
	}

	public int checkForError(JSONObject response) throws JSONException, Exception
	{

		JSONObject jsonObject =response;//{"STATUS":false,"MESSAGE":null}
		if (jsonObject.length() > 0) 
		{
			if (jsonObject.has("Data")) 
			{
				Data = jsonObject.optString("Data").toString();
				if(Data.equalsIgnoreCase("Update Version"))
				{
					return mUpdateVersion;
				}
			}
			if (jsonObject.has("MESSAGE")&&!jsonObject.getBoolean("STATUS")) 
			{
				Error = jsonObject.optString("MESSAGE");
				if(Error.equalsIgnoreCase("Update Version"))
				{
					return mUpdateVersion;	
				}
				else
				{
					return mErrorResFromWebServices;
				}
			}
			return 10; 
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int ValidateUser(JSONObject response) throws JSONException, Exception
	{
		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{

				ContentValues flcdetails=new ContentValues();
				flcdetails.put("UserID",jsonObject.optString("UserId").trim());
				//flcdetails.put("Password",HomeData.Password);
				//flcdetails.put("UserName",jsonObject.optString("UserName").trim());  
				//flcdetails.put("MobileNo",jsonObject.optString("MobileNo").trim()); 
				flcdetails.put("DistrictName",jsonObject.optString("DistrictName").trim());
				flcdetails.put("DivisionName",jsonObject.optString("DivisionName").trim());
				flcdetails.put("PHCName",jsonObject.optString("PHCName").trim());  
				flcdetails.put("SCName",jsonObject.optString("SCName").trim());  
				flcdetails.put("HCID",jsonObject.optString("HCID").trim());  
				flcdetails.put("HCType",jsonObject.optString("HCType").trim());  
				//flcdetails.put("MandalID",jsonObject.optString("ManID").trim());
				//flcdetails.put("MandalName",jsonObject.optString("MandalName").trim());
				//flcdetails.put("CreatedBy",HomeData.UserID);

			}
			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int UpdateSeedFarmLocationDetails(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}	
			}
			return mSuccess;
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}

	}
	public int AQUA_ADDPONDDETAILS(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}
	public int UPDATECFSRPONDSDETAILS(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

	public int UpdateFLCLocationDetails(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}


	public int AQUACULTURE_UPDATELOCATIONDETAILS(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

	public int UpdateaqualabLocationDetails(JSONObject response) throws JSONException, Exception 
	{
		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

	public int UpdateMITankLocationDetails(JSONObject response) throws JSONException, Exception 
	{
		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

}
