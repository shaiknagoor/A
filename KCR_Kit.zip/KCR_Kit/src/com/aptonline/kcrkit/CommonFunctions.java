package com.aptonline.kcrkit;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;
import android.content.Context;
import android.os.Environment;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class CommonFunctions 
{
	
	public static void writeLog(String className,String methodName,String strLog) 
	{

		try 
		{
			boolean isNewFile = false;
			String Dir = Environment.getExternalStorageDirectory().getPath()+ "/AHS/ErrorLog/"+className+"/";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHH");
			String FileNameFormate = dateFormat.format(new Date());
			String FileName = Dir + "/"+methodName+"_" + FileNameFormate +".txt";

			SimpleDateFormat logTimeFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
			String logTime = logTimeFormat.format(new Date());
			File dir = new File(Dir);
			if (!dir.exists()) 
			{
				dir.mkdirs();
			}
			File logFile = new File(FileName);
			if (!logFile.exists())
			{
				isNewFile = true;
				logFile.createNewFile();
			}
			FileOutputStream fOut;
			OutputStreamWriter myOutWriter;
			fOut = new FileOutputStream(logFile, true);
			myOutWriter = new OutputStreamWriter(fOut);
			if (isNewFile)
			{
				myOutWriter.append(logTime + "\n" + strLog);
			} 
			else 
			{
				myOutWriter.append("\n" + logTime + "\n" + strLog);
			}
			myOutWriter.flush();
			myOutWriter.close();
		} 
		catch (Exception ex)
		{

		}

	}
	
}
