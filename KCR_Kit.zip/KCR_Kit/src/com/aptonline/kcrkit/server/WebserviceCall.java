package com.aptonline.kcrkit.server;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;


import com.aptonline.kcrkit.HomeData;
import com.aptonline.kcrkit.LoginPage;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;
import android.widget.TextView;

public class WebserviceCall implements ErrorCodes
{

	String TransDate;
	String TotalTrans;
	public static String Error;
	StringBuilder stringBuilder;
	String namespace = "http://tempuri.org/";

	TextView login_version_Tv;

	private String url,attendaceUrl;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;  
	Context paramContext;
	public static String serverResponse;
	public static int serverUploadcount;


	public static HashMap<String, String> DashBoardInfo=new HashMap<>();

	public WebserviceCall(Context paraContext)
	{
		this.paramContext=paraContext;

		this.url=HomeData.url;
		//this.attendaceUrl=HomeData.aadhaarUrl;
	}

	public int ValidateUser(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="ValidateUser";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,80000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			//[{"UserID":"MBNR-TEST-ANM1","NAME":"TEST-ANM1-21255","MobileNo":"9908888901 ","DistrictName":"Mahabubnagar","DivisionName":"Mahabubnagar ","PHCName":"TestPHC","SCName":"TestCenter","HCID":255,"HCType":"S"}]
			JSONArray jArray = new JSONArray(result);
			if(jArray.length()<=0)
			{
				HomeData.rErrorMsgFromServer="Data not found,Please try again later..!!";
				return mErrorResFromWebServices;
			}
			JSONObject jObject=jArray.getJSONObject(0);

			if(jObject.has("ERROR"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString("ERROR");
				if(HomeData.rErrorMsgFromServer.equalsIgnoreCase("Please Update Your Device Version....!!"))
				{
					return mUpdateVersion;
				}
				return mErrorResFromWebServices;
			}
			else 
			{
				DashBoardInfo=new HashMap<>();
				//DashBoardInfo.put("DistrictName", jObject.optString("DistrictName"));
				DashBoardInfo.put("DistrictName", jObject.optString("DistrictName"));
				DashBoardInfo.put("DivisionName", jObject.optString("DivisionName"));
				DashBoardInfo.put("PHCName", jObject.optString("PHCName"));
				DashBoardInfo.put("SCName", jObject.optString("SCName"));
				DashBoardInfo.put("HCID", jObject.optString("HCID"));
				DashBoardInfo.put("HCType", jObject.optString("HCType"));
				return mSuccess;
			}
			//			Error= "Data Not Found,Please try again!!";
			//			return mFailure;
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}

	public int UPDATE_LongitudeDetails(HashMap<String, String> paramList) 
	{
		try 
		{
			String methodName="UPDATE_LongitudeDetails";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,80000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			if(result.equalsIgnoreCase("true"))
			{
				return mSuccess;
			}	
			else
			{
				HomeData.rErrorMsgFromServer="failed to upload the data please try again....!!";

				return mErrorResFromWebServices;
			}

		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}

	//upload Xml

	//	  <LatLangXML_DETAILS>//<LatLangXML_DETAILS>
	//
	// <latitude>11.266767600</latitude>
	// <longitude>12.356568500</longitude>
	// <DeviceID>HomeData.sDeviceId</DeviceID>
	//
	// <image1>HomeData.imageView2</image1> 
	// <image2>HomeData.imageView3</image2> 
	//
	// <image3>HomeData.imageView4</image3>
	//
	// <image4>HomeData.imageView5</image4> 
	//
	//</LatLangXML_DETAILS> 

}
