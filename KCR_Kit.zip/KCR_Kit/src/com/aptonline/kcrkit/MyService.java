package com.aptonline.kcrkit;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class MyService extends IntentService 
{

	public MyService(String name) 
	{
		super(name);
	}
	public MyService() 
	{
		super("MyService");
	}
	@Override
	protected void onHandleIntent(Intent intent)
	{

		HomeData.isServiceRunning=true;
		int runningService=intent.getExtras().getInt("task");
		try
		{
			GPSTracker gpsTracker=GPSTracker.getInstance(this);
			
			SharedPreferences pref = getSharedPreferences("MyPref", MODE_PRIVATE);     

			if(!pref.contains("AppInstalled"))
			{
				Editor editor = pref.edit();   
				editor.putBoolean("AppInstalled", true);  
				editor.putString("AppLaunchDate",HomeData.current_date);    
				editor.putString("Latitude", ""+gpsTracker.getLatitude());  
				editor.putString("Longitude", ""+gpsTracker.getLongitude()); 
				editor.commit(); 
			}
			else
			{
				Editor editor = pref.edit(); 
				editor.putString("Latitude", ""+gpsTracker.getLatitude());  
				editor.putString("Longitude", ""+gpsTracker.getLongitude()); 
				editor.commit(); 
			}
			Log.e("started task", ""+runningService);

		}  
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		Log.e("finnised task", ""+runningService);
		HomeData.isServiceRunning=false;
	}
}