package com.aptonline.kcrkit;


import java.io.ByteArrayOutputStream;

import com.aptonline.kcrkit.server.RequestServer;
import com.aptonline.kcrkit.server.ServerResponseListener;
import com.aptonline.kcrkit.server.WebserviceCall;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

@SuppressLint("NewApi")
public class Homepage  extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	static int percentage=0;
	ImageView camera_img;
	Handler mHandler;
	Button Submit_button;
	int PHOTO_CAPTURE=100;
	String strBaseimage="";
	String latitude,longitude;

	String strBase64img1;
	String strBase64img2;
	String strBase64img3;
	String strBase64img4;

	int photoPlace=0;

	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.kcr_home);

		((TextView)findViewById(R.id.homepage_dist_setTv)).setText(WebserviceCall.DashBoardInfo.get("DistrictName"));
		((TextView)findViewById(R.id.homepage_division_setTv)).setText(WebserviceCall.DashBoardInfo.get("DivisionName"));
		((TextView)findViewById(R.id.homepage_phc_setTv)).setText(WebserviceCall.DashBoardInfo.get("PHCName"));
		((TextView)findViewById(R.id.homepage_sc_setTv)).setText(WebserviceCall.DashBoardInfo.get("SCName"));	

		SharedPreferences pref = getSharedPreferences("MyPref", MODE_PRIVATE); 
		String Latitude=pref.getString("Latitude", "");
		String Longitude=pref.getString("Longitude", "");
		((TextView)findViewById(R.id.latitude)).setText(Latitude);	
		((TextView)findViewById(R.id.longitude)).setText(Longitude);	

		findViewById(R.id.camera_img1).setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{	
				SharedPreferences pref = getSharedPreferences("MyPref", MODE_PRIVATE); 
				String Latitude=pref.getString("Latitude", "");
				String Longitude=pref.getString("Longitude", "");
				((TextView)findViewById(R.id.latitude)).setText(Latitude);	
				((TextView)findViewById(R.id.longitude)).setText(Longitude);

				photoPlace=1;
				Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent1, PHOTO_CAPTURE);
			}
		});
		findViewById(R.id.camera_img2).setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{
				SharedPreferences pref = getSharedPreferences("MyPref", MODE_PRIVATE); 
				String Latitude=pref.getString("Latitude", "");
				String Longitude=pref.getString("Longitude", "");
				((TextView)findViewById(R.id.latitude)).setText(Latitude);	
				((TextView)findViewById(R.id.longitude)).setText(Longitude);

				photoPlace=2;
				Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent1, PHOTO_CAPTURE);
			}
		});
		findViewById(R.id.camera_img3).setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{
				SharedPreferences pref = getSharedPreferences("MyPref", MODE_PRIVATE); 
				String Latitude=pref.getString("Latitude", "");
				String Longitude=pref.getString("Longitude", "");
				((TextView)findViewById(R.id.latitude)).setText(Latitude);	
				((TextView)findViewById(R.id.longitude)).setText(Longitude);


				photoPlace=3;
				Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent1, PHOTO_CAPTURE);
			}
		});
		findViewById(R.id.camera_img4).setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{
				SharedPreferences pref = getSharedPreferences("MyPref", MODE_PRIVATE); 
				String Latitude=pref.getString("Latitude", "");
				String Longitude=pref.getString("Longitude", "");
				((TextView)findViewById(R.id.latitude)).setText(Latitude);	
				((TextView)findViewById(R.id.longitude)).setText(Longitude);

				photoPlace=4;
				Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent1, PHOTO_CAPTURE);
			}
		});

		findViewById(R.id.Submit_button).setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{	
				String LatLangXML="<LatLangXML_DETAILS>"
						+ "<latitude>11.266767600</latitude>"
						+ "<longitude>12.356568500</longitude>"
						+ "<image1>"+strBase64img1+"</image1> "
						+ "<DeviceID>"+HomeData.sDeviceId+"</DeviceID>"
						+ "<image2>"+strBase64img2+"</image2>"
						+ " <image3>"+strBase64img3+"</image3>"
						+ "<image4>"+strBase64img4+"</image4>"
						+ "</LatLangXML_DETAILS>";

				RequestServer request=new RequestServer(Homepage.this);
				request.addParam("UserID", HomeData.UserID);
				request.addParam("LatLangXML", LatLangXML);
				request.ProccessRequest(Homepage.this, "UPDATE_LongitudeDetails");
			}
		});
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		
				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				//float fKoordX = 3f, fKoordY = 5f;
				//canvas.drawPoint(fKoordX, fKoordY, paint);
				//canvas.drawText("Lat    : "+longitude, fKoordX + 3, fKoordY + 10, paint);
				//canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);


				if(photoPlace==1)
					((ImageView)findViewById(R.id.camera_img1)).setImageBitmap(scaled);
				else if(photoPlace==2)
					((ImageView)findViewById(R.id.camera_img2)).setImageBitmap(scaled);
				else if(photoPlace==3)
					((ImageView)findViewById(R.id.camera_img3)).setImageBitmap(scaled);
				else if(photoPlace==4)
					((ImageView)findViewById(R.id.camera_img4)).setImageBitmap(scaled);

				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();

				if(photoPlace==1)
					strBase64img1= Base64.encodeToString(byteArray,Base64.DEFAULT);
				else if(photoPlace==2)
					strBase64img2= Base64.encodeToString(byteArray,Base64.DEFAULT);
				else if(photoPlace==3)
					strBase64img3= Base64.encodeToString(byteArray,Base64.DEFAULT);
				else if(photoPlace==4)
					strBase64img4= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}
	}

	@Override
	public void onClick(View v) 
	{

	}

	@Override
	public void Success(String response) 
	{
		Dialogs.AlertDialogs(this, "Successfully Submited");
	}

	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this, response);
	}

	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this, "Network Not Available, Please try Again!!");
	}

	@Override
	public void AppUpdate() 
	{

	}

}
