package com.aptonline.kcrkit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver
{

	@Override
	public void onReceive(Context arg0, Intent arg1) 
	{
		if(!HomeData.isServiceRunning)
		{

			Intent intent = new Intent(arg0, MyService.class);
			intent.putExtra("task", HomeData.Task);
			arg0.startService(intent);
		}

		if(HomeData.Task==1000)
			HomeData.Task=0;
		Log.e("New Services No:", ""+HomeData.Task);
		HomeData.Task++;
	}
}
