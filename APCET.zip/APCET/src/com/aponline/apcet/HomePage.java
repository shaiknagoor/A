package com.aponline.apcet;


import com.aponline.apcet.server.RequestServer;
import com.aponline.apcet.server.ServerResponseListener;
import com.aponline.apcet.toast.Toasty;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.Toast;


public class HomePage extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	int duration = 500;
	LinearLayout apeamcet_ll,apedcet_ll,aplawcet_ll,apecet_ll,apicet_ll,appgcet_ll,awareness_ll,appecet_ll;
	ProgressDialog progressDialog;
	Handler mHandler;
	
	Context context;
	private long mLastClickTime = 0;
	boolean doubleBackToExitPressedOnce = false;
	String methodname;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.content_homepage);
		context=this;
		apeamcet_ll=(LinearLayout)findViewById(R.id.apeamcet_ll);
		apedcet_ll=(LinearLayout)findViewById(R.id.apedcet_ll);
		aplawcet_ll=(LinearLayout)findViewById(R.id.aplawcet_ll);
		apecet_ll=(LinearLayout)findViewById(R.id.apecet_ll);
		apicet_ll=(LinearLayout)findViewById(R.id.apicet_ll);
		appgcet_ll=(LinearLayout)findViewById(R.id.appgcet_ll);
		awareness_ll=(LinearLayout)findViewById(R.id.awareness_ll);
		appecet_ll=(LinearLayout)findViewById(R.id.appecet_ll);
		apeamcet_ll.setOnClickListener(this);
		apedcet_ll.setOnClickListener(this);
		aplawcet_ll.setOnClickListener(this);
		apecet_ll.setOnClickListener(this);
		apicet_ll.setOnClickListener(this);
		appgcet_ll.setOnClickListener(this);
		awareness_ll.setOnClickListener(this);
		appecet_ll.setOnClickListener(this);
		View[] views = new View[] {apeamcet_ll,apedcet_ll,aplawcet_ll,apecet_ll,apicet_ll,appgcet_ll,appecet_ll};

		// 100ms delay between Animations
		long delayBetweenAnimations = 100l; 

		for(int i = 0; i < views.length; i++) {
		    final View view = views[i];

		    // We calculate the delay for this Animation, each animation starts 100ms 
		    // after the previous one
		    int delay = (int) (i * delayBetweenAnimations);

		    view.postDelayed(new Runnable() {
		        @Override
		        public void run() {
		            Animation animation = AnimationUtils.loadAnimation(context, R.anim.zoom_in);    
		            view.startAnimation(animation);
		        }
		    }, delay);
		}
	}
	@Override
	public void onClick(View arg0) 
	{
		if(arg0.getId()==R.id.apeamcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
					methodname="EamcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(HomePage.this,"EamcetRecordsJSON");

				}
			}, duration);
		}
		else if(arg0.getId()==R.id.apedcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
				//	Toasty.warning(HomePage.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					methodname="EdcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(HomePage.this,"EdcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.aplawcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
		//			Toasty.warning(HomePage.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					methodname="LawcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(HomePage.this,"LawcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.apecet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					Toasty.warning(HomePage.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();	
					
//					methodname="EcetRecordsJSON";
//					RequestServer request=new RequestServer(context);
//					request.addParam("Username", "APSCHE");
//					request.addParam("Password","APSCHETAB");
//
//					request.ProccessRequest(HomePage.this,"EcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.apicet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
					Toasty.warning(HomePage.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();			
//					methodname="IcetRecordsJSON";
//					RequestServer request=new RequestServer(context);
//					request.addParam("Username", "APSCHE");
//					request.addParam("Password","APSCHETAB");
//
//					request.ProccessRequest(HomePage.this,"IcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.appgcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
					Toasty.warning(HomePage.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
//					methodname="PGEcetRecordsJSON";
//					RequestServer request=new RequestServer(context);
//					request.addParam("Username", "APSCHE");
//					request.addParam("Password","APSCHETAB");
//
//					request.ProccessRequest(HomePage.this,"PGEcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.awareness_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
					startActivity(new Intent(HomePage.this,CBT_Awareness.class));
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.appecet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					Toasty.warning(HomePage.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();	
//					methodname="PEcetRecordsJSON";
//					RequestServer request=new RequestServer(context);
//					request.addParam("Username", "APSCHE");
//					request.addParam("Password","APSCHETAB");
//
//					request.ProccessRequest(HomePage.this,"PEcetRecordsJSON");
					
				}
			}, duration);
		}
	}

	

	@Override
	public void onBackPressed() 
	{
	    if (doubleBackToExitPressedOnce) 
	    {
	        super.onBackPressed();
	        return;
	    }

	    this.doubleBackToExitPressedOnce = true;
	    Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

	    new Handler().postDelayed(new Runnable() 
	    {
	        @Override
	        public void run() 
	        {
	            doubleBackToExitPressedOnce=false;                       
	        }
	    }, 2000);
	}
	@Override
	public void Success(String response) {
		if(methodname.equalsIgnoreCase("EamcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APEAMCET.class));
		}
		else if(methodname.equalsIgnoreCase("LawcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APLAWCET.class));
		}
		else if(methodname.equalsIgnoreCase("EdcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APEDCET.class));
		}
		else if(methodname.equalsIgnoreCase("EcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APECET.class));
		}
		else if(methodname.equalsIgnoreCase("IcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APICET.class));
		}
		else if(methodname.equalsIgnoreCase("PGEcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APPGECET.class));
		}
		else if(methodname.equalsIgnoreCase("PEcetRecordsJSON"))
		{
			startActivity(new Intent(HomePage.this,APPECET.class));
		}
		
	}
	@Override
	public void Fail(String response) {
		Toast toast = null;
		toast=Toast.makeText(HomePage.this, response,Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
		
	}
	@Override
	public void NetworkNotAvail() {
		Toast toast = null;
		toast=Toast.makeText(HomePage.this, "Check Internet Connection",Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
		
	}
	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub
		
	}
	

}
