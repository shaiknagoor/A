package com.aponline.apcet.server;


import java.io.IOException;


import java.net.SocketTimeoutException;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;


public class WebserviceCall extends Thread implements ErrorCodes
{

	public static String Error; 
	String namespace = "http://tempuri.org/";
	//private String url="http://sche.ap.gov.in/APSCHETABLET/WebServices/APSCHEService.asmx"; 
	private String url="http://61.246.226.108:8080/APSCHETABLET/WebServices/APSCHEService.asmx";

	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	Context paramContext;
	public static int serverUploadcount;
	public static String serverResponse,FidStatus,otp;
	public static HashMap<String,String> records;
	public static int VersionNo;
	//public static HashMap<String,String> records;
	//public static HashMap<String,String> records;
	//public static HashMap<String,String> records;
	//DBAdapter db;




	public WebserviceCall(Context paraContext)
	{
		this.paramContext=paraContext;
		//db=new DBAdapter(paraContext);  

	}









	public int EamcetRecordsJSON(HashMap<String,String> local) {
		try
		{
			String methodName="EamcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("Username",local.get("Username"));
			request.addProperty("Password",local.get("Password"));

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("YESTURDAY_TOTAL"))
				{
					records.put("YESTURDAY_TOTAL",jsonObject.getString("YESTURDAY_TOTAL").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
				}
				if(jsonObject.has("ENGINEERING_TODAY"))
				{
					records.put("ENGINEERING_TODAY",jsonObject.getString("ENGINEERING_TODAY").toString().trim());
				}
				if(jsonObject.has("MEDICAL_TODAY"))
				{
					records.put("MEDICAL_TODAY",jsonObject.getString("MEDICAL_TODAY").toString().trim());
				}
				if(jsonObject.has("BOTH_TODAY"))
				{
					records.put("BOTH_TODAY",jsonObject.getString("BOTH_TODAY").toString().trim());
				}
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}
				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}
				






			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int LawcetRecordsJSON(HashMap<String, String> paramList) {
		try
		{
			String methodName="LawcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("TOTAL_YESTURDAY"))
				{
					records.put("TOTAL_YESTURDAY",jsonObject.getString("TOTAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
				}
				if(jsonObject.has("LAWCET3_YESTURDAY"))
				{
					records.put("LAWCET3_YESTURDAY",jsonObject.getString("LAWCET3_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("LAWCET5_YESTURDAY"))
				{
					records.put("LAWCET5_YESTURDAY",jsonObject.getString("LAWCET5_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("PGLCET_YESTURDAY"))
				{
					records.put("PGLCET_YESTURDAY",jsonObject.getString("PGLCET_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}

				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}





			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int EdcetRecordsJSON(HashMap<String, String> paramList) {
		try
		{
			String methodName="EdcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("TOTAL_YESTURDAY"))
				{
					records.put("TOTAL_YESTURDAY",jsonObject.getString("TOTAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
				}
				if(jsonObject.has("MATHS_YESTURDAY"))
				{
					records.put("MATHS_YESTURDAY",jsonObject.getString("MATHS_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("PHYSICS_YESTURDAY"))
				{
					records.put("PHYSICS_YESTURDAY",jsonObject.getString("PHYSICS_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("BIOLOGY_YESTURDAY"))
				{
					records.put("BIOLOGY_YESTURDAY",jsonObject.getString("BIOLOGY_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("SOCIAL_YESTURDAY"))
				{
					records.put("SOCIAL_YESTURDAY",jsonObject.getString("SOCIAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("ENGLISH_YESTURDAY"))
				{
					records.put("ENGLISH_YESTURDAY",jsonObject.getString("ENGLISH_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}

				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}





			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int EcetRecordsJSON(HashMap<String, String> paramList) {
		try
		{
			String methodName="EcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("TOTAL_YESTURDAY"))
				{
					records.put("TOTAL_YESTURDAY",jsonObject.getString("TOTAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
					}				
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}

				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}





			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int IcetRecordsJSON(HashMap<String, String> paramList) {
		try
		{
			String methodName="IcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("TOTAL_YESTURDAY"))
				{
					records.put("TOTAL_YESTURDAY",jsonObject.getString("TOTAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
					}				
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}
				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}

			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int PGEcetRecordsJSON(HashMap<String, String> paramList) {
		try
		{
			String methodName="PGEcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("TOTAL_YESTURDAY"))
				{
					records.put("TOTAL_YESTURDAY",jsonObject.getString("TOTAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
					}				
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}
				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}

			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int PEcetRecordsJSON(HashMap<String, String> paramList) {
		try
		{
			String methodName="PEcetRecords";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("NOTIF_DATE"))
				{
					records.put("NOTIF_DATE",jsonObject.getString("NOTIF_DATE").toString().trim());
				}
				if(jsonObject.has("SUB_LAST_DATE"))
				{
					records.put("SUB_LAST_DATE",jsonObject.getString("SUB_LAST_DATE").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_DATE"))
				{
					records.put("HALL_TICKET_DATE",jsonObject.getString("HALL_TICKET_DATE").toString().trim());
				}
				if(jsonObject.has("EXAM_DATE"))
				{
					records.put("EXAM_DATE",jsonObject.getString("EXAM_DATE").toString().trim());
				}
				if(jsonObject.has("TOTAL_YESTURDAY"))
				{
					records.put("TOTAL_YESTURDAY",jsonObject.getString("TOTAL_YESTURDAY").toString().trim());
				}
				if(jsonObject.has("RTIME"))
				{
					records.put("RTIME",jsonObject.getString("RTIME").toString().trim());
					}				
				if(jsonObject.has("TOTAL_TODAY"))
				{
					records.put("TOTAL_TODAY",jsonObject.getString("TOTAL_TODAY").toString().trim());
				}
				if(jsonObject.has("SUB_END_DATE"))
				{
					records.put("SUB_END_DATE",jsonObject.getString("SUB_END_DATE").toString().trim());
				}

			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Edcet_Application(HashMap<String, String> paramList) {
		try
		{
			String methodName="Edcet_Application";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			request.addProperty("PAYMENT_ID",paramList.get("PAYMENT_ID"));
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("PRIMARY_PREFERENCE"))
				{
					records.put("PRIMARY_PREFERENCE",jsonObject.getString("PRIMARY_PREFERENCE").toString().trim());
				}
				if(jsonObject.has("SECONDARY_PREFERENCE"))
				{
					records.put("SECONDARY_PREFERENCE",jsonObject.getString("SECONDARY_PREFERENCE").toString().trim());
				}
		
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}



	public int Edcet_HallTicket(HashMap<String, String> paramList) {
		try
		{
			String methodName="Edcet_HallTicket";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			request.addProperty("PAYMENT_ID",paramList.get("PAYMENT_ID"));
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("EDCET_HALL_TICKET_NO"))
				{
					records.put("EDCET_HALL_TICKET_NO",jsonObject.getString("EDCET_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CENTER_NAME"))
				{
					records.put("CENTER_NAME",jsonObject.getString("CENTER_NAME").toString().trim());
				}
				if(jsonObject.has("CENTER_ADDRESS"))
				{
					records.put("CENTER_ADDRESS",jsonObject.getString("CENTER_ADDRESS").toString().trim());
				}
				if(jsonObject.has("LAT"))
				{
					records.put("LAT",jsonObject.getString("LAT").toString().trim());
				}
				if(jsonObject.has("LONG"))
				{
					records.put("LONG",jsonObject.getString("LONG").toString().trim());
				}
				
				
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Lawcet_Application(HashMap<String, String> paramList) {
		
		try
		{
			String methodName="Lawcet_Application";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			request.addProperty("PAYMENT_ID",paramList.get("PAYMENT_ID"));
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("PRIMARY_PREFERENCE"))
				{
					records.put("PRIMARY_PREFERENCE",jsonObject.getString("PRIMARY_PREFERENCE").toString().trim());
				}
				if(jsonObject.has("SECONDARY_PREFERENCE"))
				{
					records.put("SECONDARY_PREFERENCE",jsonObject.getString("SECONDARY_PREFERENCE").toString().trim());
				}
		
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Lawcet_HallTicket(HashMap<String, String> paramList) {
		try
		{
			String methodName="Lawcet_HallTicket";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			request.addProperty("PAYMENT_ID",paramList.get("PAYMENT_ID"));
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);
		
			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("LAWCET_HALL_TICKET_NO"))
				{
					records.put("LAWCET_HALL_TICKET_NO",jsonObject.getString("LAWCET_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CENTER_NAME"))
				{
					records.put("CENTER_NAME",jsonObject.getString("CENTER_NAME").toString().trim());
				}
				if(jsonObject.has("CENTER_ADDRESS"))
				{
					records.put("CENTER_ADDRESS",jsonObject.getString("CENTER_ADDRESS").toString().trim());
				}
				if(jsonObject.has("LATITUDE"))
				{
					records.put("LATITUDE",jsonObject.getString("LATITUDE").toString().trim());
				}
				if(jsonObject.has("LONGITIDE"))
				{
					records.put("LONGITIDE",jsonObject.getString("LONGITIDE").toString().trim());
				}
				
				
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Eamcet_Application(HashMap<String, String> paramList) {
		try
		{
			String methodName="Eamcet_Application";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			request.addProperty("PAYMENT_ID",paramList.get("PAYMENT_ID"));
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			
			//request.addProperty("STREAM_ID",paramList.get("STREAM_ID"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);
		
			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
//				if(jsonObject.has("PRIMARY_PREFERENCE"))
//				{
//					records.put("PRIMARY_PREFERENCE",jsonObject.getString("PRIMARY_PREFERENCE").toString().trim());
//				}
//				if(jsonObject.has("SECONDARY_PREFERENCE"))
//				{
//					records.put("SECONDARY_PREFERENCE",jsonObject.getString("SECONDARY_PREFERENCE").toString().trim());
//				}
				if(jsonObject.has("P_TEST_CENTER_DISTRICT_ID"))
				{
					if(!(jsonObject.getString("P_TEST_CENTER_DISTRICT_ID").equalsIgnoreCase("-")))
					{
						records.put("P_TEST_CENTER_DISTRICT_ID",jsonObject.getString("P_TEST_CENTER_DISTRICT_ID").toString().trim());
						records.put("PF1_TEST_CENTER_LOCATION_ID",jsonObject.getString("PF1_TEST_CENTER_LOCATION_ID").toString().trim());
						records.put("PF2_TEST_CENTER_LOCATION_ID",jsonObject.getString("PF2_TEST_CENTER_LOCATION_ID").toString().trim());
						records.put("PF3_TEST_CENTER_LOCATION_ID",jsonObject.getString("PF3_TEST_CENTER_LOCATION_ID").toString().trim());
					}
				}
				if(jsonObject.has("S_TEST_CENTER_DISTRICT_ID"))
				{
					if(!(jsonObject.getString("S_TEST_CENTER_DISTRICT_ID").equalsIgnoreCase("-")))
					{
						records.put("S_TEST_CENTER_DISTRICT_ID",jsonObject.getString("S_TEST_CENTER_DISTRICT_ID").toString().trim());
						records.put("SF1_TEST_CENTER_LOCATION_ID",jsonObject.getString("SF1_TEST_CENTER_LOCATION_ID").toString().trim());
						records.put("SF2_TEST_CENTER_LOCATION_ID",jsonObject.getString("SF2_TEST_CENTER_LOCATION_ID").toString().trim());
						records.put("SF3_TEST_CENTER_LOCATION_ID",jsonObject.getString("SF3_TEST_CENTER_LOCATION_ID").toString().trim());
					}
				}
				if(jsonObject.has("T_TEST_CENTER_DISTRICT_ID"))
				{
					if(!(jsonObject.getString("T_TEST_CENTER_DISTRICT_ID").equalsIgnoreCase("-")))
					{
						records.put("T_TEST_CENTER_DISTRICT_ID",jsonObject.getString("T_TEST_CENTER_DISTRICT_ID").toString().trim());
						records.put("TF1_TEST_CENTER_LOCATION_ID",jsonObject.getString("TF1_TEST_CENTER_LOCATION_ID").toString().trim());
						records.put("TF2_TEST_CENTER_LOCATION_ID",jsonObject.getString("TF2_TEST_CENTER_LOCATION_ID").toString().trim());
						records.put("TF3_TEST_CENTER_LOCATION_ID",jsonObject.getString("TF3_TEST_CENTER_LOCATION_ID").toString().trim());
					}
				}
				
				
				
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Eamcet_HallTicket(HashMap<String, String> paramList) {
		try
		{
			String methodName="Eamcet_HallTicket";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			request.addProperty("DOB",paramList.get("DOB"));
			request.addProperty("STREAM_ID",paramList.get("STREAM_ID"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);
		
			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("HALL_TICKET_NO"))
				{
					records.put("HALL_TICKET_NO",jsonObject.getString("HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CENTER_NAME"))
				{
					records.put("CENTER_NAME",jsonObject.getString("CENTER_NAME").toString().trim());
				}
				if(jsonObject.has("CENTER_ADDRESS"))
				{
					records.put("CENTER_ADDRESS",jsonObject.getString("CENTER_ADDRESS").toString().trim());
				}
				if(jsonObject.has("LATITUDE"))
				{
					records.put("LATITUDE",jsonObject.getString("LATITUDE").toString().trim());
				}
				if(jsonObject.has("LONGITUDE"))
				{
					records.put("LONGITUDE",jsonObject.getString("LONGITUDE").toString().trim());
				}
				
				
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Ecet_Application(HashMap<String, String> paramList) {
	
		try
		{
			String methodName="Ecet_Application";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			request.addProperty("DOB",paramList.get("DOB"));
		
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);
		
			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("PRIMARY_PREFERENCE"))
				{
					records.put("PRIMARY_PREFERENCE",jsonObject.getString("PRIMARY_PREFERENCE").toString().trim());
				}
				if(jsonObject.has("SECONDARY_PREFERENCE"))
				{
					records.put("SECONDARY_PREFERENCE",jsonObject.getString("SECONDARY_PREFERENCE").toString().trim());
				}
				
				
				
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int Ecet_HallTicket(HashMap<String, String> paramList) {
		
		try
		{
			String methodName="Ecet_HallTicket";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("Username",paramList.get("Username"));
			request.addProperty("Password",paramList.get("Password"));
			
			request.addProperty("APPLICATION_NUMBER",paramList.get("APPLICATION_NUMBER"));
			request.addProperty("DOB",paramList.get("DOB"));
			
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);
		
			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("Data"))
				{
					Error="No Data Found"; 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("PAYMENT_ID"))
				{
					records.put("PAYMENT_ID",jsonObject.getString("PAYMENT_ID").toString().trim());
				}
				if(jsonObject.has("APPLICATION_NUMBER"))
				{
					records.put("APPLICATION_NUMBER",jsonObject.getString("APPLICATION_NUMBER").toString().trim());
				}
				if(jsonObject.has("STREAM_NAME"))
				{
					records.put("STREAM_NAME",jsonObject.getString("STREAM_NAME").toString().trim());
				}
				if(jsonObject.has("QUALIFYING_HALL_TICKET_NO"))
				{
					records.put("QUALIFYING_HALL_TICKET_NO",jsonObject.getString("QUALIFYING_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CAND_NAME"))
				{
					records.put("CAND_NAME",jsonObject.getString("CAND_NAME").toString().trim());
				}
				if(jsonObject.has("FATHER_NAME"))
				{
					records.put("FATHER_NAME",jsonObject.getString("FATHER_NAME").toString().trim());
					}				
				if(jsonObject.has("DOB"))
				{
					records.put("DOB",jsonObject.getString("DOB").toString().trim());
				}
				if(jsonObject.has("GENDER"))
				{
					records.put("GENDER",jsonObject.getString("GENDER").toString().trim());
				}
				if(jsonObject.has("CATEGORY_NAME"))
				{
					records.put("CATEGORY_NAME",jsonObject.getString("CATEGORY_NAME").toString().trim());
				}
				if(jsonObject.has("SCRIBE"))
				{
					records.put("SCRIBE",jsonObject.getString("SCRIBE").toString().trim());
				}
				if(jsonObject.has("MINORITY"))
				{
					records.put("MINORITY",jsonObject.getString("MINORITY").toString().trim());
				}
				if(jsonObject.has("SUB_MINORITY_NAME"))
				{
					records.put("SUB_MINORITY_NAME",jsonObject.getString("SUB_MINORITY_NAME").toString().trim());
				}
				if(jsonObject.has("ECET_HALL_TICKET_NO"))
				{
					records.put("ECET_HALL_TICKET_NO",jsonObject.getString("ECET_HALL_TICKET_NO").toString().trim());
				}
				if(jsonObject.has("CENTER_NAME"))
				{
					records.put("CENTER_NAME",jsonObject.getString("CENTER_NAME").toString().trim());
				}
				if(jsonObject.has("CENTER_ADDRESS"))
				{
					records.put("CENTER_ADDRESS",jsonObject.getString("CENTER_ADDRESS").toString().trim());
				}
				if(jsonObject.has("LATITUDE"))
				{
					records.put("LATITUDE",jsonObject.getString("LATITUDE").toString().trim());
				}
				if(jsonObject.has("LONGITIDE"))
				{
					records.put("LONGITIDE",jsonObject.getString("LONGITIDE").toString().trim());
				}
				
				
			}


			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}









	public int VersionChecking(HashMap<String, String> local) {
		try
		{
			String methodName="GetVersion";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("Username",local.get("Username"));
			request.addProperty("Password",local.get("Password"));

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()!=0)
			{      
				records=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return mFailure;
				}
				if(jsonObject.has("VERSION_ID"))
				{
					VersionNo=Integer.parseInt(jsonObject.getString("VERSION_ID").toString().trim());
					
				}
	
			}

			return mSuccess;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return mSocketTimeoutException;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mIOException;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}


}