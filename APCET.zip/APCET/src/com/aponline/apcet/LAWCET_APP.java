package com.aponline.apcet;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aponline.apcet.server.WebserviceCall;

public class LAWCET_APP extends AppCompatActivity
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lawcet_application);
		
		getSupportActionBar().setTitle("AP LAWCET 2018");
		getSupportActionBar().setDisplayHomeAsUpEnabled(false);
		String type = getIntent().getExtras().getString("type");
	  if(type.equalsIgnoreCase("app"))
	  {
		  
		  ((TextView)findViewById(R.id.lawcet_headername)).setText("Application Details");
		  ((LinearLayout)findViewById(R.id.lawcet_hall_ticket_ll)).setVisibility(8);
		  ((LinearLayout)findViewById(R.id.lawcet_center_ll)).setVisibility(8);
		  ((LinearLayout)findViewById(R.id.lawcet_centeradd_ll)).setVisibility(8);
		  ((TextView)findViewById(R.id.lawcet_myapp_appno)).setText(WebserviceCall.records.get("APPLICATION_NUMBER"));
			((TextView)findViewById(R.id.lawcet_myapp_candname)).setText(WebserviceCall.records.get("CAND_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_fname)).setText(WebserviceCall.records.get("FATHER_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_dob)).setText(WebserviceCall.records.get("DOB"));
			((TextView)findViewById(R.id.lawcet_myapp_gender)).setText(WebserviceCall.records.get("GENDER"));
			((TextView)findViewById(R.id.lawcet_myapp_caste)).setText(WebserviceCall.records.get("CATEGORY_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_scribe)).setText(WebserviceCall.records.get("SCRIBE"));
			((TextView)findViewById(R.id.lawcet_myapp_minority)).setText(WebserviceCall.records.get("MINORITY"));
			((TextView)findViewById(R.id.lawcet_myapp_subminority)).setText(WebserviceCall.records.get("SUB_MINORITY_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_stream)).setText(WebserviceCall.records.get("STREAM_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_primarypf)).setText(WebserviceCall.records.get("PRIMARY_PREFERENCE"));
			((TextView)findViewById(R.id.lawcet_myapp_secpf)).setText(WebserviceCall.records.get("SECONDARY_PREFERENCE"));
			((TextView)findViewById(R.id.lawcet_myapp_hallticket)).setText(WebserviceCall.records.get("QUALIFYING_HALL_TICKET_NO"));
			((TextView)findViewById(R.id.lawcet_myapp_paymentid)).setText(WebserviceCall.records.get("PAYMENT_ID"));
	  }
	  else
	  {
		  ((TextView)findViewById(R.id.lawcet_headername)).setText("Hall Ticket Details");
		  ((LinearLayout)findViewById(R.id.lawcet_primaryrf_ll)).setVisibility(8);
		  ((LinearLayout)findViewById(R.id.lawcet_secondaryrf_ll)).setVisibility(8);
		  ((TextView)findViewById(R.id.lawcet_myapp_appno)).setText(WebserviceCall.records.get("APPLICATION_NUMBER"));
			((TextView)findViewById(R.id.lawcet_myapp_candname)).setText(WebserviceCall.records.get("CAND_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_fname)).setText(WebserviceCall.records.get("FATHER_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_dob)).setText(WebserviceCall.records.get("DOB"));
			((TextView)findViewById(R.id.lawcet_myapp_gender)).setText(WebserviceCall.records.get("GENDER"));
			((TextView)findViewById(R.id.lawcet_myapp_caste)).setText(WebserviceCall.records.get("CATEGORY_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_scribe)).setText(WebserviceCall.records.get("SCRIBE"));
			((TextView)findViewById(R.id.lawcet_myapp_minority)).setText(WebserviceCall.records.get("MINORITY"));
			((TextView)findViewById(R.id.lawcet_myapp_subminority)).setText(WebserviceCall.records.get("SUB_MINORITY_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_stream)).setText(WebserviceCall.records.get("STREAM_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_hallticket)).setText(WebserviceCall.records.get("QUALIFYING_HALL_TICKET_NO"));
			((TextView)findViewById(R.id.lawcet_myapp_paymentid)).setText(WebserviceCall.records.get("PAYMENT_ID"));
			((TextView)findViewById(R.id.lawcet_myapp_hallticketno)).setText(WebserviceCall.records.get("LAWCET_HALL_TICKET_NO"));
			((TextView)findViewById(R.id.lawcet_myapp_centername)).setText(WebserviceCall.records.get("CENTER_NAME"));
			((TextView)findViewById(R.id.lawcet_myapp_centeradd)).setText(WebserviceCall.records.get("CENTER_ADDRESS"));
		final String lat=	WebserviceCall.records.get("LATITUDE");
		final String lang=WebserviceCall.records.get("LONGITIDE");
		final String mTitle=WebserviceCall.records.get("CENTER_NAME");
		((ImageView)findViewById(R.id.lawcet_centre_map)).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:<"+lat+">,<"+lang+">?q=<"+lat+">,<"+lang+">("+mTitle+")"));
				startActivity(intent);
				//String geoUri = "http://maps.google.com/maps?q=loc:" + lat + "," + lang + " (" + mTitle + ")";
				//String uri = String.format(Locale.ENGLISH, "geo:%f,%f",Double.parseDouble(lat),Double.parseDouble(lang));
				//Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));
			//startActivity(intent);
			}
		});
	  }
		}
		catch(Exception e)
		{
			
		}
		
		
	}

}
