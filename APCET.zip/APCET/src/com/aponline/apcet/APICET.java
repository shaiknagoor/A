package com.aponline.apcet;



import com.aponline.apcet.server.WebserviceCall;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class APICET extends AppCompatActivity
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.icetpage);
		getSupportActionBar().setTitle("AP ICET 2017");
		((TextView)findViewById(R.id.icet_sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.icet_sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.icet_hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.icet_exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
	}
}
