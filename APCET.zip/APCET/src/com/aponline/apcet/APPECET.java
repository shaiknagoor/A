package com.aponline.apcet;


import com.aponline.apcet.server.WebserviceCall;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class APPECET extends AppCompatActivity
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pecetpage);
		getSupportActionBar().setTitle("AP PECET 2017");
		((TextView)findViewById(R.id.pecet_sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.pecet_sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.pecet_hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.pecet_exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
		
	}
}
