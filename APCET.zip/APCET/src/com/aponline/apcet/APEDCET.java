package com.aponline.apcet;




import com.aponline.apcet.server.RequestServer;
import com.aponline.apcet.server.ServerResponseListener;
import com.aponline.apcet.server.WebserviceCall;
import com.aponline.apcet.toast.Toasty;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class APEDCET extends AppCompatActivity implements OnClickListener,ServerResponseListener 
{
	int duration = 500;
	Context context;
	private long mLastClickTime = 0;
	boolean doubleBackToExitPressedOnce = false;
	String methodname;
	ProgressDialog progressDialog;
	Handler mHandler;
	Button myapp_submit,hall_submit;
	LinearLayout myapplication_ll,myhallticket_ll,myapplication_details_ll,myhallticket_details_ll;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edcetpage);		
		getSupportActionBar().setTitle("AP EdCET 2018");
		context=this;
		myapplication_ll=(LinearLayout)findViewById(R.id.edcet_myapplication_ll);
		myhallticket_ll=(LinearLayout)findViewById(R.id.edcet_myhallticket_ll);
		myapplication_details_ll=(LinearLayout)findViewById(R.id.edcet_myapp_details);
		myhallticket_details_ll=(LinearLayout)findViewById(R.id.edcet_hallt_details);
		myapp_submit=(Button)findViewById(R.id.edcet_myapp_submit);
		hall_submit=(Button)findViewById(R.id.edcet_hallt_submit);
		((TextView)findViewById(R.id.edcet_sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.edcet_sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.edcet_hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.edcet_exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));		
		myapplication_ll.setOnClickListener(this);
		myhallticket_ll.setOnClickListener(this);
		myapp_submit.setOnClickListener(this);
		hall_submit.setOnClickListener(this);
	}
	
	public void shareMethod(View v)
	{
		if(v.getId()==R.id.mock_test_url_biology_share)
		{			
			  Intent sendIntent = new Intent(); 
              sendIntent.setAction(Intent.ACTION_SEND); 
              sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
              sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com:443//OnlineAssessment/index.html?1383@@M32"); 
              sendIntent.setType("text/plain"); 
              startActivity(sendIntent);
		}
		if(v.getId()==R.id.mock_test_url_physics_share)
		{			
			  Intent sendIntent = new Intent(); 
              sendIntent.setAction(Intent.ACTION_SEND); 
              sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
              sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com:443//OnlineAssessment/index.html?1383@@M33"); 
              sendIntent.setType("text/plain"); 
              startActivity(sendIntent);
		}
		if(v.getId()==R.id.mock_test_url_social_share)
		{			
			  Intent sendIntent = new Intent(); 
              sendIntent.setAction(Intent.ACTION_SEND); 
              sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
              sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com:443//OnlineAssessment/index.html?1383@@M34"); 
              sendIntent.setType("text/plain"); 
              startActivity(sendIntent);
		}
		if(v.getId()==R.id.mock_test_url_maths_share)
		{
			  Intent sendIntent = new Intent(); 
              sendIntent.setAction(Intent.ACTION_SEND); 
              sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
              sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com:443//OnlineAssessment/index.html?1383@@M35"); 
              sendIntent.setType("text/plain"); 
              startActivity(sendIntent);
		}
		if(v.getId()==R.id.mock_test_url_english_share)
		{
			  Intent sendIntent = new Intent(); 
              sendIntent.setAction(Intent.ACTION_SEND); 
              sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
              sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com:443//OnlineAssessment/index.html?1383@@M36"); 
              sendIntent.setType("text/plain"); 
              startActivity(sendIntent);
		}
	}

	@Override
	public void onClick(View arg0)
	{
		if(arg0.getId()==R.id.edcet_myapplication_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					
			            if(myapplication_details_ll.getVisibility()==View.GONE){
			            
			            	myapplication_details_ll.setVisibility(View.VISIBLE);
			            }
			            else
			            {			            
			            	myapplication_details_ll.setVisibility(View.GONE);
			            	((EditText)findViewById(R.id.edcet_myapp_application_no)).setText("");
			            	((EditText)findViewById(R.id.edcet_myapp_paymentid)).setText("");
			            }
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
				

				}
			}, duration);
		}
		else if(arg0.getId()==R.id.edcet_myhallticket_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					Toasty.error(APEDCET.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
//			            if(myhallticket_details_ll.getVisibility()==View.GONE){
//			            
//			            	myhallticket_details_ll.setVisibility(View.VISIBLE);
//			            	((EditText)findViewById(R.id.edcet_hallt_application_no)).requestFocus();
//			            }
//			            else
//			            {			            
//			            	myhallticket_details_ll.setVisibility(View.GONE);
//			            	((EditText)findViewById(R.id.edcet_hallt_application_no)).setText("");
//			            	((EditText)findViewById(R.id.edcet_hallt_paymentid)).setText("");
//			            }
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					
				

				}
			}, duration);
		}
		else if(arg0.getId()==R.id.edcet_myapp_submit)
		{
			if(((EditText)findViewById(R.id.edcet_myapp_paymentid)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.edcet_myapp_paymentid)).setError("Enter Pay Id");
				((EditText)findViewById(R.id.edcet_myapp_paymentid)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.edcet_myapp_application_no)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.edcet_myapp_application_no)).setError("Enter App No");
				((EditText)findViewById(R.id.edcet_myapp_application_no)).requestFocus();
				return;
			}
			
			methodname="Edcet_Application";
			RequestServer request=new RequestServer(context);
			request.addParam("Username", "APSCHE");
			request.addParam("Password","APSCHETAB");
			request.addParam("PAYMENT_ID",((EditText)findViewById(R.id.edcet_myapp_paymentid)).getText().toString().trim());
			request.addParam("APPLICATION_NUMBER",((EditText)findViewById(R.id.edcet_myapp_application_no)).getText().toString().trim());			
			request.ProccessRequest(APEDCET.this,"Edcet_Application");
		}
		else if(arg0.getId()==R.id.edcet_hallt_submit)
		{
			if(((EditText)findViewById(R.id.edcet_hallt_application_no)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.edcet_hallt_application_no)).setError("Enter App No");
				return;
			}
			if(((EditText)findViewById(R.id.edcet_hallt_paymentid)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.edcet_hallt_paymentid)).setError("Enter Pay Id");
				return;
			}
			methodname="Edcet_HallTicket";
			RequestServer request=new RequestServer(context);
			request.addParam("Username", "APSCHE");
			request.addParam("Password","SCHETAB");
			request.addParam("PAYMENT_ID",((EditText)findViewById(R.id.edcet_hallt_paymentid)).getText().toString().trim());
			request.addParam("APPLICATION_NUMBER",((EditText)findViewById(R.id.edcet_hallt_application_no)).getText().toString().trim());			
			request.ProccessRequest(APEDCET.this,"Edcet_HallTicket");
		}	
		
	}

	@Override
	public void Success(String response) {
		if(methodname.equalsIgnoreCase("Edcet_Application"))
		{
			Intent i=new Intent(APEDCET.this,EDCET_APP.class);
			i.putExtra("type","app");
			startActivity(i);			
		}
		if(methodname.equalsIgnoreCase("Edcet_HallTicket"))
		{
			Intent i=new Intent(APEDCET.this,EDCET_APP.class);
			i.putExtra("type","hall");
			startActivity(i);			
		}
		
	}

	@Override
	public void Fail(String response) {
		Toast toast = null;
		toast=Toast.makeText(APEDCET.this, response,Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
		
	}

	@Override
	public void NetworkNotAvail() {
		Toast toast = null;
		toast=Toast.makeText(APEDCET.this, "Check Internet Connection",Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
		
	}

	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub
		
	}
}
