package com.aponline.apcet;




import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.aponline.apcet.server.RequestServer;
import com.aponline.apcet.server.ServerResponseListener;
import com.aponline.apcet.server.WebserviceCall;
import com.aponline.apcet.toast.Toasty;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class APEAMCET extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	int duration = 500;
	Context context;
	private long mLastClickTime = 0;
	boolean doubleBackToExitPressedOnce = false;
	String methodname;
	ProgressDialog progressDialog;
	Handler mHandler;
	Button myapp_submit,hall_submit;
	TextView hall_dob;
	EditText myapp_dob;
	private int year,month,day; 
	LinearLayout myapplication,myhallticket,myapplication_details_ll,myhallticket_details_ll;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.apeamcet_layout);
		getSupportActionBar().setTitle("EAMCET 2018");

		myapplication=(LinearLayout)findViewById(R.id.myapplication_ll);
		myhallticket=(LinearLayout)findViewById(R.id.myhallticket_ll);
		myapplication_details_ll=(LinearLayout)findViewById(R.id.eamcet_myapp_details);
		myhallticket_details_ll=(LinearLayout)findViewById(R.id.eamcet_hallt_details);
		myapp_submit=(Button)findViewById(R.id.eamcet_myapp_submit);
		hall_submit=(Button)findViewById(R.id.eamcet_hallt_submit);
		context=this;
		((TextView)findViewById(R.id.sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
		//		SpannableString content = new SpannableString("2016:https://g01.digialm.com//OnlineAssessment/index.html?1383@@M23"+"\n\n"+"2015:https://g01.digialm.com//OnlineAssessment/index.html?1383@@M28");
		//		content.setSpan(new UnderlineSpan(), 0, content.length(), 0);

		//		Animation anim = new AlphaAnimation(0.5f, 1.0f);
		//		anim.setDuration(1150); 
		//		anim.setStartOffset(20);
		//		anim.setRepeatMode(Animation.REVERSE);
		//		anim.setRepeatCount(Animation.INFINITE);
		//test_mark_url_eng.startAnimation(anim);
		myapp_dob=(EditText)findViewById(R.id.eamcet_myapp_dob);
		hall_dob=(TextView)findViewById(R.id.eamcet_hallt_dob);
		myapplication.setOnClickListener(this);
		myhallticket.setOnClickListener(this);
		myapp_submit.setOnClickListener(this);
		hall_submit.setOnClickListener(this);
//		myapp_dob.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View arg0) {
//				DateFunction(myapp_dob);
//
//			}
//		});
		hall_dob.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				DateFunction(hall_dob);
			}
		});
		//		SpannableString content1 = new SpannableString("2016:https://g01.digialm.com//OnlineAssessment/index.html?1383@@M29"+"\n\n"+"2015:https://g01.digialm.com//OnlineAssessment/index.html?1383@@M27");
		//		content1.setSpan(new UnderlineSpan(), 0, content1.length(), 0);


		//test_mark_url_med.startAnimation(anim);

	}	
	@Override
	public void onClick(View arg0) 
	{
		if(arg0.getId()==R.id.myapplication_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if(myapplication_details_ll.getVisibility()==View.GONE){				            
						myapplication_details_ll.setVisibility(View.VISIBLE);
					}
					else
					{			            
						myapplication_details_ll.setVisibility(View.GONE);
						((EditText)findViewById(R.id.eamcet_myapp_appno)).setText("");
						((EditText)findViewById(R.id.eamcet_myapp_dob)).setText("");
					}
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();				

				}
			}, duration);
		}
		else if(arg0.getId()==R.id.myhallticket_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					
					Toasty.error(APEAMCET.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
//					if(myhallticket_details_ll.getVisibility()==View.GONE)
//					{
//						myhallticket_details_ll.setVisibility(View.VISIBLE);
//						((EditText)findViewById(R.id.eamcet_hallt_appno)).requestFocus();
//					}
//					else
//					{			            
//						myhallticket_details_ll.setVisibility(View.GONE);
//						((EditText)findViewById(R.id.eamcet_hallt_appno)).setText("");
//						((TextView)findViewById(R.id.eamcet_hallt_dob)).setText("");
//						((Spinner)findViewById(R.id.eamcet_hallt_streamid)).setSelection(0);
//					}
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.eamcet_myapp_submit)
		{
			if(((EditText)findViewById(R.id.eamcet_myapp_dob)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.eamcet_myapp_dob)).setError("Enter Payment Id");
				((EditText)findViewById(R.id.eamcet_myapp_dob)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.eamcet_myapp_appno)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.eamcet_myapp_appno)).setError("Enter App No");
				((EditText)findViewById(R.id.eamcet_myapp_appno)).requestFocus();
				return;
			}
			
			methodname="Eamcet_Application";
			RequestServer request=new RequestServer(context);
			request.addParam("Username", "APSCHE");
			request.addParam("Password","APSCHETAB");
			request.addParam("PAYMENT_ID",((EditText)findViewById(R.id.eamcet_myapp_dob)).getText().toString().trim());
			request.addParam("APPLICATION_NUMBER",((EditText)findViewById(R.id.eamcet_myapp_appno)).getText().toString().trim());			
			//request.addParam("STREAM_ID","1");
			request.ProccessRequest(APEAMCET.this,"Eamcet_Application");
			}
		else if(arg0.getId()==R.id.eamcet_hallt_submit)
		{
			if(((EditText)findViewById(R.id.eamcet_hallt_appno)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.eamcet_hallt_appno)).setError("Enter App No");
				((EditText)findViewById(R.id.eamcet_hallt_appno)).requestFocus();
				return;
			}
			if(((TextView)findViewById(R.id.eamcet_hallt_dob)).getText().toString().equalsIgnoreCase(""))
			{
				((TextView)findViewById(R.id.eamcet_hallt_dob)).setError("Enter Payment Id");
				return;
			}
			if(((Spinner)findViewById(R.id.eamcet_hallt_streamid)).getSelectedItemPosition()==0)
			{
				((Spinner)findViewById(R.id.eamcet_hallt_streamid)).requestFocusFromTouch();
				return;
			}
			methodname="Eamcet_HallTicket";
			RequestServer request=new RequestServer(context);
			request.addParam("Username", "APSCHE");
			request.addParam("Password","SCHETAB");
			request.addParam("DOB",((TextView)findViewById(R.id.eamcet_hallt_dob)).getText().toString().trim());
			request.addParam("APPLICATION_NUMBER",((EditText)findViewById(R.id.eamcet_hallt_appno)).getText().toString().trim());			
			request.addParam("STREAM_ID",Integer.toString(((Spinner)findViewById(R.id.eamcet_hallt_streamid)).getSelectedItemPosition()));
			request.ProccessRequest(APEAMCET.this,"Eamcet_HallTicket");
		}	


	}

	public void shareMethod(View v)
	{
		if(v.getId()==R.id.eng_2015_share)
		{			
			Intent sendIntent = new Intent(); 
			sendIntent.setAction(Intent.ACTION_SEND); 
			sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
			sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com//OnlineAssessment/index.html?1383@@M28"); 
			sendIntent.setType("text/plain"); 
			startActivity(sendIntent);
		}
		if(v.getId()==R.id.eng_2016_share)
		{			
			Intent sendIntent = new Intent(); 
			sendIntent.setAction(Intent.ACTION_SEND); 
			sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
			sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com//OnlineAssessment/index.html?1383@@M23"); 
			sendIntent.setType("text/plain"); 
			startActivity(sendIntent);
		}
		if(v.getId()==R.id.med_2015_share)
		{			
			Intent sendIntent = new Intent(); 
			sendIntent.setAction(Intent.ACTION_SEND); 
			sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
			sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com//OnlineAssessment/index.html?1383@@M27"); 
			sendIntent.setType("text/plain"); 
			startActivity(sendIntent);
		}
		if(v.getId()==R.id.med_2016_share)
		{
			Intent sendIntent = new Intent(); 
			sendIntent.setAction(Intent.ACTION_SEND); 
			sendIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Mock Test Url");
			sendIntent.putExtra(Intent.EXTRA_TEXT,"https://g01.digialm.com//OnlineAssessment/index.html?1383@@M29"); 
			sendIntent.setType("text/plain"); 
			startActivity(sendIntent);
		}
	}
	@Override
	public void Success(String response) {
		if(methodname.equalsIgnoreCase("Eamcet_Application"))
		{
			Intent i=new Intent(APEAMCET.this,EAMCET_APP.class);
			i.putExtra("type","app");
			startActivity(i);			
		}
		if(methodname.equalsIgnoreCase("Eamcet_HallTicket"))
		{
			Intent i=new Intent(APEAMCET.this,EAMCET_APP.class);
			i.putExtra("type","hall");
			startActivity(i);			
		}

	}
	@Override
	public void Fail(String response) {
		Toast toast = null;
		toast=Toast.makeText(APEAMCET.this, response,Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
	}
	@Override
	public void NetworkNotAvail() {
		Toast toast = null;
		toast=Toast.makeText(APEAMCET.this, "Check Internet Connection",Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
	}
	@Override
	public void AppUpdate() {


	}
	public void DateFunction(final View v)
	{
		final Calendar c = Calendar.getInstance();
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH);
		day = c.get(Calendar.DAY_OF_MONTH);
		DatePickerDialog dpd=new DatePickerDialog(APEAMCET.this, android.R.style.Theme_Holo_Dialog,new DatePickerDialog.OnDateSetListener() 
		{
			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) 
			{
				String dateSelected=(monthOfYear+1)+"/"+dayOfMonth+"/"+Integer.toString(year);
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				try {
					Date rdate = (Date)sdf.parse(dateSelected);
					String	edate= new SimpleDateFormat("yyyy-MM-dd").format(rdate);
					((TextView)v).setText(edate);

				} catch (ParseException e) 
				{

					e.printStackTrace();
				}
			}
		}, year, month, day);
		dpd.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dpd.getDatePicker().setCalendarViewShown(false);
		dpd.show();	
		dpd.getDatePicker().setMaxDate(System.currentTimeMillis());
	} 
}
