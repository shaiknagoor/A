package com.example.lenovo.retail;


import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

public class MySharedPreference {
    private static final String Log_TAG = MySharedPreference.class.getSimpleName();
    private SharedPreferences prefs;

    private Context context;

    public MySharedPreference(Context context){
        this.context = context;
        prefs = context.getSharedPreferences(Constants.SHARED_PREF, Context.MODE_PRIVATE);
    }


    public void removeProductToTheCart(String product){
        SharedPreferences.Editor edits = prefs.edit();
        edits.remove(Constants.PRODUCT_ID);
//        edits.putString(Constants.PRODUCT_ID, product);
        edits.apply();
    }

    public void addProductToTheCart(String product){
        SharedPreferences.Editor edits = prefs.edit();
        edits.putString(Constants.PRODUCT_ID, product);
        edits.apply();
        edits.clear();
    }

    public String retrieveProductFromCart(){
        return prefs.getString(Constants.PRODUCT_ID, "");
    }

    public int addOrderNum(int itemcount){
        SharedPreferences.Editor edits = prefs.edit();
        edits.putInt(Constants.ORDER_NUM,itemcount);
        edits.apply();
        return itemcount;
    }

    public int retriveOrderNum( ){
        return prefs.getInt(Constants.ORDER_NUM,0);
    }


    public void clear()
    {

        SharedPreferences.Editor edits = prefs.edit();
        edits.putInt(Constants.PRODUCT_COUNT, 0);
        edits.clear();
        edits.commit();
    }


    public void ProductCountValue(int itemcount){
        SharedPreferences.Editor edits = prefs.edit();
        edits.putInt(Constants.ITEM_Count,itemcount);
        edits.apply();
        Log.v(Log_TAG,"item_count_value"+itemcount);
    }
    public int retriveProductCountValue(){
        return prefs.getInt(Constants.ITEM_Count,0);
    }

    public void addProductCount(int productCount){
        SharedPreferences.Editor edits = prefs.edit();
        edits.putInt(Constants.PRODUCT_COUNT, productCount);
        edits.apply();
        Log.v(Log_TAG,"@@@@@@@@@@@"+productCount);
         }


    public int retrieveProductCount()
    {

       return prefs.getInt(Constants.PRODUCT_COUNT, 0);
    }
}
