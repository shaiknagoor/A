package com.example.lenovo.retail;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Lenovo on 7/10/2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "sampledb.sqlite";


    private static  String DBLOCATION ;
    private Context mContext;
//    private SQLiteDatabase mDatabase;
    private static SQLiteDatabase mSqliteDatabase = null;
    private static  DatabaseHelper mDatabase;

    public DatabaseHelper(Context context) {
        super(context, DBNAME, null, 1);
        this.mContext = context;
        DBLOCATION = "/sdcard/RetailDatabase/";
        Log.v("The Database Path", DBLOCATION);
    }


    public static synchronized DatabaseHelper getRetailDatabase(Context context) {
       {
            if ( mDatabase == null) {
                mDatabase = new DatabaseHelper(context);
            }
            return mDatabase;
        }

    }

    public static SQLiteDatabase openDataBaseNew() throws SQLException
    {
        // Open the database
        if (mSqliteDatabase == null)
        {

            mSqliteDatabase = SQLiteDatabase.openDatabase(DBLOCATION, null,SQLiteDatabase.OPEN_READWRITE| SQLiteDatabase.CREATE_IF_NECESSARY| SQLiteDatabase.NO_LOCALIZED_COLLATORS);
        }
        else if (!mSqliteDatabase.isOpen())
        {
            mSqliteDatabase = SQLiteDatabase.openDatabase(DBLOCATION, null,SQLiteDatabase.OPEN_READWRITE| SQLiteDatabase.CREATE_IF_NECESSARY| SQLiteDatabase.NO_LOCALIZED_COLLATORS);
        }
        return mSqliteDatabase;
    }

    /* create an empty database if data base is not existed */
    public void createDataBase() throws IOException {
        boolean dbExist = checkDataBase();

        if (dbExist) {
            //do nothing - database already exist
        } else {
            try {
                copyDataBase();
                Log.v("dbcopied:::","true");
            } catch (SQLiteException ex) {
                ex.printStackTrace();
                throw new Error("Error copying database");
            } catch (IOException e) {
                e.printStackTrace();
                throw new Error("Error copying database");
            }
            try {
                openDataBase();
            } catch (SQLiteException ex) {
                ex.printStackTrace();
                throw new Error("Error opening database");
            } catch (Exception e) {
                e.printStackTrace();
                throw new Error("Error opening database");
            }
        }

    }

    /* checking the data base is existed or not */
    /* return true if existed else return false */
    private boolean checkDataBase() {
        boolean dataBaseExisted = false;
        try {
            String check_Path = DBLOCATION + DBNAME;
            File file = new File(check_Path);
            if (file.exists() && !file.isDirectory())
            mSqliteDatabase = SQLiteDatabase.openDatabase(check_Path, null, SQLiteDatabase.OPEN_READWRITE);
        } catch (Exception ex) {
            // TODO: handle exception
            ex.printStackTrace();
        }
        return mSqliteDatabase != null ? true : false;
    }

    private void copyFile(InputStream in, OutputStream out) throws IOException
    {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1)
        {
            out.write(buffer, 0, read);
        }
    }

    private void copyDataBase() throws IOException {
        File dbDir = new File(DBLOCATION);
        if (!dbDir.exists()) {
            dbDir.mkdir();

        }
        InputStream myInput = mContext.getAssets().open(DBNAME);
        OutputStream myOutput = new FileOutputStream(DBLOCATION + DBNAME);
        copyFile(myInput,myOutput);

    }

    /* Open the database */
    public void openDataBase() throws SQLException {

        String check_Path = DBLOCATION + DBNAME;
        if (mSqliteDatabase != null) {
            mSqliteDatabase.close();
            mSqliteDatabase = null;
            mSqliteDatabase = SQLiteDatabase.openDatabase(check_Path, null, SQLiteDatabase.OPEN_READWRITE);
        } else {
            mSqliteDatabase = SQLiteDatabase.openDatabase(check_Path, null, SQLiteDatabase.OPEN_READWRITE);
        }
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public String getSinlgeEntry(String userName)
    {
        openDatabase();
//        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor=mSqliteDatabase.query("User", null, " UName=?", new String[]{userName}, null, null, null);
        if(cursor.getCount()<1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password= cursor.getString(cursor.getColumnIndex("Password"));
        cursor.close();
        return password;
    }

    public boolean insertUserDetails (String UName,String MobileNo,String UEmail,String Password,String ConformPassword,String IsActive,String CreatedDate,String CreatedByUserId,String UpdatedDate,String UpdatedByUserId) {
//        SQLiteDatabase db = this.getWritableDatabase();

        try {
            openDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(DataBaseKeys.UName,UName);
            contentValues.put(DataBaseKeys.MobileNo,MobileNo);
            contentValues.put(DataBaseKeys.UEmail,UEmail);
            contentValues.put(DataBaseKeys.Password,Password);
            contentValues.put(DataBaseKeys.ConformPassword,ConformPassword);
            contentValues.put(DataBaseKeys.ISACTIVE,IsActive);
            contentValues.put(DataBaseKeys.Created_Date,CreatedDate);
            contentValues.put(DataBaseKeys.CREATEDBY_UserId,CreatedByUserId);
            contentValues.put(DataBaseKeys.Updated_date,UpdatedDate);
            contentValues.put(DataBaseKeys.Updated_By_UserId,UpdatedByUserId);

            mSqliteDatabase.insert(DataBaseKeys.TABLE_USER_DETAILS, null, contentValues);
Log.v("userdata","data for user"+contentValues);
        }catch (Exception e){
            Log.v("UserDetails","Data insert failed due to"+e);
        }

        return true;
    }

    public boolean insertOrderData ( String OHId, String ProductId,String Qty,String Price,String Discount,String IsActive,String CreatedDate,String CreatedByUserId,String UpdatedDate,String UpdatedByUserId) {
//        SQLiteDatabase db = this.getWritableDatabase();
        mSqliteDatabase.beginTransaction();
        try {
            openDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(DataBaseKeys.ORDER_H_ID,OHId);
            contentValues.put(DataBaseKeys.ORDER_P_ID,ProductId);
            contentValues.put(DataBaseKeys.QTY,Qty);
            contentValues.put(DataBaseKeys.PRICE,Price);
            contentValues.put(DataBaseKeys.ISACTIVE,IsActive);
            contentValues.put(DataBaseKeys.DISCOUNT,Discount);
            contentValues.put(DataBaseKeys.Created_Date,CreatedDate);
            contentValues.put(DataBaseKeys.CREATEDBY_UserId,CreatedByUserId);
            contentValues.put(DataBaseKeys.Updated_date,UpdatedDate);
            contentValues.put(DataBaseKeys.Updated_By_UserId,UpdatedByUserId);

            mSqliteDatabase.insert(DataBaseKeys.TABLE_ORDER_DETAILS, null, contentValues);
        mSqliteDatabase.setTransactionSuccessful();
        }finally {
            mSqliteDatabase.endTransaction();
        }

        return true;
    }

    public long update_ProductTable(String Qty,  String id) {
        ContentValues con = new ContentValues();

        con.put(DataBaseKeys.QUANTITY_PRODUCT,Qty);
        Log.v("priority", Qty+"value");
        return mSqliteDatabase.update(DataBaseKeys.TABLE_PRODUCT_DETAILS, con, "ProductId ='" + id + "'",null);

    }


    public long update_cartList(String Qty,  String id) {
        ContentValues con = new ContentValues();

        con.put(DataBaseKeys.QUANTITY,Qty);
        Log.v("priority", Qty+"value");
        return mSqliteDatabase.update(DataBaseKeys.TABLE_TEMP_DETAILS, con, "PId ='" + id + "'",null);

    }

    public int getProductsCount() {
        String countQuery = "SELECT Quantity FROM " + DataBaseKeys.TABLE_TEMP_DETAILS;

        Cursor cursor = mSqliteDatabase.rawQuery(countQuery, null);
        int cnt = cursor.getCount();
        cursor.close();
        return cnt;
    }
//  sum of all quantity data
public int addAllValues(){

    int total = 0;

    Cursor c = mSqliteDatabase.rawQuery("SELECT SUM(" +DataBaseKeys.QUANTITY + ") FROM " + DataBaseKeys.TABLE_TEMP_DETAILS, null);
    if(c.moveToFirst()){
        total = c.getInt(0);
    }
    return total;
}
    //---deletes a particular Product---
    public boolean deleteProduct(String id)
    {
        return mSqliteDatabase.delete(DataBaseKeys.TABLE_TEMP_DETAILS, "PId ='" + id + "'", null) > 0;
    }

    public int deleteAll(){
        return mSqliteDatabase.delete(DataBaseKeys.TABLE_TEMP_DETAILS, null, null);
    }

    public boolean insertCartList(String P_Id,String Product_name, String Product_price, String Qty, String IsActive, String CreatedDate, String CreatedByUserId, String UpdatedDate, String UpdatedByUserId){

        ContentValues contentValues = new ContentValues();
        contentValues.put(DataBaseKeys.P_ID,P_Id);
        contentValues.put(DataBaseKeys.P_NAME,Product_name);
        contentValues.put(DataBaseKeys.P_PRICE,Product_price);
        contentValues.put(DataBaseKeys.QUANTITY,Qty);
        contentValues.put(DataBaseKeys.ISACTIVE,IsActive);
        contentValues.put(DataBaseKeys.Created_Date,CreatedDate);
        contentValues.put(DataBaseKeys.CREATEDBY_UserId,CreatedByUserId);
        contentValues.put(DataBaseKeys.Updated_date,UpdatedDate);
        contentValues.put(DataBaseKeys.Updated_By_UserId,UpdatedByUserId);

        mSqliteDatabase.insert(DataBaseKeys.TABLE_TEMP_DETAILS, null, contentValues);
        return true;

    }

    public boolean insertHeaderData(String ODId, String OrderNum, String OrderDate, String ProductId, String CustmId, String IsActive, String CreatedDate, String CreatedByUserId, String UpdatedDate, String UpdatedByUserId){

        ContentValues contentValues = new ContentValues();
        contentValues.put(DataBaseKeys.ORDER_ID,ODId);
        contentValues.put(DataBaseKeys.ORDER_NO,OrderNum);
        contentValues.put(DataBaseKeys.ORDER_DATE,OrderDate);
        contentValues.put(DataBaseKeys.ORDER_P_ID,ProductId);
        contentValues.put(DataBaseKeys.CUSTOMER_ID,CustmId);
        contentValues.put(DataBaseKeys.ISACTIVE,IsActive);
        contentValues.put(DataBaseKeys.Created_Date,CreatedDate);
        contentValues.put(DataBaseKeys.CREATEDBY_UserId,CreatedByUserId);
        contentValues.put(DataBaseKeys.Updated_date,UpdatedDate);
        contentValues.put(DataBaseKeys.Updated_By_UserId,UpdatedByUserId);

        mSqliteDatabase.insert(DataBaseKeys.TABLE_ORDER_HEADER, null, contentValues);
        return true;

    }
    public void openDatabase() {
        String dbPath = mContext.getDatabasePath(DBNAME).getPath();
        if(mSqliteDatabase != null && mSqliteDatabase.isOpen()) {
            return;
        }
        mSqliteDatabase = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    public void closeDatabase() {
        if(mSqliteDatabase!=null) {
            mSqliteDatabase.close();
        }
    }

    /*public void insertOrderDetails(OrderDetails orderDetails) {

        openDatabase();
        // ContentValues class is used to store a set of values that the ContentResolver can process.
        ContentValues contentValues = new ContentValues();

        // Get values from the POJO class and passing them to the ContentValues class
        contentValues.put(DataBaseKeys.QTY, orderDetails.getQty());
        contentValues.put(DataBaseKeys.PRICE, orderDetails.getPrice());
        contentValues.put(DataBaseKeys.DISCOUNT,orderDetails.getDiscount());
        contentValues.put(DataBaseKeys.Created_Date,orderDetails.getCreatedDate());
        contentValues.put(DataBaseKeys.CREATEDBY_UserId,orderDetails.getCreatedByUserId());
        contentValues.put(DataBaseKeys.Updated_date,orderDetails.getUpdatedDate());
        contentValues.put(DataBaseKeys.Updated_By_UserId,orderDetails.getUpdatedByUserId());
        contentValues.put(DataBaseKeys.ISACTIVE,orderDetails.getIsActive());
        // Now we can insert the data in to relevant table
        // I am going pass the id value, which is going to change because of our insert method, to a long variable to show in Toast
        long orderdetails = mSqliteDatabase.insert(DataBaseKeys.TABLE_ORDER_DETAILS, null, contentValues);
       Log.v("Orderdetails","Order_Details_data"+orderdetails);
        // It is a good practice to close the database connections after you have done with it
        closeDatabase();

    }*/
}
