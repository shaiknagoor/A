package com.example.lenovo.retail;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

/**
 * Created by Lenovo on 9/18/2017.
 */

public class VegetableFragmentOne extends Fragment {
    private static final String Log_TAG = VegetableFragment.class.getSimpleName();
    private ListView lvVegetableProduct;
    private UpdateUiListener updateUiListener;
    private ListProductAdapter adapter;
    private List<Product> mProductList;
    private DataAcceshandler mDBHelper = null;
    private DatabaseHelper databaseHelper;
    private View rootView;
    private Context mContext;
    private ActionBar actionBar;
    public void setUpdateUiListener(UpdateUiListener updateUiListener) {
        this.updateUiListener = updateUiListener;
    }

    public VegetableFragmentOne(){

        //Required defualt constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.vegetable_fragment_one,container,false);
        getActivity().setTitle("Vegetables");
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mContext = getActivity();


        /*Toolbar toolbar = (Toolbar) rootView.findViewById(R.id.toolbar);
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.setSupportActionBar(toolbar);
        actionBar = activity.getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Vegetables");*/


        lvVegetableProduct = (ListView) rootView.findViewById(R.id.listview_vegetable_one);
        mDBHelper = new DataAcceshandler(getActivity());
        databaseHelper = new DatabaseHelper(getActivity());
        loadDataBase();
        return rootView;
    }

    private void loadDataBase() {
        Constants.CARTVALUE = String.valueOf(databaseHelper.getProductsCount());

        //Get product list in db when db exists
        mProductList = mDBHelper.getListProduct();
        //Init adapter
        adapter = new ListProductAdapter(getActivity(), mProductList);
        //Set adapter for listview
        lvVegetableProduct.setAdapter(adapter);




    }
/*
    private boolean copyDatabase(Context context) {
        try {

            InputStream inputStream = context.getAssets().open(DatabaseHelper.DBNAME);
            String outFileName = DatabaseHelper.DBLOCATION + DatabaseHelper.DBNAME;
            OutputStream outputStream = new FileOutputStream(outFileName);
            byte[]buff = new byte[1024];
            int length = 0;
            while ((length = inputStream.read(buff)) > 0) {
                outputStream.write(buff, 0, length);
            }
            outputStream.flush();
            outputStream.close();
            Log.w("Vegitable","DB copied");
            return true;
        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }*/

    public void setUpdateUiListener(AdapterView.OnItemClickListener onItemClickListener) {

    }
}
