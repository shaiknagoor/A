package com.example.lenovo.retail;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Stampit-PC1 on 8/16/2017.
 */

public class OrderHeader implements Parcelable{
    private  int OHId;
    private  int ODId;
    private String OrderNumber;
    private String OrderDate;
    private int ProductId;
    private int CustomerId;
    private int CreatedByUserId;
    private  String CreatedDate;
    private  int UpdatedByUserId;
    private  String UpdatedDate;
    private int IsActive;

    public OrderHeader() {

    }


    public int getOHId() {
        return OHId;
    }

    public void setOHId(int OHId) {
        this.OHId = OHId;
    }
    public int getODId() {
        return ODId;
    }

    public void setODId(int ODId) {
        this.ODId = ODId;
    }

    public String getOrderNumber() {
        return OrderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        OrderNumber = orderNumber;
    }

    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String orderDate) {
        OrderDate = orderDate;
    }

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int productId) {
        ProductId = productId;
    }

    public int getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }

    public int getCreatedByUserId() {
        return CreatedByUserId;
    }

    public void setCreatedByUserId(int createdByUserId) {
        CreatedByUserId = createdByUserId;
    }

    public String getCreatedDate() {
        return CreatedDate;
    }

    public void setCreatedDate(String createdDate) {
        CreatedDate = createdDate;
    }

    public int getUpdatedByUserId() {
        return UpdatedByUserId;
    }

    public void setUpdatedByUserId(int updatedByUserId) {
        UpdatedByUserId = updatedByUserId;
    }

    public String getUpdatedDate() {
        return UpdatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        UpdatedDate = updatedDate;
    }

    public int getIsActive() {
        return IsActive;
    }

    public void setIsActive(int isActive) {
        IsActive = isActive;
    }

    protected OrderHeader(Parcel in) {
        OHId = in.readInt();
        ODId = in.readInt();
        OrderNumber = in.readString();
        OrderDate = in.readString();
        ProductId = in.readInt();
        CustomerId = in.readInt();
        CreatedByUserId = in.readInt();
        CreatedDate = in.readString();
        UpdatedByUserId = in.readInt();
        UpdatedDate = in.readString();
        IsActive = in.readInt();
    }

    public static final Creator<OrderHeader> CREATOR = new Creator<OrderHeader>() {
        @Override
        public OrderHeader createFromParcel(Parcel in) {
            return new OrderHeader(in);
        }

        @Override
        public OrderHeader[] newArray(int size) {
            return new OrderHeader[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(OHId);
        dest.writeInt(ODId);
        dest.writeString(OrderNumber);
        dest.writeString(OrderDate);
        dest.writeInt(ProductId);
        dest.writeInt(CustomerId);
        dest.writeInt(CreatedByUserId);
        dest.writeString(CreatedDate);
        dest.writeInt(UpdatedByUserId);
        dest.writeString(UpdatedDate);
        dest.writeInt(IsActive);
    }
}
