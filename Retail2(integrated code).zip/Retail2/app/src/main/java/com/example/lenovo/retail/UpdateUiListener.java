package com.example.lenovo.retail;

/**
 * Created by siva on 20/04/17.
 */

public interface UpdateUiListener {
    public void updateUserInterface(int refreshPosition);
}
