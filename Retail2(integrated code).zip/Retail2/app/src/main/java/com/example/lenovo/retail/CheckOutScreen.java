package com.example.lenovo.retail;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CheckOutScreen extends RetailBaseActivity {


    private static final String TAG = CheckOutScreen.class.getSimpleName();

    private RecyclerView checkRecyclerView;

    private TextView subTotal;
    private ActionBar actionBar;

    private List<CartObject> mCartListData;
    private DataAcceshandler mDBHelper = null;

    private double mSubTotal = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out_screen);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        subTotal = (TextView)findViewById(R.id.sub_total);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar=this.getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("CheckOut screen");



        checkRecyclerView = (RecyclerView)findViewById(R.id.checkout_list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(CheckOutScreen.this);
        checkRecyclerView.setLayoutManager(linearLayoutManager);
        checkRecyclerView.setHasFixedSize(true);
        checkRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(CheckOutScreen.this));


        mDBHelper = new DataAcceshandler(this);

        mCartListData = mDBHelper.getCartList();

        CheckRecyclerViewAdapter mAdapter = new CheckRecyclerViewAdapter(CheckOutScreen.this, mCartListData);
        checkRecyclerView.setAdapter(mAdapter);

        mSubTotal = getTotalPrice(mCartListData);
        subTotal.setText("Total excluding tax and shipping: " + String.valueOf(mSubTotal) + "Rs");


        Button shoppingButton = (Button)findViewById(R.id.shopping);
        assert shoppingButton != null;
        shoppingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shoppingIntent = new Intent(CheckOutScreen.this, HomeScreen.class);
                startActivity(shoppingIntent);
            }
        });

        Button checkButton = (Button)findViewById(R.id.checkout);
        assert checkButton != null;
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent paymentIntent = new Intent(CheckOutScreen.this, PaymentScreen.class);
                Bundle b=new Bundle();
             b.putString("TOTAL_PRICE", String.valueOf(mSubTotal));
               // paymentIntent.putExtra("TOTAL_PRICE", mSubTotal);
                paymentIntent.putExtras(b);
                startActivity(paymentIntent);
            }
        });

    }

    @Override
    public void Initialize() {

    }

    private List<Product> convertObjectArrayToListObject(Product[] allProducts){
        List<Product> mProduct = new ArrayList<Product>();
        Collections.addAll(mProduct, allProducts);
        return mProduct;
    }

    private double getTotalPrice(List<CartObject> mProducts){
        double totalCost = 0;
        int p_id ;
        String P_name;
        for(int i = 0; i < mProducts.size(); i++){
            CartObject pObject = mProducts.get(i);
            p_id = pObject.getQty();
            P_name = pObject.getProduct_name();
            totalCost = totalCost +( pObject.getProduct_price())*( pObject.getQty());
//            Toast.makeText(this,"item count value"+p_id,Toast.LENGTH_LONG).show();
        }
        return totalCost;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
