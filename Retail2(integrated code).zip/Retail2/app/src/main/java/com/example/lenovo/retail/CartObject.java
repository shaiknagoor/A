package com.example.lenovo.retail;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by baliReddy on 9/15/2017.
 */

public class CartObject implements Parcelable {
    public int qty;
    public  String product_name;
    public  Float product_price;
    public  int id;

    public CartObject(int qty,String product_name,Float product_price){

        this.qty = qty;
        this.product_name = product_name;
        this.product_price = product_price;
    }

    public CartObject() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public Float getProduct_price() {
        return product_price;
    }

    public void setProduct_price(Float product_price) {
        this.product_price = product_price;
    }

    protected CartObject(Parcel in) {
        id = in.readInt();
        qty = in.readInt();
        product_name = in.readString();
        product_price = in.readFloat();
    }

    public static final Creator<CartObject> CREATOR = new Creator<CartObject>() {
        @Override
        public CartObject createFromParcel(Parcel in) {
            return new CartObject(in);
        }

        @Override
        public CartObject[] newArray(int size) {
            return new CartObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(qty);
        dest.writeString(product_name);
        dest.writeFloat(product_price);
    }
}
