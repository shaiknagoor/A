package com.example.lenovo.retail;

/**
 * Created by Stampit-PC1 on 8/28/2017.
 */

public interface DrawerLocker {

    public void setDrawerEnabled(boolean enabled);
}
