package com.example.lenovo.retail;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Lenovo on 7/10/2017.
 */

public class ListProductAdapter extends BaseAdapter {
    private Context mContext;
    private List<Product> mProductList;
    private Product mproduct;
    private String itemcount_str,price,Discount,ProductId,UpdatedDate,CreatedDate,IsActive,UpdatedByUserId,CreatedByUserId;
    public TextView productName,tvPrice,tvDescription,add_item,remove_item;
    public ImageView produceImage;
    private RelativeLayout relativeLayout;

    private MySharedPreference sharedPreference;
    private DatabaseHelper dbHelper;


//    private Product product;

    private final String imageInSD = "/sdcard/RetailDatabase/Amul.jpg";
    public int i;

    public ListProductAdapter(Context mContext, List<Product> mProductList) {
        this.mContext = mContext;
        this.mProductList = mProductList;

    }

    @Override
    public int getCount() {
//        notifyDataSetChanged();
        return mProductList.size();

    }

    @Override
    public Object getItem(int position) {
        return mProductList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mProductList.get(position).getId();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View v = View.inflate(mContext, R.layout.item_listview, null);
        productName = (TextView)v.findViewById(R.id.tv_product_name);
        tvPrice = (TextView)v.findViewById(R.id.tv_product_price);
        tvDescription = (TextView)v.findViewById(R.id.tv_product_description);
        add_item = (TextView) v.findViewById(R.id.add_item);
        remove_item = (TextView) v.findViewById(R.id.remove_item);
        relativeLayout = (RelativeLayout) v.findViewById(R.id.top_icon_detail);
       final TextView Qty = (TextView) v.findViewById(R.id.Qty);
        produceImage = (ImageView) v.findViewById(R.id.product_image);
        productName.setText(mProductList.get(position).getName());
        tvDescription.setText(mProductList.get(position).getDescription());
        Qty.setText(String.valueOf(mProductList.get(position).getQty()));

        IsActive="1";
        CreatedByUserId="1";
        UpdatedByUserId="1";
        CreatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
        UpdatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
//        sharedPreference = new MySharedPreference(v.getContext());
        dbHelper = new DatabaseHelper(v.getContext());

        final Product singleProduct = mProductList.get(position);

        productName.setText(singleProduct.getName());
        produceImage.setImageResource(singleProduct.getProductPhoto());
        assert add_item != null;

        final int[] CartProductNumber = {mProductList.get(position).getQty()};

        add_item.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick( View v) {

                GsonBuilder builder = new GsonBuilder();
                Gson gson = builder.create();

                String stringObjectRepresentation = gson.toJson(singleProduct);
                final Product singleproduct = gson.fromJson(stringObjectRepresentation, Product.class);
//                Toast.makeText(v.getContext(), "cart count++ value"+ singleproduct.getName()+"-"+singleproduct.getPrice()+"-"+singleproduct.getId(), Toast.LENGTH_SHORT).show();
                if (CartProductNumber[0]<25)
                    CartProductNumber[0]++;
                Qty.setText(String.valueOf(CartProductNumber[0]));
                itemcount_str = Qty.getText().toString();

                if (CartProductNumber[0] == 1){
                    dbHelper.insertCartList(String.valueOf(singleproduct.getId()),singleproduct.getName(), String.valueOf(singleproduct.getPrice()),itemcount_str,IsActive, CreatedDate, CreatedByUserId, UpdatedDate, UpdatedByUserId);
                    Constants.CARTVALUE = String.valueOf(dbHelper.getProductsCount());

                }else {

                    dbHelper.update_cartList(itemcount_str, String.valueOf(singleproduct.getId()));
                    dbHelper.update_ProductTable(itemcount_str, String.valueOf(singleproduct.getId()));
                    Constants.CARTVALUE = String.valueOf(dbHelper.getProductsCount());

//   Toast.makeText(v.getContext(),"update the table"+singleproduct.getId(),Toast.LENGTH_SHORT).show();
                }

                Constants.CARTVALUE = String.valueOf(dbHelper.getProductsCount());

   }


        });

        remove_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                GsonBuilder builder = new GsonBuilder();
                Gson gson = builder.create();

                String stringObjectRepresentation = gson.toJson(singleProduct);
                final Product singleproduct = gson.fromJson(stringObjectRepresentation, Product.class);

                if (CartProductNumber[0]>0)
                    CartProductNumber[0]--;
                Qty.setText(String.valueOf(CartProductNumber[0]));
                itemcount_str = Qty.getText().toString().trim();
                if (CartProductNumber[0] == 0){
                    dbHelper.deleteProduct(String.valueOf(singleproduct.getId()));
                    Constants.CARTVALUE = String.valueOf(dbHelper.getProductsCount());

//                    Toast.makeText(v.getContext(),"delete the table"+singleproduct.getId(),Toast.LENGTH_SHORT).show();
                }else {
                    dbHelper.update_cartList(itemcount_str, String.valueOf(singleproduct.getId()));
                    dbHelper.update_ProductTable(itemcount_str, String.valueOf(singleproduct.getId()));
//                    Toast.makeText(v.getContext(),"updatetable for -"+singleproduct.getId(),Toast.LENGTH_SHORT).show();

                }



            }

        });



        for (i = 0;i<imageInSD.length();i++){
//            Toast.makeText(this,"Total Images+"imageInSD.length(),Toast.LENGTH_LONG).show();
            Bitmap bitmap = BitmapFactory.decodeFile(imageInSD);
            produceImage.setImageBitmap(bitmap);
        }



        tvPrice.setText("Rs:"+String.valueOf(mProductList.get(position).getPrice()) );
//        final String imageUrl = CommonUtills.getImageUrl(mProductList.get(position));
        final String imageUrl = "https://api.learn2crack.com/android/images/donut.png";
//                                  "https://api.learn2crack.com/android/images/kitkat.png",
//                                   "https://api.learn2crack.com/android/images/lollipop.png";


        Picasso.with(mContext)
                .load(imageUrl)
                .networkPolicy(NetworkPolicy.OFFLINE)
                .into(produceImage, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {
                        //Try again online if cache failed
                        Picasso.with(mContext)
                                .load(imageUrl)
                                .error(R.mipmap.ic_launcher)
                                .into(produceImage, new Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override

                                    public void onError() {
                                        Log.v("Picasso", "Could not fetch image");
//                                        if (!TextUtils.isEmpty(mProductList.get(position).getPhotoLocation())) {
//                                            loadImageFromStorage(mProductList.get(position).getPhotoLocation(), produceImage);
//                                        }
                                    }
                                });
                    }
                });


        return v;
    }



/*
    private List<Product> convertObjectArrayToListObject(Product[] allProducts){
        List<Product> mProduct = new ArrayList<Product>();
        Collections.addAll(mProduct, allProducts);
        return mProduct;
    }*/

    private void loadImageFromStorage(String path, ImageView productImage) {

        try {
            File f = new File(path);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            if (null != b) {
                productImage.setImageBitmap(b);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}