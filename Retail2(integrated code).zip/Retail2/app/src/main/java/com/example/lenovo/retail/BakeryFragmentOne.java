package com.example.lenovo.retail;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

/**
 * Created by Lenovo on 9/18/2017.
 */

public class BakeryFragmentOne extends Fragment {
    private static final String TAG = BakeryFragment.class.getSimpleName();
    private ListView lvBakeryProduct;
    private UpdateUiListener updateUiListener;
    private ListProductAdapter adapter;
    private List<Product> mProductList;
    private DataAcceshandler mDBHelper = null;
    private DatabaseHelper databaseHelper;
    private View rootView;
    private Context mContext;
    private ActionBar actionBar;
    public void setUpdateUiListener(UpdateUiListener updateUiListener) {
        this.updateUiListener = updateUiListener;
    }

    public BakeryFragmentOne(){

        //Required defualt constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.vegetable_fragment_one,container,false);
       getActivity().setTitle("Bakery And Diary");
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mContext = getActivity();



        lvBakeryProduct = (ListView) rootView.findViewById(R.id.listview_vegetable_one);
        mDBHelper = new DataAcceshandler(getActivity());
        databaseHelper = new DatabaseHelper(getActivity());
        loadDataBase();
        return rootView;
    }

    private void loadDataBase() {


        Constants.CARTVALUE = String.valueOf(databaseHelper.getProductsCount());
        //Get product list in db when db exists
        mProductList = mDBHelper.getBakeryProduct();
        //Init adapter
        adapter = new ListProductAdapter(getActivity(), mProductList);
        //Set adapter for listview
        lvBakeryProduct.setAdapter(adapter);
    }


    public void setUpdateUiListener(AdapterView.OnItemClickListener onItemClickListener) {
    }
}
