package com.example.lenovo.retail;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by Stampit-PC1 on 8/28/2017.
 */

public class ProfileScreenfragment extends Fragment {

    private static final String Log_TAG = ProfileScreenfragment.class.getSimpleName();

    private UpdateUiListener updateUiListener;
    private DataAcceshandler mDBHelper = null;
    private View rootView;
    private Context mContext;
    private User user;
    private ActionBar actionBar;
    TextView userName,mobileNum;
    public void setUpdateUiListener(UpdateUiListener updateUiListener) {
        this.updateUiListener = updateUiListener;
    }

    public ProfileScreenfragment(){

        //Required defualt constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.profile_screen_fragment,container,false);
        userName=(TextView)rootView.findViewById(R.id.nameTv2);
        mobileNum=(TextView)rootView.findViewById(R.id.MobileNoTv2);
        userName.setText(Constants.USER_NAME);
       mobileNum.setText(String.valueOf(user.getMobileNo()));



        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mContext = getActivity();

        return rootView;
    }



}
