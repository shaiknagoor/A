package com.example.lenovo.retail;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.util.List;

import static android.R.id.toggle;

public class HomeScreen extends RetailBaseActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public static final String LOG_TAG = HomeScreen.class.getName();
    private VegetableFragment vegetableFragment;
    private BakeryFragment bakeryFragment;
    private BaveragesFragment baveragesFragment;
    private PersonalCareFragment personalCareFragment;
    private HouseholdFragment householdFragment;
    private ListView listItemView;
    private ListCatagoryAdapter adapter;
    private List<Catagory> mCatagoryList;
    private List<User> mUser;
    private DataAcceshandler mDBHelper = null ;
    private DatabaseHelper databaseHelper;

    private Product mProduct;

    private SharedPreferences prefs;

    private Context context;
    private ViewFlipper viewFlipper;

    private MySharedPreference sharedPreference;
    private TextView user_name,user_email;
    private String userName;
    int mCount;

    int sum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        userName = getIntent().getStringExtra("USERNAME");
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header=navigationView.getHeaderView(0);
/*View view=navigationView.inflateHeaderView(R.layout.nav_header_main);*/
        user_name = (TextView)header.findViewById(R.id.User_name);
//        user_email = (TextView)header.findViewById(R.id.User_email);
        user_name.setText(userName);
        Constants.USER_NAME = userName;

//        user_email.setText("balireddy@stampit.biz");

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        viewFlipper=(ViewFlipper)findViewById(R.id.ViewFlip);
        int[] images={R.drawable.seed1,R.drawable.sesame,R.drawable.mothbean,R.drawable.nuts,R.drawable.seedshand,R.drawable.sapota,R.drawable.images};

        sharedPreference = new MySharedPreference(HomeScreen.this);
        mDBHelper = new DataAcceshandler(this);
        databaseHelper = new DatabaseHelper(this);
        listItemView = (ListView) findViewById(R.id.listview_catagory);

        // loop for creating ImageView's
        for (int i = 0; i < images.length; i++) {
            // create the object of ImageView
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(images[i]); // set image in ImageView
            viewFlipper.addView(imageView); // add the created ImageView in ViewFlipper
        }
        Animation in = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        Animation out = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
        // set the animation type's to ViewFlipper
        viewFlipper.setInAnimation(in);
        viewFlipper.setOutAnimation(out);
        // set interval time for flipping between views
        viewFlipper.setFlipInterval(3000);
        // set auto start for flipping between views
        viewFlipper.setAutoStart(true);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        loadDataBase();

    }

    @Override
    public void Initialize() {

    }




    private void loadDataBase() {

        sum = databaseHelper.getProductsCount();
        Constants.CARTVALUE = String.valueOf(databaseHelper.getProductsCount());
        //Get product list in db when db exists
        mCatagoryList = mDBHelper.getListCatagory();
//       mUser = mDBHelper.getUserDetails(Constants.USER_NAME);
        //Init adapter
        adapter = new ListCatagoryAdapter(this, mCatagoryList);
        //Set adapter for listview
        listItemView.setAdapter(adapter);



        // ListView setOnItemClickListener function apply here.

        listItemView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // TODO Auto-generated method stub
//


                if (position == 0) {
                    vegetableFragment= new VegetableFragment();
                    vegetableFragment.setUpdateUiListener(this);
                    replaceFragment(vegetableFragment);
                } else if (position == 1) {
                    bakeryFragment= new BakeryFragment();
                    bakeryFragment.setUpdateUiListener(this);
                    replaceFragment(bakeryFragment);
                }
                else if (position == 2) {
                    baveragesFragment= new BaveragesFragment();
                    baveragesFragment.setUpdateUiListener(this);
                    replaceFragment(baveragesFragment);
                }
                else if (position == 3) {
                    personalCareFragment= new PersonalCareFragment();
                    personalCareFragment.setUpdateUiListener(this);
                    replaceFragment(personalCareFragment);
                }
                else if (position == 4) {
                    householdFragment= new HouseholdFragment();
                    householdFragment.setUpdateUiListener(this);
                    replaceFragment(householdFragment);
                }

            }
        });

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_screen, menu);
        MenuItem menuItem = menu.findItem(R.id.action_shop);

         mCount = Integer.parseInt(Constants.CARTVALUE);
        menuItem.setIcon(buildCounterDrawable(mCount, R.drawable.ic_shopping_cart_black_24dp));
    Log.v(LOG_TAG,"mCount"+mCount);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if (id == R.id.action_shop) {
            if (mCount == 0){
//                Toast.makeText(this,"Your Cart is Empty",Toast.LENGTH_SHORT).show();
                Intent emptyIntent = new Intent(getApplicationContext(), CheckOutScreen.class);
                startActivity(emptyIntent);
                return true;
            }else {

                Intent checkoutIntent = new Intent(getApplicationContext(), CheckOutScreen.class);
                startActivity(checkoutIntent);
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private Drawable buildCounterDrawable(int count, int backgroundImageId) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.shopping_layout, null);
        view.setBackgroundResource(backgroundImageId);

        if (count == 0) {
            View counterTextPanel = view.findViewById(R.id.counterValuePanel);
            counterTextPanel.setVisibility(View.GONE);
        } else {
            TextView textView = (TextView) view.findViewById(R.id.count);
            textView.setText("" + count);
        }

        view.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());

        view.setDrawingCacheEnabled(true);
        view.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        return new BitmapDrawable(getResources(),bitmap);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.home) {

            Intent intent=new Intent(getApplicationContext(),HomeScreen.class);
            intent.putExtra("USERNAME", Constants.USER_NAME);
            startActivity(intent);
        } else if (id == R.id.vegetable) {
            setTile("Vegitables");
            VegetableFragmentOne vegetableFragment = new VegetableFragmentOne();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame,vegetableFragment)
                    .commit();

        } else if (id == R.id.bakery) {
            BakeryFragmentOne bakeryFragment = new BakeryFragmentOne();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame,bakeryFragment)
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.beverages) {
       BaveragesFragmentOne baveragesFragment = new BaveragesFragmentOne();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame,baveragesFragment)
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.personalCare) {
            PersonalCareFragmentOne personalCareFragment = new PersonalCareFragmentOne();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame,personalCareFragment)
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.household) {
            HouseholdFragmentOne householdFragment = new HouseholdFragmentOne();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame,householdFragment)
                    .addToBackStack(null)
                    .commit();

        }
        else if (id == R.id.View_your_Profile)
        {
//            Intent logout = new Intent(this,CheckOutScreen.class);
//            startActivity(logout);
            ProfileScreenfragment profileFragment = new ProfileScreenfragment();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame,profileFragment)
                    .addToBackStack(null)
                    .commit();
//            Intent profile = new Intent(this,ProfileScreenfragment.class);
//            startActivity(profile);

        }
        else if (id == R.id.log_out)
        {
           Intent logout = new Intent(this,LoginScreen.class);
            startActivity(logout);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



}
