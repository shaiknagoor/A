package com.example.lenovo.retail;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Stampit-PC1 on 8/16/2017.
 */

public class OrderDetails implements Parcelable{
    private int ODId;
    private int OHId;
    private int ProductId;
    private int Qty;
    private int price;
    private int Discount;
    private int CreatedByUserId;
    private  String CreatedDate;
    private  int UpdatedByUserId;
    private  String UpdatedDate;
    private int IsActive;

    public OrderDetails() {

    }

    public int getODId() {
        return ODId;
    }

    public void setODId(int ODId) {
        this.ODId = ODId;
    }

    public int getOHId() {
        return OHId;
    }

    public void setOHId(int OHId) {
        this.OHId = OHId;
    }

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int productId) {
        ProductId = productId;
    }

    public int getQty() {
        return Qty;
    }

    public void setQty(int qty) {
        Qty = qty;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getDiscount() {
        return Discount;
    }

    public void setDiscount(int discount) {
        Discount = discount;
    }

    public int getCreatedByUserId() {
        return CreatedByUserId;
    }

    public void setCreatedByUserId(int createdByUserId) {
        CreatedByUserId = createdByUserId;
    }

    public String getCreatedDate() {
        return CreatedDate;
    }

    public void setCreatedDate(String createdDate) {
        CreatedDate = createdDate;
    }

    public int getUpdatedByUserId() {
        return UpdatedByUserId;
    }

    public void setUpdatedByUserId(int updatedByUserId) {
        UpdatedByUserId = updatedByUserId;
    }

    public String getUpdatedDate() {
        return UpdatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        UpdatedDate = updatedDate;
    }

    public int getIsActive() {
        return IsActive;
    }

    public void setIsActive(int isActive) {
        IsActive = isActive;
    }


    protected OrderDetails(Parcel in) {
        ODId = in.readInt();
        OHId = in.readInt();
        ProductId = in.readInt();
        Qty = in.readInt();
        price = in.readInt();
        Discount = in.readInt();
        CreatedByUserId = in.readInt();
        CreatedDate = in.readString();
        UpdatedByUserId = in.readInt();
        UpdatedDate = in.readString();
        IsActive = in.readInt();
    }

    public static final Creator<OrderDetails> CREATOR = new Creator<OrderDetails>() {
        @Override
        public OrderDetails createFromParcel(Parcel in) {
            return new OrderDetails(in);
        }

        @Override
        public OrderDetails[] newArray(int size) {
            return new OrderDetails[size];
        }
    };



    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(ODId);
        dest.writeInt(OHId);
        dest.writeInt(ProductId);
        dest.writeInt(Qty);
        dest.writeInt(price);
        dest.writeInt(Discount);
        dest.writeInt(CreatedByUserId);
        dest.writeString(CreatedDate);
        dest.writeInt(UpdatedByUserId);
        dest.writeString(UpdatedDate);
        dest.writeInt(IsActive);
    }
}
