package com.example.lenovo.retail;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProductScreen extends RetailBaseActivity {

    private static final String TAG = ProductScreen.class.getSimpleName();

    private TextView productName, productColor, productPrice, productDescription;

    private ImageView productImage;

    private Gson gson;

    private int cartProductNumber = 0;



    private MySharedPreference sharedPreference;
    private ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_screen);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        sharedPreference = new MySharedPreference(ProductScreen.this);

        productImage = (ImageView)findViewById(R.id.full_product_image);
//        productSize = (TextView)findViewById(R.id.product_size);
        productName = (TextView)findViewById(R.id.product_name);
        productPrice = (TextView)findViewById(R.id.product_price);
        productDescription = (TextView)findViewById(R.id.product_description);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = this.getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Product Screen");

        CommonUtills.currentActivity = this;
        GsonBuilder builder = new GsonBuilder();
        gson = builder.create();

        String productInStringFormat = getIntent().getExtras().getString("PRODUCT");
        final Product singleProduct = gson.fromJson(productInStringFormat, Product.class);
        if(singleProduct != null){
            setTitle(singleProduct.getName());

            productImage.setImageResource(singleProduct.getProductPhoto());
//            productSize.setText("Quantity: " + String.valueOf(singleProduct.getItemCount()));
            productName.setText("Name: " + String.valueOf(singleProduct.getName()));
            productPrice.setText("Price: " + String.valueOf(new Double(singleProduct.getPrice()).intValue()) + " Rs");
            productDescription.setText(Html.fromHtml("<strong>Product Description</strong><br/>" + singleProduct.getDescription()));

            Button addToCartButton = (Button)findViewById(R.id.add_to_cart);
            assert addToCartButton != null;
            addToCartButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //increase product count
                    String productsFromCart = sharedPreference.retrieveProductFromCart();
                    if(productsFromCart.equals("")){
                        List<Product> cartProductList = new ArrayList<Product>();
                        cartProductList.add(singleProduct);
                        String cartValue = gson.toJson(cartProductList);
                        sharedPreference.addProductToTheCart(cartValue);
                        cartProductNumber = cartProductList.size();
                    }else{
                        String productsInCart = sharedPreference.retrieveProductFromCart();
                        Product[] storedProducts = gson.fromJson(productsInCart, Product[].class);

                        List<Product> allNewProduct = convertObjectArrayToListObject(storedProducts);
                        allNewProduct.add(singleProduct);
                        String addAndStoreNewProduct = gson.toJson(allNewProduct);
                        sharedPreference.addProductToTheCart(addAndStoreNewProduct);
                        cartProductNumber = allNewProduct.size();
                    }
                    sharedPreference.addProductCount(cartProductNumber);
                    invalidateCart();
                }
            });
        }
    }

    @Override
    public void Initialize() {

    }



    private List<Product> convertObjectArrayToListObject(Product[] allProducts){
        List<Product> mProduct = new ArrayList<Product>();
        Collections.addAll(mProduct, allProducts);
        return mProduct;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_screen, menu);
        MenuItem menuItem = menu.findItem(R.id.action_shop);
        int mCount = sharedPreference.retrieveProductCount();
        menuItem.setIcon(buildCounterDrawable(mCount, R.drawable.ic_shopping_cart_black_24dp));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();



        if (id == R.id.action_shop) {
            Intent checkoutIntent = new Intent(ProductScreen.this, CheckOutScreen.class);
            startActivity(checkoutIntent);
            return true;
        }

//        if (id == android.R.id.home) {
//            onBackPressed();
//        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private Drawable buildCounterDrawable(int count, int backgroundImageId) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.shopping_layout, null);
        view.setBackgroundResource(backgroundImageId);

        if (count == 0) {
            View counterTextPanel = view.findViewById(R.id.counterValuePanel);
            counterTextPanel.setVisibility(View.GONE);
        } else {
            TextView textView = (TextView) view.findViewById(R.id.count);
            textView.setText("" + count);
        }

        view.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());

        view.setDrawingCacheEnabled(true);
        view.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);

        return new BitmapDrawable(getResources(), bitmap);
    }

    private void invalidateCart() {
        invalidateOptionsMenu();
    }

}
