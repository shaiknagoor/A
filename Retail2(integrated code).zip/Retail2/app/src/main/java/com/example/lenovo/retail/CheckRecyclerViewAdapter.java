package com.example.lenovo.retail;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by BaliReddy on 8/19/2017.
 */

public class CheckRecyclerViewAdapter extends RecyclerView.Adapter<CheckRecyclerViewAdapter.MyHolder>{



    private Context context;

    private List<CartObject> mCartObject;
    int qty ;
    Float product_price ;
    private DatabaseHelper dbHelper;
    private String itemcount_str,UpdatedDate,CreatedDate,IsActive,UpdatedByUserId,CreatedByUserId;


    public CheckRecyclerViewAdapter(Context context, List<CartObject> mCartObject) {
        this.context = context;
        this.mCartObject = mCartObject;
    }

    @Override
    public CheckRecyclerViewAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.check_layout, parent, false);
        MyHolder productHolder = new MyHolder(layoutView);
        return productHolder;
    }

    @Override
    public void onBindViewHolder(final CheckRecyclerViewAdapter.MyHolder holder, final int position) {

        product_price = (mCartObject.get(position).getProduct_price())* (mCartObject.get(position).getQty());
//
        holder.quantity.setText(String.valueOf(mCartObject.get(position).getQty()));
        holder.productName.setText(mCartObject.get(position).getProduct_name());
         holder.productPrice.setText(mCartObject.get(position).getProduct_price() + " RS/-");
        holder.Qty.setText(String.valueOf(mCartObject.get(position).getQty()));

        IsActive="1";
        CreatedByUserId="1";
        UpdatedByUserId="1";
        CreatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
        UpdatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
//        sharedPreference = new MySharedPreference(v.getContext());
        dbHelper = new DatabaseHelper(context);
        final CartObject singleCartProduct = mCartObject.get(position);

//        productName.setText(singleProduct.getName());
//        produceImage.setImageResource(singleProduct.getProductPhoto());
        assert holder.addProduct != null;

        final int[] CartProductNumber = {mCartObject.get(position).getQty()};

        holder.addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                GsonBuilder builder = new GsonBuilder();
                Gson gson = builder.create();

                String stringObjectRepresentation = gson.toJson(singleCartProduct);
                final CartObject singleCart_product = gson.fromJson(stringObjectRepresentation, CartObject.class);

                if (CartProductNumber[0]<25)
                    CartProductNumber[0]++;
               holder.Qty.setText(String.valueOf(CartProductNumber[0]));
                itemcount_str = holder.Qty.getText().toString();

                if (CartProductNumber[0] == 1){
                    dbHelper.insertCartList(String.valueOf(singleCart_product.getId()),singleCart_product.getProduct_name(), String.valueOf(singleCart_product.getProduct_price()),itemcount_str,IsActive, CreatedDate, CreatedByUserId, UpdatedDate, UpdatedByUserId);
//                    Constants.CARTVALUE = String.valueOf(dbHelper.addAllValues());
//                    Toast.makeText(context, "insert product from cart"+singleCart_product.getQty()+"incre"+qty, Toast.LENGTH_LONG).show();

                }else {

                    dbHelper.update_cartList(itemcount_str, String.valueOf(singleCart_product.getId()));
                    dbHelper.update_ProductTable(itemcount_str, String.valueOf(singleCart_product.getId()));
//                    Toast.makeText(context, "update product from cart"+singleCart_product.getQty()+"incre"+qty, Toast.LENGTH_LONG).show();

                     }

                 }
        });


        holder.removeProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GsonBuilder builder = new GsonBuilder();
                Gson gson = builder.create();

                String stringObjectRepresentation = gson.toJson(singleCartProduct);
                final CartObject singleCart_product = gson.fromJson(stringObjectRepresentation, CartObject.class);

                if (CartProductNumber[0]>0)
                    CartProductNumber[0]--;
                holder.Qty.setText(String.valueOf(CartProductNumber[0]));
                itemcount_str = holder.Qty.getText().toString().trim();
                if (CartProductNumber[0] == 0){
                    dbHelper.deleteProduct(String.valueOf(singleCart_product.getId()));
                    Constants.CARTVALUE = String.valueOf(dbHelper.getProductsCount());
//                    Toast.makeText(context, "delete product from cart"+singleCart_product.getQty()+"incre"+qty, Toast.LENGTH_LONG).show();

                }
                     else {
                    dbHelper.update_cartList(itemcount_str, String.valueOf(singleCart_product.getId()));
                    dbHelper.update_ProductTable(itemcount_str, String.valueOf(singleCart_product.getId()));
//                    Toast.makeText(context, "update product from cart"+singleCart_product.getQty()+"incre"+qty, Toast.LENGTH_LONG).show();

                }

            }
        });

    }

    @Override
    public int getItemCount() {
//        product = mProductObject.size();
        return mCartObject.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        public TextView quantity, productName, productPrice, removeProduct,addProduct,Qty;
        public MyHolder(View itemView) {
            super(itemView);


            quantity = (TextView)itemView.findViewById(R.id.quantity);
            productName =(TextView)itemView.findViewById(R.id.product_name);
            productPrice = (TextView)itemView.findViewById(R.id.product_price);
            removeProduct = (TextView) itemView.findViewById(R.id.remove_item);
            addProduct = (TextView) itemView.findViewById(R.id.add_item);
            Qty = (TextView) itemView.findViewById(R.id.Qty);
        }
    }
}
