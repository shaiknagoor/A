package com.example.lenovo.retail;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class PaymentScreen extends RetailBaseActivity implements View.OnClickListener {
    EditText EnterAmount;
    TextView pUserName,totalAmount,Refund,orderNumber;
    private String ODId,OHId,quantity,ProductId,Price,Discount,IsActive,UpdatedByUserId,CreatedByUserId,OrderNum,OrderDate,CustmId,OrderNum_str;
    Button submit;
    private DatabaseHelper dbHelper;
    int totalCount=0;
    private User user;
    private OrderDetails saveOrderDetailsData = null;
    private boolean isUpdateData = false;
    private ActionBar actionBar;
    private MySharedPreference sharedPreference;
    private DataAcceshandler mDBHelper;
    private List<CartObject> mCartListData;
    private String  ProductData;
    private String UpdatedDate,CreatedDate,EnterAmount_str,TotalAmount_str,refund_str,payamount_str;

    private  Float enterAmount_Int,totalAmount_Int,refund_Int;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_screen);

        Bundle b=getIntent().getExtras();
        totalAmount=(TextView)findViewById(R.id.TotalAmount_et2);
        EnterAmount=(EditText)findViewById(R.id.userAmount2);
        Refund=(TextView)findViewById(R.id.Change2);
        submit=(Button)findViewById(R.id.submit_B);
        pUserName=(TextView)findViewById(R.id.order_number);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar=this.getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("PaymentScreen");

        user = new User();
//        pUserName.setText(Constants.USER_NAME);
//        Toast.makeText(this,"UserId"+user.getMobileNo(),Toast.LENGTH_LONG).show();


        dbHelper = new DatabaseHelper(this);

        sharedPreference = new MySharedPreference(PaymentScreen.this);



        OrderNum_str= CommonUtills.getCurrentYear()+1234;
        pUserName.setText(Constants.USER_NAME);
        totalAmount.setText(b.getCharSequence("TOTAL_PRICE"));
        payamount_str = String.valueOf(b.getCharSequence("TOTAL_PRICE"));
        saveOrderDetailsData = (OrderDetails) DataManager.getInstance().getDataFromManager(DataManager.ORDER_DETAILS);
        if (saveOrderDetailsData != null ) {
            isUpdateData = true;

        } else {

            saveOrderDetailsData = new OrderDetails();
        }
        submit.setOnClickListener(this);

        Refund.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    EnterAmount_str=EnterAmount.getText().toString().trim();
//    TotalAmount_str=String.valueOf(totalAmount);
                    enterAmount_Int= Float.valueOf(EnterAmount_str);
                    totalAmount_Int=Float.valueOf(payamount_str);
                    refund_Int=enterAmount_Int-totalAmount_Int;
                    refund_str = String.valueOf(refund_Int);
                    Refund.setText(refund_str);
                    Log.v("Payment_Sreen","Refund money"+refund_str);
//    Toast.makeText(getApplicationContext(),"Refnd Amount: "+refund_str,Toast.LENGTH_LONG).show();
                } catch (NumberFormatException e){
                    Log.v("Payment_Sreen","Numberformate exception:"+e.getMessage().toString());
//    Toast.makeText(getApplicationContext(),"Numberformate exception: "+e.getMessage().toString(),Toast.LENGTH_LONG).show();
                }

            }
        });

        mDBHelper = new DataAcceshandler(this);

        mCartListData = mDBHelper.getCartList();

    }



    private List<Product> convertObjectArrayToListObject(Product[] allProducts) {
        List<Product> mProduct = new ArrayList<Product>();
        Collections.addAll(mProduct, allProducts);
        return mProduct;
    }

    @Override
    public void Initialize() {

    }


    @Override
    public void onClick(View v) {

        /*totalCount = sharedPreference.addOrderNum(totalCount);
        if(totalCount == -1) {
            totalCount = 0; //initialize the total count value to 0
        }
       // count += 1;
        totalCount += 1;
        int ordernumbe = sharedPreference.retriveOrderNum();
       // orderNumber.setText(ordernumbe);

       Log.v("ordernum","or"+ordernumbe);*/


        insertDataOrderData(mCartListData);
        insertDataHeaderData(mCartListData);
        try {
            Thread.sleep(10000);
            Intent paymentIntent=new Intent(getApplicationContext(),HomeScreen.class);
            //Toast.makeText(getApplicationContext(), "Welcome to Homepage ", Toast.LENGTH_SHORT).show();


            startActivity(paymentIntent);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ODId="1";
        OrderNum = OrderNum_str;
        OrderDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
        CustmId="1";
        OHId= "1";
         quantity="1";
        ProductId="2";
          Price="200";
        Discount="30";
        IsActive="1";
        CreatedByUserId="1";
        UpdatedByUserId="1";
        CreatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
        UpdatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
    }

    private void insertDataHeaderData(List<CartObject> mProducts) {
        int p_id ;
        for(int i = 0; i < mProducts.size(); i++){
            CartObject pObject = mProducts.get(i);
            dbHelper.insertHeaderData(ODId,OrderNum,OrderDate, String.valueOf(pObject.getId()),CustmId,IsActive,CreatedDate,CreatedByUserId,UpdatedDate,UpdatedByUserId);
            p_id = pObject.getId();
//            Toast.makeText(getApplicationContext(),"ProductId"+p_id,Toast.LENGTH_SHORT).show();
        }
        dbHelper.deleteAll();
//        Toast.makeText(getApplicationContext(),"datadeleted",Toast.LENGTH_SHORT).show();


    }

    private void insertDataOrderData(List<CartObject> mProducts) {
        int p_id ;
        String P_name;
        for(int i = 0; i < mProducts.size(); i++){
            CartObject pObject = mProducts.get(i);
            dbHelper.insertOrderData(OHId,String.valueOf(pObject.getId()), String.valueOf(pObject.getQty()),String.valueOf(pObject.getProduct_price()),Discount, IsActive, CreatedDate, CreatedByUserId, UpdatedDate, UpdatedByUserId);

            p_id = pObject.getId();
            P_name = pObject.getProduct_name();
//            Toast.makeText(getApplicationContext(),"Product_id"+p_id+"/"+P_name,Toast.LENGTH_SHORT).show();

        }


    }

  /*  private void saveOrderHeaderData() {
        if(dbHelper.insertHeaderData(ODId,OrderNum,OrderDate,ProductId,CustmId,IsActive,CreatedDate,CreatedByUserId,UpdatedDate,UpdatedByUserId)){
            Toast.makeText(getApplicationContext(), "Order Header Data success fully inserted ", Toast.LENGTH_SHORT).show();


        }else{
            Toast.makeText(getApplicationContext(),"Order Header Data not inserted",Toast.LENGTH_SHORT).show();
        }
        ODId="1";
        OrderNum = OrderNum_str;
        OrderDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
        ProductId="2";
        CustmId="1";
        IsActive="1";
        CreatedByUserId="1";
        UpdatedByUserId="1";
        CreatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
        UpdatedDate=CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS);
//
//        Intent home = new Intent(getApplicationContext(),HomeScreen.class);
//        startActivity(home);
//        sharedPreference.clear();
    }*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

//    private void saveOrderData() {
//
//       saveOrderDetailsData.setOHId(1);
  //   saveOrderDetailsData.setQty(10);
//        saveOrderDetailsData.setProductId(1);
//        saveOrderDetailsData.setPrice(300);
//        saveOrderDetailsData.setDiscount(3);
//        saveOrderDetailsData.setIsActive(1);
//
//        saveOrderDetailsData.setCreatedByUserId(Integer.parseInt(Constants.USER_ID));
//       saveOrderDetailsData.setCreatedDate(CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS));
//        saveOrderDetailsData.setUpdatedByUserId(Integer.parseInt(Constants.USER_ID));
//       saveOrderDetailsData.setUpdatedDate(CommonUtills.getcurrentDateTime(Constants.DATE_FORMAT_DDMMYYYY_HHMMSS));
//        DataManager.getInstance().addData(DataManager.ORDER_DETAILS, saveOrderDetailsData);
//    }
}