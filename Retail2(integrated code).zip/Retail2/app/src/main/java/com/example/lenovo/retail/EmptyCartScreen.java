package com.example.lenovo.retail;

import android.content.Context;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class EmptyCartScreen extends AppCompatActivity {


    private static final String Log_TAG = EmptyCartScreen.class.getSimpleName();

    private Context mContext;
    private ActionBar actionBar;
    private TextView empty_cart_txt;
    private ImageView empty_cart_img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty_cart_screen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar=this.getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Cart List");

        empty_cart_txt = (TextView)findViewById(R.id.empty_cart_id);
        empty_cart_img = (ImageView) findViewById(R.id.empty_img_cart);




    }

    @Override
    public boolean onNavigateUp() {
        finish();
        return true;
    }
}
