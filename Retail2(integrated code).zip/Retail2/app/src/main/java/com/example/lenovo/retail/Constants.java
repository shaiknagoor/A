package com.example.lenovo.retail;



public class Constants {

   // public static final int WALLET_ENVIRONMENT = WalletConstants.ENVIRONMENT_TEST;
    public static final String MERCHANT_NAME = "Awesome Bike Store";
    public static final String CURRENCY_CODE_USD = "USD";
    public static final String PUBLISHABLE_KEY = "key";
    public static final String VERSION = "version";

    public static final String SHARED_PREF = "shared_pref";
    public static final String PRODUCT_COUNT = "product_count";
 public static final String ITEM_Count= "item_count";
    public static final String PRODUCT_ID = "product_id";
    public static String USER_NAME="Retail";
     public static String USER_ID = "1";
    public static String ORDER_NUM ="";
    public  static  String CARTVALUE = "0";
 public static String REGISTRATION_SCREEN_FROM = "";
 public static String REGISTRATION_SCREEN_FROM_NEW_USER = "registration_screen_from_new_user";


 public static String DATE_FORMAT_DDMMYYYY = "yyyy-MM-dd";
    public static String DATE_FORMAT_DDMMYYYY_HHMMSS = "yyyy-MM-dd HH:mm:ss";
     public static String DATE_FORMAT_1 = "dd-MM-yyyy HH:mm a";

}
