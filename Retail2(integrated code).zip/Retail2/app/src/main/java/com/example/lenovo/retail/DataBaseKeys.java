package com.example.lenovo.retail;

/**
 * Created by Stampit-PC1 on 8/9/2017.
 */

public class DataBaseKeys {

    public static String TABLE_User = "User";
    public static String TABLE_ADDRESS = "Address";

    public static String TABLE_ORDER_HEADER = "OrderHeader";
    public  static String TABLE_PRODUCT="Product";
    public  static String TABLE_CATAGORY="Catagory";


    public static final String TABLE_ORDER_DETAILS = "OrderDetails";
    public static final String ORDER_NO="OrderNum";
    public static final String ORDER_DATE="OrderDate";
    public static final String ORDER_ID = "ODId";
    public static final String  CUSTOMER_ID= "CustmId";
    public static final String ORDER_H_ID = "OHId";
    public static final String QTY = "Qty";
    public static final String ORDER_P_ID ="ProductId";
    public static final String PRICE = "Price";
    public static final String DISCOUNT = "Discount";
    public static final String CREATEDBY_UserId = "CreatedByUserId";
    public static final String Created_Date = "CreatedDate";
    public static final String Updated_By_UserId = "UpdatedByUserId";
    public static final String Updated_date = "UpdatedDate";
    public static final String ISACTIVE = "IsActive";

    public static final  String TABLE_USER_DETAILS = "User";
    public static final String UName="UName";
    public static final String Password="Password";
    public static final String ConformPassword = "ConformPassword";
    public static final String  UEmail= "UEmail";
    public static final String MobileNo = "MobileNo";

    public static final  String TABLE_PRODUCT_DETAILS = "Product";
    public static final  String TABLE_TEMP_DETAILS = "Temperary";
    public static final String P_ID="PId";
    public static final String P_NAME="PName";
    public static final String P_PRICE = "PPrice";
    public static final String  QUANTITY= "Quantity";
    public static final String  QUANTITY_PRODUCT= "Qty";
}
