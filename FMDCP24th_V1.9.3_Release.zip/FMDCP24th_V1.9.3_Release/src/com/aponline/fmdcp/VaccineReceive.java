package com.aponline.fmdcp;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.server.ServerResponseListener;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class VaccineReceive extends AppCompatActivity implements ServerResponseListener,OnItemSelectedListener,OnClickListener
{
	ActionBar ab;
	TextView mfdate,expdate,mfgCompany;


	DBAdapter db;
	ArrayList<String> acklist=new ArrayList<String>();
	String noofdoses,mfddate,expiry,temp,receivedquantity,brewno,distd;
	ArrayList<String> brewnolist=new ArrayList<String>();

	ArrayAdapter<String> adapter;



	EditText tempEt,nooddosesEt,mfdEt,expEt,dod,tempd;
	ProgressDialog progressDialog;
	Handler mHandler;
	Context context;
	Spinner brewnosp;
	Button submit;

	private int mYear, mMonth, mDay;

	String userRoleID;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.vaccine_acknowledge); 
		ab=getSupportActionBar();
		ab.setTitle("Vaccine Details");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		db=new DBAdapter(this);

		userRoleID="5";
		initializeViews();

	}
	private void initializeViews() 
	{
		((Spinner)findViewById(R.id.ack_manifComapany_sp)).setSelection(0);
		((Spinner) findViewById(R.id.ack_fmdcpRound_sp)).setSelection(0);
		((TextView)findViewById(R.id.ackw_BrewNo_Et)).setText("");
		((TextView) findViewById(R.id.ackw_manifDate_Tv)).setText("");
		((TextView) findViewById(R.id.ackw_ExpireDate_Tv)).setText("");
		((TextView) findViewById(R.id.ackw_ReceivingDate_Tv)).setText("");
		((EditText) findViewById(R.id.ackw_whiteCards_Et)).setText("");
		((EditText) findViewById(R.id.ackw_Remark_Et)).setText("");



		((Spinner)findViewById(R.id.ack_fmdcpRound_sp)).setOnItemSelectedListener(this);
		((Spinner)findViewById(R.id.ack_BrewNo_sp)).setOnItemSelectedListener(this);
		((Spinner)findViewById(R.id.ack_BrewNo_sp)).setVisibility(8);
		((TextView)findViewById(R.id.ackw_BrewNo_Et)).setVisibility(0);

		findViewById(R.id.ack_submit_Bt).setOnClickListener(this);

		((TextView) findViewById(R.id.ackw_manifDate_Tv)).setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				showdate(((TextView) findViewById(R.id.ackw_manifDate_Tv)));
			}
		});
		((TextView) findViewById(R.id.ackw_ExpireDate_Tv)).setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				showdate1(((TextView) findViewById(R.id.ackw_ExpireDate_Tv)));
			}
		});
		((TextView) findViewById(R.id.ackw_ReceivingDate_Tv)).setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				showdate(((TextView) findViewById(R.id.ackw_ReceivingDate_Tv)));
			}
		});
		((EditText) findViewById(R.id.ackw_whiteCards_Et)).addTextChangedListener(new TextWatcher() 
		{
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count)
			{
				if(s!=null&&!s.toString().equalsIgnoreCase("")&&!s.toString().equalsIgnoreCase("0"))
				{
					try 
					{
						int recVials=Integer.parseInt(s.toString().trim());
						((TextView) findViewById(R.id.ackw_ReceivingDoses_Tv)).setText(""+(recVials*50));
					}
					catch (NumberFormatException e) 
					{
						e.printStackTrace();
					}
				}
				else
				{
					((TextView) findViewById(R.id.ackw_ReceivingDoses_Tv)).setText("0");
				}
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after)
			{
			}

			@Override
			public void afterTextChanged(Editable s)
			{
			}
		});
	}
	public void loadSpinnerData(String query, Spinner spinner)
	{
		db.open(); 
		// Spinner Drop down elements
		List<String> lables =db.getSpinnerData(query);
		db.close();
		// Creating adapter for spinner
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lables);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		// attaching data adapter to spinner
		spinner.setAdapter(dataAdapter);

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	@Override
	public void Success(String response) 
	{
		//		String brewNo=((Spinner) findViewById(R.id.ack_batchNo_sp)).getSelectedItem().toString().trim();
		//		String recDate=((TextView) findViewById(R.id.ackw_ReceivingDate_Tv)).getText().toString().trim();
		//		String recQuntity=((TextView) findViewById(R.id.ackw_ReceivingDoses_Tv)).getText().toString().trim();
		//		//String recTem=((EditText) findViewById(R.id.ackw_ReceivingTemp_Et)).getText().toString().trim();
		//
		//		ContentValues contentValues=new ContentValues();
		//		contentValues.put("NoOfDoses_Received", recQuntity);
		//		contentValues.put("Receiving_Date", recDate);
		//		//	contentValues.put("Receiving_Temperature", "5");
		//		contentValues.put("UserID", HomeData.userID);
		//		contentValues.put("AvailDoses", recQuntity);
		//		contentValues.put("Is_Ack", "Y");
		//		contentValues.put("Is_Sync", "Y");
		//		String[] batchNoData=brewNo.split("-");
		//		db.open();
		//		db.updateTableData("Vaccine_Distribution_master", contentValues, " VaccDistributionID='"+batchNoData[1]+"'");
		//		db.close();
		//		AlertDialogs("Information!!", "Successfully Submited");
		//		initializeViews();
	}
	@Override
	public void Fail(String response) 
	{
		AlertDialogs("Information!!",response);
	}
	@Override
	public void NetworkNotAvail()
	{
		AlertDialogs("Information!!", "Network not Available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(VaccineReceive.this,AppUpdatePage.class));
		finish();
		return;
	}
	public void showdate(final TextView t)
	{
		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);

		DatePickerDialog dpd = new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener()
		{
			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth)
			{
				Calendar cal=Calendar.getInstance();
				cal.set(year,monthOfYear,dayOfMonth);
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
				t.setText(df.format(cal.getTime()));
				//t.setText(dayOfMonth + "/"+ (monthOfYear + 1) + "/" + year);
			}
		}, mYear, mMonth, mDay);
		dpd.getDatePicker().setMaxDate(c.getTimeInMillis());
		dpd.show();


	}
	public void showdate1(final TextView t)
	{
		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);

		DatePickerDialog dpd = new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener()
		{
			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth)
			{
				Calendar cal=Calendar.getInstance();
				cal.set(year,monthOfYear,dayOfMonth);
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
				t.setText(df.format(cal.getTime()));
				
				//t.setText(dayOfMonth + "/"+ (monthOfYear + 1) + "/" + year);
			}
		}, mYear, mMonth, mDay);
		dpd.getDatePicker().setMinDate(c.getTimeInMillis());
		dpd.show();

	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
		case R.id.ack_submit_Bt:
			validateData();
			break;

		default:
			break;
		}
	}
	private void validateData() 
	{
		try 
		{
			Spinner fmdcpRound=(Spinner) findViewById(R.id.ack_fmdcpRound_sp);
			Spinner manifSp=(Spinner) findViewById(R.id.ack_manifComapany_sp);
			EditText brewNoEt=(EditText) findViewById(R.id.ackw_BrewNo_Et);
			TextView manifDateTv=(TextView) findViewById(R.id.ackw_manifDate_Tv);
			TextView expiryDateTv=(TextView) findViewById(R.id.ackw_ExpireDate_Tv);
			TextView recDateTv=(TextView) findViewById(R.id.ackw_ReceivingDate_Tv);
			EditText recWhiteVialsEt=(EditText) findViewById(R.id.ackw_whiteCards_Et);

			int fmcdpRound=fmdcpRound.getSelectedItemPosition();
			String fRound = "";
			if(fmcdpRound==0)
			{
				AlertDialogs("Information!!", "Please Select FMDCP Round");
				fmdcpRound.setFocusable(true); 
				fmdcpRound.setFocusableInTouchMode(true);
				fmdcpRound.requestFocus();
				return;
			}
			else if(fmcdpRound==1)
			{
				fRound="23";
			}
			else if(fmcdpRound==2)
			{
				fRound="24";
			}


			String brewNo;
			if(fRound.equalsIgnoreCase("23"))
			{
				brewNo=((Spinner)findViewById(R.id.ack_BrewNo_sp)).getSelectedItem().toString().trim();
				Spinner btnosp=(Spinner) findViewById(R.id.ack_BrewNo_sp);
				if(btnosp.getSelectedItemPosition()==0)
				{
					AlertDialogs("Information!!", "Please Select Batch/Brew Number");
					btnosp.setFocusable(true); 
					btnosp.setFocusableInTouchMode(true);
					btnosp.requestFocus();
					return;
				}
			}
			else
			{
				brewNo=brewNoEt.getText().toString().trim();
				if(brewNo.equalsIgnoreCase("")||brewNo.equalsIgnoreCase("0"))
				{
					brewNoEt.requestFocus();
					brewNoEt.setError("Enter Brew/Batch Number");
					return;
				}
			}
			int manifComapany=manifSp.getSelectedItemPosition();
			if(manifComapany==0)
			{
				AlertDialogs("Information!!", "Please Select Manufacturing Company");
				manifSp.setFocusable(true); 
				manifSp.setFocusableInTouchMode(true);
				manifSp.requestFocus();
				return;
			}
			String manifDate=manifDateTv.getText().toString().trim();
			if(manifDate.equalsIgnoreCase("")||manifDate.equalsIgnoreCase("0"))
			{
				manifDateTv.requestFocus();
				AlertDialogs("Information!!", "Please Select Manufacturing Date");
				return;
			}
			String expiryDate=expiryDateTv.getText().toString().trim();
			if(expiryDate.equalsIgnoreCase("")||expiryDate.equalsIgnoreCase("0"))
			{
				expiryDateTv.requestFocus();
				AlertDialogs("Information!!", "Please Select Expiry Date");
				return;
			}
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy"); 
			Date date1=(Date)sdf1.parse(manifDate);
			Date date2 = (Date)sdf1.parse(expiryDate);
			if(date1.after(date2))
			{
				AlertDialogs("Information!!", "Expiry Date must be After the Manufacturing Date");
				expiryDateTv.requestFocus();
				return;
			}
			String recDate=recDateTv.getText().toString().trim();
			if(recDate.equalsIgnoreCase("")||recDate.equalsIgnoreCase("0"))
			{
				recDateTv.requestFocus();
				AlertDialogs("Information!!", "Please Select Receiving Date");
				return;
			}
			date1=(Date)sdf1.parse(manifDate);
			date2 = (Date)sdf1.parse(recDate);
			if(date1.before(date2) || date1.equals(date2))
			{
				recDate=new SimpleDateFormat("dd/MM/yyyy").format(date2);
			}
			else
			{
				AlertDialogs("Information!!", "Received Date must be After the Manufacturing Date");
				recDateTv.requestFocus();
				return;
			}	

			String recWhiteVials=recWhiteVialsEt.getText().toString().trim();
			if(recWhiteVials.equalsIgnoreCase("")||recWhiteVials.equalsIgnoreCase("0"))
			{
				recWhiteVialsEt.requestFocus();
				recWhiteVialsEt.setError("Enter No.of Vials Received with White Card");
				return;
			}
			else if(Integer.parseInt(recWhiteVials)==0)
			{
				recWhiteVialsEt.requestFocus();
				recWhiteVialsEt.setError("Enter No.of Vials Received with White Card");
				return;
			}

			date1=(Date)sdf1.parse(manifDate);
			manifDate=new SimpleDateFormat("dd/MM/yyyy").format(date1);
			date1=(Date)sdf1.parse(expiryDate);
			expiryDate=new SimpleDateFormat("dd/MM/yyyy").format(date1);


			String remarks=((EditText)findViewById(R.id.ackw_Remark_Et)).getText().toString().trim();
			Calendar c = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			String createdDate = sdf.format(c.getTime());


			int doses=Integer.parseInt(recWhiteVials)*50;


			ContentValues contentValues=new ContentValues();
			contentValues.put("Manufacturing_Company", ""+manifComapany);
			contentValues.put("BatchNo", brewNo);
			contentValues.put("Manufacturing_Date",manifDate);
			contentValues.put("Expiry_Date",expiryDate);
			contentValues.put("Receiving_Date", recDate);
			contentValues.put("Noofvialreceived", recWhiteVials);
			contentValues.put("NoOfDoses_Received", ""+doses); 
			contentValues.put("AvailDoses", ""+doses);
			contentValues.put("VaccDistributionID",""+GenerateUniqueID());
			contentValues.put("Remark", remarks); 
			contentValues.put("UserID", HomeData.loginID);
			contentValues.put("Created_By ",HomeData.userAadhaarID);
			contentValues.put("Is_Ack", "Y");
			contentValues.put("Is_Sync", "N");
			contentValues.put("FMDCP_Round",fRound);

			if(fRound.equalsIgnoreCase("24"))
			{
				db.open();
				int count=db.getRowCount("select count(BatchNo) from Vaccine_Distribution_master where BatchNo='"+brewNo+"' and FMDCP_Round='24'");
				db.close();
				if(count<=0)
				{
					db.open();
					db.insertTableDate("Vaccine_Distribution_master", contentValues);
					db.close();
					AlertDialogs("Information!!", "Successfully Submited");
					initializeViews();
				}
				else
				{
					AlertDialogs("Information!!", "Batch Number Already Available");
				}
			}
			else
			{
				db.open();
				db.updateTableData("Vaccine_Distribution_master", contentValues,"Created_By='"+HomeData.userAadhaarID+"' and FMDCP_Round='23' and BatchNo='"+brewNo+"'");
				db.close();
				AlertDialogs("Information!!", "Successfully Submited");
				initializeViews();
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) 
	{
		switch (parent.getId()) 
		{
		case R.id.ack_fmdcpRound_sp:
		{
			try {
				((Spinner)findViewById(R.id.ack_BrewNo_sp)).setVisibility(8);
				((TextView)findViewById(R.id.ackw_BrewNo_Et)).setVisibility(0);
				if(parent.getSelectedItemPosition()==1)
				{
					((Spinner)findViewById(R.id.ack_BrewNo_sp)).setVisibility(0);
					((TextView)findViewById(R.id.ackw_BrewNo_Et)).setVisibility(8);

					((TextView)findViewById(R.id.ackw_whiteCards_tv)).setText("No. of Vials Available \nwith white Card");
					((TextView)findViewById(R.id.ackw_ReceivingDoses_TvLb)).setText("No. of Doses Available");

					loadSpinnerData("select BatchNo from Vaccine_Distribution_master where Is_Ack='Y' and Created_By='"+HomeData.userAadhaarID+"' and FMDCP_Round='23'", ((Spinner)findViewById(R.id.ack_BrewNo_sp)));

				}
				else
				{
					((TextView)findViewById(R.id.ackw_BrewNo_Et)).setText("");
					((TextView) findViewById(R.id.ackw_manifDate_Tv)).setText("");
					((TextView) findViewById(R.id.ackw_ExpireDate_Tv)).setText("");
					((TextView) findViewById(R.id.ackw_ReceivingDate_Tv)).setText("");
					((EditText) findViewById(R.id.ackw_whiteCards_Et)).setText("");
					((EditText) findViewById(R.id.ackw_Remark_Et)).setText("");
					((Spinner)findViewById(R.id.ack_manifComapany_sp)).setSelection(0);

					((TextView)findViewById(R.id.ackw_whiteCards_tv)).setText("No. of Vials Received \nwith white Card");
					((TextView)findViewById(R.id.ackw_ReceivingDoses_TvLb)).setText("No. of Doses Received");
				}
			} 
			catch (Exception e)
			{
				AlertDialogs("Information!!!!", "Please tray again!!");
				e.printStackTrace();
			}
		}
		break;
		case R.id.ack_BrewNo_sp:
		{
			try 
			{
				((TextView)findViewById(R.id.ackw_BrewNo_Et)).setText("");
				((TextView) findViewById(R.id.ackw_manifDate_Tv)).setText("");
				((TextView) findViewById(R.id.ackw_ExpireDate_Tv)).setText("");
				((TextView) findViewById(R.id.ackw_ReceivingDate_Tv)).setText("");
				((EditText) findViewById(R.id.ackw_whiteCards_Et)).setText("");
				((EditText) findViewById(R.id.ackw_Remark_Et)).setText("");
				((Spinner)findViewById(R.id.ack_manifComapany_sp)).setSelection(0);
				if(parent.getSelectedItemPosition()>0)
				{
					db.open();
					Cursor cursor=db.getTableDataCursor("select Manufacturing_Date,Expiry_Date,Receiving_Date,Manufacturing_Company from Vaccine_Distribution_master where BatchNo='"+parent.getSelectedItem().toString()+"' and Created_By='"+HomeData.userAadhaarID+"'");
					if(cursor.getCount()>0)
					{
						if(cursor.moveToFirst())
						{
							((TextView)findViewById(R.id.ackw_manifDate_Tv)).setText(cursor.getString(cursor.getColumnIndex("Manufacturing_Date")));
							((TextView)findViewById(R.id.ackw_ExpireDate_Tv)).setText(cursor.getString(cursor.getColumnIndex("Expiry_Date")));
							((TextView)findViewById(R.id.ackw_ReceivingDate_Tv)).setText(cursor.getString(cursor.getColumnIndex("Receiving_Date")));
							((Spinner)findViewById(R.id.ack_manifComapany_sp)).setSelection(Integer.parseInt(cursor.getString(cursor.getColumnIndex("Manufacturing_Company"))));
						}
					}
					cursor.close();
					db.close();
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!!!", "Please select another batch number");
				e.printStackTrace();
			}
		}
		break;
		default:
			break;
		}
	}
	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}


	@SuppressLint("DefaultLocale")
	private String GenerateUniqueID()
	{
		String strSecretCode = "";
		try
		{
			UUID uuid = UUID.randomUUID();    
			String strguid = uuid.toString();
			strSecretCode = strguid.substring(strguid.lastIndexOf("-") + 1);
			strSecretCode = strSecretCode.toUpperCase().replace('O', 'W').replace('0', '4');
			strSecretCode = strSecretCode.substring(0, 11);
			strSecretCode = "V" + strSecretCode;
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			//
		}
		return strSecretCode;
	}
}
