package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.database.DBAdapter;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class VaccineDetailsView_New extends AppCompatActivity
{

	DBAdapter db;
	TextView vdate,batchno,mfd,expd,noofdises,adharno,farmername,gender,mno,mandal,village,ss,fmalewc,ffwc,fmb,ffb,wcnoofmalevaccinated,buffnoofmalevaccinated,cattleusedford,buffusedford,reasonfornotvcattle,reasonffornotvacbuff,nooffemalvacccattle,nooffemalevaccbuff,noofvaccinfemalpregwc,noofvaccinatedfempregbuff,reasonfornotvaccwc,reasonfornotvsbuff;
	TextView malewhitecattle,femalewhitecattle,malebuff,femalbuff;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{

		super.onCreate(savedInstanceState);
		setContentView(R.layout.vaccinationdetailview);
		db=new DBAdapter(this);


		vdate=(TextView) findViewById(R.id.vaccinationddetail_vaccinedate);
		batchno=(TextView) findViewById(R.id.vaccinedetail_batchno);
		mfd=(TextView) findViewById(R.id.vaccinedetail_mfddate);
		expd=(TextView) findViewById(R.id.vaccinedetail_expdate);
		noofdises=(TextView) findViewById(R.id.vaccinedetail_noofdoses);
		farmername=(TextView) findViewById(R.id.vaccinedetail_farmername);
		gender=(TextView) findViewById(R.id.vaccinedetail_gender);
		mno=(TextView) findViewById(R.id.vaccinedetail_mobileno);
		mandal=(TextView) findViewById(R.id.vaccinedetail_mandal);
		village=(TextView) findViewById(R.id.vaccinedetail_village);
		ss=(TextView) findViewById(R.id.vaccinedetail_socialstatus);

		malewhitecattle=(TextView) findViewById(R.id.vaccinedetail_malewhitecattle);
		femalewhitecattle=(TextView) findViewById(R.id.vaccinedetail_femalewhitecattle);
		malebuff=(TextView) findViewById(R.id.vaccinedetail_malebuffelo);
		femalbuff=(TextView) findViewById(R.id.vaccinedetail_femalebuffelo);

		adharno=(TextView) findViewById(R.id.vaccinedetail_adharno);
		wcnoofmalevaccinated=(TextView) findViewById(R.id.fmd_whiteMaleVaccinated_Et);
		buffnoofmalevaccinated=(TextView) findViewById(R.id.fmd_buffaloMaleVaccinated_Et);
		cattleusedford=(TextView) findViewById(R.id.fmd_whiteMaleDraught_Et);
		buffusedford=(TextView) findViewById(R.id.fmd_buffaloMaleDraught_Et);
		reasonfornotvcattle=(TextView) findViewById(R.id.txt1);
		reasonffornotvacbuff=(TextView) findViewById(R.id.txt2);
		nooffemalvacccattle=(TextView) findViewById(R.id.txt3);
		nooffemalevaccbuff=(TextView) findViewById(R.id.txt4);
		noofvaccinfemalpregwc=(TextView) findViewById(R.id.txt5);
		noofvaccinatedfempregbuff=(TextView) findViewById(R.id.txt6);
		reasonfornotvaccwc=(TextView) findViewById(R.id.txt7);
		reasonfornotvsbuff=(TextView) findViewById(R.id.txt8);
		String data = getIntent().getExtras().getString("adharno");
		getdetailfromadharno(data);
		getfarmerdetail(data);

	}

	public void getdetailfromadharno(String adhno)
	{

		
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from FMD_Vaccination_Details where FarmerRegID='"+adhno+"'");
		ArrayList<String> data=new ArrayList<String>();
		int noofvaccinatedanimal=0;
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{

					vdate.setText(cursor.getString(cursor.getColumnIndex("DateOfVaccination")));
					batchno.setText(cursor.getString(cursor.getColumnIndex("BatchNo")));
					wcnoofmalevaccinated.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_Male_vaccinated")));
					buffnoofmalevaccinated.setText(cursor.getString(cursor.getColumnIndex("Buffalo_Male_vaccinated")));
					cattleusedford.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_NoUsedForDraught")));
					buffusedford.setText(cursor.getString(cursor.getColumnIndex("Buffalo_NoUsedForDraught")));
					reasonfornotvcattle.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_Male_AnimalsNotVaccinated_Reason")));
					reasonffornotvacbuff.setText(cursor.getString(cursor.getColumnIndex("Buffalo_Male_AnimalsNotVaccinated_Reason")));
					nooffemalvacccattle.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_Female_vaccinated")));
					nooffemalevaccbuff.setText(cursor.getString(cursor.getColumnIndex("Buffalo_Female_vaccinated")));
					noofvaccinfemalpregwc.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_NumberOfAnimalsPregnant")));
					noofvaccinatedfempregbuff.setText(cursor.getString(cursor.getColumnIndex("Buffalo_NumberOfAnimalsPregnant")));
					reasonfornotvaccwc.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_FeMale_AnimalsNotVaccinated_Reason")));
					reasonfornotvsbuff.setText(cursor.getString(cursor.getColumnIndex("Buffalo_FeMale_AnimalsNotVaccinated_Reason")));
					getdetailfrombatchno(batchno.getText().toString());
				}while(cursor.moveToNext());

			}

			cursor.close();
			db.close();


		}


	}

	public void getfarmerdetail(String d)
	{

		//	db=new DBAdapter(this);
		db.open();
		Cursor cursor=db.getTableDataCursor("Select F.Farmer_Name,F.Aadhar_No,MS.SocialStatusName,F.Mobile_No,F.Male_White_Cattle,F.Male_Buffaloes,F.Female_White_Cattle,F.Female_Buffaloes,MV.VillageName,MM.MandalName,MG.Gender from FARMER_REG_DETAILS F INNER JOIN Master_Village MV on F.Village_Id=MV.VillageID INNER JOIN Master_Gender MG on F.Gender=MG.GenderID INNER JOIN Master_Mandal MM on F.District_Id=MM.DistrictID AND F.Mandal_Id=MM.MandalID INNER JOIN Master_SocialStatus MS on F.Social_Status=MS.SocialStatusID where Aadhar_No='"+d+"'");
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{

					adharno.setText(cursor.getString(cursor.getColumnIndex("Aadhar_No")));
					farmername.setText(cursor.getString(cursor.getColumnIndex("Farmer_Name")));
					gender.setText(cursor.getString(cursor.getColumnIndex("Gender")));
					mno.setText(cursor.getString(cursor.getColumnIndex("Mobile_No")));
					mandal.setText(cursor.getString(cursor.getColumnIndex("MandalName")));
					village.setText(cursor.getString(cursor.getColumnIndex("VillageName")));
					malewhitecattle.setText(cursor.getString(cursor.getColumnIndex("Male_White_Cattle")));
					femalewhitecattle.setText(cursor.getString(cursor.getColumnIndex("Female_White_Cattle")));
					malebuff.setText(cursor.getString(cursor.getColumnIndex("Male_Buffaloes")));
					femalbuff.setText(cursor.getString(cursor.getColumnIndex("Female_Buffaloes")));
					ss.setText(cursor.getString(cursor.getColumnIndex("SocialStatusName")));

					//c.close();
				}while(cursor.moveToNext());



			}

			cursor.close();

			db.close();
		}



	}

	public void getdetailfrombatchno(String b)
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select Manufacturing_Date,Expiry_Date,AvailDoses from Vaccine_Distribution_master where BatchNo='"+b+"'");
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{

					mfd.setText(cursor.getString(cursor.getColumnIndex("Manufacturing_Date")));
					expd.setText(cursor.getString(cursor.getColumnIndex("Expiry_Date")));
					noofdises.setText(cursor.getString(cursor.getColumnIndex("AvailDoses")));


				}while(cursor.moveToNext());

			}

			cursor.close();
			db.close();


		}

	}
}
