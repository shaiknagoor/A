package com.aponline.fmdcp.adapter;

import java.util.ArrayList;

import com.aponline.fmdcp.R;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class vaccinationreportlistadapter extends BaseAdapter 
{
	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;
	
	
	public vaccinationreportlistadapter(Context applicationContext,ArrayList<ArrayList<String>> data) 
	{
		// TODO Auto-generated constructor stub
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);
	}
	
	
	

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}
	@Override
	public Object getItem(int paramInt)
	{
		return Integer.valueOf(paramInt);
	}
	@Override
	public long getItemId(int paramInt)
	{
		return paramInt;
	}
	@Override
	public View getView(int position, View paramView, ViewGroup paramViewGroup) 
	{
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.vaccinationreport, null);
			this.mHolder = new Holder();
			this.mHolder.serialno = ((TextView)paramView.findViewById(R.id.vaccinationserialno));
			this.mHolder.vaccid = ((TextView)paramView.findViewById(R.id.vaccdetail));
			this.mHolder.regid = ((TextView)paramView.findViewById(R.id.regid));
	//		this.mHolder.depregiid = ((TextView)paramView.findViewById(R.id.depregid));
			this.mHolder.batchno = ((TextView)paramView.findViewById(R.id.batchno));
			this.mHolder.dateofvaccination = ((TextView)paramView.findViewById(R.id.dateofvacc));
			this.mHolder.wcused = ((TextView)paramView.findViewById(R.id.wcused));
			this.mHolder.wcmalvaccinated = ((TextView)paramView.findViewById(R.id.wcvaccinated));
			this.mHolder.wcfemalevaccinated = ((TextView)paramView.findViewById(R.id.wcfemalevacc));
			this.mHolder.wcpregnant = ((TextView)paramView.findViewById(R.id.wcpregnant));
			this.mHolder.buffnousedfordraught = ((TextView)paramView.findViewById(R.id.buffusedfordraught));
			this.mHolder.buffmalevaccinated = ((TextView)paramView.findViewById(R.id.buffmalevacc));
			this.mHolder.bufffemalevaccinated = ((TextView)paramView.findViewById(R.id.bufffemalevacc));
			this.mHolder.buffpregnant = ((TextView)paramView.findViewById(R.id.buffpreg));
			this.mHolder.buffmalenotvaccreason = ((TextView)paramView.findViewById(R.id.buffmalevaccreason));
			this.mHolder.bufffemalenotvaccreason = ((TextView)paramView.findViewById(R.id.bufffemalevaccreason));
			this.mHolder.wcmalenotvaccreason = ((TextView)paramView.findViewById(R.id.wcmallvaccinreason));
			this.mHolder.wcfemalenotvaccreason = ((TextView)paramView.findViewById(R.id.wcfemalevaccreason));
			this.mHolder.noofdosesremaining = ((TextView)paramView.findViewById(R.id.noofdoses));
			this.mHolder.isactive = ((TextView)paramView.findViewById(R.id.isactive));
			this.mHolder.issync = ((TextView)paramView.findViewById(R.id.issyncc));
			
			paramView.setTag(this.mHolder);
		}
		else
		
			
			this.mHolder=(Holder)paramView.getTag();
			Log.d("INSIDE ADAPTER", Integer.toString(position));
			ArrayList<String> data=this.localArrayList.get(position);
			this.mHolder.serialno.setText(Integer.toString(position+1));
			this.mHolder.vaccid.setText(data.get(0));
			this.mHolder.regid.setText(data.get(1));
		//	this.mHolder.depregiid.setText(data.get(2));
			this.mHolder.batchno.setText(data.get(3));
			this.mHolder.dateofvaccination.setText(data.get(4));
			this.mHolder.wcused.setText(data.get(5));
			this.mHolder.wcmalvaccinated.setText(data.get(6));
			this.mHolder.wcfemalevaccinated.setText(data.get(7));
			this.mHolder.wcpregnant.setText(data.get(8));
			this.mHolder.buffnousedfordraught.setText(data.get(9));
			this.mHolder.buffmalevaccinated.setText(data.get(10));
			this.mHolder.bufffemalevaccinated.setText(data.get(11));
			this.mHolder.buffpregnant.setText(data.get(12));
			this.mHolder.buffmalenotvaccreason.setText(data.get(13));
			this.mHolder.bufffemalenotvaccreason.setText(data.get(14));
			this.mHolder.wcmalenotvaccreason.setText(data.get(15));
			this.mHolder.wcfemalenotvaccreason.setText(data.get(16));
			this.mHolder.noofdosesremaining.setText(data.get(17));
			this.mHolder.isactive.setText(data.get(18));
			this.mHolder.issync.setText(data.get(19));
		
			return paramView;

		//this.mHolder.ReportOrderSno.setText(""+(paramInt+1));
	//	this.mHolder.ReportOrderCustId.setText(this.localArrayList.get(paramInt));
		
		
		

	}
	public class Holder
	{
		TextView serialno;
		TextView vaccid;
		TextView regid;
	//	TextView depregiid;
		TextView batchno;
		TextView dateofvaccination;
		TextView  wcused;
		TextView wcmalvaccinated;
		TextView wcfemalevaccinated;
		TextView wcpregnant;
		TextView buffnousedfordraught;
		TextView buffmalevaccinated;
		TextView bufffemalevaccinated;
		TextView buffpregnant;
		TextView buffmalenotvaccreason;
		TextView bufffemalenotvaccreason;
		TextView wcmalenotvaccreason;
		TextView wcfemalenotvaccreason;
		TextView noofdosesremaining;
		TextView isactive;
		TextView issync;
		
		

		private Holder()
		{
		}
	}
}


