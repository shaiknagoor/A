package com.aponline.fmdcp.adapter;

import java.util.ArrayList;

import com.aponline.fmdcp.R;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class FarmerVaccineDetailadapter  extends BaseAdapter
{
	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;

	public FarmerVaccineDetailadapter(Context applicationContext,ArrayList<ArrayList<String>> data) {
		// TODO Auto-generated constructor stub\
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);

	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}
	@Override
	public Object getItem(int paramInt)
	{
		return Integer.valueOf(paramInt);
	}
	@Override
	public long getItemId(int paramInt)
	{
		return paramInt;
	}

	@Override
	public View getView(int position, View paramView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.farmerlistrow, null);
			this.mHolder = new Holder();
			this.mHolder.farmerrowlist_name = ((TextView)paramView.findViewById(R.id.farmerrowlist_name));
			this.mHolder.farmerrowlist_aadhar = ((TextView)paramView.findViewById(R.id.farmerrowlist_aadhar));
			this.mHolder.farmerrowlist_mobileno = ((TextView)paramView.findViewById(R.id.farmerrowlist_mobileno));
			paramView.setTag(this.mHolder);


		}
		else 
			this.mHolder=(Holder)paramView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));
		ArrayList<String> data=this.localArrayList.get(position);

		this.mHolder.farmerrowlist_name.setText(data.get(0));
		this.mHolder.farmerrowlist_aadhar.setText(data.get(1));
		this.mHolder.farmerrowlist_mobileno.setText(data.get(2));
		return paramView;
	}

	public class Holder
	{
		TextView farmerrowlist_name;
		TextView farmerrowlist_aadhar;
		TextView farmerrowlist_mobileno;
	
	public Holder()
		{
		}
	}
}
