package com.aponline.fmdcp.adapter;

import java.util.ArrayList;

import com.aponline.fmdcp.R;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class farmerdetailadapter extends BaseAdapter {

	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;

	public farmerdetailadapter(Context applicationContext,ArrayList<ArrayList<String>> data) {
		// TODO Auto-generated constructor stub\
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);

	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}
	@Override
	public Object getItem(int paramInt)
	{
		return Integer.valueOf(paramInt);
	}
	@Override
	public long getItemId(int paramInt)
	{
		return paramInt;
	}

	@Override
	public View getView(int position, View paramView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.farmerreportlist, null);
			this.mHolder = new Holder();
			this.mHolder.serialno = ((TextView)paramView.findViewById(R.id.serialno));
			this.mHolder.vaccineDate = ((TextView)paramView.findViewById(R.id.vaccineDate));
			this.mHolder.farmername = ((TextView)paramView.findViewById(R.id.farmername));
			this.mHolder.adharno = ((TextView)paramView.findViewById(R.id.adharno));
			this.mHolder.totalanimal = ((TextView)paramView.findViewById(R.id.totalanimal));
			this.mHolder.vaccinatedanima = ((TextView)paramView.findViewById(R.id.vaccinatedanimal));
			this.mHolder.issync = ((TextView)paramView.findViewById(R.id.IsSync));
			paramView.setTag(this.mHolder);


		}
		else 
			this.mHolder=(Holder)paramView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));
		ArrayList<String> data=this.localArrayList.get(position);

		this.mHolder.serialno.setText(""+(position+1));
		this.mHolder.vaccineDate.setText(data.get(5));
		this.mHolder.farmername.setText(data.get(1));
		this.mHolder.adharno.setText(data.get(0));
		this.mHolder.totalanimal.setText(data.get(2));
		this.mHolder.vaccinatedanima.setText(data.get(3));
		this.mHolder.issync.setText(data.get(4));

		return paramView;
	}

	public class Holder
	{
		TextView serialno;
		TextView vaccineDate;
		TextView farmername;
		TextView adharno;
		TextView totalanimal;
		TextView  vaccinatedanima;
		TextView issync;



		public Holder()
		{
		}
	}

}
