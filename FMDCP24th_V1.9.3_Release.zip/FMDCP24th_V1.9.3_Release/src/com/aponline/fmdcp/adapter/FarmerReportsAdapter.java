package com.aponline.fmdcp.adapter;

import java.util.ArrayList;

import com.aponline.fmdcp.R;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


public class FarmerReportsAdapter extends BaseAdapter 
{
	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;

	public FarmerReportsAdapter(Context applicationContext,ArrayList<ArrayList<String>> data)
	{
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);
	}
	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}
	@Override
	public Object getItem(int paramInt)
	{
		return Integer.valueOf(paramInt);
	}
	@Override
	public long getItemId(int paramInt)
	{
		return paramInt;
	}
	@Override
	public View getView(int position, View paramView, ViewGroup paramViewGroup) 
	{
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.farmerdetilas_reports_list, null);
			this.mHolder = new Holder();
			this.mHolder.serialno = ((TextView)paramView.findViewById(R.id.frd_sno));
			this.mHolder.farmername = ((TextView)paramView.findViewById(R.id.frd_farmername));
			this.mHolder.adharno = ((TextView)paramView.findViewById(R.id.frd_adharno));
			this.mHolder.villagename = ((TextView)paramView.findViewById(R.id.frd_villagename));
			this.mHolder.gender = ((TextView)paramView.findViewById(R.id.frd_gender));
			this.mHolder.totalAnimals = ((TextView)paramView.findViewById(R.id.frd_totalAnimals));
			this.mHolder.IsSync = ((TextView)paramView.findViewById(R.id.frd_IsSync));
			this.mHolder.mobileno = ((TextView)paramView.findViewById(R.id.frd_mobileno));

			paramView.setTag(this.mHolder);
		}
		else


			this.mHolder=(Holder)paramView.getTag();
		//Log.d("INSIDE ADAPTER", Integer.toString(position));
		ArrayList<String> data=this.localArrayList.get(position);
		this.mHolder.serialno.setText(Integer.toString(position+1));
		this.mHolder.farmername.setText(data.get(0));
		this.mHolder.adharno.setText(data.get(1));
		this.mHolder.villagename.setText(data.get(2));
		this.mHolder.mobileno.setText(data.get(3));
		this.mHolder.gender.setText(data.get(4));
		this.mHolder.totalAnimals.setText(data.get(5));
		this.mHolder.IsSync.setText(data.get(6));

		return paramView;
	}
	public class Holder
	{
		public TextView villagename;
		TextView serialno;
		TextView farmername;
		TextView adharno;
		TextView gender;
		TextView totalAnimals;
		TextView IsSync;
		TextView mobileno;
		TextView socialstatus;


		private Holder()
		{
		}
	}
}

