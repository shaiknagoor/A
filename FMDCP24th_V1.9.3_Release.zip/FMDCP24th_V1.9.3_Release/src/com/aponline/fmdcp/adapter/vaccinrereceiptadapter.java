package com.aponline.fmdcp.adapter;

import java.util.ArrayList;

import com.aponline.fmdcp.R;
import com.aponline.fmdcp.adapter.vaccinationreportlistadapter.Holder;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class vaccinrereceiptadapter extends BaseAdapter {

	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;
	
	public vaccinrereceiptadapter(Context applicationContext,ArrayList<ArrayList<String>> data) 
	{
		// TODO Auto-generated constructor stub
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return localArrayList.size();
	}

	@Override
	public Object getItem(int paramInt) {
		// TODO Auto-generated method stub
		return Integer.valueOf(paramInt);
	}

	@Override
	public long getItemId(int paramInt) {
		// TODO Auto-generated method stub
		return paramInt;
		}

	@Override
	public View getView(int position, View paramView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.vaccinationreceipt, null);
			this.mHolder = new Holder();
			this.mHolder.serialno = ((TextView)paramView.findViewById(R.id.vaccinationserialno_receipt));
			this.mHolder.manfacturingcompny = ((TextView)paramView.findViewById(R.id.mfc_receipt));
			this.mHolder.batchno = ((TextView)paramView.findViewById(R.id.batchno_receipt));
	//		this.mHolder.depregiid = ((TextView)paramView.findViewById(R.id.depregid));
			this.mHolder.manufacturingdate = ((TextView)paramView.findViewById(R.id.mfddate_receipt));
			this.mHolder.expirydate = ((TextView)paramView.findViewById(R.id.expirydate_receipt));
			this.mHolder.receiveddate = ((TextView)paramView.findViewById(R.id.receiveddate_receipt));
			this.mHolder.noofvialreceived = ((TextView)paramView.findViewById(R.id.noofvial_receipt));
			this.mHolder.availabledoses = ((TextView)paramView.findViewById(R.id.availabledoses_receipt));
			this.mHolder.Isupld = ((TextView)paramView.findViewById(R.id.Isupld));
			
			
			paramView.setTag(this.mHolder);
		}
		else
		
		this.mHolder=(Holder)paramView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));
		ArrayList<String> data=this.localArrayList.get(position);
		this.mHolder.serialno.setText(Integer.toString(position+1));
		this.mHolder.manfacturingcompny.setText(data.get(0));
		this.mHolder.batchno.setText(data.get(1));
	//	this.mHolder.depregiid.setText(data.get(2));
	//	this.mHolder.batchno.setText(data.get(3));
		this.mHolder.manufacturingdate.setText(data.get(2));
		this.mHolder.expirydate.setText(data.get(3));
		this.mHolder.receiveddate.setText(data.get(4));
		this.mHolder.availabledoses.setText(data.get(5));
		this.mHolder.noofvialreceived.setText(data.get(6));
		this.mHolder.Isupld.setText(data.get(7));
		
	//	this.mHolder.noofvialreceived.setText(data.get(7));
		
		return paramView;
	}
	
	private class Holder
	{
		TextView serialno;
		TextView manfacturingcompny;
	
	//	TextView depregiid;
		TextView batchno;
		TextView manufacturingdate;
		TextView  expirydate;
		TextView receiveddate;
		TextView availabledoses;
		TextView noofvialreceived;
		TextView Isupld;
		

		private Holder()
		{
		}
	}

}
