package com.aponline.fmdcp;


import com.aponline.fmdcp.server.RequestServer;
import com.aponline.fmdcp.server.ServerResponseListener;
import com.aponline.fmdcp.server.WebserviceCall;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class FeedbackPage extends AppCompatActivity implements OnClickListener,ServerResponseListener
{

	public static StringBuilder Feedback_stb = new StringBuilder();
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.feedbackpage);
		ActionBar ab=getSupportActionBar();
		ab.setTitle("Feedback");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		findViewById(R.id.Feedback_submit_Bt).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId())
		{
		case R.id.Feedback_submit_Bt:
			SendData();
			break;
		default:
			break;
		}

	}


	private void SendData() 
	{
		String comments=((EditText) findViewById(R.id.Feedback_comments)).getText().toString();

		String rating="0";
		if (((RadioButton)findViewById(R.id.Excellent_rd)).isChecked())
		{
			rating = "5";
		}
		else if (((RadioButton) findViewById(R.id.VeryGood_rd)).isChecked())
		{
			rating = "4";
		}
		else if (((RadioButton) findViewById(R.id.Good_rd)).isChecked())
		{
			rating = "3";
		}
		else if (((RadioButton) findViewById(R.id.Average_rd)).isChecked())
		{
			rating = "2";
		}
		else if (((RadioButton) findViewById(R.id.Poor_rd)).isChecked())
		{
			rating = "1";
		}

		if(rating.equalsIgnoreCase("0"))
		{
			AlertDialogs("Information", "Please give one Rating","OK");	
			return;
		}


		Feedback_stb=new StringBuilder();
		Feedback_stb.append("<FeedBack>");
		Feedback_stb.append(""
				+ "<Rating>"+rating+"</Rating>"
				+"<Comments>"+comments+"</Comments>"
				+ "");
		Feedback_stb.append("</FeedBack>");

		RequestServer request=new RequestServer(this);
		request.addParam("XML",Feedback_stb.toString());
		request.ProccessRequest(this, "FMDCP_UserFeedBack");


	}


	public void AlertDialogs(String title, String msg, final String pageSubmit) 
	{
		AlertDialog.Builder adb = new AlertDialog.Builder(this);
		adb.setTitle(title);
		adb.setMessage(msg);
		adb.setPositiveButton("Ok", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int which)
			{
				if (pageSubmit.equals("SUBMIT"))
				{
					onBackPressed();
				}
				else if (pageSubmit.equals("OK"))
				{
					dialog.dismiss();
				}
				else 
				{
					return;
				}
			}
		});
		adb.show();
	}

	@Override
	public void Success(String response)
	{
		if(response.equalsIgnoreCase("FMDCP_UserFeedBack"))
		{
			if(WebserviceCall.msg.equalsIgnoreCase("Exists"))
			{
				AlertDialogs("Information", "Feedback Already Submitted");
				return;
			}
			else
			{

				AlertDialogs("Information", "Feedback Successfully Submitted");
				return;

			}

		}

	}

	@Override
	public void Fail(String response) 
	{
		AlertDialogs("Information!!", response);
	}
	@Override

	public void NetworkNotAvail() 
	{
		AlertDialogs("Information", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(this,AppUpdatePage.class));
		//getActivity().finish();

		return;
	}

	public void AlertDialogs(String title, String msg) 
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		//		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		//	yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
	}

}
