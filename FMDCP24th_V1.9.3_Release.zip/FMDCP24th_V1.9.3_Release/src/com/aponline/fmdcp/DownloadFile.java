package com.aponline.fmdcp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class DownloadFile extends AsyncTask<String, Integer, Void> 
{
	NotificationManager mNotifyManager;
	NotificationCompat.Builder mBuilder;
	String URL = "", filename = "";
	Context mContext;
	String path = "";
	public DownloadFile(Context context,String url1, String filename1) 
	{
		this.mContext=context;
		URL = url1;
		filename = filename1;
	}

	protected void onPreExecute()
	{
		super.onPreExecute();

		// String path =
		// Environment.getExternalStorageDirectory()+"/DCIM/"+"FMDCP1stround%20guidlines2017-18.pdf";

		String storeDir = Environment.getExternalStorageDirectory().toString();
		path = storeDir + "/" + filename;
		mNotifyManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
		mBuilder = new NotificationCompat.Builder(mContext);
		Intent intent = new Intent();
		intent.setAction(android.content.Intent.ACTION_VIEW);
		File file = new File(path);
		intent.setDataAndType(Uri.fromFile(file), "application/pdf");
		PendingIntent pIntent = PendingIntent.getActivity(mContext, 0, intent, 0);

//		 Bitmap notificationLargeIconBitmap = BitmapFactory.decodeResource(
//		 mContext.getResources(),R.drawable.ongole_bull_icon110);

		mBuilder.setContentTitle("FMDCP User Manual").setContentText("Download in progress")
				.setColor(mContext.getResources().getColor(R.color.blue))
				.setSmallIcon(R.drawable.ongole_bull_icon110).setContentIntent(pIntent);

		Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		mBuilder.setSound(uri);
		mBuilder.setAutoCancel(true);
		mBuilder.setOnlyAlertOnce(true);

		Toast.makeText(mContext, "Downloading the file... The download progress is on notification bar.",Toast.LENGTH_LONG).show();
		
	/*	Toast toast = Toast.makeText(mContext, "I am custom Toast!", Toast.LENGTH_LONG);
        View toastView = toast.getView(); //This'll return the default View of the Toast.

         And now you can get the TextView of the default View of the Toast. 
        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
        toastMessage.setTextSize(25);
        toastMessage.setTextColor(Color.RED);
        toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_feedback, 0, 0, 0);
        toastMessage.setGravity(Gravity.CENTER);
        toastMessage.setCompoundDrawablePadding(16);
        toastView.setBackgroundColor(Color.CYAN);
        toast.show(); 
         
        
        
//	    LayoutInflater inflater = mContext.getLayoutInflater();
//       View toastLayout = inflater.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.custom_toast_layout));
		
//		 Toast toast = new Toast(mContext);
//         toast.setDuration(Toast.LENGTH_LONG);
//         toast.setView(toastLayout);
//         toast.show();

*/
	}

	@Override
	protected Void doInBackground(String... params) 
	{
		URL url;
		int count;

		String storeDir = Environment.getExternalStorageDirectory().toString();
		try 
		{
			url = new URL(URL);
			// String pathl = "";
			try 
			{
				File f = new File(storeDir);
				if (f.exists()) 
				{
					HttpURLConnection con = (HttpURLConnection) url.openConnection();
					InputStream is = con.getInputStream();
					String pathr = url.getPath();
					// String
					// filename=pathr.substring(pathr.lastIndexOf('/')+1);
					path = storeDir + "/" + filename;
					FileOutputStream fos = new FileOutputStream(path);
					int lenghtOfFile = con.getContentLength();
					byte data[] = new byte[1024];
					long total = 0;
					while ((count = is.read(data)) != -1) {
						total += count;
						// publishing the progress
						publishProgress((int) ((total * 100) / lenghtOfFile));
						// writing data to output file
						fos.write(data, 0, count);
					}

					is.close();
					fos.flush();
					fos.close();
				} 
				else 
				{
					Log.e("Error", "Not found: " + storeDir);

				}

				File pdfFile = new File(path);
				if (pdfFile.exists())
				{
					Uri path = Uri.fromFile(pdfFile);
					Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
					pdfIntent.setDataAndType(path, "application/pdf");
					pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

					try 
					{
						mContext.startActivity(pdfIntent);

					} 
					catch (ActivityNotFoundException e) 
					{
						Toast.makeText(mContext, "No Application available to view pdf", Toast.LENGTH_LONG)
								.show();
					}
				}

			} catch (Exception e) {
				e.printStackTrace();

			}

		} 
		catch (MalformedURLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}

	protected void onProgressUpdate(Integer... progress)
	{

		mBuilder.setProgress(100, progress[0], false);
		// Displays the progress bar on notification
		mNotifyManager.notify(0, mBuilder.build());
	}

	protected void onPostExecute(Void result) 
	{
		mBuilder.setContentText("Download complete");
		// Removes the progress bar
		mBuilder.setProgress(0, 0, false);
		mNotifyManager.notify(0, mBuilder.build());

	}

}
