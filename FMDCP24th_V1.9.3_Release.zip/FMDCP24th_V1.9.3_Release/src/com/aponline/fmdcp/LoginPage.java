package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.server.RequestServer;
import com.aponline.fmdcp.server.ServerResponseListener;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;



public class LoginPage extends AppCompatActivity implements OnClickListener,OnItemSelectedListener,ServerResponseListener
{

	Button loginBt;
	EditText loginpage_userEt,loginpage_pswEt;
	public static String UserName,Password;
	TextView errorMsg,termsandConditions;
	ProgressDialog progressDialog;
	Handler mHandler;
	Boolean isSubmited=false;
	Context context;
	EditText name,emails,cpwd;
	DBAdapter db;


	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.login_page);
		context=this;
		db=new DBAdapter(this);
		loginpage_userEt=(EditText)findViewById(R.id.loginpage_userEt);
		loginpage_pswEt=(EditText)findViewById(R.id.loginpage_pswEt);
		loginBt=(Button)findViewById(R.id.loginBt);
		findViewById(R.id.registerBt).setOnClickListener(this);
		findViewById(R.id.forgotpswTv).setOnClickListener(this);
		((TextView)findViewById(R.id.versionId)).setText("V"+HomeData.sAppVersionName);
		
		loginBt.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(loginpage_pswEt.getWindowToken(), 0);
				UserName=loginpage_userEt.getText().toString();
				Password=loginpage_pswEt.getText().toString();

				if(UserName.equals(""))
				{
					loginpage_userEt.setError("Enter User Name");
					loginpage_userEt.requestFocus();
					return;
				}
				if(Password.equals(""))
				{
					loginpage_pswEt.setError("Enter Password"); 
					loginpage_pswEt.requestFocus();
					return; 
				}
				HomeData.loginID=UserName;

				if(isNetworkAvailable(LoginPage.this))
				{
					RequestServer request=new RequestServer(LoginPage.this);
					request.addParam("UserID", UserName);
					request.addParam("password", Password);
					request.ProccessRequest(LoginPage.this, "ValidateUserDetails");
				}
				else
				{
					CheckWithLocalDbData();
				}

			}
		});

	}


	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	protected void CheckWithLocalDbData() 
	{
		db=new DBAdapter(this);
		db.open();
		String username = null,password = null;
		Cursor loginDetails=db.getTableDataCursor("Select UserID,Password,AADHARNo from Department_User_Registration where UserID='"+UserName+"'");
		if(loginDetails.getCount()>0)
		{
			if(loginDetails.moveToFirst())
			{
				username=loginDetails.getString(loginDetails.getColumnIndex("UserID"));
				password=loginDetails.getString(loginDetails.getColumnIndex("Password"));
				HomeData.userAadhaarID=loginDetails.getString(loginDetails.getColumnIndex("AADHARNo"));
			}
		}
		else
		{
			loginDetails.close();
			db.close();      
			Dialogs.AlertDialogs(LoginPage.this, "Information!!", "Data Not Found");
			return; 
		}
		loginDetails.close(); 
		db.close();

		if(!username.equalsIgnoreCase(UserName))
		{
			loginpage_userEt.setError("Enter Valid User Name");
			loginpage_userEt.requestFocus();    
			return;
		}
		if(password==null)    
		{
			AlertDialogs("Information!!", "First Time Must Login in Online");
			return;
		} 
		if(!password.equalsIgnoreCase(Password))    
		{
			loginpage_pswEt.setError("Enter Valid Password");
			loginpage_pswEt.requestFocus();
			return;
		} 
		HomeData.loginID=UserName; 
		HomeData.SaveCreadentials(LoginPage.this,UserName,Password);
		Intent i= new Intent (LoginPage.this,HomePage.class);
		startActivity(i);
		LoginPage.this.finish();
		overridePendingTransition(R.anim.left_in, R.anim.left_out);

	}


	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
		case R.id.registerBt:
			startActivity(new Intent(LoginPage.this, UserRegistration.class));
			finish();
			break;
		case R.id.forgotpswTv:

		default:
			break;
		}
	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

			//	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(FarmerRegistration.this,android.R.layout.simple_spinner_item, lables);
			//	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}
	String empdistrictName,empdivisionName,empinstitypeName,empMandalName;
	@Override
	public void onItemSelected(AdapterView<?> parent, View view,int position, long id) 
	{

		switch (parent.getId()) 
		{
		case R.id.emp_districtSp:

			empdistrictName=parent.getSelectedItem().toString().trim();  
			if(!empdistrictName.equalsIgnoreCase("--Select--"))
			{
				CommonFunctions.loadSpinnerData(LoginPage.this,"select distinct DV.DivisionName from  Master_Division DV,Master_District D "
						+ "where DV.DistrictID=D.DistrictID and trim(D.DistrictName)='"+empdistrictName+"'", ((Spinner)findViewById(R.id.emp_divisionSp)));
			}
			break;
		case R.id.emp_divisionSp:
			empdivisionName=parent.getSelectedItem().toString().trim(); 
			if(!empdivisionName.equalsIgnoreCase("--Select--"))
			{
				CommonFunctions.loadSpinnerData(LoginPage.this,"select distinct M.MandalName from Master_Mandal M,Master_Division DV,Master_District D "
						+ "where M.DistrictID=D.DistrictID and M.DivisionID=DV.DivisionID and DV.DistrictID=D.DistrictID "
						+ "and trim(D.DistrictName)='"+empdistrictName+"' and trim(DV.DivisionName)='"+empdivisionName+"'",  ((Spinner)findViewById(R.id.emp_mandalSp)));
			}
			break;

		case R.id.emp_mandalSp:

			loadSpinnerData("select distinct Institution_Type_Name from  Master_Institution_Types",((Spinner)findViewById(R.id.institutiontypeSp)));

			break;

		case R.id.institutiontypeSp:

			empinstitypeName=parent.getSelectedItem().toString().trim();
			db.open();
			String instiTypeID=db.getSingleValue("select distinct Institution_TypeID from Master_Institution_Types where trim(Institution_Type_Name)='"+empinstitypeName+"'");
			db.close();
			if(!empinstitypeName.equalsIgnoreCase("--Select--"))  
			{
				empMandalName=((Spinner)findViewById(R.id.emp_mandalSp)).getSelectedItem().toString().trim();
				CommonFunctions.loadSpinnerData(LoginPage.this,"select distinct MI.Institute_Location from Master_Institutions MI,Master_Mandal M,Master_Division DV,Master_District D "
						+ "where MI.DistrictID=D.DistrictID and MI.MandalID=M.MandalID and MI.DivisionID=DV.DivisionID and "
						+ "M.DivisionID=DV.DivisionID and D.DistrictID=DV.DistrictID "
						+ "and trim(MI.Institution_TypeID)='"+instiTypeID+"' and trim(D.DistrictName)='"+empdistrictName+"' and "
						+ "trim(DV.DivisionName)='"+empdivisionName+"' and trim(M.MandalName)='"+empMandalName+"'",  ((Spinner)findViewById(R.id.Location_InstitutionSp)));

			}
			break;

		default:
			break;
		}
	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) 
	{
		// TODO Auto-generated method stub

	}

	boolean doubleBackToExitPressedOnce = false;
	@Override
	public void onBackPressed() 
	{
		try 
		{
			if (doubleBackToExitPressedOnce)
			{
				super.onBackPressed();
				return;
			}
			this.doubleBackToExitPressedOnce = true;
			//			findViewById(R.id.main2).setVisibility(8);
			//			findViewById(R.id.main1).setVisibility(0);
			Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					doubleBackToExitPressedOnce=false;
				}
			}, 2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void Success(String response)
	{
		HomeData.SaveCreadentials(LoginPage.this,UserName,Password);
		Intent i= new Intent (LoginPage.this,HomePage.class);
		startActivity(i);
		LoginPage.this.finish();
		overridePendingTransition(R.anim.left_in, R.anim.left_out);
	}
	@Override
	public void Fail(String response) 
	{
		AlertDialogs("Information!!", response);
	}
	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(LoginPage.this,AppUpdatePage.class));
		finish();
		overridePendingTransition(R.anim.left_in, R.anim.left_out);
		return;
	}

}
