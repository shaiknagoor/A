package com.aponline.fmdcp.server;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import com.aponline.fmdcp.CommonFunctions;
import com.aponline.fmdcp.HomeData;
import com.aponline.fmdcp.database.DBAdapter;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class WebserviceCall implements ErrorCodes
{

	/**
	 * Variable Decleration................
	 * 
	 */
	// http://www.sandbyshg.ap.gov.in/SandTabDownLoadFile/DownloadFile.aspx
	String TransDate;
	String TotalTrans;
	public static String Error,Data,msg;
	StringBuilder stringBuilder;
	String namespace = "http://tempuri.org/";
	private String url;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	Context paramContext;  
	DBAdapter db;
	public static String serverResponse;
	public static int serverUploadcount;
	public static String reachId;
	public static String districtId;
	public static String ppcId;
	public static String LatestAppversion;

	public static HashMap<String, String> paramList=new HashMap<String, String>();


	public WebserviceCall(Context paraContext) 
	{
		this.paramContext = paraContext;
		db = new DBAdapter(paraContext);
		this.url = HomeData.url;
	}

	public int ValidateUserDetails(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="FMDCP24_Mobile_ValidateUserDetails";//"ValidateUserDetails_Mobile";
			Log.e("Method Name", methodName);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//password=test@123; UserID=693767192760; VersionID=1;
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			request.addProperty("VersionID",HomeData.sAppVersion);


			//request.addProperty("VersionID","1.0");
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get Login Details", result);
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()>0)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					//					if(Data.equalsIgnoreCase("Update Version"))
					//					{
					return mUpdateVersion;
					//	}
				}
				if(!jsonObject.equals(null))
				{
					ContentValues contentValues=new ContentValues();
					contentValues.put("UserID", paramList.get("UserID"));
					contentValues.put("Password", paramList.get("password"));
					contentValues.put("AADHARNo", jsonObject.optString("AADHARNo"));
					
					String lc_emp=jsonObject.getString("EmployeeName").toUpperCase();
					
					contentValues.put("DeptRegID",jsonObject.optString("DeptRegID"));
					contentValues.put("DistrictID",jsonObject.optString("DistrictID"));
					contentValues.put("DivisionID ",jsonObject.optString("DivisionID"));
					contentValues.put("MandalID",jsonObject.optString("MandalID"));
					contentValues.put("LocationOfInstitutionID ",jsonObject.optString("LocationOfInstitutionID"));
					contentValues.put("TypeOfInstitution ",jsonObject.optString("TypeOfInstitution"));
					contentValues.put("EmployeeID ",jsonObject.optString("EmployeeID"));
					contentValues.put("EmployeeName ",jsonObject.optString("EmployeeName"));
					contentValues.put("GenderID ",jsonObject.optString("GenderID"));
					contentValues.put("Designation ",jsonObject.optString("Designation"));
					contentValues.put("MobileNo ",jsonObject.optString("MobileNo"));

					
					HomeData.userAadhaarID=jsonObject.optString("AADHARNo");
					HomeData.loginID=paramList.get("UserID");
					db.open();
					db.deleteTableData("Department_User_Registration", "UserID='"+paramList.get("UserID")+"'");
					db.insertTableDate("Department_User_Registration", contentValues);
					db.close();
					return mSuccess;
				}
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}


	public int GetForgotPassword() 
	{
		try 
		{
			String methodName="GetForgotPassword";
			Log.e("Method Name", methodName);
			Log.e("Device ID", HomeData.sDeviceId);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("userID", "");
			request.addProperty("deviceID",HomeData.sDeviceId);
			request.addProperty("versionID",HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			if(result.contains("Error"))
			{
				JSONArray jsonArray=new JSONArray(result);
				if(jsonArray.length()>0)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(0);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.optString("Error"); 
						if(Error.equalsIgnoreCase("UPDATE NEW VERSION"))
						{
							return 500;
						}
						return 100;
					}
					if(!jsonObject.equals(null))
					{
					}
				}
			}
			if(result.contains("Data"))
			{
				JSONArray jsonArray=new JSONArray(result);
				if(jsonArray.length()>0)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(0);
					Data=jsonObject.optString("Data").toString(); 
					if(Data.equalsIgnoreCase("Update Version"))
					{
						return 500;
					}
				}
			}
			if(result.equalsIgnoreCase("true"))
			{
				return 12;
			}
			else
			{
				return 13;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return 10;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int GetFarmerFMDDetails_Mobile() 
	{
		try 
		{

			String methodName="FMDCP24_Mobile_GetFarmerFMDDetails";//"GetFarmerFMDDetails_Mobile";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);  
			request.addProperty("UserID", HomeData.loginID);
			request.addProperty("VersionID",HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get Login Details", result);
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()>0)
			{
				JSONArray jarray1=jsonArray.getJSONArray(0);
				JSONObject jsonObject=jarray1.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					return mUpdateVersion;
				}
				for(int i=0;i<jarray1.length();i++)
				{

					JSONObject jsonObject1=jarray1.getJSONObject(i);
					if (!jsonObject1.equals(null)) 
					{
						if(i==0)
						{
							db.open();
							db.execSQL("delete from FARMER_REG_DETAILS where Created_By='"+HomeData.userAadhaarID+"' and Is_Sync!='N'");   
							db.execSQL("delete from FMD_Vaccination_Details where CreatedBy='"+HomeData.userAadhaarID+"' and Is_Sync!='N'"); 
							db.close();
						}  
						ContentValues FarmerDetails=new ContentValues();
						FarmerDetails.put("Aadhar_No",jsonObject1.optString("AADHARNo"));
						FarmerDetails.put("Farmer_Name",jsonObject1.optString("FarmerName"));
						FarmerDetails.put("Mobile_No",jsonObject1.optString("MobileNo"));
						FarmerDetails.put("Male_White_Cattle",jsonObject1.optString("WhiteCattleMale"));
						FarmerDetails.put("Male_Buffaloes",jsonObject1.optString("BuffalloesMale"));
						FarmerDetails.put("Female_White_Cattle",jsonObject1.optString("WhiteCattleFemale"));
						FarmerDetails.put("Female_Buffaloes",jsonObject1.optString("BuffalloesFemale"));
						FarmerDetails.put("Gender",jsonObject1.optString("GenderID"));
						FarmerDetails.put("District_Id",jsonObject1.optString("DistrictID"));
						FarmerDetails.put("Mandal_Id",jsonObject1.optString("MandalID"));
						FarmerDetails.put("Village_Id",jsonObject1.optString("VillageID"));
						FarmerDetails.put("Social_Status",jsonObject1.optString("SocialStatusID"));
						FarmerDetails.put("Is_Sync","Y");
						//	FarmerDetails.put("Created_Date",createdDate1);
						FarmerDetails.put("Created_By",HomeData.userAadhaarID);

						db.open();
						db.deleteTableData("FARMER_REG_DETAILS", "Aadhar_No='"+jsonObject1.optString("AADHARNo")+"' and Created_By='"+HomeData.userAadhaarID+"'");
						db.insertTableDate("FARMER_REG_DETAILS",FarmerDetails);
						db.close(); 

						String FMDVaccDetID=jsonObject1.optString("FMDVaccDetID");
						if(FMDVaccDetID!=null && !FMDVaccDetID.equalsIgnoreCase("null") && !FMDVaccDetID.equalsIgnoreCase(""))
						{

							ContentValues VaccinationDetails=new ContentValues();
							VaccinationDetails.put("FarmerRegID",jsonObject1.optString("AADHARNo"));  
							VaccinationDetails.put("BatchNo",jsonObject1.optString("BatchOrBrewNo")); 
							VaccinationDetails.put("DateOfVaccination",jsonObject1.optString("DateOfVaccination")); 
							VaccinationDetails.put("WhiteCattle_NoUsedForDraught",jsonObject1.optString("WhiteCattle_NoUsedForDraught"));  
							VaccinationDetails.put("WhiteCattle_Male_vaccinated",jsonObject1.optString("WhiteCattle_Male_vaccinated"));  
							VaccinationDetails.put("WhiteCattle_Female_vaccinated",jsonObject1.optString("WhiteCattle_Female_vaccinated"));  
							VaccinationDetails.put("WhiteCattle_NumberOfAnimalsPregnant",jsonObject1.optString("WhiteCattle_NumberOfAnimalsPregnant"));  
							VaccinationDetails.put("Buffalo_NoUsedForDraught",jsonObject1.optString("Buffalo_NoUsedForDraught"));  
							VaccinationDetails.put("Buffalo_Male_vaccinated",jsonObject1.optString("Buffalo_Male_vaccinated"));  
							VaccinationDetails.put("Buffalo_Female_vaccinated",jsonObject1.optString("Buffalo_Female_vaccinated"));
							VaccinationDetails.put("Buffalo_NumberOfAnimalsPregnant",jsonObject1.optString("Buffalo_NumberOfAnimalsPregnant")); 
							VaccinationDetails.put("Buffalo_Male_AnimalsNotVaccinated_Reason",jsonObject1.optString("Buffalo_Male_AnimalsNotVaccinated_Reason"));  
							VaccinationDetails.put("Buffalo_FeMale_AnimalsNotVaccinated_Reason",jsonObject1.optString("Buffalo_FeMale_AnimalsNotVaccinated_Reason")); 
							VaccinationDetails.put("WhiteCattle_Male_AnimalsNotVaccinated_Reason",jsonObject1.optString("WhiteCattle_Male_AnimalsNotVaccinated_Reason"));  
							VaccinationDetails.put("WhiteCattle_FeMale_AnimalsNotVaccinated_Reason",jsonObject1.optString("WhiteCattle_FeMale_AnimalsNotVaccinated_Reason"));
							VaccinationDetails.put("NoOfDosesRemaining",jsonObject1.optString("NoOfDosesRemaining"));
							VaccinationDetails.put("SeqID",jsonObject1.optString("SequenceNo"));
							VaccinationDetails.put("Latitude",jsonObject1.optString("Latitude"));
							VaccinationDetails.put("Longitude",jsonObject1.optString("Longitude"));
							VaccinationDetails.put("Is_Sync","Y");
							VaccinationDetails.put("IsActive","Y");
							VaccinationDetails.put("CreatedBy",HomeData.userAadhaarID);
							VaccinationDetails.put("CreatedDate",jsonObject1.optString("DateOfVaccination"));
							VaccinationDetails.put("ModifiedBy",HomeData.userAadhaarID);
							//	VaccinationDetails.put("ModifiedDate",createdDate);

														
							db.open();
							db.deleteTableData("FMD_Vaccination_Details", "FarmerRegID='"+jsonObject1.optString("AADHARNo")+"' and CreatedBy='"+HomeData.userAadhaarID+"'");
							db.insertTableDate("FMD_Vaccination_Details",VaccinationDetails);
							db.close();
						}
					}
				}
				JSONArray jarray2=jsonArray.getJSONArray(1);
				for(int i=0;i<jarray2.length();i++)
				{

					JSONObject jsonObject1=jarray2.getJSONObject(i);
					if (!jsonObject1.equals(null)) 
					{
						db.open();
						if(i==0)
						{
							db.deleteTableData("FMD_VaccinationDoneBy_Details", "CreatedBy='"+HomeData.userAadhaarID+"'");
						}
						ContentValues VaccinationDoneByDetails=new ContentValues();
						VaccinationDoneByDetails.put("FarmerRegID",jsonObject1.optString("FarmerAadhaarNo"));  
						VaccinationDoneByDetails.put("VaccDoneBy_Name",jsonObject1.optString("Name")); 
						VaccinationDoneByDetails.put("VaccDoneBy_Aadhar",jsonObject1.optString("AadharNo")); 
						VaccinationDoneByDetails.put("VaccDoneBy_Designation",jsonObject1.optString("Designation"));  
						VaccinationDoneByDetails.put("CreatedBy",HomeData.userAadhaarID);  
						VaccinationDoneByDetails.put("Is_Sync","Y");  

						db.insertTableDate("FMD_VaccinationDoneBy_Details",VaccinationDoneByDetails);
						db.close();
					}

				}
				return mSuccess;
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}

	}  
	public int InsertUserRegistrationDetails(HashMap<String, String> paramList)
	{ 
		try 
		{
			String methodName="InsertUserRegistrationDetails_Mobile";  //VOLOGIN METHOD
			Log.e("Method Name", methodName);
			Log.e("Device ID", HomeData.sDeviceId);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			//request.addProperty("DeviceId",HomeData.sDeviceId);
			request.addProperty("VersionID",HomeData.sAppVersion);
			//DeviceID=865770025678661; XML=<DeptUserRegistraion><AADHARNo>654321098766</AADHARNo><DistrictID>4</DistrictID><DivisionID>5</DivisionID><MandalID></MandalID><LocationOfInstitutionID></LocationOfInstitutionID><TypeOfInstitution></TypeOfInstitution><EmployeeName>anshu</EmployeeName><Designation>5</Designation><MobileNo>9870878078</MobileNo><EmployeeID>empansh1</EmployeeID><BankName></BankName><AccountNo></AccountNo><IFSCCode></IFSCCode><BranchName></BranchName><Gender>1</Gender><Longitude>78.3679631</Longitude><Latitude>17.4589151</Latitude><Image></Image></DeptUserRegistraion>; VersionID=1;			



			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true; 
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 
			androidHttpTransport.call(SOAP_ACTION, envelope);
			serverResponse = envelope.getResponse().toString();//[{"Message":"True"}]
			//[{"Error":"Parameter is not valid."}]
			//[{"Error":"User Alredy Exists"}]
			Log.d("InsertUserReistratin", serverResponse);//58546543688
			JSONArray jArray= new JSONArray(serverResponse);

			if(jArray.length()>0)
			{
				JSONObject jsonObject=jArray.getJSONObject(0);
				if(jsonObject.has("Message"))
				{
					msg=jsonObject.optString("Message");
					if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exist"))
					{
						return mSuccess;
					}
					else
					{
						WebserviceCall.Error="Upload Failed, Please Try Again!!";
						return mFailure;
					}

				}
				else if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				else if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 

					return mUpdateVersion;

				}

			}
			else
			{
				Error="Upload Failed,please try again";
				return mFailure;
			}

		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;

	}
	public int GetVaccineDetails_Mobile() 
	{
		try
		{

			String methodName="FMDCP24_Mobile_GetVaccineDetails";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName; 
			request = new SoapObject(namespace, methodName);
			//ReceivedDate=8/8/2016; ReceivedQty=4000; Remarks=; VacDisDetID=16; UserID=693767192760; DeviceID=865770025678661;
			request.addProperty("UserID", HomeData.loginID);
			request.addProperty("VersionID", HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);

			envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);

			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			serverResponse = envelope.getResponse().toString();
			//[{"VacRecID":9,"DeptRegID":217,"BatchOrBrewNo":"AT2000","ManufacturingCompany":1,"ManufacturingDate":"\/Date(1420655400000)\/","ExpiryDate":"\/Date(1502821800000)\/","NoOfDoses":2500,"VaccinedDoses":8,"AvailableDoses":2492},{"VacRecID":10,"DeptRegID":217,"BatchOrBrewNo":"BT30000","ManufacturingCompany":2,"ManufacturingDate":"\/Date(1470508200000)\/","ExpiryDate":"\/Date(1507401000000)\/","NoOfDoses":1000,"VaccinedDoses":10,"AvailableDoses":990}]
			//[{"VacRecID":9,"DeptRegID":217,"BatchOrBrewNo":"AT2000","ManufacturingCompany":1,"ManufacturingDate":"08/01/2015","ExpiryDate":"16/08/2017","Vials":50,"NoOfDoses":2500,"VaccinedDoses":8,"AvailableDoses":2492,"ReceivedDate":"16/08/2015"},{"VacRecID":10,"DeptRegID":217,"BatchOrBrewNo":"BT30000","ManufacturingCompany":2,"ManufacturingDate":"07/08/2016","ExpiryDate":"08/10/2017","Vials":20,"NoOfDoses":1000,"VaccinedDoses":10,"AvailableDoses":990,"ReceivedDate":"16/07/2016"}]
			//[{"VacRecID":6,"BatchOrBrewNo":"FMD17082016","ManufacturingCompany":1,"ManufacturingDate":"17/08/2015","ExpiryDate":"17/08/2020","Vials":50,"NoOfDoses":2500,"VaccinedDoses":null,"AvailableDoses":null,"ReceivedDate":"17/08/2015"}]
			Log.d("UpdateVaccineAcknowledgement", serverResponse);

			JSONArray jsonArray=new JSONArray(serverResponse);
			if(jsonArray.length()>0)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					//Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					//	Data=jsonObject.optString("Data").toString(); 
					//					if(Data.equalsIgnoreCase("Update Version"))
					//					{
					return mErrorResFromWebServices;
					//}
				}
				for(int i=0;i<jsonArray.length();i++)
				{
					jsonObject=jsonArray.getJSONObject(i);
					if(i==0)
					{
						db.open();
						db.deleteTableData("Vaccine_Distribution_master", "Is_Sync!='N' and Created_By='"+HomeData.userAadhaarID+"'");
						db.close();
					}
					if (!jsonObject.equals(null))  
					{
						ContentValues contentValues=new ContentValues();
						contentValues.put("Manufacturing_Company",jsonObject.optString("ManufacturingCompany"));
						contentValues.put("BatchNo", jsonObject.optString("BatchOrBrewNo"));
						contentValues.put("Manufacturing_Date",jsonObject.optString("ManufacturingDate"));
						contentValues.put("Expiry_Date",jsonObject.optString("ExpiryDate"));
						contentValues.put("Receiving_Date", jsonObject.optString("ReceivedDate"));
						contentValues.put("Noofvialreceived", jsonObject.optString("Vials"));
						contentValues.put("NoOfDoses_Received", jsonObject.optString("NoOfDoses")); 
						contentValues.put("AvailDoses", jsonObject.optString("AvailableDoses"));
						contentValues.put("VaccDistributionID",jsonObject.optString("VacRecID"));
						contentValues.put("Remark", jsonObject.optString("Remark")); 
						contentValues.put("FMDCP_Round", jsonObject.optString("FmdcpRound"));
						contentValues.put("UserID", HomeData.loginID);
						contentValues.put("Created_By ",HomeData.userAadhaarID);
						contentValues.put("Is_Ack", "Y");
						contentValues.put("Is_Sync", "Y");
						db.open();
						db.insertTableDate("Vaccine_Distribution_master", contentValues);
						db.close();
					}
				}
				return mSuccess;
			}
			else
			{
				//Error= "Data Not Found";
				return mErrorResFromWebServices;
			}

		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}
	public int UploadOfflineData(HashMap<String, String> paramList)
	{

		serverUploadcount=0;
		ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();

		try 
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("Select distinct AUTO_ID,METHOD_NAME,Aadhaar_No,XMLDATA from UPLOAD_OFFLINEDATA where UPLOAD_STATUS='N'");
			if(cursor.getCount()>0)
			{
				if(cursor.moveToFirst())
				{
					do
					{
						ArrayList<String> localArrayList=new ArrayList<String>();
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("METHOD_NAME"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("Aadhaar_No"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("XMLDATA"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("AUTO_ID"))));
						data.add(localArrayList);
					}while(cursor.moveToNext());
				}
			}
			cursor.close(); 
			db.close();
			if(data.size()<=0)  
			{
				Error="Data Not Found";

				return mErrorResFromWebServices;
			}
			for(int i=0;i<data.size();i++)
			{
				ArrayList<String> localArrayList=data.get(i);
				String methodName=localArrayList.get(0);
				String aadharNo=localArrayList.get(1);
				String xmldoc=localArrayList.get(2);
				String autoId=localArrayList.get(3);
				Log.e("Method Name", methodName);
				Log.d("XMLDOC",xmldoc);

				SOAP_ACTION = namespace + methodName;
				request = new SoapObject(namespace, methodName);
				for ( String key : paramList.keySet() )
				{
					request.addProperty(key,paramList.get(key));
					Log.e(key, paramList.get(key));
				}
				request.addProperty("UserID", HomeData.loginID);
				request.addProperty("XML", xmldoc);
				request.addProperty("VersionID", HomeData.sAppVersion);
				request.addProperty("DeviceID", HomeData.sDeviceId); 
				CommonFunctions.writeLog("WebService", "InsertFMDDetails", request.toString());

				//DeviceID=865770025678661; UserID=693767192760; XML=<FarmerUserRegistraion><AADHARNo>908765432123</AADHARNo><FarmerName>asdf</FarmerName><Gender>1</Gender><MobileNo>9858785482</MobileNo><VillageID>926</VillageID><SocialStatusID>1</SocialStatusID><BankName>gtegj</BankName><AccNo>1235</AccNo><IFSCCode>hh56</IFSCCode><BranchName>hyd</BranchName><WhiteCattleMale>5</WhiteCattleMale><WhiteCattleFemale>4</WhiteCattleFemale><BuffaloesMale>5</BuffaloesMale><BuffaloesFemale>4</BuffaloesFemale><Sheep>1</Sheep><Goats>1</Goats><Pigs>1</Pigs><Dogs>1</Dogs><Backyardpoultry>1</Backyardpoultry><commercialLayers>1</commercialLayers><commercialBroilers>1</commercialBroilers><Ducks>1</Ducks><FodderCultivated>10</FodderCultivated><CattleShedAttached>true</CattleShedAttached><CowMilkProduced>20</CowMilkProduced><CowMilkSold>20</CowMilkSold><BuffeloMilkProduced>20</BuffeloMilkProduced><BuffeloMilkSold>20</BuffeloMilkSold></FarmerUserRegistraion>; VersionID=1;
				envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
				envelope.dotNet=true;
				envelope.setOutputSoapObject(request); 
				// Make the soap call.
				androidHttpTransport = new HttpTransportSE(url,120000);
				androidHttpTransport.debug = true;
				androidHttpTransport.call(SOAP_ACTION, envelope);
				
				serverResponse = envelope.getResponse().toString();
				Log.d("InserFMDDetails", serverResponse);
				
				JSONArray jArray= new JSONArray(serverResponse);

				if(jArray.length()>0)
				{
					JSONObject jsonObject=jArray.getJSONObject(0);
					if(jsonObject.has("Message"))
					{
						msg=jsonObject.optString("Message");
						if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exist"))
						{
							serverUploadcount++;
							ContentValues data1=new ContentValues();
							data1.put("UPLOAD_STATUS", "Y");
							db.open();
							db.updateTableData("UPLOAD_OFFLINEDATA", data1, "AUTO_ID='"+autoId+"'");
							db.close();
						}
						//						else
						//						{
						//							WebserviceCall.Error="Upload Failed, Please Try Again!!";
						//							return mFailure;
						//						}

					}
					else if(jsonObject.has("Error"))
					{
						Error=jsonObject.optString("Error"); 
						return mErrorResFromWebServices;
					}
					else if(jsonObject.has("Data"))
					{
						Data=jsonObject.optString("Data").toString(); 

						return mUpdateVersion;

					}

				}
			}
			if(serverUploadcount>0)
			{
				return mSuccess;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}

	public int InsertVaccineReceivingDetails_Mobile()
	{
		serverUploadcount=0;
		ArrayList<HashMap<String, String>> data=new ArrayList<HashMap<String,String>>();
		try 
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("select * from Vaccine_Distribution_master where Is_Sync!='Y' and Created_By='"+HomeData.userAadhaarID+"'");
			if(cursor.getCount()>0)
			{
				if(cursor.moveToFirst())
				{
					do
					{
						HashMap<String, String> localArrayList=new HashMap<String, String>();
						localArrayList.put("BatchOrBrewNo", cursor.getString(cursor.getColumnIndex(("BatchNo"))));
						localArrayList.put("ManufacturingCompanyID", cursor.getString(cursor.getColumnIndex(("Manufacturing_Company"))));
						 
						
						String manifDate=cursor.getString(cursor.getColumnIndex(("Manufacturing_Date")));
						String expiryDate=cursor.getString(cursor.getColumnIndex(("Expiry_Date")));
						String recDate=cursor.getString(cursor.getColumnIndex(("Receiving_Date")));
						
						SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy"); 
						Date date1=(Date)sdf1.parse(manifDate);
						Date date2 = (Date)sdf1.parse(expiryDate);
						Date date3 = (Date)sdf1.parse(recDate);
						manifDate=new SimpleDateFormat("MM/dd/yyyy").format(date1);
						expiryDate=new SimpleDateFormat("MM/dd/yyyy").format(date2);
						recDate=new SimpleDateFormat("MM/dd/yyyy").format(date3);
					
						localArrayList.put("ManufacturingDate",manifDate);
						localArrayList.put("ExpiryDate", expiryDate);
						localArrayList.put("ReceivedQuantity", cursor.getString(cursor.getColumnIndex(("Noofvialreceived"))));
						localArrayList.put("ReceivedDate", recDate);
						localArrayList.put("Remarks", cursor.getString(cursor.getColumnIndex(("Remark"))));
						localArrayList.put("SequenceNo", cursor.getString(cursor.getColumnIndex(("VaccDistributionID"))));
						localArrayList.put("Is23or24", cursor.getString(cursor.getColumnIndex(("FMDCP_Round"))));

						data.add(localArrayList);
					}while(cursor.moveToNext());
				}
			}
			cursor.close(); 
			db.close();
			if(data.size()<=0)  
			{
				Error="Data Not Found";
				return mErrorResFromWebServices;
			}
			for(int i=0;i<data.size();i++)
			{
				HashMap<String, String> paramList=data.get(i);


				String methodName="FMDCP24_Mobile_InsertVacineReceivingDetails";//"InsertVacineReceivingDetails_Mobile";
				Log.e("Method Name", methodName);
				SOAP_ACTION = namespace + methodName;
				request = new SoapObject(namespace, methodName);
				for ( String key : paramList.keySet() )
				{
					request.addProperty(key,paramList.get(key));
					Log.e(key, paramList.get(key));
				}
				request.addProperty("UserID", HomeData.loginID);
				request.addProperty("DeviceID", HomeData.sDeviceId);
				request.addProperty("VersionID", HomeData.sAppVersion);
				//InsertVacineReceivingDetails_Mobile{SequenceNo=V9ABD744BCBA; Is22or23=23; Remarks=; ReceivedQuantity=2; BatchOrBrewNo=BT231; ManufacturingDate=11/26/2016; ExpiryDate=07/26/2017; ReceivedDate=02/07/2017; ManufacturingCompanyID=1; UserID=726911531473; DeviceID=865770025678659; VersionID=8; } 
				envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
				envelope.dotNet=true;
				envelope.setOutputSoapObject(request); 
				// Make the soap call.
				androidHttpTransport = new HttpTransportSE(url,70000);
				androidHttpTransport.debug = true;
				androidHttpTransport.call(SOAP_ACTION, envelope);
				serverResponse = envelope.getResponse().toString();//[{"Message":"False"}]
				Log.d("InserFMDDetails", serverResponse);

				JSONArray jArray= new JSONArray(serverResponse);

				if(jArray.length()>0)
				{
					JSONObject jsonObject=jArray.getJSONObject(0);
					if(jsonObject.has("Message"))
					{
						msg=jsonObject.optString("Message");
						if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exist"))
						{
							serverUploadcount++;
							ContentValues data1=new ContentValues();
							data1.put("Is_Sync", "Y");
							db.open();
							db.updateTableData("Vaccine_Distribution_master", data1, "VaccDistributionID='"+paramList.get("SequenceNo")+"'");
							db.close();
						}
					}
					else if(jsonObject.has("Error"))
					{
						Error=jsonObject.optString("Error"); 
						return mErrorResFromWebServices;
					}
					else if(jsonObject.has("Data"))
					{
						Data=jsonObject.optString("Data").toString(); 
						return mUpdateVersion;
					}
				}
			}
			if(serverUploadcount>0)
			{
				return mSuccess;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}
	public int InsertUserInstitutionLocation_Mobile(HashMap<String, String> paramList)
	{
		//serverUploadcount=0;
		ArrayList<HashMap<String, String>> data=new ArrayList<HashMap<String,String>>();

		try 
		{

			String methodName="InsertUserInstitutionLocation_Mobile";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			request.addProperty("UserID", HomeData.loginID);
			request.addProperty("DeviceID", HomeData.sDeviceId);
			request.addProperty("VersionID", HomeData.sAppVersion);
			//{ExpiryDate=08/16/2017; ReceivedQuantity=10; ManufacturingCompanyID=1; ReceivedDate=08/16/2015; Remarks=; SequenceNo=V6F95F5B8E53; BatchOrBrewNo=AT2000; ManufacturingDate=01/08/2015; UserID=233344027170; DeviceID=868159026563606; VersionID=2; }
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			serverResponse = envelope.getResponse().toString();
			Log.d("InserFMDDetails", serverResponse);

			JSONArray jArray= new JSONArray(serverResponse);

			if(jArray.length()>0)
			{
				JSONObject jsonObject=jArray.getJSONObject(0);
				if(jsonObject.has("Message"))
				{
					msg=jsonObject.optString("Message");
					if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exist"))
					{
						return mSuccess;
					}
				}
				else if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				/*	serverUploadcount++;
							ContentValues data1=new ContentValues();
							data1.put("Is_Sync", "Y");
							db.open();
							db.updateTableData("Vaccine_Distribution_master", data1, "VaccDistributionID='"+paramList.get("SequenceNo")+"'");
							db.close();*/
				else if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					return mUpdateVersion;
				}
			}

			//			if(serverUploadcount>0)
			//			{
			//				return mSuccess;
			//
			//			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}
	
		
	
	public int Get_MandalMasterDetails(HashMap<String, String> paramList)
	{

		try 
		{
			String methodName="FMDCP24_Mobile_GetMasterMandalsVillages";       //FMDCP24 
			Log.e("Method Name", methodName);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			request.addProperty("VersionID",HomeData.sAppVersion);

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get MasterMandals_Villages Details", result);
			JSONArray jsonArray=new JSONArray(result);
			
			if(jsonArray.length()==2)
			{

				JSONArray mandals_jsonArray = jsonArray.getJSONArray(0);
				JSONArray villages_jsonArray = jsonArray.getJSONArray(1);

				if (mandals_jsonArray.length() > 0) // 3
				{
					for (int i = 0; i < mandals_jsonArray.length(); i++) //
					{

						JSONObject mandals_jsonObject = mandals_jsonArray.getJSONObject(i);

						if (!mandals_jsonObject.equals(null))
						{
							ContentValues contentValues = new ContentValues();
							contentValues.put("DistrictID", mandals_jsonObject.optString("DistrictID"));
							contentValues.put("DivisionID ", mandals_jsonObject.optString("DivisionID"));
							contentValues.put("MandalID ", mandals_jsonObject.optString("MandalID"));
							contentValues.put("MandalName", mandals_jsonObject.optString("MandalName"));

							contentValues.put("CreatedBy", mandals_jsonObject.optString("CreatedBy"));
							contentValues.put("CreatedDate", mandals_jsonObject.optString("CreatedDate"));
							contentValues.put("IsActive", mandals_jsonObject.optString("IsActive"));

							db.open();
							String qry="select count(*) from Master_Mandal where DistrictID='"+mandals_jsonObject.optString("DistrictID")+"' and DivisionID='"+mandals_jsonObject.optString("DivisionID")+"' and  MandalID='"+mandals_jsonObject.optString("MandalID")+"'";
							int count=db.getRowCount(qry);
							if(count==0)
							{
								 db.insertTableDate("Master_Mandal", contentValues);
							}
							db.close();
						}
					}
				}

				if (villages_jsonArray.length() > 0) // 3
				{

					for (int j = 0; j < villages_jsonArray.length(); j++) 
					{

						JSONObject villages_jsonObject = villages_jsonArray.getJSONObject(j);

						if (!villages_jsonObject.equals(null))
						{

							ContentValues contentValues = new ContentValues();
							contentValues.put("DistrctID", villages_jsonObject.optString("DistrictID"));
							contentValues.put("DivisionID ", villages_jsonObject.optString("DivisionID"));
							contentValues.put("MandalID ", villages_jsonObject.optString("MandalID"));

							contentValues.put("VillageID", villages_jsonObject.optString("VillageID"));
							contentValues.put("VillageName", villages_jsonObject.optString("VillageName"));

							contentValues.put("CreatedBy", villages_jsonObject.optString("CreatedBy"));
							contentValues.put("CreatedDate", villages_jsonObject.optString("CreatedDate"));
							contentValues.put("IsActive", villages_jsonObject.optString("IsActive"));

							db.open();
							String qry="select count(*) from Master_Village where DistrctID='"+villages_jsonObject.optString("DistrictID")+"' and DivisionID='"+villages_jsonObject.optString("DivisionID")+"' and  MandalID='"+villages_jsonObject.optString("MandalID")+"'and VillageID='"+villages_jsonObject.optString("VillageID")+"'";
							int count=db.getRowCount(qry);
							if(count==0)
							{
								db.insertTableDate("Master_Village", contentValues);
							}
							db.close();
					
						}
					}

				}

				return mSuccess;
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return mException;
		}
			
	}
	

	public int FMDCP_UserFeedBack(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="FMDCP24_Mobile_UserFeedBack";
			Log.e("Method Name", methodName);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			request.addProperty("UserId",HomeData.loginID);
			request.addProperty("VersionID",HomeData.sAppVersion);
			request.addProperty("DeviceID",HomeData.sDeviceId);
		
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get FEEDBACK Details", result);



			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()>0)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					//	if(Data.equalsIgnoreCase("Update Version"))
					//	{
					return mUpdateVersion;
					//	}
				}


				if(!jsonObject.equals(null))
				{
					if(jsonObject.has("Message"))
					{
						msg=jsonObject.optString("Message");
						if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exists"))
						{
							return mSuccess;

						}

					}					

					//return mSuccess;
				}
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}

}
