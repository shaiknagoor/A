package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.server.RequestServer;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

public class ReportsMenuPage extends AppCompatActivity implements OnClickListener
{

	ActionBar ab;
	int i=0;
	ArrayList<ArrayList<String>> list;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reports_menupage);
		ab=getSupportActionBar();
		ab.setTitle("Report");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		
		findViewById(R.id.Reports_VaccinationReceiptReport_Btn).setOnClickListener(this);
		findViewById(R.id.Reports_VaccinationDetail_Btn).setOnClickListener(this);
		findViewById(R.id.Reports_FarmerDetail_Btn).setOnClickListener(this);
	}
	
	public void onClick(View v)
	{
		switch (v.getId())
		{
		case R.id.Reports_VaccinationReceiptReport_Btn:
			startActivity(new Intent(this, VaccineReceivedReport.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.Reports_FarmerDetail_Btn:
			startActivity(new Intent(this, FarmerDetailsReport.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.Reports_VaccinationDetail_Btn:
			startActivity(new Intent(this, VaccinationDetailsReport.class).putExtra("parent", "report"));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		default:
			break;
		}
	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
}
