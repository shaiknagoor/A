package com.aponline.fmdcp;

import java.io.ByteArrayOutputStream;

import org.kobjects.base64.Base64;

import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.server.RequestServer;
import com.aponline.fmdcp.server.ServerResponseListener;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Capturegeotag extends AppCompatActivity implements ServerResponseListener
{

	ActionBar ab;
	GPSTracker gps;
	public static double latitude,longitude;
	ImageView photoCaptureIv;

	private static final int CAMERA_REQUEST = 1888; 
	private static final int REQUEST_CAMERA = 0, SELECT_FILE = 1;
	public static String strBaseimage="";
	String locationid;
	DBAdapter db=new DBAdapter(this);

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.caputre);
		ab=getSupportActionBar();
		ab.setTitle("Capture Institute Photo");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		photoCaptureIv=(ImageView) findViewById(R.id.capture_imageview);
		photoCaptureIv.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v) 
			{
				selectImage();
			}
		});



		findViewById(R.id.capture_submit).setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v) 
			{
				if(strBaseimage.equalsIgnoreCase(""))
				{
					AlertDialogs("Information!!", "Please Capture Photo");
				}
				else
				{
				db.open();
				locationid=db.getSingleValue("select LocationOfInstitutionID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
				db.close();
				RequestServer request=new RequestServer(Capturegeotag.this);
				request.addParam("Latitude", String.valueOf(latitude));
				request.addParam("Langitude", String.valueOf(longitude));
				request.addParam("Image", strBaseimage);
				request.addParam("InstitutionLocationID",locationid);
				request.ProccessRequest(Capturegeotag.this, "InsertUserInstitutionLocation_Mobile");
				}
			}
		});

	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	private void selectImage()
	{
		try {

			gps=new GPSTracker(Capturegeotag.this);
			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, REQUEST_CAMERA);


			}
			else
			{
				gps.showSettingsAlert();
			}



		}
		catch (Exception e)
		{
			e.printStackTrace();
		}


	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK)
		{

			if (requestCode == REQUEST_CAMERA)
				onCaptureImageResult(data);
		}
	}
	private void onCaptureImageResult(Intent data)
	{
		try
		{
			Bitmap photo = (Bitmap) data.getExtras().get("data");
			int width=photo.getWidth();
			int height=photo.getHeight();
			Bitmap scaled = Bitmap.createScaledBitmap(photo,width,height, true);
			photoCaptureIv.setImageBitmap(scaled);
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
			byte[] byteArray = stream.toByteArray();
			strBaseimage= Base64.encode(byteArray);

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	@Override
	public void Success(String response) 
	{
		Dialogs.AlertDialogs(this,"Information!!", "Data Successfully Uploaded");
		((ImageView)findViewById(R.id.capture_imageview)).setImageResource(R.drawable.cow_img);
	}
	@Override 
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}


	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(Capturegeotag.this,AppUpdatePage.class));
		finish();
		return;
	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
}
