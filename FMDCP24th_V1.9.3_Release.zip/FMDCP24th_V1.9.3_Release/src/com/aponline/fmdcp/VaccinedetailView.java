package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.database.DBAdapter;
import android.annotation.SuppressLint;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class VaccinedetailView extends AppCompatActivity
{

	DBAdapter db;
	TextView vdate,batchno,mfd,expd,noofdises,adharno,farmername,genderTv,mno,mandal,village,ss,fmalewc,ffwc,fmb,ffb,wcnoofmalevaccinated,buffnoofmalevaccinated,cattleusedford,buffusedford,reasonfornotvcattle,reasonffornotvacbuff,nooffemalvacccattle,nooffemalevaccbuff,noofvaccinfemalpregwc,noofvaccinatedfempregbuff,reasonfornotvaccwc,reasonfornotvsbuff;
	TextView malewhitecattle,femalewhitecattle,malebuff,femalbuff;
	String Dist_id;
	ActionBar ab;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{

		super.onCreate(savedInstanceState);
		setContentView(R.layout.vaccinationdetailview);
		ab=getSupportActionBar();
		ab.setTitle("Vaccination Details");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		db=new DBAdapter(this);
		db.open();
		Dist_id=db.getSingleValue("select DistrictID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		db.close();

		vdate=(TextView) findViewById(R.id.vaccinationddetail_vaccinedate);
		batchno=(TextView) findViewById(R.id.vaccinedetail_batchno);
		mfd=(TextView) findViewById(R.id.vaccinedetail_mfddate);
		expd=(TextView) findViewById(R.id.vaccinedetail_expdate);
		noofdises=(TextView) findViewById(R.id.vaccinedetail_noofdoses);
		farmername=(TextView) findViewById(R.id.vaccinedetail_farmername);
		genderTv=(TextView) findViewById(R.id.vaccinedetail_gender);
		mno=(TextView) findViewById(R.id.vaccinedetail_mobileno);
		mandal=(TextView) findViewById(R.id.vaccinedetail_mandal);
		village=(TextView) findViewById(R.id.vaccinedetail_village);
		ss=(TextView) findViewById(R.id.vaccinedetail_socialstatus);

		malewhitecattle=(TextView) findViewById(R.id.vaccinedetail_malewhitecattle);
		femalewhitecattle=(TextView) findViewById(R.id.vaccinedetail_femalewhitecattle);
		malebuff=(TextView) findViewById(R.id.vaccinedetail_malebuffelo);
		femalbuff=(TextView) findViewById(R.id.vaccinedetail_femalebuffelo);

		adharno=(TextView) findViewById(R.id.vaccinedetail_adharno);
		wcnoofmalevaccinated=(TextView) findViewById(R.id.fmd_whiteMaleVaccinated_Et);
		buffnoofmalevaccinated=(TextView) findViewById(R.id.fmd_buffaloMaleVaccinated_Et);
		cattleusedford=(TextView) findViewById(R.id.fmd_whiteMaleDraught_Et);
		buffusedford=(TextView) findViewById(R.id.fmd_buffaloMaleDraught_Et);
		reasonfornotvcattle=(TextView) findViewById(R.id.txt1);
		reasonffornotvacbuff=(TextView) findViewById(R.id.txt2);
		nooffemalvacccattle=(TextView) findViewById(R.id.txt3);
		nooffemalevaccbuff=(TextView) findViewById(R.id.txt4);
		noofvaccinfemalpregwc=(TextView) findViewById(R.id.txt5);
		noofvaccinatedfempregbuff=(TextView) findViewById(R.id.txt6);
		reasonfornotvaccwc=(TextView) findViewById(R.id.txt7);
		reasonfornotvsbuff=(TextView) findViewById(R.id.txt8);
		String data = getIntent().getExtras().getString("adharno");
		getdetailfromadharno(data);
		getfarmerdetail(data);

		loadVaccineDoneByDetails(data);
	}

	@SuppressLint("NewApi")
	private void loadVaccineDoneByDetails(String data) 
	{
		db.open();
		Cursor cursor1=db.getTableDataCursor("Select fmd.VaccDoneBy_Name,md.DesignationName,fmd.VaccDoneBy_Aadhar from FMD_VaccinationDoneBy_Details fmd,Master_Designation md where fmd.FarmerRegID='"+data+"' and fmd.VaccDoneBy_Designation=md.DesignationID");
		if(cursor1.getCount()>0)
		{
			if(cursor1.moveToFirst())
			{
				do
				{

					LayoutInflater inflater = getLayoutInflater();
					final View tr = (View)inflater.inflate(R.layout.row, null, false);
					((ImageButton)tr.findViewById(R.id.check)).setVisibility(8);
					((EditText)tr.findViewById(R.id.column1Et)).setText(cursor1.getString(cursor1.getColumnIndex("VaccDoneBy_Name")));
					CommonFunctions.loadSpinnerSetSelectedItem(VaccinedetailView.this,"select DesignationName from Master_Designation",(Spinner)tr.findViewById(R.id.column2Sp), cursor1.getString(cursor1.getColumnIndex("DesignationName")));
					((EditText)tr.findViewById(R.id.column3Et)).setText(cursor1.getString(cursor1.getColumnIndex("VaccDoneBy_Aadhar")));

					((LinearLayout)findViewById(R.id.VaccDoneby_tabledata)).addView(tr);

					
					((Spinner)tr.findViewById(R.id.column2Sp)).setEnabled(false);
					((EditText)tr.findViewById(R.id.column1Et)).setFocusableInTouchMode(false);
					((EditText)tr.findViewById(R.id.column3Et)).setFocusableInTouchMode(false);
				}while(cursor1.moveToNext()); 
			}
		}
		cursor1.close();
		db.close();
	}

	public void getdetailfromadharno(String adhno)
	{


		db.open();
		Cursor cursor=db.getTableDataCursor("select * from FMD_Vaccination_Details where FarmerRegID='"+adhno+"'");
		ArrayList<String> data=new ArrayList<String>();
		int noofvaccinatedanimal=0;
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{

					vdate.setText(cursor.getString(cursor.getColumnIndex("DateOfVaccination")));
					batchno.setText(cursor.getString(cursor.getColumnIndex("BatchNo")));
					wcnoofmalevaccinated.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_Male_vaccinated")));
					buffnoofmalevaccinated.setText(cursor.getString(cursor.getColumnIndex("Buffalo_Male_vaccinated")));
					cattleusedford.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_NoUsedForDraught")));
					buffusedford.setText(cursor.getString(cursor.getColumnIndex("Buffalo_NoUsedForDraught")));
					nooffemalvacccattle.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_Female_vaccinated")));
					nooffemalevaccbuff.setText(cursor.getString(cursor.getColumnIndex("Buffalo_Female_vaccinated")));
					noofvaccinfemalpregwc.setText(cursor.getString(cursor.getColumnIndex("WhiteCattle_NumberOfAnimalsPregnant")));
					noofvaccinatedfempregbuff.setText(cursor.getString(cursor.getColumnIndex("Buffalo_NumberOfAnimalsPregnant")));
					
					
					String whiteMaleResoans=cursor.getString(cursor.getColumnIndex("WhiteCattle_Male_AnimalsNotVaccinated_Reason"));
	                String buffaloMaleResoans=cursor.getString(cursor.getColumnIndex("Buffalo_Male_AnimalsNotVaccinated_Reason"));
	                
	                if(whiteMaleResoans.equalsIgnoreCase("4"))
	                {
	                	whiteMaleResoans="5";
	                }
	               // whiteMaleResoans = whiteMaleResoans == "4" ?  "5" :  whiteMaleResoans;
	                if(buffaloMaleResoans.equalsIgnoreCase("4"))
	                {
	                	buffaloMaleResoans="5";
	                }
	              //  buffaloMaleResoans = buffaloMaleResoans == "4" ?  "5" :  buffaloMaleResoans;
					
					String reson=db.getSingleValue("select Reason  from Master_Reasons  where ReasonID='"+cursor.getString(cursor.getColumnIndex("WhiteCattle_FeMale_AnimalsNotVaccinated_Reason"))+"'");
					reasonfornotvaccwc.setText(reson = reson == "0" ? "No Reason" : reson);
					reson=db.getSingleValue("select Reason  from Master_Reasons  where ReasonID='"+cursor.getString(cursor.getColumnIndex("Buffalo_FeMale_AnimalsNotVaccinated_Reason"))+"'");
					reasonfornotvsbuff.setText(reson = reson == "0" ? "No Reason" : reson);
					reson=db.getSingleValue("select Reason  from Master_Reasons  where ReasonID='"+whiteMaleResoans+"'");
					reasonfornotvcattle.setText(reson = reson == "0" ? "No Reason" : reson);
					reson=db.getSingleValue("select Reason  from Master_Reasons  where ReasonID='"+buffaloMaleResoans+"'");
					reasonffornotvacbuff.setText(reson = reson == "0" ? "No Reason" : reson);
					
					
					getdetailfrombatchno(batchno.getText().toString());
				}while(cursor.moveToNext());

			}

			cursor.close();
			db.close();


		}


	}

	public void getfarmerdetail(String d)
	{

		//	db=new DBAdapter(this);
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from FARMER_REG_DETAILS where Aadhar_No='"+d+"'");
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{

					adharno.setText(cursor.getString(cursor.getColumnIndex("Aadhar_No")));
					farmername.setText(cursor.getString(cursor.getColumnIndex("Farmer_Name")));
					String gender=cursor.getString(cursor.getColumnIndex("Gender"));
					if(gender.equalsIgnoreCase("1"))
					{
						gender="Male";
					}
					else
					{
						gender="Female";
					}
					genderTv.setText(gender);
					mno.setText(cursor.getString(cursor.getColumnIndex("Mobile_No")));

					malewhitecattle.setText(cursor.getString(cursor.getColumnIndex("Male_White_Cattle")));
					femalewhitecattle.setText(cursor.getString(cursor.getColumnIndex("Female_White_Cattle")));
					malebuff.setText(cursor.getString(cursor.getColumnIndex("Male_Buffaloes")));
					femalbuff.setText(cursor.getString(cursor.getColumnIndex("Female_Buffaloes")));

					int mandalID=cursor.getInt(cursor.getColumnIndex("Mandal_Id"));
					int villageID=cursor.getInt(cursor.getColumnIndex("Village_Id"));
					int socialStutsID=cursor.getInt(cursor.getColumnIndex("Social_Status"));

					String mandalName = db.getSingleValue("select MandalName from Master_Mandal  where MandalID='" + mandalID + "' and DistrictID='"+Dist_id+"'");
					String VillageName = db.getSingleValue("select VillageName from Master_Village  where VillageID='" + villageID + "'");
					String socialstatus = db.getSingleValue("select SocialStatusName from Master_SocialStatus  where SocialStatusID='" + socialStutsID + "'");

					mandal.setText(mandalName);
					village.setText(VillageName);
					ss.setText(socialstatus);


				}while(cursor.moveToNext()); 



			}

			cursor.close();

			db.close();
		}



	}

	public void getdetailfrombatchno(String b)
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select Manufacturing_Date,Expiry_Date,AvailDoses from Vaccine_Distribution_master where BatchNo='"+b+"'");
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{

					mfd.setText(cursor.getString(cursor.getColumnIndex("Manufacturing_Date")));
					expd.setText(cursor.getString(cursor.getColumnIndex("Expiry_Date")));
					noofdises.setText(cursor.getString(cursor.getColumnIndex("AvailDoses")));


				}while(cursor.moveToNext());

			}

			cursor.close();
			db.close();


		}

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
}
