package com.aponline.fmdcp;


import java.io.File;

import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.server.ServerResponseListener;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class HomePage extends AppCompatActivity implements OnClickListener,ServerResponseListener 
{
	DBAdapter db;
	int AvailDoses=0;
	String path = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_page);

		db=new DBAdapter(this);
		
	

		//	db.open();
		//  HomeData.userRole="5";//db.getSingleValue("select RoleID from Master_Designation R,Department_User_Registration U where R.DesignationID=U.Designation and U.AADHARNo='"+HomeData.userID+"'");
		//	db.close();

		findViewById(R.id.homepage_VaccineReceived_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_VaccinationDetails_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_ViewVaccinationReceipt_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_ViewVaccinationDetail_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_uploadVaccineReceipt_Btn).setOnClickListener(this);
		findViewById(R.id.reportBt).setOnClickListener(this);
		findViewById(R.id.homepage_userDetails_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_help_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_capture_Btn).setOnClickListener(this);
		findViewById(R.id.logout_iv).setOnClickListener(this);
		
		findViewById(R.id.homepage_usermanual_Btn).setOnClickListener(this);
		findViewById(R.id.homepage_feedback_Btn).setOnClickListener(this);
		


		findViewById(R.id.homePageContent_ll).setVisibility(0);
		findViewById(R.id.userDetails_ll).setVisibility(8);

		findViewById(R.id.userDetails_iv).setOnClickListener(this);


	}
	@Override
	public void onStart()
	{
		super.onStart();
		loadDashBoardDetails();
	}
	private void loadDashBoardDetails() 
	{

		try 
		{
			db.open();
			String userName=db.getSingleValue("select EmployeeName from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
			String recDoses=db.getSingleValue("select ifnull(sum(NoOfDoses_Received),0) as ReceivedDoses from Vaccine_Distribution_master where Is_Ack='Y' and Created_By='"+HomeData.userAadhaarID+"'");
			String usedDoses=db.getSingleValue("select ifnull(sum(ifnull(WhiteCattle_Male_vaccinated,'0')+ifnull(WhiteCattle_Female_vaccinated,0)+ifnull(Buffalo_Male_vaccinated,0)+ifnull(Buffalo_Female_vaccinated,0)),0) as UsedDoses from FMD_Vaccination_Details where CreatedBy='"+HomeData.userAadhaarID+"'");
			String totalFarmers=db.getSingleValue("select ifnull(count(distinct FarmerRegID),0) from FMD_Vaccination_Details where CreatedBy='"+HomeData.userAadhaarID+"'");
			db.close();

			((TextView)findViewById(R.id.receiveddoses_txtview)).setText(" "+recDoses);
			((TextView) findViewById(R.id.useddoses_txt)).setText(" "+usedDoses);
			AvailDoses=(Integer.parseInt(recDoses)-Integer.parseInt(usedDoses));
			((TextView) findViewById(R.id.available_txt)).setText(" "+AvailDoses);
			((TextView) findViewById(R.id.animalvaccinated_txt)).setText(" "+usedDoses);
			((TextView) findViewById(R.id.farmercovered_txt)).setText(" "+totalFarmers);


			((TextView) findViewById(R.id.userName_scrollTv)).setText("***** Welcome To  : "+userName + " *****");
			((TextView) findViewById(R.id.userName_scrollTv)).startAnimation((Animation)AnimationUtils.loadAnimation(HomePage.this,R.anim.text_translate));
		} 
		catch (NumberFormatException e) 
		{

			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}
	public void onClick(View v)
	{
		switch (v.getId())
		{
		case R.id.homepage_VaccineReceived_Btn:
			startActivity(new Intent(HomePage.this, VaccineReceive.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.homepage_VaccinationDetails_Btn:
			if(AvailDoses>0)
			{
				startActivity(new Intent(HomePage.this, VaccinationDetails.class));
				overridePendingTransition(R.anim.left_in, R.anim.left_out);
			}
			else
				Dialogs.AlertDialogs(HomePage.this, "Information!!", "Vaccine doses are not available, Please receive the doses");
			break;
		case R.id.homepage_ViewVaccinationReceipt_Btn:
			startActivity(new Intent(HomePage.this, VaccineReceivedReport.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.homepage_ViewVaccinationDetail_Btn:
			startActivity(new Intent(HomePage.this, VaccinationDetailsReport.class).putExtra("parent", "update"));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.homepage_uploadVaccineReceipt_Btn:
//			RequestServer request=new RequestServer(HomePage.this);
//			request.ProccessRequest(HomePage.this, "UploadOfflineData");
			startActivity(new Intent(HomePage.this, DeviceMGNT.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.reportBt:
			startActivity(new Intent(HomePage.this, ReportsMenuPage.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
			//		case R.id.homepage_uploadVaccineDetail_Btn:
			//			RequestServer request1=new RequestServer(HomePage.this);
			//			request1.addParam("DeviceID", HomeData.sDeviceId);
			//			request1.ProccessRequest(HomePage.this, "UploadOfflineData");
			//			break;
		case R.id.homepage_userDetails_Btn:
			if(!isShowingUserDetails)
				ShowUserDetails();
			break;
		case R.id.homepage_help_Btn:
			startActivity(new Intent(HomePage.this, Help.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
			
		case R.id.homepage_usermanual_Btn:
			boolean mExist = filexist();
			if(mExist)
			{
				try
				{
					viewfile();
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				DownloadAlert("http://ahd.aponline.gov.in/AHMS/views/Downloads/FMDCP1stround%20guidlines2017-18.pdf", "FMDCP1stround%20guidlines2017-18.pdf");

			}
			break;

		case R.id.homepage_capture_Btn:
			startActivity(new Intent(HomePage.this, Capturegeotag.class));

			break;
			
		case R.id.homepage_feedback_Btn://feedback
			startActivity(new Intent(HomePage.this, FeedbackPage.class));
			overridePendingTransition(R.anim.left_in, R.anim.left_out);
			break;
		case R.id.userDetails_iv:
			if(!isShowingUserDetails)
				ShowUserDetails();
			else
				closeUserDetails();
			break;
		case R.id.logout_iv:
			LogoutAlert();
			break;
		default:
			break;
		}
	}

	private boolean filexist()
	{
		String storeDir = Environment.getExternalStorageDirectory().toString();
		path = storeDir + "/" + "FMDCP1stround%20guidlines2017-18.pdf";
	
		File File = new File(path);
		Log.v("File", File + "  "+ File.exists());
		return File.exists();
	}

//	Dialog dialog;
//	private void showHelp()
//	{
//		dialog = new Dialog(this);
//		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
//		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation2;
//		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//		dialog.setContentView(R.layout.help);
//		dialog.setCancelable(false);
//		ImageView cancel =(ImageView)dialog.findViewById(R.id.help_cancel_btn); 
//		cancel.setOnClickListener(new View.OnClickListener() 
//		{
//			@Override
//			public void onClick(View v)
//			{
//				dialog.dismiss();
//				return;
//			}
//		}); 
//		if(!dialog.isShowing())
//			dialog.show();
//	}
	private void ShowUserDetails()
	{
		isShowingUserDetails = true;
		loadUserDetails() ;

		findViewById(R.id.userDetails_ll).setVisibility(0);


		Animation slid=AnimationUtils.loadAnimation(this, R.anim.slid_left_middle);
		findViewById(R.id.userDetails_ll).startAnimation(slid);

		//		dialog = new Dialog(this);
		//		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		//		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation2;
		//		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		//		dialog.setContentView(R.layout.user_details);
		//		dialog.setCancelable(false);
		//		loadUserDetails(dialog);
		//		Button logout =(Button)dialog.findViewById(R.id.user_logout_btn); 
		//		Button changePsw =(Button)dialog.findViewById(R.id.user_changePws_btn); 
		//		ImageView cancel =(ImageView)dialog.findViewById(R.id.userDetails_cancel_btn); 
		//		//	yes.startAnimation(shake);
		//		logout.setOnClickListener(new View.OnClickListener() 
		//		{
		//			@Override
		//			public void onClick(View v)
		//			{
		//				dialog.dismiss();
		//				HomeData.isLogOut(HomePage.this);
		//				startActivity(new Intent(HomePage.this,LoginPage.class));
		//				finish();
		//				return;
		//			}
		//		}); 
		//		cancel.setOnClickListener(new View.OnClickListener() 
		//		{
		//			@Override
		//			public void onClick(View v)
		//			{
		//				dialog.dismiss();
		//				return;
		//			}
		//		}); 
		//		if(!dialog.isShowing())
		//			dialog.show();

	}
	private void loadUserDetails() 
	{
		String designationID="",districtID="",divisionID="",mandalID="",intitutionTypeID="",intitutionLocationID="";
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		if(cursor.getCount()>0)
		{
			cursor.moveToFirst();
			((TextView)findViewById(R.id.userDetails_empName_Tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeName")));
			designationID=cursor.getString(cursor.getColumnIndex("Designation"));
			((TextView)findViewById(R.id.userDetails_empID_Tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeID")));
			((TextView)findViewById(R.id.userDetails_empAadhrNo_Tv)).setText(cursor.getString(cursor.getColumnIndex("AADHARNo")));
			((TextView)findViewById(R.id.userDetails_empMobNo_Tv)).setText(cursor.getString(cursor.getColumnIndex("MobileNo")));
			String gender=cursor.getString(cursor.getColumnIndex("GenderID"));
			if(gender.equalsIgnoreCase("1"))
				gender="Male";
			else
				gender="Female";
			((TextView)findViewById(R.id.userDetails_gender_Tv)).setText(gender);
			districtID=cursor.getString(cursor.getColumnIndex("DistrictID"));
			divisionID=cursor.getString(cursor.getColumnIndex("DivisionID"));
			mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
			intitutionTypeID=cursor.getString(cursor.getColumnIndex("TypeOfInstitution"));
			intitutionLocationID=cursor.getString(cursor.getColumnIndex("LocationOfInstitutionID"));
		}
		cursor.close();
		String designation = "", intitutionType="";
	//	String designation="VAS";//db.getSingleValue("select  DesignationName from Master_Designation where DesignationID='"+designationID+"'");
		
		if(designationID.equalsIgnoreCase("7"))    //VAS
		{
			 designation="VETERINARY ASSISTANT SURGEON";
			 intitutionType="VETERINARY DISPENSARY";

		}
		else if(designationID.equalsIgnoreCase("6"))//AVH
		{
			designation="ASSISTANT DIRECTOR";
			intitutionType="AREA VETERINARY HOSPITAL";
			
		}
		else if(designationID.equalsIgnoreCase("43"))//VPC
		{
			designation="DEPUTY DIRECTOR";
			intitutionType="VETERINARY POLYCLINIC";
		}
		else if(designationID.equalsIgnoreCase("42"))//SSVH
		{
			designation="JOINT DIRECTOR";
			intitutionType="SUPER SPECIALITY  VETERINARY HOSPITAL";
		}
		
		String district=db.getSingleValue("select distinct DistrictName from Master_District where DistrictID='"+districtID+"'");
		String division=db.getSingleValue("select distinct DivisionName from Master_Division where DivisionID='"+divisionID+"' and DistrictID='"+districtID+"'");
		String mandal=db.getSingleValue("select distinct MandalName from Master_Mandal where MandalID='"+mandalID+"' and DistrictID='"+districtID+"' and DivisionID='"+divisionID+"'");
	//	String intitutionType=db.getSingleValue("select distinct Institution_Type_Name from Master_Institution_Types where Institution_TypeID='"+intitutionTypeID+"'");
		String intitutionLocation=db.getSingleValue("select Institute_Location from Master_Institutions where InstituteID='"+intitutionLocationID+"'");
		db.close();

		((TextView)findViewById(R.id.userDetails_empDesig_Tv)).setText(designation);
		((TextView)findViewById(R.id.userDetails_District_tv)).setText(district);
		((TextView)findViewById(R.id.userDetails_Division_tv)).setText(division);
		((TextView)findViewById(R.id.userDetails_mandal_tv)).setText(mandal);
		((TextView)findViewById(R.id.userDetails_IntitutionType_tv)).setText(intitutionType);
		((TextView)findViewById(R.id.userDetails_IntitutionLocation_tv)).setText(intitutionLocation);

	}

	public void LogoutAlert()
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				HomeData.isLogOut(HomePage.this);
				Intent i=	new Intent(HomePage.this,LoginPage.class);
				startActivity(i);
				HomePage.this.finish();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	private void loadUserDetails(Dialog dialog) 
	{
		String designationID="",districtID="",divisionID="",mandalID="",intitutionTypeID="",intitutionLocationID="";
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		if(cursor.getCount()>0)
		{
			cursor.moveToFirst();
			((TextView)dialog.findViewById(R.id.userDetails_empName_Tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeName")));
			designationID=cursor.getString(cursor.getColumnIndex("Designation"));
			((TextView)dialog.findViewById(R.id.userDetails_empID_Tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeID")));
			((TextView)dialog.findViewById(R.id.userDetails_empAadhrNo_Tv)).setText(cursor.getString(cursor.getColumnIndex("AADHARNo")));
			((TextView)dialog.findViewById(R.id.userDetails_empMobNo_Tv)).setText(cursor.getString(cursor.getColumnIndex("MobileNo")));
			String gender=cursor.getString(cursor.getColumnIndex("GenderID"));
			if(gender.equalsIgnoreCase("1"))
				gender="Male";
			else
				gender="Female";
			((TextView)dialog.findViewById(R.id.userDetails_gender_Tv)).setText(gender);
			districtID=cursor.getString(cursor.getColumnIndex("DistrictID"));
			divisionID=cursor.getString(cursor.getColumnIndex("DivisionID"));
			mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
			intitutionTypeID=cursor.getString(cursor.getColumnIndex("TypeOfInstitution"));
			intitutionLocationID=cursor.getString(cursor.getColumnIndex("LocationOfInstitutionID"));
		}
		cursor.close();
		db.close();
		db.open();
		String designation=db.getSingleValue("select  DesignationName from Master_Designation where DesignationID='"+designationID+"'");
		String district=db.getSingleValue("select distinct DistrictName from Master_District where DistrictID='"+districtID+"'");
		String division=db.getSingleValue("select distinct DivisionName from Master_Division where DivisionID='"+divisionID+"' and DistrictID='"+districtID+"'");
		String mandal=db.getSingleValue("select distinct MandalName from Master_Mandal where MandalID='"+mandalID+"' and DistrictID='"+districtID+"' and DivisionID='"+divisionID+"'");
		String intitutionType=db.getSingleValue("select distinct Institution_Type_Name from Master_Institution_Types where Institution_TypeID='"+intitutionTypeID+"'");
		String intitutionLocation=db.getSingleValue("select Institute_Location from Master_Institutions where InstituteID='"+intitutionLocationID+"'");
		db.close();

		((TextView)dialog.findViewById(R.id.userDetails_empDesig_Tv)).setText(designation);
		((TextView)dialog.findViewById(R.id.userDetails_District_tv)).setText(district);
		((TextView)dialog.findViewById(R.id.userDetails_Division_tv)).setText(division);
		((TextView)dialog.findViewById(R.id.userDetails_mandal_tv)).setText(mandal);
		((TextView)dialog.findViewById(R.id.userDetails_IntitutionType_tv)).setText(intitutionType);
		((TextView)dialog.findViewById(R.id.userDetails_IntitutionLocation_tv)).setText(intitutionLocation);

	}
	
	public void viewfile() 
	{
		String storeDir = Environment.getExternalStorageDirectory().toString();
		path = storeDir + "/" + "FMDCP1stround%20guidlines2017-18.pdf";
		
		File file = new File(path);
		if (file.exists())
		{
				Uri path = Uri.fromFile(file);
				Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
				pdfIntent.setDataAndType(path, "application/pdf");
				pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

				try 
				{
					startActivity(pdfIntent);

				}
				catch (ActivityNotFoundException e)
                {
					Toast.makeText(HomePage.this, "No Application available to view pdf", Toast.LENGTH_LONG).show();
				}catch (Exception e1)
                {
					Toast.makeText(HomePage.this, "Error "+e1, Toast.LENGTH_LONG).show();
				}
			
		} 
		else 
		{
			DownloadAlert("", "FMDCP User Manual");
		}
	}
	public void DownloadAlert(final String url, final String CertificateName)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(HomePage.this);
		builder1.setCancelable(false);
		
		builder1.setMessage("Do you wants to Download the User Manual");
		builder1.setPositiveButton("Yes", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id) 
			{

				new DownloadFile(HomePage.this,url, CertificateName).execute();
				dialog.cancel();
			}
		});
		builder1.setNegativeButton("No", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();

		return;

	}
		
	boolean isShowingUserDetails = false;
	boolean doubleBackToExitPressedOnce = false;
	@Override
	public void onBackPressed() 
	{
		try 
		{
			if (doubleBackToExitPressedOnce)
			{
				//startActivity(new Intent(this,LoginPage.class));
				finish();
				return;
			}
			if(isShowingUserDetails)
			{
				closeUserDetails();
				isShowingUserDetails = false;
			}
			this.doubleBackToExitPressedOnce = true;
			//			findViewById(R.id.main2).setVisibility(8);
			//			findViewById(R.id.main1).setVisibility(0);
			Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					doubleBackToExitPressedOnce=false;
				}
			}, 2000);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	private void closeUserDetails()
	{
		isShowingUserDetails=false;
		findViewById(R.id.userDetails_ll).setVisibility(8);


		Animation slid=AnimationUtils.loadAnimation(this, R.anim.slid_middle_left);
		findViewById(R.id.userDetails_ll).startAnimation(slid);
	}
	public void Success(String response) 
	{
		Dialogs.AlertDialogs(HomePage.this,"Information!!", "Data Successfully Transferred to Server");
		loadDashBoardDetails();
	}
	@Override 
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(HomePage.this,"Information!!", response);
		if(response.equalsIgnoreCase("Data Not Found"))
			loadDashBoardDetails();
	}
	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(HomePage.this,"Information!!", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(HomePage.this,AppUpdatePage.class));
		finish();
		return;
	}
}




