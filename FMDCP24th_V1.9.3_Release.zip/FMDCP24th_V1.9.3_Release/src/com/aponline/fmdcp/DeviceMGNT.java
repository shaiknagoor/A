package com.aponline.fmdcp;

import java.io.File;

import com.aponline.fmdcp.server.CheckConnection;
import com.aponline.fmdcp.server.RequestServer;
import com.aponline.fmdcp.server.ServerResponseListener;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

public class DeviceMGNT extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	ActionBar ab;

	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.device_mgnt1);
		ab=getSupportActionBar();
		ab.setTitle("Device Management");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.dark_blue)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		findViewById(R.id.dwld_mandal).setOnClickListener(this);
		findViewById(R.id.dwld_usermanual).setOnClickListener(this);
		//findViewById(R.id.upldFarRegBt).setOnClickListener(this);
		//findViewById(R.id.upldVaccAckBt).setOnClickListener(this);
		//findViewById(R.id.upldFMDBt).setOnClickListener(this);
		findViewById(R.id.upldOfflineBt).setOnClickListener(this);

	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();

		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}
	RequestServer request=new RequestServer(DeviceMGNT.this);
	@Override
	public void onClick(View v)
	{

		switch (v.getId())
		{
		case R.id.dwld_mandal:
			request.addParam("UserID", HomeData.loginID);
			request.ProccessRequest(DeviceMGNT.this, "Get_MandalMasterDetails");
			break;
			
		case R.id.dwld_usermanual:
			if(filexist())
			{
				String storeDir = Environment.getExternalStorageDirectory().toString();
				String path = storeDir + "/" + "FMDCP1stround%20guidlines2017-18.pdf";
			
				File file = new File(path);
				file.delete();
			}
			new DownloadFile(DeviceMGNT.this,"http://ahd.aponline.gov.in/AHMS/views/Downloads/FMDCP1stround%20guidlines2017-18.pdf", "FMDCP1stround%20guidlines2017-18.pdf").execute();
			break;
			
		case R.id.upldOfflineBt:
			RequestServer request=new RequestServer(DeviceMGNT.this);
			request.ProccessRequest(DeviceMGNT.this, "UploadOfflineData");
			break;
			
		
//		case R.id.upldVaccAckBt:
//			break;

		default:
			break;
		}
	}
	private boolean filexist()
	{
		String storeDir = Environment.getExternalStorageDirectory().toString();
		String path = storeDir + "/" + "FMDCP1stround%20guidlines2017-18.pdf";
	
		File File = new File(path);
		Log.v("File", File + "  "+ File.exists());
		
		return File.exists();
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	@Override
	public void Success(String response) 
	{
		if(response.equalsIgnoreCase("UploadOfflineData"))
		{
			AlertDialogs("Information!!", "Data Successfully Transferred to Server");
		}
//		else if(response.equalsIgnoreCase("GetVaccineDistributionDetails"))
//		{
//			AlertDialogs("Information!!", "Vaccine Distribution Details Successfully Downloaded");
//		}
		else
		{
			AlertDialogs("Information!!", "Successfully Downloaded");
		}
	}
	@Override 
	public void Fail(String response) 
	{
		AlertDialogs("Information!!", response);
	}


	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information!!", "Network not available, Please try again!!");
	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(DeviceMGNT.this,AppUpdatePage.class));
		finish();
		return;
	}
}
