package com.aponline.fmdcp;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

public class AppUpdatePage extends AppCompatActivity
{
	private ProgressDialog pDialog;
	public static final int progress_bar_type = 0; 
	TextView content;
	TextView header;
	//Button ok;
	//Button skip;

	private void updateSP()
	{
//		SharedPreferences.Editor localEditor = getBaseContext().getSharedPreferences("user_settings", 0).edit();
//		localEditor.putString("updatecheckday", HomeData.current_date);
//		localEditor.commit();
	}

	protected void onCreate(Bundle paramBundle)
	{
		super.onCreate(paramBundle);
		setContentView(R.layout.app_update_page);
		updateSP();
		this.header = ((TextView)findViewById(R.id.header));
		this.content = ((TextView)findViewById(R.id.content));
		//this.ok = ((Button)findViewById(R.id.ok));
	//	this.skip = ((Button)findViewById(R.id.skip));
		new CheckApp().execute("http://www.aptonline.in/APTOMobilityServices/FMDCP.apk");
////		if ((HomeData.smUpgrade_header != null) && (HomeData.smUpgrade_header.trim().length() > 0))
////			this.header.setText(HomeData.smUpgrade_header.toUpperCase());
////		if ((HomeData.smUpgrade_Content != null) && (HomeData.smUpgrade_Content.trim().length() > 0))
////			this.content.setText(HomeData.smUpgrade_Content);
//		this.ok.setOnClickListener(new View.OnClickListener()
//		{
//			public void onClick(View paramView)
//			{
//				new CheckApp().execute("http://125.16.9.138/tssandwebservice/WebServices/TSMDC.apk");  
////				Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + AppUpdatePage.this.getPackageName()));
////				try
////				{
////					AppUpdatePage.this.startActivity(localIntent);
////					AppUpdatePage.this.finish();
////					return;
////				}
////				catch (ActivityNotFoundException localActivityNotFoundException)
////				{
////					Toast.makeText(AppUpdatePage.this, "You don't have Google Play installed", 1).show();
////				}
//			}
//		});
//		this.skip.setOnClickListener(new View.OnClickListener()
//		{
//			public void onClick(View paramView)
//			{				
//				finish();
//			}
//		});
	}
	@Override
	@Deprecated
	protected Dialog onCreateDialog(int id) 
	{
		switch (id) 
		{
		case progress_bar_type:
			pDialog = new ProgressDialog(this);
			pDialog.setMessage("Downloading. Please wait...");
			pDialog.setIndeterminate(false);
			pDialog.setMax(100);
			pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			pDialog.setCancelable(false); 
			pDialog.show();
			return pDialog;
		default:
			return null;
		}
		
	}
	
	class CheckApp extends AsyncTask<String,String,String>{


		private Context mContext;

		protected String doInBackground(String... sUrl) {
			// String path = "/sdcard/YourApp.apk";
			String path=Environment.getExternalStorageDirectory().getPath()+"/UPDATEAH.apk";
			try {
				URL url = new URL(sUrl[0]);
				URLConnection connection = url.openConnection();
				connection.connect();

				int fileLength = connection.getContentLength();

				
				InputStream input = new BufferedInputStream(url.openStream());
				OutputStream output = new FileOutputStream(path);

				byte data[] = new byte[1024];
				long total = 0;
				int count;
				while ((count = input.read(data)) != -1) {
					total += count;
					System.out.println((total * 100 / fileLength));
					 publishProgress(""+(total * 100 / fileLength));
					output.write(data, 0, count);
				}

				output.flush();
				output.close();
				input.close();
			} catch (Exception e) {

			}
			return path;
		}
		protected void onPreExecute()
		{
			super.onPreExecute();
			showDialog(progress_bar_type);
			pDialog.setProgress(0);
		}
		
		@Override
		protected void onPostExecute(String path)
		{
			dismissDialog(progress_bar_type);
			Intent i = new Intent();
			i.setAction(Intent.ACTION_VIEW);
			i.setDataAndType(Uri.fromFile(new File(path)), "application/vnd.android.package-archive" );

			startActivity(i);
		}
		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub

			super.onProgressUpdate(values);
			pDialog.setProgress(Integer.parseInt(values[0]));
		}

	}
}