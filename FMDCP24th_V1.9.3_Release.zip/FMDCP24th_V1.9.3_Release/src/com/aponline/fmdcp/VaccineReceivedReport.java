package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.adapter.vaccinrereceiptadapter;
import com.aponline.fmdcp.database.DBAdapter;

import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;

public class VaccineReceivedReport extends AppCompatActivity 
{

	Spinner sp;
	ListView Reports_listView;
	HorizontalScrollView maintain;
	LinearLayout vaccreceipt;
	DBAdapter db;
	ActionBar ab;
	int i=0;
	ArrayList<ArrayList<String>> list;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.report);
		db=new DBAdapter(this);
		ab=getSupportActionBar();
		ab.setTitle("Vaccine Received Report");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		Reports_listView=(ListView) findViewById(R.id.Reports_listView);
		findViewById(R.id.Reports_searchLL).setVisibility(8);
		maintain=(HorizontalScrollView) findViewById(R.id.horizontalScrollView_mainTable);
		vaccreceipt=(LinearLayout) findViewById(R.id.vaccinationreceipt_report);
		vaccinereport();
		
	}
	
	public void vaccinereport()
	{
		list=new ArrayList<ArrayList<String>>(); 

		db.open();
		Cursor cursor=db.getTableDataCursor("Select * From Vaccine_Distribution_master where Created_By='"+HomeData.userAadhaarID+"'");//SchoolCode,DEVICEID
		if(cursor.getCount()>0)
		{
			

			Reports_listView.setVisibility(View.VISIBLE);
			vaccreceipt.setVisibility(View.VISIBLE);
			if(cursor.moveToFirst())
			{
				do
				{
					ArrayList<String> data=new ArrayList<String>();
					String stuId=cursor.getString(cursor.getColumnIndex("Manufacturing_Company"));
					if(stuId.equalsIgnoreCase("1"))
					{
						data.add("Indian Immunologicals Ltd");
					}
					else
					{
						data.add("Brilliant Biopharma Ltd");
					}
					data.add(cursor.getString(cursor.getColumnIndex("BatchNo")));
					data.add(cursor.getString(cursor.getColumnIndex("Manufacturing_Date")));
					data.add(cursor.getString(cursor.getColumnIndex("Expiry_Date")));
					data.add(cursor.getString(cursor.getColumnIndex("Receiving_Date")));
					data.add(cursor.getString(cursor.getColumnIndex("AvailDoses")));
					int vc=(cursor.getInt(cursor.getColumnIndex("Noofvialreceived")));
					String s=String.valueOf(vc);
					data.add(s);
					data.add(cursor.getString(cursor.getColumnIndex("Is_Sync")));
					list.add(data);
				}while(cursor.moveToNext());



			}

			cursor.close();
			db.close();
			vaccinrereceiptadapter adapter=new vaccinrereceiptadapter(VaccineReceivedReport.this, list);
		//	vaccinationreportlistadapter adapter=new vaccinationreportlistadapter(VaccineReceiptReport.this, list);
			Reports_listView.setAdapter(adapter);




		}
	}
	
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}

}
