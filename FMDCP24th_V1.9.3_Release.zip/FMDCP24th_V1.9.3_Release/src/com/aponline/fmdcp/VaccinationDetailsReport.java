package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.adapter.farmerdetailadapter;
import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.database.SP;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class VaccinationDetailsReport extends AppCompatActivity implements OnItemSelectedListener,OnClickListener
{

	Spinner sp;
	ListView Reports_listView;
	HorizontalScrollView maintain;
	LinearLayout farmer;
	DBAdapter db;
	ActionBar ab;
	int i=0;
	ArrayList<ArrayList<String>> list;
	String viewType;
	
	LinearLayout vaccreceipt;
	String Dist_id,Mandal_id,Village_Id;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.report);
		db=new DBAdapter(this);
		ab=getSupportActionBar();
		ab.setTitle("Vaccination Details Report");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		viewType= getIntent().getExtras().getString("parent");
		
		findViewById(R.id.Reports_searchLL).setVisibility(0);
		
		Reports_listView=(ListView) findViewById(R.id.Reports_listView);
		
		maintain=(HorizontalScrollView) findViewById(R.id.horizontalScrollView_mainTable);
		vaccreceipt=(LinearLayout) findViewById(R.id.farmerDetailse_reportlayout);
		findViewById(R.id.Reports_searchLL).setVisibility(0);
		db.open();
		Dist_id=db.getSingleValue("select DistrictID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		Mandal_id=db.getSingleValue("select MandalID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");

		
		db.close();
		((Spinner) findViewById(R.id.reports_mandal_sp)).setOnItemSelectedListener(this);
		((Spinner) findViewById(R.id.reports_village_sp)).setOnItemSelectedListener(this);
		
		CommonFunctions.loadSpinnerData(this,"select distinct trim(MandalName) from Master_Mandal where DistrictID='"+Dist_id+"' and MandalID='"+Mandal_id+"' ORDER BY MandalName", (Spinner) findViewById(R.id.reports_mandal_sp));
	//	CommonFunctions.loadSpinnerData(this,SP.getVillageList(Dist_id, Mandal_id), (Spinner) findViewById(R.id.reports_village_sp));
		((Spinner)findViewById(R.id.reports_mandal_sp)).setSelection(1);
		((Spinner)findViewById(R.id.reports_mandal_sp)).setEnabled(false);
		
		farmerreport(SP.getVaccinationDetails_SP(HomeData.userAadhaarID, Dist_id, Mandal_id));
		
		findViewById(R.id.reports_searchdataBt).setOnClickListener(this);

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}

	
	public  void onStart() 
	{
		super.onStart();
		((EditText)findViewById(R.id.reports_searchdata_Et)).setText("");
		//((Spinner) findViewById(R.id.reports_mandal_sp)).setSelection(0);
		farmer=(LinearLayout) findViewById(R.id.farmerreportlayout);
		farmerreport(SP.getVaccinationDetails_SP(HomeData.userAadhaarID));
		Reports_listView.setOnItemClickListener(new OnItemClickListener() 
		{

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3)
			{

				String adharno=((TextView)arg1.findViewById(R.id.adharno)).getText().toString();
				String isSync=((TextView)arg1.findViewById(R.id.IsSync)).getText().toString();
				Log.d("Aadhaar", adharno);
				if(viewType.equalsIgnoreCase("report"))
				{
					Intent i=new Intent(VaccinationDetailsReport.this,VaccinedetailView.class);
					i.putExtra("adharno", adharno);
					startActivity(i);
				}
				else
				{
					Intent i=new Intent(VaccinationDetailsReport.this,UpdateVaccinationdetailView.class);
					i.putExtra("adharno", adharno);					
					startActivity(i);
				}

			}
		});
	}
	public void farmerreport(String query)
	{

		try 
		{
			farmer.setVisibility(View.VISIBLE);
			maintain.setVisibility(View.VISIBLE);
			list=new ArrayList<ArrayList<String>>(); 

			db.open();
			Cursor cursor=db.getTableDataCursor(query);
			if(cursor.getCount()>0)
			{
				Reports_listView.setVisibility(View.VISIBLE);
				if(cursor.moveToFirst())
				{
					do
					{
						ArrayList<String> data=new ArrayList<String>();
						data.add(cursor.getString(cursor.getColumnIndex("Aadhar_No")));	
						data.add(cursor.getString(cursor.getColumnIndex("Farmer_Name")));
						data.add(cursor.getString(cursor.getColumnIndex("TotalAnimals")));
						data.add(cursor.getString(cursor.getColumnIndex("VaccinetedAnimals")));	
						String isSync=cursor.getString(cursor.getColumnIndex("Is_Sync"));
						data.add(isSync);
						data.add(cursor.getString(cursor.getColumnIndex("DateOfVaccination")));	
						if(viewType.equalsIgnoreCase("update"))
						{
							if(isSync.equalsIgnoreCase("N"))
								list.add(data);
						}
						else
						{
							list.add(data);
						}
					}while(cursor.moveToNext());

				}
				cursor.close();
				db.close();
				
			}
			else
			{
				Toast.makeText(VaccinationDetailsReport.this, "No Data Found", Toast.LENGTH_LONG).show();
			}
			farmerdetailadapter fmd=new farmerdetailadapter(VaccinationDetailsReport.this, list);
			Reports_listView.setAdapter(fmd);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public int getdetailfromadharno(String adhno)
	{


		db.open();
		Cursor cursor=db.getTableDataCursor("select * from FMD_Vaccination_Details where FarmerRegID='"+adhno+"'");
		int noofvaccinatedanimal=0;
		if(cursor.getCount()>0)
		{


			if(cursor.moveToFirst())
			{
				do
				{


					String r=cursor.getString(cursor.getColumnIndex("WhiteCattle_Male_vaccinated"));
					String s=cursor.getString(cursor.getColumnIndex("WhiteCattle_Female_vaccinated"));	

					String p=cursor.getString(cursor.getColumnIndex("Buffalo_Male_vaccinated"));
					String q=cursor.getString(cursor.getColumnIndex("Buffalo_Female_vaccinated"));


					noofvaccinatedanimal=Integer.parseInt(r)+Integer.parseInt(s)+Integer.parseInt(p)+Integer.parseInt(q);

				}while(cursor.moveToNext());

			}
		}
		return noofvaccinatedanimal;
	}
	
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) 
	{
		switch (parent.getId())
		{
		case R.id.reports_mandal_sp:

			String mandalName=parent.getSelectedItem().toString().trim();
			if(!mandalName.equalsIgnoreCase("--Select--"))
			{
				((Spinner) findViewById(R.id.reports_village_sp)).setSelection(0);
				db.open();
				Mandal_id=db.getSingleValue("select MandalID from Master_Mandal where DistrictID='"+Dist_id+"' and  trim(MandalName)='"+mandalName.trim()+"' ORDER BY MandalName");
				db.close();
				
				CommonFunctions.loadSpinnerData(this,SP.getVillageList(Dist_id, Mandal_id), (Spinner) findViewById(R.id.reports_village_sp));
				farmerreport(SP.getVaccinationDetails_SP(HomeData.userAadhaarID, Dist_id, Mandal_id));
			}
			break;
		case R.id.reports_village_sp:
			String villName=parent.getSelectedItem().toString().trim();
			if(!villName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				Village_Id=db.getSingleValue(SP.getVillageID(Dist_id, Mandal_id, villName));
				db.close();
				farmerreport(SP.getVaccinationDetails_SP(HomeData.userAadhaarID, Dist_id, Mandal_id,Village_Id));
			}
			break;
		default:
			break;
		}
	}
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.reports_searchdataBt:
			String searchdata=((EditText)findViewById(R.id.reports_searchdata_Et)).getText().toString();
			if(searchdata.equalsIgnoreCase(""))
			{
				((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(((EditText)findViewById(R.id.reports_searchdata_Et)).getWindowToken(), 0);
				((EditText)findViewById(R.id.reports_searchdata_Et)).requestFocus();
				((EditText)findViewById(R.id.reports_searchdata_Et)).setError("Enter Farmer Aadhar Number");
				return;
			}

			((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(((EditText)findViewById(R.id.reports_searchdata_Et)).getWindowToken(), 0);
			farmerreport(SP.getVaccinationDetails_Search_SP(HomeData.userAadhaarID, searchdata));
			break;
		default:
			break;
		}
	}
	
	@Override
	public void onNothingSelected(AdapterView<?> parent) 
	{
	
	}
}