package com.aponline.fmdcp;

import java.util.List;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

public class Help extends AppCompatActivity implements OnClickListener
{
	ActionBar ab;

	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);
		findViewById(R.id.help_Email).setOnClickListener(this);
		ab=getSupportActionBar();
		ab.setTitle("Help");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true);

	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	@Override
	public void onClick(View v) 
	{

		switch (v.getId()) 
		{
		case R.id.help_Email:
			try
			{
				Intent intent = new Intent(Intent.ACTION_SEND);
				intent.setType("message/rfc822"); 
				intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"fmdcpaphelp@gmail.com,ahdsoftwareap@gmail.com"});
				intent.putExtra(Intent.EXTRA_SUBJECT,HomeData.loginID+"  "+"VAS Feedback from Device ID  "+HomeData.sDeviceId);
				intent.putExtra(Intent.EXTRA_TEXT,"Information:    ");
				intent.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
				startActivity(intent);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				//Toast.makeText(this, " Error in sending", Toast.LENGTH_SHORT).show();
				
				try 
				{
					Intent intent = new Intent(Intent.ACTION_SEND);
					intent.setType("message/rfc822"); 
					intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"fmdcpaphelp@gmail.com,ahdsoftwareap@gmail.com"});
					intent.putExtra(Intent.EXTRA_SUBJECT,HomeData.loginID+"  "+"VAS Feedback from Device ID  "+HomeData.sDeviceId);
					intent.putExtra(Intent.EXTRA_TEXT,"Information:    ");
					final PackageManager pm = getPackageManager();
					final List<ResolveInfo> matches = pm.queryIntentActivities(intent, 0);
					ResolveInfo best = null;
					for(final ResolveInfo info : matches)
					    if (info.activityInfo.packageName.endsWith(".gm") || info.activityInfo.name.toLowerCase().contains("gmail"))
					        best = info;
					if (best != null)
						intent.setClassName(best.activityInfo.packageName, best.activityInfo.name);
					startActivity(intent);
				} 
				catch (Exception e1) 
				{
					e1.printStackTrace();
					CommonFunctions.writeLog(Help.this.getClass().getName(), "onClick", e1.getMessage());
				}
				
			}
			break;
		default:
			break;
		}

	}


	public void sendEmail(String[] recipientList,String title, String subject, String body) 
	{
		
		
		
		Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);    
		emailIntent.setType("plain/text");    
		emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, recipientList);
		emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);   
		emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, body);
		startActivity(Intent.createChooser(emailIntent, title));
	}
}
