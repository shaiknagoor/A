package  com.aponline.fmdcp;


import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.kobjects.base64.Base64;

import com.aponline.fmdcp.adapter.FarmerVaccineDetailadapter;
import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.database.SP;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

@SuppressLint("NewApi")
public class VaccinationDetails extends AppCompatActivity implements OnItemSelectedListener,OnClickListener
{
	GPSTracker gps;
	double latitude=0,longitude=0;
	private static final int REQUEST_CAMERA = 0, SELECT_FILE = 1;
	ImageView photoCaptureIv;
	private static final int CAMERA_REQUEST = 1888; 
	public static String strBaseimage="";

	ActionBar ab;
	ImageView searchBtn;
	EditText searchNoEt;
	TextView statusView;
	DBAdapter db;
	Context context;
	LinearLayout tl;
	public static String Dist_id,Mandal_id,Viialge_id,bankdetailsStaus="gone",livestockStaus="gone",socialstatusId;
	List<String> mandallist,villagelist;
	RadioButton GemderRd;
	String AadhaarNo,sequenceNo,batchNo="--Select--",batno;
	ArrayList<HashMap<String, String>> Vaccdonebydata;
	ArrayList<ContentValues> VaccinationDoneByDetailslist;
	Spinner brewNoSp;
	ListView VacDetails_frsearchResList_ll;
	ArrayList<ArrayList<String>> list;
	@Override
	public void onStart()
	{
		super.onStart();

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{


		super.onCreate(savedInstanceState);
		setContentView(R.layout.vaccination_details);
		context=this;
		ab=getSupportActionBar();
		ab.setTitle("Vaccination Details");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 

		db=new DBAdapter(this);

		db.open();
		Dist_id=db.getSingleValue("select DistrictID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		Mandal_id=db.getSingleValue("select MandalID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		db.close();

		((Spinner)findViewById(R.id.VacDetails_village_sp)).setSelection(0);
		((Spinner) findViewById(R.id.VacDetails_mandal_sp)).setOnItemSelectedListener(this);
		((Spinner) findViewById(R.id.VacDetails_village_sp)).setOnItemSelectedListener(this);


		loadSpinnerData("select distinct trim(MandalName) from Master_Mandal where DistrictID='"+Dist_id+"' and MandalID='"+Mandal_id+"' ORDER BY MandalName", (Spinner) findViewById(R.id.VacDetails_mandal_sp));
		((Spinner)findViewById(R.id.VacDetails_mandal_sp)).setSelection(1);
		((Spinner)findViewById(R.id.VacDetails_mandal_sp)).setEnabled(false);
		//loadSpinnerData(SP.getVillageList(Dist_id, Mandal_id), (Spinner) findViewById(R.id.VacDetails_village_sp));

		brewNoSp=(Spinner)findViewById(R.id.fmd_batchNo_sp);
		brewNoSp.setOnItemSelectedListener(this);
		loadSpinnerData("select distinct BatchNo from Vaccine_Distribution_master where Is_Ack='Y' and Created_By='"+HomeData.userAadhaarID+"'", brewNoSp);

		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String currentDate = sdf.format(c.getTime());

		SharedPreferences pref = getSharedPreferences("AH_VDate", Context.MODE_PRIVATE);     
		if(pref.contains("AppInstalled"))
		{
			String lastVDate=pref.getString("LastVDate", currentDate);
			String LastLoginID=pref.getString("LastLoginID", "");
			if(!lastVDate.equalsIgnoreCase(currentDate)&&!LastLoginID.equalsIgnoreCase(HomeData.loginID))
			{
				Editor editor = pref.edit();   
				editor.putString("LastVDate", currentDate);
				editor.putString("LastLoginID", HomeData.loginID);
				editor.commit(); 
				ShowVaccinationTeamDialog();
			}
		}
		else
		{
			Editor editor = pref.edit();   
			editor.putBoolean("AppInstalled", true); 
			editor.putString("LastVDate", currentDate);
			editor.putString("LastLoginID", HomeData.loginID);
			editor.commit(); 
			ShowVaccinationTeamDialog();
		}




		initializeViews();

	}

	private void initializeViews()
	{

		CommonFunctions.loadSpinnerSetSelectedItem(VaccinationDetails.this,"select distinct BatchNo from Vaccine_Distribution_master where Is_Ack='Y' and Created_By='"+HomeData.userAadhaarID+"'",brewNoSp, batchNo);
		((Spinner)findViewById(R.id.VacDetails_socialstatus_sp)).setSelection(0);
		((Spinner) findViewById(R.id.VacDetails_socialstatus_sp)).setOnItemSelectedListener(this);

		loadSpinnerData("select SocialStatusName from Master_SocialStatus", (Spinner) findViewById(R.id.VacDetails_socialstatus_sp));
		((EditText)findViewById(R.id.VacDetails_aadharEt)).requestFocus();
		((EditText)findViewById(R.id.VacDetails_aadharEt)).setText("");
		((EditText)findViewById(R.id.VacDetails_formaerNameEt)).setText("");
		((RadioButton) findViewById(R.id.VacDetails_gender_MaleRd)).setSelected(true);
		((EditText)findViewById(R.id.VacDetails_mobileEt)).setText("");
		((EditText)findViewById(R.id.MaleCattle_edt)).setText("");
		((EditText)findViewById(R.id.Malebuffaloes_edt)).setText("");
		((EditText)findViewById(R.id.FemaleCattle_edt)).setText("");
		((EditText)findViewById(R.id.Femalebuffaloes_edt)).setText("");

		findViewById(R.id.VaccDetails_VaccinationDetails).setVisibility(8);
		findViewById(R.id.VacDetails_FarmerDetailsLL).setVisibility(8);
		findViewById(R.id.VaccDetails_VaccinationDoneByLL).setVisibility(8);
		findViewById(R.id.VacDetails_FarmerButtonLL).setVisibility(8);
		findViewById(R.id.VacDetails_farmerSearchLL).setVisibility(8);
		findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);

		loadSpinnerData("select Reason from Master_Reasons where ReasonID!=4", (Spinner)findViewById(R.id.fmd_whiteMaleResoans_Sp));
		loadSpinnerData("select Reason from Master_Reasons", (Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp));
		loadSpinnerData("select Reason from Master_Reasons where ReasonID!=4", (Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp));
		loadSpinnerData("select Reason from Master_Reasons", (Spinner)findViewById(R.id.fmd_buffaloFemaleResoans_Sp));

		findViewById(R.id.VacDetails_Submit_Btn).setOnClickListener(this);
		findViewById(R.id.VacDetails_NewFarmer_Btn).setOnClickListener(this);
		findViewById(R.id.VacDetails_ExistFarmer_Btn).setOnClickListener(this);
		findViewById(R.id.FR_searchdataBt).setOnClickListener(this);

		VacDetails_frsearchResList_ll=(ListView) findViewById(R.id.VacDetails_frsearchResList_ll);
		setListViewHeightBasedOnChildren(VacDetails_frsearchResList_ll);
		VacDetails_frsearchResList_ll.setOnTouchListener(new OnTouchListener()
		{
			@Override
			public boolean onTouch(View v, MotionEvent event)
			{
				v.getParent().requestDisallowInterceptTouchEvent(true);
				return false;
			}
		});

		photoCaptureIv=(ImageView)findViewById(R.id.userReg_capturePhoto_Iv);
		photoCaptureIv.setImageResource(R.drawable.cow_img);
		photoCaptureIv.setOnClickListener(this);

		tl = (LinearLayout)findViewById(R.id.VaccDoneby_tabledata);
		tl.removeAllViews();
		for(int i=1;i<=1;i++)
		{
			LayoutInflater inflater = getLayoutInflater();
			final View tr = (View)inflater.inflate(R.layout.row, tl, false);
			ImageButton ck=(ImageButton)tr.findViewById(R.id.check);
			loadSpinnerData("select DesignationName from Master_Designation", (Spinner)tr.findViewById(R.id.column2Sp));
			ck.setOnClickListener(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					View row = (View) v.getParent();
					ViewGroup container = ((ViewGroup)row.getParent());
					View view = ((ViewGroup) row).getChildAt(0);
					container.removeView(row);
					container.invalidate();
				}
			});
			tl.addView(tr);
		}
		findViewById(R.id.VaccDoneby_AddBt).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{ 
				LayoutInflater inflater = getLayoutInflater();
				final View tr = (View)inflater.inflate(R.layout.row, tl, false);
				ImageButton ck=(ImageButton)tr.findViewById(R.id.check);
				loadSpinnerData("select DesignationName from Master_Designation", (Spinner)tr.findViewById(R.id.column2Sp));
				ck.setOnClickListener(new OnClickListener() 
				{
					@Override
					public void onClick(View v) 
					{
						View row = (View) v.getParent();
						ViewGroup container = ((ViewGroup)row.getParent());
						View view = ((ViewGroup) row).getChildAt(0);
						container.removeView(row);
						container.invalidate();
					}
				});
				tl.addView(tr);
				tr.requestFocus();
			}
		});

		findViewById(R.id.fmd_DateOfVaccination_Et).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{ 
				showdate((TextView)findViewById(R.id.fmd_DateOfVaccination_Et));
			}
		});

	}
	public static void setListViewHeightBasedOnChildren(ListView listView)
	{
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null)
			return;

		int desiredWidth = MeasureSpec.makeMeasureSpec(listView.getWidth(), MeasureSpec.UNSPECIFIED);
		int totalHeight = 0;
		View view = null;
		for (int i = 0; i < listAdapter.getCount(); i++) 
		{
			view = listAdapter.getView(i, view, listView);
			if (i == 0)
				view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, LayoutParams.WRAP_CONTENT));

			view.measure(desiredWidth, MeasureSpec.UNSPECIFIED);
			totalHeight += view.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	private void loadVaccinatorDetails() 
	{
		db.open();
		String qry="Select fmd.Vaccinator_Name,md.DesignationName,fmd.Vaccinator_Aadhar from FMD_Vaccinator_Details fmd,Master_Designation md where  fmd.Vaccinator_Designation=md.DesignationID and fmd.CreatedBy='"+HomeData.userAadhaarID+"'";
		Cursor cursor1=db.getTableDataCursor(qry);
		//Cursor cursor1=db.getTableDataCursor("Select fmd.Vaccinator_Name,md.DesignationName,fmd.Vaccinator_Aadhar from FMD_Vaccinator_Details fmd,Master_Designation md where  fmd.Vaccinator_Designation=md.DesignationID");
		if(cursor1.getCount()>0)
		{
			int i=cursor1.getCount();
			((LinearLayout)findViewById(R.id.VaccDoneby_tabledata)).removeAllViews();
			if(cursor1.moveToFirst())
			{
				do
				{

					LayoutInflater inflater = getLayoutInflater();
					final View tr = (View)inflater.inflate(R.layout.row, null, false);

					((EditText)tr.findViewById(R.id.column1Et)).setText(cursor1.getString(cursor1.getColumnIndex("Vaccinator_Name")));
					CommonFunctions.loadSpinnerSetSelectedItem(VaccinationDetails.this,"select DesignationName from Master_Designation",(Spinner)tr.findViewById(R.id.column2Sp), cursor1.getString(cursor1.getColumnIndex("DesignationName")));
					((EditText)tr.findViewById(R.id.column3Et)).setText(cursor1.getString(cursor1.getColumnIndex("Vaccinator_Aadhar")));

					ImageButton ck=(ImageButton)tr.findViewById(R.id.check);
					ck.setOnClickListener(new OnClickListener() 
					{
						@Override
						public void onClick(View v) 
						{
							View row = (View) v.getParent();
							ViewGroup container = ((ViewGroup)row.getParent());
							View view = ((ViewGroup) row).getChildAt(0);
							container.removeView(row);
							container.invalidate();
						}
					});

					((LinearLayout)findViewById(R.id.VaccDoneby_tabledata)).addView(tr);
				}while(cursor1.moveToNext());
			}
		}

		cursor1.close();
		db.close();

	}
	private int mYear, mMonth, mDay, mHour, mMinute;
	public void showdate(final TextView t)
	{

		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);

		// Launch Date Picker Dialog
		DatePickerDialog dpd = new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener() 
		{
			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) 
			{
				try 
				{

					Calendar cal=Calendar.getInstance();
					cal.set(year,monthOfYear,dayOfMonth);

					String endDateString = "16/10/2017";  //26/09/2017 old date
					String startDateString = "23/08/2017";
					DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
					Date endDateDate = df.parse(endDateString);
					Date startDateDate = df.parse(startDateString);



					if( (endDateDate.after(cal.getTime()) && startDateDate.before(cal.getTime())) || startDateDate.equals(cal.getTime()))
					{
						t.setText(df.format(cal.getTime()));
					}
					else
					{
						t.setText("");
						AlertDialogs("Information!!", "Vaccination not allowed on this Date");
					}

				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		}, mYear, mMonth, mDay);

		String endDateString = "15/10/2017";  //25/09/2017
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
		Date endDateDate;
		try 
		{
			endDateDate = df.parse(endDateString);

			if(!endDateDate.after(c.getTime()))
			{
				dpd.getDatePicker().setMaxDate(endDateDate.getTime());
			}
			else
			{
				dpd.getDatePicker().setMaxDate(c.getTimeInMillis());
			}
		} 
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		dpd.getDatePicker().setCalendarViewShown(false);
		dpd.show();

	}
	StringBuilder FarmerRegXmlDoc;
	int usedDoses,tot_Animals;
	ContentValues VaccinationDetails,FarmerDetails,VaccinationDoneByDetails;

	public void ValidateData()
	{
		String dateOFvacinnation=((TextView)findViewById(R.id.fmd_DateOfVaccination_Et)).getText().toString().trim();
		if(dateOFvacinnation.equalsIgnoreCase(""))
		{
			((TextView)findViewById(R.id.fmd_DateOfVaccination_Et)).requestFocus();

			AlertDialogs("Information!!", "Please select Date of Vaccination"); 
			return;
		}
		if(((Spinner) findViewById(R.id.VacDetails_mandal_sp)).getSelectedItemPosition()==0)
		{
			((Spinner)findViewById(R.id.VacDetails_mandal_sp)).setFocusable(true); 
			((Spinner)findViewById(R.id.VacDetails_mandal_sp)).setFocusableInTouchMode(true);
			((Spinner)findViewById(R.id.VacDetails_mandal_sp)).requestFocus();
			AlertDialogs("Information!!", "Please select Mandal");
			return;
		}
		if(((Spinner) findViewById(R.id.VacDetails_village_sp)).getSelectedItemPosition()==0)
		{
			((Spinner)findViewById(R.id.VacDetails_village_sp)).setFocusable(true); 
			((Spinner)findViewById(R.id.VacDetails_village_sp)).setFocusableInTouchMode(true);
			((Spinner)findViewById(R.id.VacDetails_village_sp)).requestFocus();
			AlertDialogs("Information!!", "Please select Village");
			return;
		}

		AadhaarNo=((EditText)findViewById(R.id.VacDetails_aadharEt)).getText().toString().trim(); 
		if(AadhaarNo.equalsIgnoreCase("")||AadhaarNo.length()!=12)
		{
			((EditText)findViewById(R.id.VacDetails_aadharEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_aadharEt)).setError("FIELD CAN NOT BE EMPTY");
			return;
		}
		else if(AadhaarNo.length()!=12)
		{
			((EditText)findViewById(R.id.VacDetails_aadharEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_aadharEt)).setError("ENTER VALID AADHAR NUMBER");
			return;
		}
		else if(!CommonFunctions.validateAadharNumber(AadhaarNo))
		{
			((EditText)findViewById(R.id.VacDetails_aadharEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_aadharEt)).setError("Please Enter Valid Aadhaar Number");
			return;
		}

		db.open();
		int rowCount=db.getRowCount("select count(Aadhar_No) from FARMER_REG_DETAILS where Aadhar_No='"+AadhaarNo+"'");
		db.close();
		if(rowCount>0)
		{
			AlertDialogs("Information!!", "Farmer Already Registered on this Aadhaar/Voter ID number,Please check once");
			return;
		}

		String name=((EditText)findViewById(R.id.VacDetails_formaerNameEt)).getText().toString();
		if(name.trim().equalsIgnoreCase(""))
		{
			((EditText)findViewById(R.id.VacDetails_formaerNameEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_formaerNameEt)).setError("FIELD CAN NOT BE EMPTY");
			return;
		}
		else if(!name.matches("[\\p{L}- ]+")||name.startsWith(" ")) 
		{
			((EditText)findViewById(R.id.VacDetails_formaerNameEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_formaerNameEt)).setError("ENTER ONLY ALPHABETICAL CHARACTER");
			return;
		}
		String gender="1";
		if(((RadioButton) findViewById(R.id.VacDetails_gender_MaleRd)).isChecked())
		{
			gender="1";
		}
		else
		{
			gender="2";
		}
		String mobile=((EditText)findViewById(R.id.VacDetails_mobileEt)).getText().toString().trim();
		if(mobile.equalsIgnoreCase("")||mobile.equalsIgnoreCase("0"))
		{
			((EditText)findViewById(R.id.VacDetails_mobileEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_mobileEt)).setError("Please Enter Mobile Number");
			return;
		}
		else if(!mobile.matches("[7-9]{1}+[0-9]+")||mobile.length()!=10)
		{
			((EditText)findViewById(R.id.VacDetails_mobileEt)).requestFocus();
			((EditText)findViewById(R.id.VacDetails_mobileEt)).setError("Enter Valid Mobile Number");
			return;
		}

		if(((Spinner) findViewById(R.id.VacDetails_socialstatus_sp)).getSelectedItemPosition()==0)
		{
			AlertDialogs("Information!!", "Please select Social Status");
			((Spinner) findViewById(R.id.VacDetails_socialstatus_sp)).requestFocus();
			return;
		}
		EditText MaleCattle_edt=(EditText) findViewById(R.id.MaleCattle_edt);
		if(MaleCattle_edt.getText().toString().isEmpty() )
		{
			MaleCattle_edt.requestFocus();
			MaleCattle_edt.setError("Enter Male Cattle");
			return;
		}

		EditText Malebuffaloes_edt=(EditText) findViewById(R.id.Malebuffaloes_edt);
		if(Malebuffaloes_edt.getText().toString().isEmpty() )
		{
			Malebuffaloes_edt.requestFocus();
			Malebuffaloes_edt.setError("Enter Male Buffaloes");
			return;
		}
		EditText FemaleCattle_edt=(EditText) findViewById(R.id.FemaleCattle_edt);
		if(FemaleCattle_edt.getText().toString().isEmpty() )
		{
			FemaleCattle_edt.requestFocus();
			FemaleCattle_edt.setError("Enter Female Cattle");
			return;
		}

		EditText Femalebuffaloes_edt=(EditText) findViewById(R.id.Femalebuffaloes_edt);
		if(Femalebuffaloes_edt.getText().toString().isEmpty() )
		{
			Femalebuffaloes_edt.requestFocus();
			Femalebuffaloes_edt.setError("Enter Female Buffaloes");
			return;
		}

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String createdDate1 = sdf1.format(cal.getTime());


		String total_FemaleWhiteCatle=FemaleCattle_edt.getText().toString().trim();
		String total_FemaleBuffalo=Femalebuffaloes_edt.getText().toString().trim();
		String total_MaleWhiteCatle=MaleCattle_edt.getText().toString().trim();
		String total_MaleBuffalo=Malebuffaloes_edt.getText().toString().trim();

		if(total_FemaleWhiteCatle.equalsIgnoreCase("")||total_FemaleWhiteCatle==null)
			total_FemaleWhiteCatle="0";
		if(total_FemaleBuffalo.equalsIgnoreCase("")||total_FemaleBuffalo==null)
			total_FemaleBuffalo="0";
		if(total_MaleWhiteCatle.equalsIgnoreCase("")||total_MaleWhiteCatle==null)
			total_MaleWhiteCatle="0";
		if(total_MaleBuffalo.equalsIgnoreCase("")||total_MaleBuffalo==null)
			total_MaleBuffalo="0";
		tot_Animals=Integer.parseInt(total_FemaleWhiteCatle)+Integer.parseInt(total_FemaleBuffalo)+Integer.parseInt(total_MaleWhiteCatle)+Integer.parseInt(total_MaleBuffalo);
		if(tot_Animals<=0)
		{
			AlertDialogs("Information!!", "Please Enter Minimum 1 Livestock Owned By Farmer");
			MaleCattle_edt.requestFocus();
			return;
		}

		String fmd_whiteMaleVaccinated=((EditText)findViewById(R.id.fmd_whiteMaleVaccinated_Et)).getText().toString().trim();
		if(fmd_whiteMaleVaccinated.equalsIgnoreCase(""))
		{
			fmd_whiteMaleVaccinated="0";
		}
		if(Integer.parseInt(total_MaleWhiteCatle)<Integer.parseInt(fmd_whiteMaleVaccinated))
		{
			((EditText)findViewById(R.id.fmd_whiteMaleVaccinated_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_whiteMaleVaccinated_Et)).setError("Enter Valid Number"); 
			return;
		}
		String fmd_whiteMaleDraught=((EditText)findViewById(R.id.fmd_whiteMaleDraught_Et)).getText().toString().trim();
		if(fmd_whiteMaleDraught.equalsIgnoreCase(""))
		{
			fmd_whiteMaleDraught="0";
		}
		if(Integer.parseInt(fmd_whiteMaleVaccinated)<Integer.parseInt(fmd_whiteMaleDraught))
		{
			((EditText)findViewById(R.id.fmd_whiteMaleDraught_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_whiteMaleDraught_Et)).setError("Enter Valid Number"); 
			return;
		}

		String fmd_whiteMaleResoans=""+((Spinner)findViewById(R.id.fmd_whiteMaleResoans_Sp)).getSelectedItemPosition();
		if(fmd_whiteMaleResoans.equalsIgnoreCase("0"))
		{
			if(Integer.parseInt(total_MaleWhiteCatle)>Integer.parseInt(fmd_whiteMaleVaccinated))
			{

				((Spinner)findViewById(R.id.fmd_whiteMaleResoans_Sp)).setFocusable(true); 
				((Spinner)findViewById(R.id.fmd_whiteMaleResoans_Sp)).setFocusableInTouchMode(true);
				((Spinner)findViewById(R.id.fmd_whiteMaleResoans_Sp)).requestFocus();
				Dialogs.AlertDialogs(VaccinationDetails.this, "Information!!", "Please select Reason for Not Vaccination of Male White Cattle");
				return;
			}

		}
		String fmd_whiteFamaleVaccinated=((EditText)findViewById(R.id.fmd_whiteFamaleVaccinated_Et)).getText().toString().trim();
		if(fmd_whiteFamaleVaccinated.equalsIgnoreCase(""))
		{
			fmd_whiteFamaleVaccinated="0";
		}
		if(Integer.parseInt(total_FemaleWhiteCatle)<Integer.parseInt(fmd_whiteFamaleVaccinated))
		{
			((EditText)findViewById(R.id.fmd_whiteFamaleVaccinated_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_whiteFamaleVaccinated_Et)).setError("Enter Valid Number"); 
			return;
		}

		String fmd_whiteFeMalePragnant=((EditText)findViewById(R.id.fmd_whiteFeMalePragnant_Et)).getText().toString().trim();
		if(fmd_whiteFeMalePragnant.equalsIgnoreCase(""))
		{
			fmd_whiteFeMalePragnant="0";
		}
		if(Integer.parseInt(fmd_whiteFamaleVaccinated)<Integer.parseInt(fmd_whiteFeMalePragnant))
		{
			((EditText)findViewById(R.id.fmd_whiteFeMalePragnant_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_whiteFeMalePragnant_Et)).setError("Enter Valid Number"); 
			return;
		}

		String fmd_whiteFemaleResoans=""+((Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp)).getSelectedItemPosition();
		if(fmd_whiteFemaleResoans.equalsIgnoreCase("0"))
		{
			if(Integer.parseInt(fmd_whiteFamaleVaccinated)<Integer.parseInt(total_FemaleWhiteCatle))
			{
				((Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp)).setFocusable(true); 
				((Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp)).setFocusableInTouchMode(true);
				((Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp)).requestFocus();
				//	((Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp)).requestFocusFromTouch();
				Dialogs.AlertDialogs(VaccinationDetails.this, "Information!!", "Please select Reason for not Vaccination of Female White Cattle");
				return;
			}
		} 
		String fmd_buffaloMaleVaccinated=((EditText)findViewById(R.id.fmd_buffaloMaleVaccinated_Et)).getText().toString().trim();
		if(fmd_buffaloMaleVaccinated.equalsIgnoreCase(""))
		{
			fmd_buffaloMaleVaccinated="0";
		}
		if(Integer.parseInt(total_MaleBuffalo)<Integer.parseInt(fmd_buffaloMaleVaccinated))
		{
			((EditText)findViewById(R.id.fmd_buffaloMaleVaccinated_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_buffaloMaleVaccinated_Et)).setError("Enter Valid Number"); 
			return;
		}
		String fmd_buffaloMaleDraught=((EditText)findViewById(R.id.fmd_buffaloMaleDraught_Et)).getText().toString().trim();
		if(fmd_buffaloMaleDraught.equalsIgnoreCase(""))
		{
			fmd_buffaloMaleDraught="0";
		}
		if(Integer.parseInt(fmd_buffaloMaleVaccinated)<Integer.parseInt(fmd_buffaloMaleDraught))
		{
			((EditText)findViewById(R.id.fmd_buffaloMaleDraught_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_buffaloMaleDraught_Et)).setError("Enter Valid Number"); 
			return;
		}
		String fmd_buffaloMaleResoans=""+((Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp)).getSelectedItemPosition();
		if(fmd_buffaloMaleResoans.equalsIgnoreCase("0"))
		{
			if(Integer.parseInt(total_MaleBuffalo)>Integer.parseInt(fmd_buffaloMaleVaccinated))
			{
				((Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp)).setFocusable(true); 
				((Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp)).setFocusableInTouchMode(true);
				((Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp)).requestFocus();
				//((Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp)).requestFocusFromTouch();
				Dialogs.AlertDialogs(VaccinationDetails.this, "Information!!", "Please select Reason for not Vaccination of Male Buffalo");
				return;
			}
		}

		String fmd_buffaloFamaleVaccinated=((EditText)findViewById(R.id.fmd_buffaloFamaleVaccinated_Et)).getText().toString().trim();
		if(fmd_buffaloFamaleVaccinated.equalsIgnoreCase(""))
		{
			fmd_buffaloFamaleVaccinated="0";
		}
		if(Integer.parseInt(total_FemaleBuffalo)<Integer.parseInt(fmd_buffaloFamaleVaccinated))
		{
			((EditText)findViewById(R.id.fmd_buffaloFamaleVaccinated_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_buffaloFamaleVaccinated_Et)).setError("Enter Valid Number"); 
			return;
		}
		String fmd_buffaloFemalePragnant=((EditText)findViewById(R.id.fmd_buffaloFemalePragnant_Et)).getText().toString().trim();
		if(fmd_buffaloFemalePragnant.equalsIgnoreCase(""))
		{
			fmd_buffaloFemalePragnant="0";
		}
		if(Integer.parseInt(fmd_buffaloFamaleVaccinated)<Integer.parseInt(fmd_buffaloFemalePragnant))
		{
			((EditText)findViewById(R.id.fmd_buffaloFemalePragnant_Et)).requestFocus();
			((EditText)findViewById(R.id.fmd_buffaloFemalePragnant_Et)).setError("Enter Valid Number"); 
			return;
		}

		String fmd_buffaloFemaleResoans=""+((Spinner)findViewById(R.id.fmd_buffaloFemaleResoans_Sp)).getSelectedItemPosition();
		if(fmd_buffaloFemaleResoans.equalsIgnoreCase("0"))
		{
			if(Integer.parseInt(fmd_buffaloFamaleVaccinated)<Integer.parseInt(total_FemaleBuffalo))
			{
				((Spinner)findViewById(R.id.fmd_buffaloFemaleResoans_Sp)).setFocusable(true); 
				((Spinner)findViewById(R.id.fmd_buffaloFemaleResoans_Sp)).setFocusableInTouchMode(true);
				((Spinner)findViewById(R.id.fmd_buffaloFemaleResoans_Sp)).requestFocus();
				Dialogs.AlertDialogs(VaccinationDetails.this, "Information!!", "Please select Reason for not Vaccination of Female Buffalo");
				return;
			}
		}

		Vaccdonebydata=new ArrayList<HashMap<String,String>>();
		ArrayList<String> adhaarList=new ArrayList<String>();

		if(tl.getChildCount()>=1)
		{
			for (int i = 0; i < tl.getChildCount(); i++) 
			{
				HashMap<String, String> data=new HashMap<String, String>();

				View child = tl.getChildAt(i);

				if (child instanceof LinearLayout) 
				{
					LinearLayout row = (LinearLayout) child;

					View view = row.getChildAt(0);
					View view1 = row.getChildAt(1);
					View view2 = row.getChildAt(2);

					if(((EditText)view).getText().toString().trim().equalsIgnoreCase(""))		
					{
						((EditText)view).requestFocus();
						((EditText)view).setError("Enter Name");
						return;
					}
					else 
					{
						String vaName=((EditText)view).getText().toString();
						data.put("VName",vaName);
					}

					if(((Spinner)view1).getSelectedItemPosition()==0)		
					{
						((Spinner)view1).setFocusable(true); 
						((Spinner)view1).setFocusableInTouchMode(true);
						((Spinner)view1).requestFocus();
						AlertDialogs("Information!!", "Please select Designation");
						return;
					}
					else 
					{
						String vaDesignation=((Spinner)view1).getSelectedItem().toString();
						db.open();
						String vadesignation_Id=db.getSingleValue("select DesignationID from Master_Designation where DesignationName='"+vaDesignation+"'");
						db.close();
						data.put("VDesignation",vadesignation_Id);
					}
					if(((EditText)view2).getText().toString().equalsIgnoreCase("") ||(((EditText)view2).getText().toString().length()!=12 ))		
					{
						((EditText)view2).requestFocus();
						((EditText)view2).setError("Enter AadharNo.");
						return;
					}
					else if(!CommonFunctions.validateAadharNumber(((EditText)view2).getText().toString()))
					{
						((EditText)view2).requestFocus();
						((EditText)view2).setError("Please Enter Valid Aadhaar Number");
						return;
					}
					else 
					{
						String vaaadhar=((EditText)view2).getText().toString();


						//Duplicate aadhaar number checking
						if(adhaarList.contains(vaaadhar))
						{
							((EditText)view2).requestFocus();
							((EditText)view2).setError("Aadhaar Number Already Exist");
							return;
						}
						adhaarList.add(vaaadhar); //Duplicate aadhaar number checking					

						data.put("VAadharNo",vaaadhar);

					}

					Vaccdonebydata.add(data);

				}
			}
		}
		else
		{
			AlertDialogs("Information!!", "Please Add Minimum 1 member Details");
			return;
		}
		//		if(Vaccdonebydata.size() <=0)
		//		{
		//			db.open();
		//			String empName=db.getSingleValue("select EmployeeName from Department_User_Registration where AADHARNo='"+HomeData.userID+"'");
		//			String empDesignation=db.getSingleValue("select Designation from Department_User_Registration where AADHARNo='"+HomeData.userID+"'");
		//			db.close();
		//			
		//			HashMap<String, String> data=new HashMap<String, String>();
		//			data.put("VName",empName);
		//			data.put("VDesignation",empDesignation);
		//			data.put("VAadharNo",HomeData.userID);
		//			Vaccdonebydata.add(data); 
		//		}
		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat sdfServerDF = new SimpleDateFormat("dd/MM/yyyy");
		String serverDate=dateOFvacinnation;
		try 
		{
			Date date = sdfServerDF.parse(dateOFvacinnation);
			serverDate = sdf.format(date.getTime());
		} 
		catch (ParseException e)
		{
			e.printStackTrace();
		}





		String createdDate = sdf.format(c.getTime());

		if(fmd_whiteMaleVaccinated.equalsIgnoreCase("")||fmd_whiteMaleVaccinated==null)
			fmd_whiteMaleVaccinated="0";
		if(fmd_whiteFamaleVaccinated.equalsIgnoreCase("")||fmd_whiteFamaleVaccinated==null)
			fmd_whiteFamaleVaccinated="0";
		if(fmd_buffaloMaleVaccinated.equalsIgnoreCase("")||fmd_buffaloMaleVaccinated==null)
			fmd_buffaloMaleVaccinated="0";
		if(fmd_buffaloFamaleVaccinated.equalsIgnoreCase("")||fmd_buffaloFamaleVaccinated==null)
			fmd_buffaloFamaleVaccinated="0";
		usedDoses=Integer.parseInt(fmd_whiteMaleVaccinated)+Integer.parseInt(fmd_whiteFamaleVaccinated)	+Integer.parseInt(fmd_buffaloMaleVaccinated)+Integer.parseInt(fmd_buffaloFamaleVaccinated);
		String noOfDoses=((TextView)findViewById(R.id.fmd_nofDoses_Tv)).getText().toString();
		if(Float.parseFloat(noOfDoses)<usedDoses)
		{
			AlertDialogs("Information", "Vaccination Doses Not Available, Please check No.of Doses Available");
			return;
		}
		String remain_Doses=""+(tot_Animals-usedDoses);
		batchNo=brewNoSp.getSelectedItem().toString().trim();
		sequenceNo=GenerateUniqueID();
		//<Old_AADHARNo></Old_AADHARNo> <New_AADHARNo></New_AADHARNo>
		FarmerRegXmlDoc=new StringBuilder();
		FarmerRegXmlDoc.append("<FarmerFMDCP>");
		FarmerRegXmlDoc.append(""
				+ "<DateOfVaccination>"+serverDate+"</DateOfVaccination>" 
				+ "<MandalID>"+Mandal_id+"</MandalID>"
				+ "<VillageID>"+Viialge_id+"</VillageID>"
				+ "<BatchNo>"+batchNo+"</BatchNo>"
				+ "<Old_AADHARNo>"+AadhaarNo+"</Old_AADHARNo>"
				+ "<New_AADHARNo>"+AadhaarNo+"</New_AADHARNo>"
				+ "<FarmerName>"+name+"</FarmerName>"
				+ "<Gender>"+gender+"</Gender>"
				+ "<MobileNo>"+mobile+"</MobileNo>" 
				+ "<SocialStatusID>"+socialstatusId+"</SocialStatusID>"
				+ "<WhiteCattleMale>"+MaleCattle_edt.getText().toString()+"</WhiteCattleMale>"
				+ "<WhiteCattleFemale>"+FemaleCattle_edt.getText().toString()+"</WhiteCattleFemale>"
				+ "<BuffaloesMale>"+Malebuffaloes_edt.getText().toString()+"</BuffaloesMale>"
				+ "<BuffaloesFemale>"+Femalebuffaloes_edt.getText().toString()+"</BuffaloesFemale>"
				+ "<WhiteCattle_NoUsedForDraught>"+fmd_whiteMaleDraught+"</WhiteCattle_NoUsedForDraught>"
				+ "<WhiteCattle_Male_vaccinated>"+fmd_whiteMaleVaccinated+"</WhiteCattle_Male_vaccinated>"
				+ "<WhiteCattle_Female_vaccinated>"+fmd_whiteFamaleVaccinated+"</WhiteCattle_Female_vaccinated>"
				+ "<WhiteCattle_NumberOfAnimalsPregnant>"+fmd_whiteFeMalePragnant+"</WhiteCattle_NumberOfAnimalsPregnant>"
				+ "<Buffalo_NoUsedForDraught>"+fmd_buffaloMaleDraught+"</Buffalo_NoUsedForDraught>"
				+ "<Buffalo_Male_vaccinated>"+fmd_buffaloMaleVaccinated+"</Buffalo_Male_vaccinated>"
				+ "<Buffalo_Female_vaccinated>"+fmd_buffaloFamaleVaccinated+"</Buffalo_Female_vaccinated>"
				+ "<Buffalo_NumberOfAnimalsPregnant>"+fmd_buffaloFemalePragnant+"</Buffalo_NumberOfAnimalsPregnant>"
				+ "<Buffalo_Male_AnimalsNotVaccinated_Reason>"+fmd_buffaloMaleResoans+"</Buffalo_Male_AnimalsNotVaccinated_Reason>"
				+ "<Buffalo_FeMale_AnimalsNotVaccinated_Reason>"+fmd_buffaloFemaleResoans+"</Buffalo_FeMale_AnimalsNotVaccinated_Reason>"
				+ "<WhiteCattle_Male_AnimalsNotVaccinated_Reason>"+fmd_whiteMaleResoans+"</WhiteCattle_Male_AnimalsNotVaccinated_Reason>"
				+ "<WhiteCattle_FeMale_AnimalsNotVaccinated_Reason>"+fmd_whiteFemaleResoans+"</WhiteCattle_FeMale_AnimalsNotVaccinated_Reason>"
				+ "<NoOfDosesRemaining>"+remain_Doses+"</NoOfDosesRemaining>"
				+ "<UsedDoses>"+usedDoses+"</UsedDoses>"
				+ "<Longitude>"+longitude+"</Longitude>"
				+ "<Latitude>"+latitude+"</Latitude>"
				+ "<Image>"+strBaseimage+"</Image>"
				+ "<SequenceNo>"+sequenceNo+"</SequenceNo>"); 
		FarmerRegXmlDoc.append("<VaccDoneBy>");
		for(HashMap<String, String> hm:Vaccdonebydata)
		{
			FarmerRegXmlDoc.append("<VaccDoneByDetails>");
			FarmerRegXmlDoc.append("<VaccDoneBy_Name>"+hm.get("VName")+"</VaccDoneBy_Name>");
			FarmerRegXmlDoc.append("<VaccDoneBy_Designation>"+hm.get("VDesignation")+"</VaccDoneBy_Designation>");
			FarmerRegXmlDoc.append("<VaccDoneBy_AadharNo>"+hm.get("VAadharNo")+"</VaccDoneBy_AadharNo>");
			FarmerRegXmlDoc.append("</VaccDoneByDetails>");  
		}
		FarmerRegXmlDoc.append("</VaccDoneBy>");
		FarmerRegXmlDoc.append("</FarmerFMDCP>");


		SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
		String vaccinatedDate = sdf2.format(c.getTime());

		FarmerDetails=new ContentValues();
		//	FarmerDetails.put("User_Name","test");
		FarmerDetails.put("Aadhar_No",AadhaarNo);
		FarmerDetails.put("Farmer_Name",name);
		FarmerDetails.put("Mobile_No",mobile);
		FarmerDetails.put("Male_White_Cattle",MaleCattle_edt.getText().toString() );
		FarmerDetails.put("Male_Buffaloes",Malebuffaloes_edt.getText().toString() );
		FarmerDetails.put("Female_White_Cattle",FemaleCattle_edt.getText().toString() );
		FarmerDetails.put("Female_Buffaloes",Femalebuffaloes_edt.getText().toString() );
		FarmerDetails.put("Gender",gender);
		FarmerDetails.put("District_Id",Dist_id);
		FarmerDetails.put("Mandal_Id",Mandal_id);
		FarmerDetails.put("Village_Id",Viialge_id);
		FarmerDetails.put("Social_Status",socialstatusId);
		FarmerDetails.put("Is_Sync","N");
		FarmerDetails.put("Created_Date",createdDate1);
		FarmerDetails.put("Created_By",HomeData.userAadhaarID);

		VaccinationDetails=new ContentValues();
		VaccinationDetails.put("FarmerRegID",AadhaarNo);  
		VaccinationDetails.put("BatchNo",batchNo); 
		VaccinationDetails.put("DateOfVaccination",dateOFvacinnation); 
		VaccinationDetails.put("WhiteCattle_NoUsedForDraught",fmd_whiteMaleDraught);  
		VaccinationDetails.put("WhiteCattle_Male_vaccinated",fmd_whiteMaleVaccinated);  
		VaccinationDetails.put("WhiteCattle_Female_vaccinated",fmd_whiteFamaleVaccinated);  
		VaccinationDetails.put("WhiteCattle_NumberOfAnimalsPregnant",fmd_whiteFeMalePragnant);  
		VaccinationDetails.put("Buffalo_NoUsedForDraught",fmd_buffaloMaleDraught);  
		VaccinationDetails.put("Buffalo_Male_vaccinated",fmd_buffaloMaleVaccinated);  
		VaccinationDetails.put("Buffalo_Female_vaccinated",fmd_buffaloFamaleVaccinated);
		VaccinationDetails.put("Buffalo_NumberOfAnimalsPregnant",fmd_buffaloFemalePragnant); 
		VaccinationDetails.put("Buffalo_Male_AnimalsNotVaccinated_Reason",fmd_buffaloMaleResoans);  
		VaccinationDetails.put("Buffalo_FeMale_AnimalsNotVaccinated_Reason",fmd_buffaloFemaleResoans); 
		VaccinationDetails.put("WhiteCattle_Male_AnimalsNotVaccinated_Reason",fmd_whiteMaleResoans);  
		VaccinationDetails.put("WhiteCattle_FeMale_AnimalsNotVaccinated_Reason",fmd_whiteFemaleResoans);
		VaccinationDetails.put("NoOfDosesRemaining",remain_Doses);
		VaccinationDetails.put("Is_Sync","N");
		VaccinationDetails.put("IsActive","Y");
		VaccinationDetails.put("Image",strBaseimage);
		VaccinationDetails.put("Latitude",latitude);
		VaccinationDetails.put("Longitude",longitude);
		VaccinationDetails.put("CreatedBy",HomeData.userAadhaarID);
		//VaccinationDetails.put("CreatedDate",vaccinatedDate);
		VaccinationDetails.put("ModifiedBy",HomeData.userAadhaarID);
		//VaccinationDetails.put("ModifiedDate",vaccinatedDate);

		VaccinationDoneByDetailslist=new ArrayList<ContentValues>();

		for(HashMap<String, String> hm:Vaccdonebydata)
		{

			VaccinationDoneByDetails=new ContentValues();
			VaccinationDoneByDetails.put("FarmerRegID",AadhaarNo);
			VaccinationDoneByDetails.put("SeqID",sequenceNo);  
			VaccinationDoneByDetails.put("VaccDoneBy_Name",hm.get("VName"));  
			VaccinationDoneByDetails.put("VaccDoneBy_Aadhar",hm.get("VAadharNo"));  
			VaccinationDoneByDetails.put("VaccDoneBy_Designation",hm.get("VDesignation"));  
			VaccinationDoneByDetails.put("CreatedBy",HomeData.userAadhaarID);  
			VaccinationDoneByDetails.put("CreatedDate",createdDate); 
			VaccinationDoneByDetailslist.add(VaccinationDoneByDetails);

		}

		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.optional_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("Do you want to Sumbmit the Vaccination details?");
		Button yes =(Button)dialog.findViewById(R.id.yes_button); 
		Button no =(Button)dialog.findViewById(R.id.no_button); 
		//	yes.startAnimation(shake);
		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				insertFarmerData(); 
				return;
			}
		}); 
		no.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		}); 
		if(!dialog.isShowing())
			dialog.show();

	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
	{
		switch (parent.getId())
		{
		case R.id.VacDetails_mandal_sp:

			String mandalName=parent.getSelectedItem().toString().trim();
			if(!mandalName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				Mandal_id=db.getSingleValue("select MandalID from Master_Mandal where DistrictID='"+Dist_id+"' and  trim(MandalName)='"+mandalName.trim()+"' ORDER BY MandalName");
				db.close();
				loadSpinnerData(SP.getVillageList(Dist_id, Mandal_id), (Spinner) findViewById(R.id.VacDetails_village_sp));
			}
			break;
		case R.id.VacDetails_village_sp:
			String villName=parent.getSelectedItem().toString().trim();
			if(!villName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				Viialge_id=db.getSingleValue(SP.getVillageID(Dist_id, Mandal_id, villName));
				db.close();
			}
			break;
		case R.id.VacDetails_socialstatus_sp:
			String socialsp=parent.getSelectedItem().toString().trim();
			if(!socialsp.equalsIgnoreCase("--Select--"))
			{
				db.open();
				socialstatusId=db.getSingleValue(SP.getSocialStatusID(socialsp));
				db.close();
			}
			break;
		case R.id.fmd_batchNo_sp:
			batno=parent.getSelectedItem().toString();
			if(!batno.equalsIgnoreCase("--Select--")) 
			{
				db.open();
				Cursor cursor=db.getTableDataCursor("select Manufacturing_Date,Expiry_Date,AvailDoses from Vaccine_Distribution_master where BatchNo='"+batno+"' and Created_By='"+HomeData.userAadhaarID+"'");
				if(cursor.getCount()>0)
				{
					if(cursor.moveToFirst())
					{
						((TextView)findViewById(R.id.fmd_manifDate_tv)).setText(cursor.getString(cursor.getColumnIndex("Manufacturing_Date")));
						((TextView)findViewById(R.id.fmd_expDate_tv)).setText(cursor.getString(cursor.getColumnIndex("Expiry_Date")));
						((TextView)findViewById(R.id.fmd_nofDoses_Tv)).setText(cursor.getString(cursor.getColumnIndex("AvailDoses")));
					}
				}
				cursor.close();
				db.close();
				findViewById(R.id.VaccDetails_VaccinationDetails).setVisibility(8);
				findViewById(R.id.VacDetails_FarmerDetailsLL).setVisibility(8);
				findViewById(R.id.VaccDetails_VaccinationDoneByLL).setVisibility(8);
				findViewById(R.id.VacDetails_FarmerButtonLL).setVisibility(0);
				findViewById(R.id.VacDetails_farmerSearchLL).setVisibility(8);
				findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);
			}
			else
			{
				findViewById(R.id.VaccDetails_VaccinationDetails).setVisibility(8);
				findViewById(R.id.VacDetails_FarmerDetailsLL).setVisibility(8);
				findViewById(R.id.VaccDetails_VaccinationDoneByLL).setVisibility(8);
				findViewById(R.id.VacDetails_FarmerButtonLL).setVisibility(8);
				findViewById(R.id.VacDetails_farmerSearchLL).setVisibility(8);
				findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);
				((TextView)findViewById(R.id.fmd_manifDate_tv)).setText("");
				((TextView)findViewById(R.id.fmd_expDate_tv)).setText("");
				((TextView)findViewById(R.id.fmd_nofDoses_Tv)).setText("");
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {

	}


	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.VacDetails_Submit_Btn:
			ValidateData();
			break;
		case R.id.VacDetails_NewFarmer_Btn:

			findViewById(R.id.VacDetails_FarmerButtonLL).setVisibility(0);
			findViewById(R.id.VacDetails_farmerSearchLL).setVisibility(8);
			findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);
			findViewById(R.id.VaccDetails_VaccinationDetails).setVisibility(0);
			findViewById(R.id.VacDetails_FarmerDetailsLL).setVisibility(0);
			findViewById(R.id.VaccDetails_VaccinationDoneByLL).setVisibility(0);////

			((EditText)findViewById(R.id.fmd_whiteMaleVaccinated_Et)).setText("");
			((EditText)findViewById(R.id.fmd_whiteMaleDraught_Et)).setText("");
			((EditText)findViewById(R.id.fmd_whiteFamaleVaccinated_Et)).setText("");
			((EditText)findViewById(R.id.fmd_whiteFeMalePragnant_Et)).setText("");
			((EditText)findViewById(R.id.fmd_buffaloMaleVaccinated_Et)).setText("");
			((EditText)findViewById(R.id.fmd_buffaloMaleDraught_Et)).setText("");
			((EditText)findViewById(R.id.fmd_buffaloFamaleVaccinated_Et)).setText("");
			((EditText)findViewById(R.id.fmd_buffaloFemalePragnant_Et)).setText("");

			loadSpinnerData("select Reason from Master_Reasons where ReasonID!=4", (Spinner)findViewById(R.id.fmd_whiteMaleResoans_Sp));
			loadSpinnerData("select Reason from Master_Reasons", (Spinner)findViewById(R.id.fmd_whiteFemaleResoans_Sp));
			loadSpinnerData("select Reason from Master_Reasons where ReasonID!=4", (Spinner)findViewById(R.id.fmd_buffaloMaleResoans_Sp));
			loadSpinnerData("select Reason from Master_Reasons", (Spinner)findViewById(R.id.fmd_buffaloFemaleResoans_Sp));
			loadVaccinatorDetails();

			break;

		case R.id.VacDetails_ExistFarmer_Btn:

			findViewById(R.id.VacDetails_FarmerButtonLL).setVisibility(0);
			findViewById(R.id.VacDetails_farmerSearchLL).setVisibility(0);
			findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);
			findViewById(R.id.VaccDetails_VaccinationDetails).setVisibility(8);
			findViewById(R.id.VacDetails_FarmerDetailsLL).setVisibility(8);
			findViewById(R.id.VaccDetails_VaccinationDoneByLL).setVisibility(8);

			((EditText)findViewById(R.id.FR_searchdata_Et)).setText("");
			break;

		case R.id.userReg_capturePhoto_Iv:
			selectImage();
			break;

		case R.id.FR_searchdataBt:
			searchFarmerData();
			break;
		default:
			break;
		}
	}
	Dialog dialog;
	public void ShowVaccinationTeamDialog()
	{
		dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.vaccinationteamdetails);
		dialog.setCancelable(false);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		loadVaccinationTeamDetails(dialog);
		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				validateVaccinationTeamDetails(dialog);

				return;
			}


		});        
		if(!dialog.isShowing())
			dialog.show();
		dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
	}

	private void validateVaccinationTeamDetails(Dialog dialog) 
	{
		LinearLayout tl=((LinearLayout)dialog.findViewById(R.id.VaccDoneby_tabledata));
		Vaccdonebydata=new ArrayList<HashMap<String,String>>();
		ArrayList<String> adhaarList=new ArrayList<String>();

		if(tl.getChildCount()>=1)
		{
			for (int i = 0; i < tl.getChildCount(); i++) 
			{
				HashMap<String, String> data=new HashMap<String, String>();

				View child = tl.getChildAt(i);

				if (child instanceof LinearLayout) 
				{
					LinearLayout row = (LinearLayout) child;

					View view = row.getChildAt(0);
					View view1 = row.getChildAt(1);
					View view2 = row.getChildAt(2);

					if(((EditText)view).getText().toString().trim().equalsIgnoreCase(""))		
					{
						((EditText)view).requestFocus();
						((EditText)view).setError("Enter Name");
						return;
					}
					else 
					{
						String vaName=((EditText)view).getText().toString();
						data.put("VName",vaName);
					}

					if(((Spinner)view1).getSelectedItemPosition()==0)		
					{
						((Spinner)view1).setFocusable(true); 
						((Spinner)view1).setFocusableInTouchMode(true);
						((Spinner)view1).requestFocus();
						AlertDialogs("Information!!", "Please select Designation");
						return;
					}
					else 
					{
						String vaDesignation=((Spinner)view1).getSelectedItem().toString();
						db.open();
						String vadesignation_Id=db.getSingleValue("select DesignationID from Master_Designation where DesignationName='"+vaDesignation+"'");
						db.close();
						data.put("VDesignation",vadesignation_Id);
					}
					if(((EditText)view2).getText().toString().equalsIgnoreCase("") ||(((EditText)view2).getText().toString().length()!=12 ))		
					{
						((EditText)view2).requestFocus();
						((EditText)view2).setError("Enter AadharNo.");
						return;
					}
					else if(!CommonFunctions.validateAadharNumber(((EditText)view2).getText().toString()))
					{
						((EditText)view2).requestFocus();
						((EditText)view2).setError("Please Enter Valid Aadhaar Number");
						return;
					}
					else 
					{
						String vaaadhar=((EditText)view2).getText().toString();


						//Duplicate aadhaar number checking
						if(adhaarList.contains(vaaadhar))
						{
							((EditText)view2).requestFocus();
							((EditText)view2).setError("Aadhaar Number Already Exist");
							return;
						}
						adhaarList.add(vaaadhar); //Duplicate aadhaar number checking					

						data.put("VAadharNo",vaaadhar);

					}

					Vaccdonebydata.add(data);

				}
			}
		}
		else
		{
			AlertDialogs("Information!!", "Please Add Minimum 1 member Details");
			return;
		}

		db.open();
		db.deleteTableData("FMD_Vaccinator_Details", null);
		for(HashMap<String, String> ac:Vaccdonebydata)
		{
			ContentValues VaccinatorDetails=new ContentValues();
			VaccinatorDetails.put("Vaccinator_Name", ac.get("VName"));
			VaccinatorDetails.put("Vaccinator_Aadhar", ac.get("VAadharNo"));
			VaccinatorDetails.put("Vaccinator_Designation", ac.get("VDesignation"));
			VaccinatorDetails.put("CreatedBy", HomeData.userAadhaarID);
			db.insertTableDate("FMD_Vaccinator_Details",VaccinatorDetails);
		}
		db.close();
		initializeViews();
		if(dialog.isShowing())
			dialog.dismiss();

	}
	private void loadVaccinationTeamDetails(final Dialog dialog) 
	{
		dialog.findViewById(R.id.VaccDoneby_AddBt).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{ 
				LayoutInflater inflater = getLayoutInflater();
				final View tr = (View)inflater.inflate(R.layout.row, tl, false);
				ImageButton ck=(ImageButton)tr.findViewById(R.id.check);
				loadSpinnerData("select DesignationName from Master_Designation", (Spinner)tr.findViewById(R.id.column2Sp));
				ck.setOnClickListener(new OnClickListener() 
				{
					@Override
					public void onClick(View v) 
					{
						View row = (View) v.getParent();
						ViewGroup container = ((ViewGroup)row.getParent());
						View view = ((ViewGroup) row).getChildAt(0);
						container.removeView(row);
						container.invalidate();
					}
				});
				((LinearLayout)dialog.findViewById(R.id.VaccDoneby_tabledata)).addView(tr);
				tr.requestFocus();

			}
		});


		db.open();
		Cursor cursor1=db.getTableDataCursor("Select distinct fmd.VaccDoneBy_Aadhar,fmd.VaccDoneBy_Name,md.DesignationName from FMD_VaccinationDoneBy_Details fmd,Master_Designation md where  fmd.VaccDoneBy_Designation=md.DesignationID and fmd.CreatedBy='"+HomeData.userAadhaarID+"' group by fmd.VaccDoneBy_Aadhar");
		if(cursor1.getCount()>0)
		{
			int i=0;
			((LinearLayout)dialog.findViewById(R.id.VaccDoneby_tabledata)).removeAllViews();
			if(cursor1.moveToFirst())
			{
				do
				{

					LayoutInflater inflater = getLayoutInflater();
					final View tr = (View)inflater.inflate(R.layout.row, null, false);

					((EditText)tr.findViewById(R.id.column1Et)).setText(cursor1.getString(cursor1.getColumnIndex("VaccDoneBy_Name")));
					CommonFunctions.loadSpinnerSetSelectedItem(VaccinationDetails.this,"select DesignationName from Master_Designation",(Spinner)tr.findViewById(R.id.column2Sp), cursor1.getString(cursor1.getColumnIndex("DesignationName")));
					((EditText)tr.findViewById(R.id.column3Et)).setText(cursor1.getString(cursor1.getColumnIndex("VaccDoneBy_Aadhar")));

					ImageButton ck=(ImageButton)tr.findViewById(R.id.check);
					ck.setOnClickListener(new OnClickListener() 
					{
						@Override
						public void onClick(View v) 
						{
							View row = (View) v.getParent();
							ViewGroup container = ((ViewGroup)row.getParent());
							View view = ((ViewGroup) row).getChildAt(0);
							container.removeView(row);
							container.invalidate();
						}
					});

					((LinearLayout)dialog.findViewById(R.id.VaccDoneby_tabledata)).addView(tr);
				}while(cursor1.moveToNext());
			}
		}

		cursor1.close();
		db.close();

	}

	private void searchFarmerData() 
	{
		String searchdata=((EditText)findViewById(R.id.FR_searchdata_Et)).getText().toString();
		if(searchdata.equalsIgnoreCase(""))
		{
			((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(((EditText)findViewById(R.id.FR_searchdata_Et)).getWindowToken(), 0);
			((EditText)findViewById(R.id.FR_searchdata_Et)).requestFocus();
			((EditText)findViewById(R.id.FR_searchdata_Et)).setError("Enter Aadhar Number");
			return;
		}

		((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(((EditText)findViewById(R.id.FR_searchdata_Et)).getWindowToken(), 0);
		list=new ArrayList<ArrayList<String>>();

		db.open();
		Cursor cursor=db.getTableDataCursor("Select * from FARMER_REG_DETAILS where District_Id='"+Dist_id+"' and Mandal_Id='"+Mandal_id+"' and Village_Id='"+Viialge_id+"' and (Farmer_Name like '%"+searchdata+"%' OR Aadhar_No like '%"+searchdata+"%' OR Mobile_No like '%"+searchdata+"%')");
		if(cursor.getCount()>0)
		{

			if(cursor.moveToFirst())
			{
				do
				{
					ArrayList<String> data=new ArrayList<String>();
					data.add(cursor.getString(cursor.getColumnIndex("Farmer_Name")));	
					data.add(cursor.getString(cursor.getColumnIndex("Aadhar_No")));
					data.add(cursor.getString(cursor.getColumnIndex("Mobile_No")));	
					list.add(data);
				}while(cursor.moveToNext());

			}
			cursor.close();
			db.close();
			FarmerVaccineDetailadapter fvd=new FarmerVaccineDetailadapter(VaccinationDetails.this, list);
			VacDetails_frsearchResList_ll.setAdapter(fvd);
			VacDetails_frsearchResList_ll.setVisibility(0);
			findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(0);
		}
		else
		{
			AlertDialogs("Information!!", searchdata + "  Is Not Registered");
			((EditText)findViewById(R.id.FR_searchdata_Et)).requestFocus();
			VacDetails_frsearchResList_ll.setVisibility(8);
			findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);
		}
		cursor.close();
		db.close();



		VacDetails_frsearchResList_ll.setOnItemClickListener(new OnItemClickListener() 
		{

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3)
			{

				String adharno=((TextView)arg1.findViewById(R.id.farmerrowlist_aadhar)).getText().toString();
				String vaccineDate=((TextView)findViewById(R.id.fmd_DateOfVaccination_Et)).getText().toString().trim();
				Log.d("Aadhaar", adharno);
				db.open();
				int rowCount=db.getRowCount("select count(FarmerRegID) from FMD_Vaccination_Details where FarmerRegID='"+adharno+"'");
				db.close();
				if(rowCount>0)
				{
					AlertDialogs("Information!!", "Vaccination Already Done. If you want to Update then go to Update Vaccination Page");
					return;
				}
				else
				{
					Intent i=new Intent(VaccinationDetails.this,UpdateVaccinationdetailView.class);
					i.putExtra("adharno", adharno);
					i.putExtra("batchNo", batno);
					i.putExtra("vaccDate", vaccineDate);
					startActivity(i);
					findViewById(R.id.VacDetails_farmerSearchLL).setVisibility(8);
					findViewById(R.id.VacDetails_farmerSearchnamelistLL).setVisibility(8);
				}
			}
		});
	}

	private void selectImage()
	{
		try {
			final CharSequence[] items = { "Take Photo", "Choose from Library","Cancel" };
			android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(VaccinationDetails.this);
			builder.setTitle("Select Photo!");
			builder.setItems(items, new DialogInterface.OnClickListener()
			{
				@Override
				public void onClick(DialogInterface dialog, int item)
				{
					if (items[item].equals("Take Photo"))
					{
						gps=new GPSTracker(VaccinationDetails.this);
						if(gps.canGetLocation())
						{
							latitude=gps.getLatitude();
							longitude=gps.getLongitude();
							Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
							startActivityForResult(intent, REQUEST_CAMERA);
						}
						else
						{
							gps.showSettingsAlert();
						}

					}
					else if (items[item].equals("Choose from Library"))
					{
						Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
						intent.setType("image/*");
						startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
					}
					else if (items[item].equals("Cancel"))
					{
						dialog.dismiss();
					}
				}
			});
			builder.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void insertFarmerData() 
	{
		db.open();
		db.insertTableDate("FARMER_REG_DETAILS",FarmerDetails);
		db.insertTableDate("FMD_Vaccination_Details",VaccinationDetails);

		for(ContentValues ac:VaccinationDoneByDetailslist)
		{
			ContentValues VaccinatorDetails=new ContentValues();
			VaccinatorDetails.put("Vaccinator_Name", ac.getAsString("VaccDoneBy_Name"));
			VaccinatorDetails.put("Vaccinator_Aadhar", ac.getAsString("VaccDoneBy_Aadhar"));
			VaccinatorDetails.put("Vaccinator_Designation", ac.getAsString("VaccDoneBy_Designation"));
			VaccinatorDetails.put("CreatedBy", HomeData.userAadhaarID);

			db.insertTableDate("FMD_VaccinationDoneBy_Details",ac);
			db.insertTableDate("FMD_Vaccinator_Details",VaccinatorDetails);

		}
		db.close();


		ContentValues data=new ContentValues();
		data.put("METHOD_NAME", "FMDCP24_Mobile_InsertFarmerFMDDetails");
		data.put("XMLDATA", FarmerRegXmlDoc.toString());
		data.put("Aadhaar_No", AadhaarNo);
		db.open();
		db.insertTableDate("UPLOAD_OFFLINEDATA",data);
		//db.close();
		db.execSQL("update Vaccine_Distribution_master set AvailDoses=AvailDoses-'"+usedDoses+"' where BatchNo='"+batchNo+"'");
		db.close();

		tl.removeAllViews();

		initializeViews();
		AlertDialogs("Information!!", "Vaccination Details Successfully Submited");
	}


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == Activity.RESULT_OK)
		{
			if (requestCode == SELECT_FILE)
				onSelectFromGalleryResult(data);
			else if (requestCode == REQUEST_CAMERA)
				onCaptureImageResult(data);
		}
	}
	private void onCaptureImageResult(Intent data)
	{
		try
		{
			Bitmap photo = (Bitmap) data.getExtras().get("data");
			int width=photo.getWidth()/2;
			int height=photo.getHeight()/2;
			Bitmap scaled = Bitmap.createScaledBitmap(photo,width,height, true);
			photoCaptureIv.setImageBitmap(scaled);
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
			byte[] byteArray = stream.toByteArray();
			strBaseimage= Base64.encode(byteArray);

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}


	@SuppressWarnings("deprecation")
	private void onSelectFromGalleryResult(Intent data)
	{
		try
		{
			Uri selectedImageUri = data.getData();
			String[] projection = { MediaStore.MediaColumns.DATA };
			Cursor cursor = managedQuery(selectedImageUri, projection, null, null,null);
			int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
			cursor.moveToFirst();
			String selectedImagePath = cursor.getString(column_index);
			Bitmap photo;
			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeFile(selectedImagePath, options);
			final int REQUIRED_SIZE = 200;
			int scale = 1;
			while (options.outWidth / scale / 2 >= REQUIRED_SIZE&& options.outHeight / scale / 2 >= REQUIRED_SIZE)
				scale *= 2;
			options.inSampleSize = scale;
			options.inJustDecodeBounds = false;
			photo = BitmapFactory.decodeFile(selectedImagePath, options);

			int width=photo.getWidth()/2;
			int height=photo.getHeight()/2;
			Bitmap scaled = Bitmap.createScaledBitmap(photo,width,height, true);
			photoCaptureIv.setImageBitmap(scaled);
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
			byte[] byteArray = stream.toByteArray();
			strBaseimage= Base64.encode(byteArray);

			photoCaptureIv.setImageBitmap(photo);

		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onBackPressed()
	{
		super.onBackPressed();

		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}

	@SuppressLint("DefaultLocale")
	private String GenerateUniqueID()
	{
		String strSecretCode = "";
		try
		{
			UUID uuid = UUID.randomUUID();    
			String strguid = uuid.toString();
			strSecretCode = strguid.substring(strguid.lastIndexOf("-") + 1);
			strSecretCode = strSecretCode.toUpperCase().replace('O', 'W').replace('0', '4');
			strSecretCode = strSecretCode.substring(0, 11);
			strSecretCode = "S" + strSecretCode;
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			//
		}
		return strSecretCode;
	}
}
