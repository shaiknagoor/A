package com.aponline.fmdcp;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.kobjects.base64.Base64;

import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.database.SP;
import com.aponline.fmdcp.server.RequestServer;
import com.aponline.fmdcp.server.ServerResponseListener;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class UserRegistration extends AppCompatActivity implements OnClickListener,OnItemSelectedListener,ServerResponseListener
{
	GPSTracker gps;
	double latitude,longitude;

	public static String UserName,Password;

	ProgressDialog progressDialog;
	Handler mHandler;
	Context context;

	DBAdapter db;
	private String distrID="",divisionID="",mandalID="",instiTypeID="",instiLoctinID="",desigID="";
	int roleID=5;


	ImageView photoCaptureIv;
	private static final int CAMERA_REQUEST = 1888; 
	public static String strBaseimage="";

	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.userregistration);
		context=this;
		db=new DBAdapter(this);
		intializeViews();

	}
	StringBuilder UserRegXmlDoc;
	private void validateData() 
	{
		try 
		{
			String empName=((EditText)findViewById(R.id.empName_ET)).getText().toString().trim();
			if(empName.equalsIgnoreCase(""))
			{
				//	AlertDialogs("Information!!", " Please Enter the Farmer Name");
				((EditText)findViewById(R.id.empName_ET)).requestFocus();
				((EditText)findViewById(R.id.empName_ET)).setError("FIELD CAN NOT BE EMPTY");
				return;
			}
			else if(!empName.matches("[\\p{L}-]+")||empName.startsWith(" "))
			{
				((EditText)findViewById(R.id.empName_ET)).requestFocus();
				((EditText)findViewById(R.id.empName_ET)).setError("ENTER ONLY ALPHABETICAL CHARACTER");
				return;
			}

			String designation=((Spinner)findViewById(R.id.empDesig_Sp)).getSelectedItem().toString().trim();
			if(designation.equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Designation");
				((Spinner)findViewById(R.id.empDesig_Sp)).requestFocus();
				return;
			}
			String empID=((EditText)findViewById(R.id.empID_ET)).getText().toString().trim();
			if(empID.equalsIgnoreCase(""))
			{
				if(!designation.contains("Gopal"))
				{
					((EditText)findViewById(R.id.empID_ET)).requestFocus();
					((EditText)findViewById(R.id.empID_ET)).setError("FIELD CAN NOT BE EMPTY");
					return;
				}
			}
			String aadhaarNo=((EditText)findViewById(R.id.empAadhrNo_ET)).getText().toString().trim();
			if(aadhaarNo.equalsIgnoreCase(""))
			{
				//AlertDialogs("Information!!", " Please Enter the Aadhaar Number");
				((EditText)findViewById(R.id.empAadhrNo_ET)).requestFocus();
				((EditText)findViewById(R.id.empAadhrNo_ET)).setError("FIELD CAN NOT BE EMPTY");
				return;
			}
			if(Character.isDigit(aadhaarNo.charAt(0)))
			{
				if(!CommonFunctions.validateAadharNumber(aadhaarNo))
				{
					//AlertDialogs("Information!!", " Please Enter Valid Aadhaar Number");
					((EditText)findViewById(R.id.empAadhrNo_ET)).requestFocus();
					((EditText)findViewById(R.id.empAadhrNo_ET)).setError(" Please Enter Valid Aadhaar Number");
					return;
				}
			}
			String mobile=((EditText)findViewById(R.id.empMobNo_ET)).getText().toString().trim();
			if(mobile.equalsIgnoreCase("")||mobile.equalsIgnoreCase("0"))
			{
				//AlertDialogs("Information!!", " Please Enter Mobile Number");
				((EditText)findViewById(R.id.empMobNo_ET)).requestFocus();
				((EditText)findViewById(R.id.empMobNo_ET)).setError("Please Enter Mobile Number");
				return;
			}
			else if(!mobile.matches("[7-9]{1}+[0-9]+")||mobile.length()!=10)
			{
				((EditText)findViewById(R.id.empMobNo_ET)).requestFocus();
				((EditText)findViewById(R.id.empMobNo_ET)).setError("Please Enter Valid Mobile Number");
				return;
			}
			String gender="1";
			if(((RadioButton)findViewById(R.id.male_RD)).isChecked())
			{
				gender="1";
			}
			else if(((RadioButton)findViewById(R.id.female_RD)).isChecked())
			{
				gender="2";
			}
			if(roleID >= 2)
			{
				String districtNa=((Spinner)findViewById(R.id.emp_districtSp)).getSelectedItem().toString().trim();
				if(districtNa.equalsIgnoreCase("--Select--"))
				{
					AlertDialogs("Information!!", " Please Select District");
					((Spinner)findViewById(R.id.emp_districtSp)).requestFocus();
					return;
				}
			}
			if(roleID >= 3)
			{
				String divisionNa=((Spinner)findViewById(R.id.emp_divisionSp)).getSelectedItem().toString().trim();
				if(divisionNa.equalsIgnoreCase("--Select--"))
				{
					AlertDialogs("Information!!", " Please Select Division");
					((Spinner)findViewById(R.id.emp_divisionSp)).requestFocus();
					return;
				}
			}
			if(roleID >= 4)
			{
				String mandalNa=((Spinner)findViewById(R.id.emp_mandalSp)).getSelectedItem().toString().trim();
				if(mandalNa.equalsIgnoreCase("--Select--"))
				{
					AlertDialogs("Information!!", " Please Select Mandal");
					((Spinner)findViewById(R.id.emp_mandalSp)).requestFocus();
					return;
				}
			}	
			if(roleID >= 5)
			{
				String institutionType=((Spinner)findViewById(R.id.institutiontypeSp)).getSelectedItem().toString().trim();
				if(institutionType.equalsIgnoreCase("--Select--"))
				{
					AlertDialogs("Information!!", " Please Select Institution Type");
					((Spinner)findViewById(R.id.institutiontypeSp)).requestFocus();
					return;
				}
				String insLocation=((Spinner)findViewById(R.id.Location_InstitutionSp)).getSelectedItem().toString().trim();
				if(insLocation.equalsIgnoreCase("--Select--"))
				{
					AlertDialogs("Information!!", " Please Select Institution Location");
					((Spinner)findViewById(R.id.Location_InstitutionSp)).requestFocus();
					return;
				}
			}
			String bankName=((EditText) findViewById(R.id.bankNameEt)).getText().toString().trim();
			//			if(!bankName.equalsIgnoreCase(""))
			//			{
			//				if(!bankName.matches("[\\p{L}- ]+"))
			//				{
			//					((EditText)findViewById(R.id.bankNameEt)).requestFocus();
			//					((EditText)findViewById(R.id.bankNameEt)).setError("ENTER ONLY ALPHABETICAL CHARACTER");
			//					return;
			//				}
			//			}
			String accno=((EditText) findViewById(R.id.accno_edt)).getText().toString().trim();
			//			if(accno.isEmpty())
			//			{
			//				if(!bankName.equalsIgnoreCase(""))
			//				{
			//					((EditText) findViewById(R.id.accno_edt)).requestFocus();
			//					((EditText) findViewById(R.id.accno_edt)).setError("Enter Bank Account No.");
			//					return;
			//				}
			//			}
			String ifsccod=((EditText) findViewById(R.id.ifsccode_edt)).getText().toString().trim();
			//			if(ifsccod.isEmpty())
			//			{
			//				if(!bankName.equalsIgnoreCase("")||!accno.equalsIgnoreCase(""))
			//				{
			//					((EditText) findViewById(R.id.ifsccode_edt)).requestFocus();
			//					((EditText) findViewById(R.id.ifsccode_edt)).setError("Enter IFSC code");
			//					return;
			//				}
			//			}
			String bankBranch=((EditText) findViewById(R.id.bankBranch_edt)).getText().toString().trim();
			//			if(bankBranch.isEmpty())
			//			{
			//				if(!bankName.equalsIgnoreCase("")||!accno.equalsIgnoreCase(""))
			//				{
			//					((EditText) findViewById(R.id.bankBranch_edt)).requestFocus();
			//					((EditText) findViewById(R.id.bankBranch_edt)).setError("Enter Bank Branch Name");
			//					return;
			//				}
			//			} 

			gps=new GPSTracker(UserRegistration.this);
			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();

				Calendar c = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				String createdDate = sdf.format(c.getTime());

				db.open();
				int rowCount=db.getRowCount("select count(AADHARNo) from Department_User_Registration where AADHARNo='"+aadhaarNo+"'");
				db.close();
				if(rowCount>0)
				{
					AlertDialogs("Information!!", "User Already registered on this Aadhaar/Voter id number,Please check once");
					return;
				}

				//				if(CheckConnection.isNetworkAvailable(UserRegistration.this))
				//				{
				UserRegXmlDoc=new StringBuilder();
				UserRegXmlDoc.append("<DeptUserRegistraion>");
				UserRegXmlDoc.append(""
						+ "<AADHARNo>"+aadhaarNo+"</AADHARNo>"
						+ "<DistrictID>"+distrID+"</DistrictID>"
						+ "<DivisionID>"+divisionID+"</DivisionID>"
						+ "<MandalID>"+mandalID+"</MandalID>"
						+ "<LocationOfInstitutionID>"+instiLoctinID+"</LocationOfInstitutionID>"
						+ "<TypeOfInstitution>"+instiTypeID+"</TypeOfInstitution>"
						+ "<EmployeeName>"+empName+"</EmployeeName>"
						+ "<Designation>"+desigID+"</Designation>"
						+ "<MobileNo>"+mobile+"</MobileNo>"
						+ "<EmployeeID>"+empID+"</EmployeeID>"
						+ "<BankName>"+bankName+"</BankName>"
						+ "<AccountNo>"+accno+"</AccountNo>"
						+ "<IFSCCode>"+ifsccod+"</IFSCCode>"
						+ "<BranchName>"+bankBranch+"</BranchName>"
						+ "<Gender>"+gender+"</Gender>"
						+ "<Longitude>"+longitude+"</Longitude>"
						+ "<Latitude>"+latitude+"</Latitude>"
						+ "<Image>"+strBaseimage+"</Image>");
				UserRegXmlDoc.append("</DeptUserRegistraion>");
				RequestServer request=new RequestServer(this);
				request.addParam("XML", UserRegXmlDoc.toString());
				request.addParam("DeviceID", HomeData.sDeviceId);
				request.ProccessRequest(this, "InsertUserRegistrationDetails");
				return;
				//				}
				//				else
				//				{
				//
				//					ContentValues contentValues=new ContentValues();
				//					//contentValues.put("DeptRegID", userRegID );
				//					contentValues.put("AADHARNo", aadhaarNo);
				//					contentValues.put("DistrictID",distrID );
				//					contentValues.put("DivisionID",divisionID );
				//					contentValues.put("MandalID",mandalID );
				//					contentValues.put("LocationOfInstitutionID",instiLoctinID );
				//					contentValues.put("TypeOfInstitution",instiTypeID );
				//					contentValues.put("EmployeeID",empID );
				//					contentValues.put("EmployeeName",empName );
				//					contentValues.put("GenderID",gender );
				//					contentValues.put("Designation",desigID );
				//					contentValues.put("MobileNo",mobile);
				//					contentValues.put("BankName",bankName);
				//					contentValues.put("AccountNo",accno);
				//					contentValues.put("IFSCCode",ifsccod);
				//					contentValues.put("BranchName",bankBranch);
				//					contentValues.put("IsActive","Y" );
				//					contentValues.put("CreatedBy",empName );
				//					contentValues.put("CreatedDate",createdDate );
				//					db.open(); 
				//					db.insertTableDate("Department_User_Registration", contentValues);
				//					db.close();
				//
				//					ContentValues contentValues2=new ContentValues();
				//					contentValues.put("UserLoginID", aadhaarNo);
				//					contentValues.put("UserID",aadhaarNo );
				//					contentValues.put("RoleID",roleID );
				//					contentValues.put("IsActive","Y" );
				//					db.open(); 
				//					db.insertTableDate("User_Login_Details", contentValues2);
				//					db.close();
				//					AlertDialogs("Information!!", "User Registration Successfully Completed");
				//					intializeViews();
				//				}
			}
			else
			{
				gps.showSettingsAlert();
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	private void intializeViews()   
	{

		try 
		{
			((EditText)findViewById(R.id.empName_ET)).requestFocus();
			((EditText)findViewById(R.id.empID_ET)).setText("");
			((EditText)findViewById(R.id.empName_ET)).setText("");
			((EditText)findViewById(R.id.empMobNo_ET)).setText("");
			((EditText)findViewById(R.id.empAadhrNo_ET)).setText("");
			((RadioButton)findViewById(R.id.male_RD)).setChecked(true);
			((RadioButton)findViewById(R.id.female_RD)).setChecked(false);
			((EditText)findViewById(R.id.bankNameEt)).setText("");
			((EditText) findViewById(R.id.ifsccode_edt)).setText("");
			((EditText) findViewById(R.id.accno_edt)).setText("");
			((EditText) findViewById(R.id.bankBranch_edt)).setText("");
			//((ImageView) findViewById(R.id.userReg_capturePhoto_Iv)
			loadSpinnerData("select distinct DesignationName from  Master_Designation where IsActive=1",((Spinner)findViewById(R.id.empDesig_Sp)));

			((Spinner)findViewById(R.id.empDesig_Sp)).setSelection(0);
			((Spinner)findViewById(R.id.emp_districtSp)).setSelection(0);
			((Spinner)findViewById(R.id.emp_divisionSp)).setSelection(0);
			((Spinner)findViewById(R.id.emp_mandalSp)).setSelection(0);
			((Spinner)findViewById(R.id.institutiontypeSp)).setSelection(0);
			((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);



			((Spinner)findViewById(R.id.empDesig_Sp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.emp_districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.emp_divisionSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.emp_mandalSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.institutiontypeSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.Location_InstitutionSp)).setOnItemSelectedListener(this);
			findViewById(R.id.userReg_BankDetailsMore_Tv).setOnClickListener(this);
			photoCaptureIv=(ImageView)findViewById(R.id.userReg_capturePhoto_Iv);
			photoCaptureIv.setOnClickListener(this);

			findViewById(R.id.loginRegBt).setOnClickListener(this);
			findViewById(R.id.submitRegData).setOnClickListener(this);

		} 
		catch (Exception e)
		{
			CommonFunctions.writeLog("UserRegistration", "intializeViews", e.getMessage());
			e.printStackTrace();
		}
	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

			//	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(FarmerRegistration.this,android.R.layout.simple_spinner_item, lables);
			//	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view,int position, long id) 
	{

		switch (parent.getId()) 
		{
		case R.id.empDesig_Sp:
			String desg=parent.getSelectedItem().toString();
			if(!desg.equalsIgnoreCase("--Select--"))
			{
				try 
				{
					loadSpinnerData("select distinct DistrictName from  Master_District",((Spinner)findViewById(R.id.emp_districtSp)));
					db.open();
					desigID=db.getSingleValue(SP.getDesignationId_SP(desg));
					String RoleID=db.getSingleValue(SP.getRoleID_SP(desg));
					db.close();
					roleID=Integer.parseInt(RoleID);
				} 
				catch (Exception e)
				{
					roleID=5;
					e.printStackTrace();
				}
				checkRoleState();
			}
			else
			{
				roleID=5;
				checkRoleState();
			}
			break;
		case R.id.emp_districtSp:
			String empdistrictName=parent.getSelectedItem().toString().trim();  
			if(!empdistrictName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				distrID=db.getSingleValue(SP.getDistrictID_SP(empdistrictName));
				db.close();
				loadSpinnerData(SP.getDivisionList_SP(distrID), ((Spinner)findViewById(R.id.emp_divisionSp)));
			}
			else
			{
				((Spinner)findViewById(R.id.emp_divisionSp)).setSelection(0);
				((Spinner)findViewById(R.id.emp_mandalSp)).setSelection(0);
				((Spinner)findViewById(R.id.institutiontypeSp)).setSelection(0);
				((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
			}
			break;
		case R.id.emp_divisionSp:
			String empdivisionName=parent.getSelectedItem().toString().trim(); 
			if(!empdivisionName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				divisionID=db.getSingleValue(SP.getDivisionID_SP(empdivisionName,distrID));
				db.close();
				loadSpinnerData(SP.getMandalList_SP(divisionID,distrID),((Spinner)findViewById(R.id.emp_mandalSp)));
			}
			else
			{
				((Spinner)findViewById(R.id.emp_mandalSp)).setSelection(0);
				((Spinner)findViewById(R.id.institutiontypeSp)).setSelection(0);
				((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
			}
			break;

		case R.id.emp_mandalSp:
			String mandalName=parent.getSelectedItem().toString();
			if(!mandalName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				mandalID=db.getSingleValue(SP.getMandalID_SP(mandalName, divisionID, distrID));
				db.close();
				loadSpinnerData(SP.getInstitutionTypeList_SP(distrID, divisionID, mandalID),((Spinner)findViewById(R.id.institutiontypeSp)));
			}
			else
			{
				((Spinner)findViewById(R.id.institutiontypeSp)).setSelection(0);
				((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
			}
			break;

		case R.id.institutiontypeSp:
			String institypeName=parent.getSelectedItem().toString().trim();

			if(!institypeName.equalsIgnoreCase("--Select--"))  
			{
				db.open();
				instiTypeID=db.getSingleValue(SP.getInstitutionTypeID(institypeName));
				db.close();
				loadSpinnerData(SP.getInstitutionsLocationList_SP(instiTypeID,distrID, divisionID, mandalID),((Spinner)findViewById(R.id.Location_InstitutionSp)));
			}
			else
			{
				((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
			}
			break;
		case R.id.Location_InstitutionSp:
			String instituteName=parent.getSelectedItem().toString();
			if(!instituteName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				instiLoctinID=db.getSingleValue(SP.getInstitutionsLocationID_SP(instituteName, distrID, divisionID, mandalID));
				db.close();
			}
		default:
			break;
		}
	}
	private void checkRoleState() 
	{
		if(roleID==1)
		{
			findViewById(R.id.districtLL).setVisibility(8);
			findViewById(R.id.divisionLL).setVisibility(8);
			findViewById(R.id.mandalLL).setVisibility(8);
			findViewById(R.id.InstitutionLL).setVisibility(8);
			findViewById(R.id.Location_InstitutionLL).setVisibility(8);
		}
		else if(roleID==2)
		{
			findViewById(R.id.districtLL).setVisibility(0);
			findViewById(R.id.divisionLL).setVisibility(8);
			findViewById(R.id.mandalLL).setVisibility(8);
			findViewById(R.id.InstitutionLL).setVisibility(8);
			findViewById(R.id.Location_InstitutionLL).setVisibility(8);
		}
		else if(roleID==3)
		{
			findViewById(R.id.districtLL).setVisibility(0);
			findViewById(R.id.divisionLL).setVisibility(0);
			findViewById(R.id.mandalLL).setVisibility(8);
			findViewById(R.id.InstitutionLL).setVisibility(8);
			findViewById(R.id.Location_InstitutionLL).setVisibility(8);
		}
		else if(roleID==4)
		{
			findViewById(R.id.districtLL).setVisibility(0);
			findViewById(R.id.divisionLL).setVisibility(0);
			findViewById(R.id.mandalLL).setVisibility(0);
			findViewById(R.id.InstitutionLL).setVisibility(8);
			findViewById(R.id.Location_InstitutionLL).setVisibility(8);
		}
		else
		{
			findViewById(R.id.districtLL).setVisibility(0);
			findViewById(R.id.divisionLL).setVisibility(0);
			findViewById(R.id.mandalLL).setVisibility(0);
			findViewById(R.id.InstitutionLL).setVisibility(0);
			findViewById(R.id.Location_InstitutionLL).setVisibility(0);

			((Spinner)findViewById(R.id.emp_districtSp)).setSelection(0);
			((Spinner)findViewById(R.id.emp_divisionSp)).setSelection(0);
			((Spinner)findViewById(R.id.emp_mandalSp)).setSelection(0);
			((Spinner)findViewById(R.id.institutiontypeSp)).setSelection(0);
			((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
		}

	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) 
	{
		// TODO Auto-generated method stub

	}

	boolean doubleBackToExitPressedOnce = false;
	@Override
	public void onBackPressed() 
	{
		try 
		{
			startActivity(new Intent(UserRegistration.this, LoginPage.class));
			finish();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.loginRegBt:
			startActivity(new Intent(UserRegistration.this, LoginPage.class));
			finish();
			break;
		case R.id.submitRegData:
			validateData();
			break;
		case R.id.userReg_BankDetailsMore_Tv:
			if((findViewById(R.id.userReg_BankDetailsMore_LL)).getVisibility()==View.GONE)
			{
				(findViewById(R.id.userReg_BankDetailsMore_LL)).setVisibility(View.VISIBLE);
			}
			else
			{
				(findViewById(R.id.userReg_BankDetailsMore_LL)).setVisibility(View.GONE);
			}
			break;
		case R.id.userReg_capturePhoto_Iv:
			takePhoto();
			break;
		default:
			break;
		}
	}
	public void takePhoto()
	{

		try 
		{
			Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(cameraIntent, CAMERA_REQUEST);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
	}
	@SuppressLint("NewApi")
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{ 
		try 
		{
			if (requestCode == CAMERA_REQUEST)
			{ 
				try
				{
					Bitmap photo = (Bitmap) data.getExtras().get("data");
					int width=photo.getWidth()/2;
					int height=photo.getHeight()/2;
					Bitmap scaled = Bitmap.createScaledBitmap(photo,width,height, true);
					int size=scaled.getByteCount();
					photoCaptureIv.setImageBitmap(scaled);
					ByteArrayOutputStream stream = new ByteArrayOutputStream();
					scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
					byte[] byteArray = stream.toByteArray();
					strBaseimage= Base64.encode(byteArray);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}  
	}
	@Override
	public void Success(String response)
	{

		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String createdDate = sdf.format(c.getTime());

		String aadhaarNo=((EditText)findViewById(R.id.empAadhrNo_ET)).getText().toString().trim();
		String empName=((EditText)findViewById(R.id.empName_ET)).getText().toString().trim();
		String empID=((EditText)findViewById(R.id.empID_ET)).getText().toString().trim();
		String mobile=((EditText)findViewById(R.id.empMobNo_ET)).getText().toString().trim();
		String gender="1";
		if(((RadioButton)findViewById(R.id.male_RD)).isChecked())
		{
			gender="1";
		}
		else if(((RadioButton)findViewById(R.id.female_RD)).isChecked())
		{
			gender="2";
		}
		String bankName=((EditText) findViewById(R.id.bankNameEt)).getText().toString().trim();
		String accno=((EditText) findViewById(R.id.accno_edt)).getText().toString().trim();
		String ifsccod=((EditText) findViewById(R.id.ifsccode_edt)).getText().toString().trim();
		String bankBranch=((EditText) findViewById(R.id.bankBranch_edt)).getText().toString().trim();

		ContentValues contentValues=new ContentValues();
		contentValues.put("AADHARNo", aadhaarNo);
		contentValues.put("DistrictID",distrID );
		contentValues.put("DivisionID",divisionID );
		contentValues.put("MandalID",mandalID );
		contentValues.put("LocationOfInstitutionID",instiLoctinID );
		contentValues.put("TypeOfInstitution",instiTypeID );
		contentValues.put("EmployeeID",empID );
		contentValues.put("EmployeeName",empName );
		contentValues.put("GenderID",gender );
		contentValues.put("Designation",desigID );
		contentValues.put("MobileNo",mobile);
		contentValues.put("BankName",bankName);
		contentValues.put("AccountNo",accno);
		contentValues.put("IFSCCode",ifsccod);
		contentValues.put("BranchName",bankBranch);
		contentValues.put("IsActive","Y" );
		contentValues.put("Is_Sync","Y" );
		contentValues.put("CreatedBy",empName );
		contentValues.put("CreatedDate",createdDate );
		contentValues.put("Latitude",latitude );
		contentValues.put("Longitude",longitude );
		db.open(); 
		db.insertTableDate("Department_User_Registration", contentValues);
		db.close();

		AlertDialogs("Information!!", "User Registration Successfully Completed");
		intializeViews();
	}
	@Override
	public void Fail(String response) 
	{
		AlertDialogs("Information!!", response);
	}
	@Override
	public void NetworkNotAvail()
	{
		AlertDialogs("Information!!", "NetWork not available,Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(UserRegistration.this,AppUpdatePage.class));
		finish();
		return;
	}
}
