package com.aponline.fmdcp;

import java.util.ArrayList;

import com.aponline.fmdcp.adapter.FarmerReportsAdapter;
import com.aponline.fmdcp.database.DBAdapter;
import com.aponline.fmdcp.database.SP;

import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;

public class FarmerDetailsReport extends AppCompatActivity implements OnItemSelectedListener,OnClickListener
{

	Spinner sp;
	ListView Reports_listView;
	HorizontalScrollView maintain;
	LinearLayout vaccreceipt;
	DBAdapter db;
	ActionBar ab;
	int i=0;
	ArrayList<ArrayList<String>> list;
	String Dist_id,Mandal_id,Village_Id;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.report);
		db=new DBAdapter(this);
		ab=getSupportActionBar();
		ab.setTitle("Farmer Details Report");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.app_hrd_dark)));
		ab.setDisplayHomeAsUpEnabled(true); 
		ab=getSupportActionBar();
		Reports_listView=(ListView) findViewById(R.id.Reports_listView);
		findViewById(R.id.Reports_searchLL).setVisibility(0);
		maintain=(HorizontalScrollView) findViewById(R.id.horizontalScrollView_mainTable);
		vaccreceipt=(LinearLayout) findViewById(R.id.farmerDetailse_reportlayout);
		findViewById(R.id.Reports_searchLL).setVisibility(0);
		db.open();
		Dist_id=db.getSingleValue("select DistrictID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		Mandal_id=db.getSingleValue("select MandalID from Department_User_Registration where AADHARNo='"+HomeData.userAadhaarID+"'");
		db.close();
		((Spinner) findViewById(R.id.reports_mandal_sp)).setOnItemSelectedListener(this);
		((Spinner) findViewById(R.id.reports_village_sp)).setOnItemSelectedListener(this);

		CommonFunctions.loadSpinnerData(this,"select distinct trim(MandalName) from Master_Mandal where DistrictID='"+Dist_id+"' and MandalID='"+Mandal_id+"' ORDER BY MandalName", (Spinner) findViewById(R.id.reports_mandal_sp));
		//	CommonFunctions.loadSpinnerData(this,SP.getVillageList(Dist_id, Mandal_id), (Spinner) findViewById(R.id.reports_village_sp));
		((Spinner)findViewById(R.id.reports_mandal_sp)).setSelection(1);
		((Spinner)findViewById(R.id.reports_mandal_sp)).setEnabled(false);

		findViewById(R.id.reports_searchdataBt).setOnClickListener(this);
		//	vaccinereport("select Farmer_Name,Aadhar_No,Village_Id,Mobile_No,Gender,(Male_White_Cattle+Male_Buffaloes+Female_White_Cattle+Female_Buffaloes) as TotalAmimals,Is_Sync from FARMER_REG_DETAILS where Created_By='"+HomeData.userAadhaarID+"' order by Created_Date");


//		vaccinereport("select FMD.Farmer_Name,FMD.Aadhar_No,V.VillageName,FMD.Mobile_No,FMD.Gender,"
//				+ "(FMD.Male_White_Cattle+FMD.Male_Buffaloes+FMD.Female_White_Cattle+FMD.Female_Buffaloes) as TotalAmimals,FMD.Is_Sync from FARMER_REG_DETAILS FMD,Master_Village V "
//				+ "where FMD.District_Id='"+Dist_id+"' and FMD.Mandal_Id='"+Mandal_id+"' and FMD.Created_By='"+HomeData.userAadhaarID+"' and V.VillageID=FMD.Village_Id order by FMD.Created_Date");

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		overridePendingTransition(R.anim.right_in, R.anim.right_out);
	}
	public void vaccinereport(String query)
	{
		list=new ArrayList<ArrayList<String>>(); 

		db.open();
		Cursor cursor=db.getTableDataCursor(query);//SchoolCode,DEVICEID
		if(cursor.getCount()>0)
		{
			Reports_listView.setVisibility(View.VISIBLE);
			vaccreceipt.setVisibility(View.VISIBLE);
			if(cursor.moveToFirst())
			{
				do
				{
					ArrayList<String> data=new ArrayList<String>();
					data.add(cursor.getString(cursor.getColumnIndex("Farmer_Name")));
					data.add(cursor.getString(cursor.getColumnIndex("Aadhar_No")));
					//String villagename=db.getSingleValue("select VillageName from Master_Village where VillageID='"+cursor.getString(cursor.getColumnIndex("Village_Id"))+"'");
					data.add(cursor.getString(cursor.getColumnIndex("VillageName")));
					data.add(cursor.getString(cursor.getColumnIndex("Mobile_No")));
					String stuId=cursor.getString(cursor.getColumnIndex("Gender"));
					if(stuId.equalsIgnoreCase("1"))
					{
						data.add("Male");
					}
					else
					{
						data.add("Female");
					}
					data.add(cursor.getString(cursor.getColumnIndex("TotalAmimals")));
					data.add(cursor.getString(cursor.getColumnIndex("Is_Sync")));
					list.add(data);
				}while(cursor.moveToNext());
			}

			cursor.close();
			db.close();
		}
		FarmerReportsAdapter adapter=new FarmerReportsAdapter(this, list);
		//	vaccinationreportlistadapter adapter=new vaccinationreportlistadapter(VaccineReceiptReport.this, list);
		Reports_listView.setAdapter(adapter);
	}
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) 
	{
		switch (parent.getId())
		{
		case R.id.reports_mandal_sp:

			String mandalName=parent.getSelectedItem().toString().trim();
			if(!mandalName.equalsIgnoreCase("--Select--"))
			{
				((Spinner) findViewById(R.id.reports_village_sp)).setSelection(0);
				db.open();
				Mandal_id=db.getSingleValue("select MandalID from Master_Mandal where DistrictID='"+Dist_id+"' and  trim(MandalName)='"+mandalName.trim()+"' ORDER BY MandalName");
				db.close();
				CommonFunctions.loadSpinnerData(this,SP.getVillageList(Dist_id, Mandal_id), (Spinner) findViewById(R.id.reports_village_sp));
				//vaccinereport("select Farmer_Name,Aadhar_No,Village_Id,Mobile_No,Gender,(Male_White_Cattle+Male_Buffaloes+Female_White_Cattle+Female_Buffaloes) as TotalAmimals,Is_Sync from FARMER_REG_DETAILS where Created_By='"+HomeData.userAadhaarID+"' and Mandal_Id='"+Mandal_id+"' order by Created_Date");
			
				vaccinereport("select Distinct FMD.Farmer_Name,FMD.Aadhar_No,V.VillageName,FMD.Mobile_No,FMD.Gender,"
						+ "(FMD.Male_White_Cattle+FMD.Male_Buffaloes+FMD.Female_White_Cattle+FMD.Female_Buffaloes) as TotalAmimals,FMD.Is_Sync from FARMER_REG_DETAILS FMD,Master_Village V "
						+ "where FMD.District_Id='"+Dist_id+"' and FMD.Mandal_Id='"+Mandal_id+"' and FMD.Created_By='"+HomeData.userAadhaarID+"' and V.VillageID=FMD.Village_Id order by FMD.Created_Date");
			}
			break;
		case R.id.reports_village_sp:
			String villName=parent.getSelectedItem().toString().trim();
			if(!villName.equalsIgnoreCase("--Select--"))
			{
				db.open();
				Village_Id=db.getSingleValue(SP.getVillageID(Dist_id, Mandal_id, villName));
				db.close();
				vaccinereport("select Distinct FMD.Farmer_Name,FMD.Aadhar_No,V.VillageName,FMD.Mobile_No,FMD.Gender,"
						+ "(FMD.Male_White_Cattle+FMD.Male_Buffaloes+FMD.Female_White_Cattle+FMD.Female_Buffaloes) as TotalAmimals,FMD.Is_Sync "
						+ "from FARMER_REG_DETAILS FMD,Master_Village V where FMD.District_Id='"+Dist_id+"' and FMD.Mandal_Id='"+Mandal_id+"' and FMD.Village_Id='"+Village_Id+"' "
						+ "and FMD.Created_By='"+HomeData.userAadhaarID+"' and V.VillageID=FMD.Village_Id order by FMD.Created_Date");
			}
			break;
		default:
			break;
		}
	}
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.reports_searchdataBt:
			String searchdata=((EditText)findViewById(R.id.reports_searchdata_Et)).getText().toString();
			if(searchdata.equalsIgnoreCase(""))
			{
				((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(((EditText)findViewById(R.id.reports_searchdata_Et)).getWindowToken(), 0);
				((EditText)findViewById(R.id.reports_searchdata_Et)).requestFocus();
				((EditText)findViewById(R.id.reports_searchdata_Et)).setError("Enter Farmer Aadhar Number");
				return;
			}

			((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(((EditText)findViewById(R.id.reports_searchdata_Et)).getWindowToken(), 0);
			vaccinereport("select Distinct FMD.Farmer_Name,FMD.Aadhar_No,V.VillageName,FMD.Mobile_No,FMD.Gender,(FMD.Male_White_Cattle+FMD.Male_Buffaloes+FMD.Female_White_Cattle+FMD.Female_Buffaloes) as TotalAmimals,FMD.Is_Sync from FARMER_REG_DETAILS FMD,Master_Village V "
					+ "where FMD.Created_By='"+HomeData.userAadhaarID+"' and V.VillageID=FMD.Village_Id "
					+ "and (FMD.Farmer_Name like '%"+searchdata+"%' OR FMD.Aadhar_No like '%"+searchdata+"%' OR FMD.Mobile_No like '%"+searchdata+"%') order by FMD.Created_Date");
			break;
		default:
			break;
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) 
	{

	}
}
