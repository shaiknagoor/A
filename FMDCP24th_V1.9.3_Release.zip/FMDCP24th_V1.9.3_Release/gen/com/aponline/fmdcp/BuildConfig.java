/** Automatically generated file. DO NOT MODIFY */
package com.aponline.fmdcp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}