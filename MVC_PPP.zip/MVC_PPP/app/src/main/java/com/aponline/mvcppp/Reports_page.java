package com.aponline.mvcppp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import com.aponline.mvcppp.R;
import com.aponline.mvcppp.Adapter.Report_Adapter;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.database.SP;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({ "NewApi", "SimpleDateFormat" })
public class Reports_page extends AppCompatActivity implements OnClickListener
{

	Context context;
	DBAdapter db;
	ArrayList<HashMap<String, String>> reportAl;

	Report_Adapter adapter;
	ListView reportLV;
	String MethodName,TableName,IntentValueName,Repquery,editquery,edate,edate1,extQuery="";
	TextView EntryDate,reporttitleTv,Rept_Date,To_DateEv,AbstractsubimitDateBt;
	public static ArrayList<HashMap<String, String>> EditDataAl;

	private int year,month,day,nyear,nmonth,nday;
	private String fday,fmonth,fyear;

	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.report_page); 
		context=this;

		db=new DBAdapter(this);
		reportLV=(ListView) findViewById(R.id.reportLV);
		reporttitleTv=(TextView) findViewById(R.id.reporttitleTv);

		Rept_Date=(TextView) findViewById(R.id.rept_DateEv);
		To_DateEv=(TextView) findViewById(R.id.To_DateEv);
		AbstractsubimitDateBt=(TextView) findViewById(R.id.AbstractsubimitDateBt);
		
		((TextView)(findViewById(R.id.reportTv10))).setText("Date \n"+"(dd-mm-yyyy)");

		findViewById(R.id.subimitDateBt).setOnClickListener(this);
		findViewById(R.id.subimitAllBt).setOnClickListener(this);
		findViewById(R.id.AbstractsubimitDateBt).setOnClickListener(this);



		Rept_Date.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v) 
			{
				final Calendar c = Calendar.getInstance();
				year = c.get(Calendar.YEAR);
				month = c.get(Calendar.MONTH);
				day = c.get(Calendar.DAY_OF_MONTH);

				DatePickerDialog dpd=new DatePickerDialog(Reports_page.this, new DatePickerDialog.OnDateSetListener() 
				{
					@Override
					public void onDateSet(DatePicker view, int year,int month,int date) 
					{


						String month1=Integer.toString(month+1);
						String date1=Integer.toString(date);
						if(month1.length()==1)
							month1="0"+Integer.toString(month+1);
						if(date1.length()==1)
							date1="0"+Integer.toString(date);
						String dateSelected=date1+"-"+month1+"-"+Integer.toString(year);
						nday=Integer.parseInt(date1);nmonth=Integer.parseInt(month1);nyear=year;
						Rept_Date.setText(dateSelected);


					}
				}, year, month, day);
				dpd.show();	
				dpd.getDatePicker().setMaxDate(System.currentTimeMillis());
			}
		});


		To_DateEv.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v) 
			{
				final Calendar c = Calendar.getInstance();
				year = c.get(Calendar.YEAR);
				month = c.get(Calendar.MONTH);
				day = c.get(Calendar.DAY_OF_MONTH);

				DatePickerDialog dpd=new DatePickerDialog(Reports_page.this, new DatePickerDialog.OnDateSetListener() 
				{
					@Override
					public void onDateSet(DatePicker view, int year,int month,int date) 
					{


						String month1=Integer.toString(month+1);
						String date1=Integer.toString(date);
						if(month1.length()==1)
							month1="0"+Integer.toString(month+1);
						if(date1.length()==1)
							date1="0"+Integer.toString(date);
						String dateSelected=date1+"-"+month1+"-"+Integer.toString(year);
						nday=Integer.parseInt(date1);nmonth=Integer.parseInt(month1);nyear=year;
						To_DateEv.setText(dateSelected);


					}
				}, year, month, day);
				dpd.show();	

				dpd.getDatePicker().setMaxDate(System.currentTimeMillis());

			}
		});

		Intent intent=getIntent();
		if(!(intent.getStringExtra("Vaccinations")==null) && intent.getStringExtra("Vaccinations").toString().equalsIgnoreCase("Vaccinations") )
		{
			AbstractsubimitDateBt.setVisibility(8);
			To_DateEv.setVisibility(8);
			reporttitleTv.setText("Vaccinations");
			MethodName="InsertVaccineData_VIM";
			TableName="Vaccination_Details";
			IntentValueName="Vaccinations";

			Repquery="select SUM(Number),EntryDate  from Vaccination_Details  where CreatedBy='"+HomeData.userID+"'";

			//Repquery="SELECT Master_Animal_Kind.AnimalKindName, Number, EntryDate FROM Vaccination_Details INNER JOIN Master_Animal_Kind "
			//+ "ON Master_Animal_Kind.AnimalKindID=Vaccination_Details.AnimalKindID where Vaccination_Details.CreatedBy='"+HomeData.userID+"'"+extQuery;

			editquery="select AnimalKindID,Number,EntryDate from Vaccination_Details ";
			Reports(Repquery);
		}else 
			if(!(intent.getStringExtra("Dewormings")==null) && intent.getStringExtra("Dewormings").toString().equalsIgnoreCase("Dewormings") )
			{

				AbstractsubimitDateBt.setVisibility(8);
				To_DateEv.setVisibility(8);
				reporttitleTv.setText("Dewormings  (Preventive Treatment)");
				MethodName="InsertDewormingDetails_VIM";
				TableName="Dewormings";
				IntentValueName="Dewormings";

				Repquery="select SUM(Number),EntryDate  from Dewormings  where CreatedBy='"+HomeData.userID+"'";
				//Repquery="SELECT Master_Animal_Kind.AnimalKindName, Number, EntryDate FROM Dewormings INNER JOIN Master_Animal_Kind "
				//+ "ON Master_Animal_Kind.AnimalKindID=Dewormings.AnimalKindID where Dewormings.CreatedBy='"+HomeData.userID+"'"+extQuery;

				editquery="select AnimalKindID,Number,EntryDate from Dewormings ";

				Reports(Repquery);

			}else if(!(intent.getStringExtra("Castrations")==null) && intent.getStringExtra("Castrations").toString().equalsIgnoreCase("Castrations") )
			{

				AbstractsubimitDateBt.setVisibility(8);
				To_DateEv.setVisibility(8);
				reporttitleTv.setText("Castrations");
				MethodName="InsertCastrations_VIM";
				TableName="Castration_Details";
				IntentValueName="Castrations";

				Repquery="select SUM(Number),EntryDate  from Castration_Details  where CreatedBy='"+HomeData.userID+"'";

				//Repquery="SELECT Master_Animal_Kind.AnimalKindName, Number, EntryDate FROM Castration_Details INNER JOIN Master_Animal_Kind "
				//+ "ON Master_Animal_Kind.AnimalKindID=Castration_Details.AnimalKindID where Castration_Details.CreatedBy='"+HomeData.userID+"'"+extQuery;

				editquery="select AnimalKindID,Number,EntryDate from '"+TableName+"' ";

				Reports(Repquery);

			}else if(!(intent.getStringExtra("Artificial_Insemination")==null) && intent.getStringExtra("Artificial_Insemination").toString().equalsIgnoreCase("Artificial_Insemination") )
			{

				AbstractsubimitDateBt.setVisibility(8);
				To_DateEv.setVisibility(8);
				reporttitleTv.setText("Artificial Insemination");
				MethodName="InsertArtificialInsemination_VIM";
				TableName="Artificial_Insemination_Details";
				IntentValueName="Artificial_Insemination";

				Repquery="select SUM(Number),EntryDate  from Artificial_Insemination_Details  where CreatedBy='"+HomeData.userID+"'";

				//Repquery="SELECT Master_Animal_Kind.AnimalKindName, Number, EntryDate FROM Artificial_Insemination_Details INNER JOIN Master_Animal_Kind "
				//+ "ON Master_Animal_Kind.AnimalKindID=Artificial_Insemination_Details.AnimalKindID where Artificial_Insemination_Details.CreatedBy='"+HomeData.userID+"'"+extQuery;

				editquery="select AnimalKindID,Number,EntryDate from '"+TableName+"' ";
				Reports(Repquery);
			}else if(!(intent.getStringExtra("Surgery")==null) && intent.getStringExtra("Surgery").toString().equalsIgnoreCase("Surgery") )
			{

				AbstractsubimitDateBt.setVisibility(8);
				To_DateEv.setVisibility(8);
				((TextView)(findViewById(R.id.reportTv3))).setText("Major");
				((TextView)(findViewById(R.id.reportTv4))).setText("Minor");
				((TextView)(findViewById(R.id.reportTv4))).setVisibility(0);

				reporttitleTv.setText("Surgeries  (Operations)");
				MethodName="InsertOperationalDetails_VIM";
				TableName="Operation_Details";
				IntentValueName="Surgery";

				Repquery="SELECT SUM(Major),SUM(Minor),EntryDate FROM Operation_Details where CreatedBy='"+HomeData.userID+"'";

				editquery=("select AnimalKindID,Major,Minor,EntryDate from Operation_Details  ");

				Reports(Repquery);
			}else if(!(intent.getStringExtra("CalvesBorn")==null) && intent.getStringExtra("CalvesBorn").toString().equalsIgnoreCase("CalvesBorn") )
			{

				AbstractsubimitDateBt.setVisibility(8);
				To_DateEv.setVisibility(8);
				((TextView)(findViewById(R.id.reportTv3))).setText("Male");
				((TextView)(findViewById(R.id.reportTv4))).setText("Female");
				((TextView)(findViewById(R.id.reportTv4))).setVisibility(0);

				reporttitleTv.setText("Calves Born");
				MethodName="InsertCalvesBorn_VIM";
				TableName="Calves_Born_Details";
				IntentValueName="CalvesBorn";

				Repquery="SELECT SUM(Male),SUM(Female),EntryDate FROM Calves_Born_Details  where CreatedBy='"+HomeData.userID+"'";

				editquery=("select AnimalKindID,Male,Female,EntryDate from Calves_Born_Details  ");

				Reports(Repquery);
			}else if(!(intent.getStringExtra("AnimalsTreated")==null) && intent.getStringExtra("AnimalsTreated").toString().equalsIgnoreCase("AnimalsTreated") )
			{

				AbstractsubimitDateBt.setVisibility(8);
				To_DateEv.setVisibility(8);
				((TextView)(findViewById(R.id.reportTv3))).setText("Digestive Disorders");
				((TextView)(findViewById(R.id.reportTv4))).setText("Respiratory Disorders");
				((TextView)(findViewById(R.id.reportTv5))).setText("Reproductive Disorders");
				((TextView)(findViewById(R.id.reportTv6))).setText("Uro Genital Problems");
				((TextView)(findViewById(R.id.reportTv7))).setText("Musculo Skeletal");
				((TextView)(findViewById(R.id.reportTv8))).setText("Metabolic Diseases");
				((TextView)(findViewById(R.id.reportTv9))).setText("Others");

				((TextView)(findViewById(R.id.reportTv4))).setVisibility(0);
				((TextView)(findViewById(R.id.reportTv5))).setVisibility(0);
				((TextView)(findViewById(R.id.reportTv6))).setVisibility(0);
				((TextView)(findViewById(R.id.reportTv7))).setVisibility(0);
				((TextView)(findViewById(R.id.reportTv8))).setVisibility(0);
				((TextView)(findViewById(R.id.reportTv9))).setVisibility(0);
				reporttitleTv.setText("Animals Treated  (Curative Treatment)");
				MethodName="InsertAnimalsTreated_VIM";
				TableName="Animals_Treated";
				IntentValueName="AnimalsTreated";

				Repquery="SELECT SUM(DigestiveDisorder),SUM(RespiratoryDisorder),SUM(ReproductiveDisorder),SUM(UroGenitalProblems),SUM(MuscleSkeletal),SUM(MetabolicDisease),SUM(Others),EntryDate from Animals_Treated  where CreatedBy='"+HomeData.userID+"'";

				editquery=("SELECT DigestiveDisorder,RespiratoryDisorder,ReproductiveDisorder,UroGenitalProblems,MuscleSkeletal,MetabolicDisease,Others,EntryDate from Animals_Treated  ");

				Reports(Repquery);
			}else if(!(intent.getStringExtra("AbstractBt_report")==null) && intent.getStringExtra("AbstractBt_report").toString().equalsIgnoreCase("AbstractBt_report") )
			{
				AbstractsubimitDateBt.setVisibility(0);
				To_DateEv.setVisibility(0);
				findViewById(R.id.subimitAllBt).setVisibility(8);
				findViewById(R.id.subimitDateBt).setVisibility(8);
				findViewById(R.id.mainOneLL).setVisibility(8);

				Toast toast = null;
				toast=Toast.makeText(this, "Please Select From Date and To date",Toast.LENGTH_LONG);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();





				//				reportAl=new ArrayList<HashMap<String,String>>();
				//
				//				((TextView)(findViewById(R.id.reportTv3))).setText("Animals Treated");
				//				((TextView)(findViewById(R.id.reportTv4))).setText("Dewormings");
				//				((TextView)(findViewById(R.id.reportTv5))).setText("Surgeries");
				//				((TextView)(findViewById(R.id.reportTv6))).setText("Vaccinations");
				//				((TextView)(findViewById(R.id.reportTv7))).setText("Artificial Inseminations");
				//				((TextView)(findViewById(R.id.reportTv8))).setText("Calves Born");
				//				((TextView)(findViewById(R.id.reportTv9))).setText("Castrations");
				//
				//				((TextView)(findViewById(R.id.reportTv3))).setVisibility(0);
				//				((TextView)(findViewById(R.id.reportTv4))).setVisibility(0);
				//				((TextView)(findViewById(R.id.reportTv5))).setVisibility(0);
				//				((TextView)(findViewById(R.id.reportTv6))).setVisibility(0);
				//				((TextView)(findViewById(R.id.reportTv7))).setVisibility(0);
				//				((TextView)(findViewById(R.id.reportTv8))).setVisibility(0);
				//				((TextView)(findViewById(R.id.reportTv9))).setVisibility(0);
				//
				//				((TextView)(findViewById(R.id.reportTv2))).setVisibility(8);
				//				((TextView)(findViewById(R.id.reportTv10))).setVisibility(0);
				//				reporttitleTv.setText("Dash bord");
				//				//MethodName="InsertAnimalsTreated_VIM";
				//				TableName="AbstractBt_report";
				//				//IntentValueName="AnimalsTreated";
				//
				//
				//				try
				//				{
				//
				//					ArrayList<ArrayList<String>> list=new ArrayList<ArrayList<String>>();
				//
				//					db.open();
				//					List<String> datelistList=db.getSingleColumnData("Select distinct Aadhaar_No from UPLOAD_OFFLINEDATA WHERE Aadhaar_No BETWEEN '08/29/2016' AND '09/01/2016'");
				//					db.close();
				//					db.open();
				//					for(String date:datelistList)
				//					{
				//
				//
				//
				//						HashMap<String, String> localHM=new HashMap<String, String>();
				//
				//						localHM.put("animalT",(db.getSingleValue("SELECT IFNULL((sum(DigestiveDisorder)+sum(RespiratoryDisorder)+sum(ReproductiveDisorder)+sum(UroGenitalProblems)+sum(MuscleSkeletal)+sum(MetabolicDisease)+sum(Others)),0) from Animals_Treated   where CreatedBy='"+HomeData.userID+"'  and EntryDate='"+date+"'")));
				//						localHM.put("deworming",db.getSingleValue("SELECT IFNULL(sum(Number),0) from Dewormings   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'"));
				//						localHM.put("surgeries",(db.getSingleValue("SELECT IFNULL((sum(Major)+sum(Minor)),0) from Operation_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
				//						localHM.put("vaccination",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Vaccination_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
				//						localHM.put("artificial",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Artificial_Insemination_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
				//						localHM.put("calvesBorn",(db.getSingleValue("SELECT IFNULL((sum(Male)+sum(Female)),0) from Calves_Born_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
				//						localHM.put("castration",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Castration_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
				//						localHM.put("EntryDate", date);
				//
				//						reportAl.add(localHM);
				//
				//
				//					}
				//
				//					db.close();
				//					reportLV.setVisibility(0);
				//					adapter=new Report_Adapter(this, reportAl,TableName);
				//					reportLV.setAdapter(adapter);
				//
				//				} 
				//
				//
				//				catch (Exception e) 
				//				{
				//
				//					e.printStackTrace();
				//				}




				//
				//		HashMap<String, String> localHM=new HashMap<String, String>();
				//		db.open();
				//		localHM.put("animalT",(db.getSingleValue("SELECT IFNULL((sum(DigestiveDisorder)+sum(RespiratoryDisorder)+sum(ReproductiveDisorder)+sum(UroGenitalProblems)+sum(MuscleSkeletal)+sum(MetabolicDisease)+sum(Others)),0) from Animals_Treated   where CreatedBy='"+HomeData.userID+"'")));
				//		localHM.put("deworming",db.getSingleValue("SELECT IFNULL(sum(Number),0) from Dewormings   where CreatedBy='"+HomeData.userID+"'"));
				//		localHM.put("surgeries",(db.getSingleValue("SELECT IFNULL((sum(Major)+sum(Minor)),0) from Operation_Details   where CreatedBy='"+HomeData.userID+"'")));
				//		localHM.put("vaccination",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Vaccination_Details   where CreatedBy='"+HomeData.userID+"'")));
				//		localHM.put("artificial",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Artificial_Insemination_Details   where CreatedBy='"+HomeData.userID+"'")));
				//		localHM.put("calvesBorn",(db.getSingleValue("SELECT IFNULL((sum(Male)+sum(Female)),0) from Calves_Born_Details   where CreatedBy='"+HomeData.userID+"'")));
				//		localHM.put("castration",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Castration_Details   where CreatedBy='"+HomeData.userID+"'")));
				//		db.close();
				//		reportAl.add(localHM);
				//		reportLV.setVisibility(0);
				//		adapter=new Report_Adapter(this, reportAl,TableName);
				//		reportLV.setAdapter(adapter);


			}




		reportLV.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				EntryDate=(TextView) view.findViewById(R.id.dateRL);
				String sdate=EntryDate.getText().toString();
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				try {
					Date rdate = (Date)sdf.parse(sdate);
					edate= new SimpleDateFormat("MM/dd/yyyy").format(rdate);
				} catch (ParseException e) {
					
					e.printStackTrace();
				}

				if(!TableName.equalsIgnoreCase("AbstractBt_report"))
				{
					Alert("Do you want to Edit  Record of this  " +sdate+ "  date",edate);
				}
				//				db.open();
				//				String status=db.getSingleValue("select UPLOAD_STATUS from UPLOAD_OFFLINEDATA where Aadhaar_No='"+edate+"' and METHOD_NAME='"+MethodName+"'");
				//				db.close();
				//				if(!status.equalsIgnoreCase("N"))
				//				{
				//					Toast toast = null;
				//					toast=Toast.makeText(Reports_page.this, "This data already submit to server..",Toast.LENGTH_SHORT);
				//					toast.setGravity(Gravity.BOTTOM, 0, 200);
				//					toast.show();
				//				}else {
				//
				//					editreportdata(edate);
				//				}

			}


		});

	}

	@SuppressLint("SimpleDateFormat")
	@Override
	public void onClick(View v) 
	{

		String	date="",ToDate="";
		Date date1= null;
		Date date2 = null;

		try {
			date=Rept_Date.getText().toString();
			ToDate=To_DateEv.getText().toString();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy"); 
			date1= (Date)sdf1.parse(date);
			date=new SimpleDateFormat("MM/dd/yyyy").format(date1);
			
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy"); 
			date2= (Date)sdf2.parse(ToDate);
			ToDate=new SimpleDateFormat("MM/dd/yyyy").format(date2);





		} catch (ParseException e) {

			e.printStackTrace();
		}

		switch (v.getId()) 
		{

		case R.id.subimitDateBt:
			extQuery=" and EntryDate='"+date+"'";
			if(date.equalsIgnoreCase(""))
			{
				Toast toast = null;
				toast=Toast.makeText(this, "Please Select Date",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();
				return;
			}
			else 
			{
				Reports(Repquery);
			}
			break;
		case R.id.subimitAllBt:
			extQuery="";
			Rept_Date.setText("");
			Reports(Repquery);

			break;

		case R.id.AbstractsubimitDateBt:



			if(date.equalsIgnoreCase("") && ToDate.equalsIgnoreCase(""))
			{
				Toast toast = null;
				toast=Toast.makeText(this, "Please Select From Date and To date",Toast.LENGTH_LONG);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();
				return;
			}else if(date1.after(date2))
			{

				Toast toast = null;
				toast=Toast.makeText(this, "From Date must be After the To Date",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();

				return;
			}
			else 
			{
				AbstractReport(date, ToDate);
			}

			break;


		default:
			break;
		}

	}


	public void AbstractReport(String fmDate,String todate)
	{
		reportAl=new ArrayList<HashMap<String,String>>();

		((TextView)(findViewById(R.id.reportTv3))).setText("Animals Treated");
		((TextView)(findViewById(R.id.reportTv4))).setText("Dewormings");
		((TextView)(findViewById(R.id.reportTv5))).setText("Surgeries");
		((TextView)(findViewById(R.id.reportTv6))).setText("Vaccinations");
		((TextView)(findViewById(R.id.reportTv7))).setText("Artificial Inseminations");
		((TextView)(findViewById(R.id.reportTv8))).setText("Calves Born");
		((TextView)(findViewById(R.id.reportTv9))).setText("Castrations");

		((TextView)(findViewById(R.id.reportTv3))).setVisibility(0);
		((TextView)(findViewById(R.id.reportTv4))).setVisibility(0);
		((TextView)(findViewById(R.id.reportTv5))).setVisibility(0);
		((TextView)(findViewById(R.id.reportTv6))).setVisibility(0);
		((TextView)(findViewById(R.id.reportTv7))).setVisibility(0);
		((TextView)(findViewById(R.id.reportTv8))).setVisibility(0);
		((TextView)(findViewById(R.id.reportTv9))).setVisibility(0);

		((TextView)(findViewById(R.id.reportTv2))).setVisibility(8);
		((TextView)(findViewById(R.id.reportTv10))).setVisibility(0);
		reporttitleTv.setText("Abstract Report");
		//MethodName="InsertAnimalsTreated_VIM";
		TableName="AbstractBt_report";
		//IntentValueName="AnimalsTreated";


		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			ArrayList<ArrayList<String>> list=new ArrayList<ArrayList<String>>();

			db.open();
			List<String> datelistList=db.getSingleColumnData("Select distinct Aadhaar_No from UPLOAD_OFFLINEDATA WHERE Aadhaar_No BETWEEN '"+fmDate+"' AND '"+todate+"' and CreatedBy='"+HomeData.userID+"'  order by Aadhaar_No  DESC");
			db.close();
			db.open();

			if(!datelistList.isEmpty())
			{
				for(String date:datelistList)
				{

					HashMap<String, String> localHM=new HashMap<String, String>();

					localHM.put("animalT",(db.getSingleValue("SELECT IFNULL((sum(DigestiveDisorder)+sum(RespiratoryDisorder)+sum(ReproductiveDisorder)+sum(UroGenitalProblems)+sum(MuscleSkeletal)+sum(MetabolicDisease)+sum(Others)),0) from Animals_Treated   where CreatedBy='"+HomeData.userID+"'  and EntryDate='"+date+"'")));
					localHM.put("deworming",db.getSingleValue("SELECT IFNULL(sum(Number),0) from Dewormings   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'"));
					localHM.put("surgeries",(db.getSingleValue("SELECT IFNULL((sum(Major)+sum(Minor)),0) from Operation_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
					localHM.put("vaccination",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Vaccination_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
					localHM.put("artificial",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Artificial_Insemination_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
					localHM.put("calvesBorn",(db.getSingleValue("SELECT IFNULL((sum(Male)+sum(Female)),0) from Calves_Born_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
					localHM.put("castration",(db.getSingleValue("SELECT IFNULL(sum(Number),0) from Castration_Details   where CreatedBy='"+HomeData.userID+"' and EntryDate='"+date+"'")));
					
					try {
						Date rdate = (Date)sdf.parse(date);
						localHM.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
					//localHM.put("EntryDate", date);

					reportAl.add(localHM);


				}

				db.close();


				findViewById(R.id.mainOneLL).setVisibility(0);
				reportLV.setVisibility(0);
				adapter=new Report_Adapter(this, reportAl,TableName);
				reportLV.setAdapter(adapter);
			}
			else 
			{
				Toast toast = null;
				toast=Toast.makeText(Reports_page.this, "No Data Found Between Dates",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.BOTTOM, 0, 200);
				view.setBackgroundResource(R.color.red);
				toast.show();
			}

		} 


		catch (Exception e) 
		{

			e.printStackTrace();
		}

	}


	public void editreportdata(String edate1)
	{
		editquery=editquery+"where EntryDate='"+edate1+"' and CreatedBy='"+HomeData.userID+"'";
		EditDataAl=new ArrayList<HashMap<String,String>>();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		db.open();

		Cursor editCursor=db.getTableDataCursor(editquery);

		if (editCursor.getCount() > 0) {

			for (editCursor.moveToFirst(); !editCursor.isAfterLast(); editCursor.moveToNext()) 
			{

				HashMap<String, String> editDataHm=new HashMap<String, String>();
				if(TableName.equalsIgnoreCase("Calves_Born_Details") || TableName.equalsIgnoreCase("Operation_Details"))
				{
					editDataHm.put("Male", editCursor.getString(1).trim());
					editDataHm.put("Female", editCursor.getString(2).trim());
					
					try {
						Date rdate = (Date)sdf.parse(editCursor.getString(3));
						editDataHm.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
					//editDataHm.put("EntryDate", editCursor.getString(3));
				}else if(TableName.equalsIgnoreCase("Animals_Treated"))
				{
					editDataHm.put("1", editCursor.getString(0).trim());
					editDataHm.put("2", editCursor.getString(1).trim());
					editDataHm.put("3", editCursor.getString(2).trim());
					editDataHm.put("4", editCursor.getString(3).trim());
					editDataHm.put("5", editCursor.getString(4).trim());
					editDataHm.put("6", editCursor.getString(5).trim());
					editDataHm.put("7", editCursor.getString(6).trim());
					
					try {
						Date rdate = (Date)sdf.parse(editCursor.getString(7));
						editDataHm.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
					//editDataHm.put("EntryDate", editCursor.getString(7));
				}else {
					editDataHm.put(editCursor.getString(0).trim(), editCursor.getString(1).trim());
					
					try {
						Date rdate = (Date)sdf.parse(editCursor.getString(2));
						editDataHm.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
					//editDataHm.put("EntryDate", editCursor.getString(2));
				}
				EditDataAl.add(editDataHm);

			}


			db.close();
//			Intent i=new Intent(this,Hospitalmanagement.class);
//			i.putExtra(IntentValueName, IntentValueName);
//			i.putExtra("ReportStatus", "True");
//			startActivity(i);
//			finish();
		}
	}



	//	SELECT IFNULL ((sum(a.DigestiveDisorder)+sum(a.RespiratoryDisorder)+sum(a.ReproductiveDisorder)+sum(a.UroGenitalProblems)+sum(a.MuscleSkeletal)+sum(a.MetabolicDisease)+sum(a.Others)),0),IFNULL (sum(d.Number),0),IFNULL ((sum(s.Major)+sum(s.Minor)),0),IFNULL(sum(v.Number),0),IFNULL(sum(ai.Number),0),IFNULL ((sum(cb.Male)+sum(cb.Female)),0),IFNULL (sum(ca.Number),0) from Animals_Treated a left join Dewormings d ON a.EntryDate=d.EntryDate left join Operation_Details s ON a.EntryDate=s.EntryDate
	//			left join Vaccination_Details v ON a.EntryDate=v.EntryDate  left join Artificial_Insemination_Details ai ON a.EntryDate=ai.EntryDate  left join Calves_Born_Details cb ON a.EntryDate=cb.EntryDate  left join Castration_Details ca ON a.EntryDate=ca.EntryDate WHERE a.EntryDate BETWEEN '08/31/2016' AND '09/01/2016'   GROUP BY a.EntryDate


	public void Reports(String Query)
	{
		//extQuery=" GROUP BY EntryDate";

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

		reportLV.setVisibility(8);
		db.open();
		reportAl=new ArrayList<HashMap<String,String>>();
		Cursor cursor=db.getTableDataCursor(Query+extQuery+" GROUP BY EntryDate  order by EntryDate DESC");


		if (cursor.getCount() > 0) {

			for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) 
			{
				HashMap<String, String> localHM=new HashMap<String, String>();
				if(TableName.equalsIgnoreCase("Calves_Born_Details") || TableName.equalsIgnoreCase("Operation_Details"))
				{
					//localHM.put("AnimalKindName", cursor.getString(0).trim());
					localHM.put("Male", cursor.getString(0));
					localHM.put("Female", cursor.getString(1));

					try {
						Date rdate = (Date)sdf.parse(cursor.getString(2));
						localHM.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}


				}else if(TableName.equalsIgnoreCase("Animals_Treated") )
				{
					//localHM.put("1", cursor.getString(0).trim());
					localHM.put("2", cursor.getString(0));
					localHM.put("3", cursor.getString(1));
					localHM.put("4", cursor.getString(2));
					localHM.put("5", cursor.getString(3));
					localHM.put("6", cursor.getString(4));
					localHM.put("7", cursor.getString(5));
					localHM.put("8", cursor.getString(6));
					try {
						Date rdate = (Date)sdf.parse(cursor.getString(7));
						localHM.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
					//localHM.put("EntryDate", cursor.getString(7));
				}else {

					//localHM.put("AnimalKindName", cursor.getString(0).trim());
					localHM.put("Number", cursor.getString(0));
					try {
						Date rdate = (Date)sdf.parse(cursor.getString(1));
						localHM.put("EntryDate", new SimpleDateFormat("dd-MM-yyyy").format(rdate));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
					//localHM.put("EntryDate", cursor.getString(1));
				}
				reportAl.add(localHM);
			}
			reportLV.setVisibility(0);
			adapter=new Report_Adapter(this,reportAl,TableName);
			reportLV.setAdapter(adapter);
			extQuery="";


		}else {
			Toast toast = null;
			toast=Toast.makeText(Reports_page.this, "No Data Found",Toast.LENGTH_SHORT);
			View view = toast.getView();
			toast.setGravity(Gravity.BOTTOM, 0, 200);
			view.setBackgroundResource(R.color.red);
			toast.show();
		}

		db.close();

	}

	public void Alert(String msg1,final String date1)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Veterinary Institution Management");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{

				db.open();
				String status=db.getSingleValue("select UPLOAD_STATUS from UPLOAD_OFFLINEDATA where Aadhaar_No='"+date1+"' and METHOD_NAME='"+MethodName+"'  and CreatedBy='"+HomeData.userID+"'");
				db.close();
				if(!status.equalsIgnoreCase("N"))
				{
					Toast toast = null;
					toast=Toast.makeText(Reports_page.this, "This data is already submitted to server..",Toast.LENGTH_SHORT);
					toast.setGravity(Gravity.BOTTOM, 0, 200);
					toast.show();
				}else {

					editreportdata(edate);
				}
				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}



}
