package com.aponline.mvcppp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import com.aponline.mvcppp.R;
import com.aponline.mvcppp.Treatment_Act;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.ServerResponseListener;

public class Treatment_Medicine_Details extends AppCompatActivity implements OnClickListener,ServerResponseListener
{

	Context context;
	DBAdapter db;
	ActionBar ab;
	LinearLayout slideMenuLL;
	RelativeLayout userDetailsLL;
	Spinner Treatment_ItemSp;
	TextView NoofSheepDewormedTv,NoofGoatDewormedTv,TotalDewormedTv,NoofFarmerBenefitedtTv,userId;
	EditText ExpendableRecvDateEt,Treatment_Receipt_DateEt,Treatment_Exp_DateEt,Treatment_Mfg_DateEt;
	private int year,month,day;

	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.treatment_medicine_details);
		db=new DBAdapter(this);
		context=this; 


		ab=getSupportActionBar();
		ab.setTitle("Treatment");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(true); 

		Treatment_ItemSp=(Spinner) findViewById(R.id.Treatment_ItemSp);
		ExpendableRecvDateEt=(EditText) findViewById(R.id.ExpendableRecvDateEt);
		Treatment_Receipt_DateEt=(EditText) findViewById(R.id.Treatment_Receipt_DateEt);
		Treatment_Exp_DateEt=(EditText) findViewById(R.id.Treatment_Exp_DateEt);
		Treatment_Mfg_DateEt=(EditText) findViewById(R.id.Treatment_Mfg_DateEt);
		
		((Button)findViewById(R.id.proceedBt)).setOnClickListener(this);
		findViewById(R.id.ExpendableRecvDateEt).setOnClickListener(this);
		findViewById(R.id.Treatment_Receipt_DateEt).setOnClickListener(this);
		findViewById(R.id.Treatment_Exp_DateEt).setOnClickListener(this);
		findViewById(R.id.Treatment_Mfg_DateEt).setOnClickListener(this);
		
		findViewById(R.id.ExpendableRecvDateEt).setOnClickListener(this);

		loadSpinnerData("select distinct Item_Name from Master_Equipment order by Item_Name",Treatment_ItemSp);
	}

	public void DateFunction(final String Type,final EditText edittext)
	{
		final Calendar c = Calendar.getInstance();
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH);
		day = c.get(Calendar.DAY_OF_MONTH);



		DatePickerDialog dpd=new DatePickerDialog(Treatment_Medicine_Details.this, new DatePickerDialog.OnDateSetListener() 
		{

			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) 
			{

				String dateSelected=(monthOfYear+1)+"/"+dayOfMonth+"/"+Integer.toString(year);

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				try 
				{
					Date rdate = (Date)sdf.parse(dateSelected);
					String	edate= new SimpleDateFormat("dd-MMM-yyyy").format(rdate);

					edittext.setText(edate);

				} catch (ParseException e) 
				{

					e.printStackTrace();
				}
				//

			}
		}, year, month, day);
		dpd.getDatePicker().setCalendarViewShown(false);
		dpd.show();	

		if(Type.equalsIgnoreCase("Treatment_Exp_DateEt")) 
		{
			dpd.getDatePicker().setMinDate(c.getTimeInMillis());
		}else {
			dpd.getDatePicker().setMaxDate(System.currentTimeMillis());
		}

	}
	public void loadSpinnerDataStatic(ArrayList<String> lables, Spinner spinner) 
	{
		try
		{
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			//	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(FarmerRegistration.this,android.R.layout.simple_spinner_item, lables);
			//	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}
	@Override
	public void Success(String response) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Fail(String response) {
		// TODO Auto-generated method stub

	}

	@Override
	public void NetworkNotAvail() {
		// TODO Auto-generated method stub

	}

	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.proceedBt:

			break;
		case R.id.Treatment_Mfg_DateEt:
			DateFunction("ExpendableRecvDateEt",(EditText) v);

			break;
		case R.id.Treatment_Exp_DateEt:
			DateFunction("Treatment_Exp_DateEt",(EditText) v);

			break;
		case R.id.Treatment_Receipt_DateEt:
			DateFunction("ExpendableRecvDateEt",(EditText) v);

			break;
		case R.id.ExpendableRecvDateEt:
			DateFunction("ExpendableRecvDateEt",(EditText) v);

			break;
		
		default:
			break;
		}

	}
}
