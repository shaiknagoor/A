package com.aponline.mvcppp;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;

public class Artificial_Insemination_Act extends AppCompatActivity implements OnClickListener
{
	Spinner opt;
	LinearLayout l5;
	EditText dewedt1,dewedt2,dewedt3,dewedt4,dewedt5,dewedt6,dewedt7,dewedt8,inseminationedt1,inseminationedt2;

	TextView dewtotal,inseminationtotal;
	Button confirmbtn,submitbtn;

	ActionBar ab;
	TextView title,title1;
	String provision_type,Report_Status="",whereDate;
	ArrayList<String> Kind_of_Animal,AtProblems,FinalAList;
	String FarmerName,FarmerAdhaar,UniqueID,skip_Xml;
	private int year,month,day,nyear,nmonth,nday;
	private String fday,fmonth,fyear;


	Context cnt;
	DBAdapter db;

	StringBuilder XmlDoc;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{

		super.onCreate(savedInstanceState);
		setContentView(R.layout.artificial_incemination);

		cnt=this;
		db=new DBAdapter(this);


		ab=getSupportActionBar();
		ab.setTitle("Artificial Insemination");
		ab.setHomeButtonEnabled(false);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(false); 






		title=(TextView) findViewById(R.id.titleTv);
		title1=(TextView) findViewById(R.id.title1Tv);



		l5=(LinearLayout) findViewById(R.id.inseminationtable);

		dewedt1=(EditText) findViewById(R.id.dewedt1);
		dewedt2=(EditText) findViewById(R.id.dewedt2);
		dewedt3=(EditText) findViewById(R.id.dewedt3);
		dewedt4=(EditText) findViewById(R.id.dewedt4);
		dewedt5=(EditText) findViewById(R.id.dewedt5);
		dewedt6=(EditText) findViewById(R.id.dewedt6);
		dewedt7=(EditText) findViewById(R.id.dewedt7);
		dewedt8=(EditText) findViewById(R.id.dewedt8);
		dewtotal=(TextView) findViewById(R.id.dewtoataltxt);


		inseminationedt1=(EditText) findViewById(R.id.inseminationedt1);
		inseminationedt2=(EditText) findViewById(R.id.inseminationedt2);
		inseminationtotal=(TextView) findViewById(R.id.inseminationtoal);







		confirmbtn=(Button) findViewById(R.id.AIconfirmbtn);
		submitbtn=(Button) findViewById(R.id.AISubmit_btn);

		findViewById(R.id.AI_Skip).setOnClickListener(this);

		try 
		{


			Intent intent = getIntent(); 
			if(!(intent.getStringExtra("skip_Xml")==null)&& !(intent.getStringExtra("UniqueID")==null) && !(intent.getStringExtra("Farmer_Name")==null) && !(intent.getStringExtra("Farmer_Aadhaar")==null) )
			{

				UniqueID=intent.getStringExtra("UniqueID").toString();
				FarmerName=intent.getStringExtra("Farmer_Name").toString();
				FarmerAdhaar=intent.getStringExtra("Farmer_Aadhaar").toString();
				skip_Xml=intent.getStringExtra("skip_Xml").toString();

			}

		} catch (Exception e) 
		{
			e.printStackTrace();
		}


		title1.setText("Artificial Insemination");
		title.setText("Artificial Insemination");

		confirmbtn.setVisibility(View.VISIBLE);
		l5.setVisibility(View.VISIBLE);

		submitbtn.setVisibility(View.GONE);

		setblank(new EditText[]{inseminationedt1, inseminationedt2},new TextView[]{inseminationtotal});



	}

	public void CommonAction(View v)
	{


		switch (v.getId()) 
		{
		case R.id.AIconfirmbtn:

			validate(new EditText[]{inseminationedt1, inseminationedt2});
			calculatetotal();
			addlistener(new EditText[]{inseminationedt1, inseminationedt2});

			break;

		default:
			break;

		}	

	}

	public void calculatetotal()
	{
		try {


			FinalAList=new ArrayList<String>();

			submitbtn.setVisibility(View.VISIBLE);
			confirmbtn.setVisibility(View.GONE);
			int dtotal= Integer.parseInt(inseminationedt1.getText().toString())+Integer.parseInt(inseminationedt2.getText().toString());
			String dtot=String.valueOf(dtotal);
			inseminationtotal.setText(dtot);

			//FinalAList.add((inseminationedt1.getText().toString())+"/"+(inseminationedt2.getText().toString())+"/"+dtot);

			FinalAList.add("1"+"/"+(inseminationedt1.getText().toString()));
			FinalAList.add("2"+"/"+(inseminationedt2.getText().toString()));

		} catch (Exception e) 
		{
			e.printStackTrace();
		}


	}


	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{
					if(Type.equalsIgnoreCase("DataSubmit"))
					{
						Intent i=new Intent(Artificial_Insemination_Act.this,Deworming_Act.class);
						i.putExtra("UniqueID",UniqueID);
						i.putExtra("Farmer_Name",FarmerName);
						i.putExtra("Farmer_Aadhaar",FarmerAdhaar);
						i.putExtra("skip_Xml",skip_Xml+"1");
						startActivity(i);
					}
					dialog.dismiss();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void Submit(View v)
	{


		if(inseminationtotal.getText().toString().equalsIgnoreCase("0"))
		{
			Toast toast = null;
			toast=Toast.makeText(Artificial_Insemination_Act.this,"Enter Any One Value ",Toast.LENGTH_SHORT);
			View view = toast.getView();
			toast.setGravity(Gravity.CENTER, 0, 0);
			//view.setBackgroundResource(R.color.blue);
			toast.show();
			return;
		}else {


			try {


				ArrayList<ContentValues> ALCV=new ArrayList<ContentValues>();

				findViewById(R.id.AISubmit_btn).setEnabled(true);

				if(!FinalAList.isEmpty())
				{
					XmlDoc=new StringBuilder();
					XmlDoc.append("<IsAI>1</IsAI>");
					XmlDoc.append("<ArtificialInsemination>");

					for(String a:FinalAList)
					{
						String[] temp = a.split("/");

						ArrayList<String> finaldata=new ArrayList<String>();

						for(String ss:temp)
						{
							finaldata.add(ss);
						}


						if(!(finaldata.get(1).toString().equalsIgnoreCase("0")))
						{
							XmlDoc.append("<ArtificialInseminationDetails>");

							XmlDoc.append("<AnimalKindID>"+finaldata.get(0).toString()+"</AnimalKindID>");
							XmlDoc.append("<Number>"+finaldata.get(1).toString()+"</Number>");
							XmlDoc.append("</ArtificialInseminationDetails>");

							ContentValues cv=new ContentValues();


							cv.put("AnimalKindID",finaldata.get(0).toString());
							cv.put("Number",finaldata.get(1).toString());
							cv.put("UniqueID",UniqueID);
							cv.put("FarmerName",FarmerName);
							cv.put("Farmer_Adhaar",FarmerAdhaar);
							cv.put("CreatedBy",HomeData.userID);
							cv.put("UniqueID",UniqueID);
							cv.put("Status","N");

							db.open();
							db.insertTableDate("Artificial_Insemination_Details", cv);
							db.close();
						}
					}
					XmlDoc.append("</ArtificialInsemination>");

					db.open();
					String xml=db.getSingleValue("select XMLDATA from Farmer_FullDetails where  RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"' and Farmer_Aadhaar='"+FarmerAdhaar+"'");
					xml=xml+XmlDoc.toString();
					db.execSQL("UPDATE Farmer_FullDetails set XMLDATA='"+xml+"' where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
					db.close();

					AlertDialogs("Information!!", "Artificial Insemination Details Successfully Submitted","DataSubmit");
				}

			}catch (Exception e) 
			{
				Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
			}

		}
	}




	private boolean validate(EditText[] fields)
	{
		try {

			for(int i=0; i<fields.length; i++)
			{
				EditText currentField=fields[i];
				if(currentField.getText().toString().length()==0){
					currentField.setText("0");
				}
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return true;

	}

	private boolean setblank(EditText[] fields,TextView[] text)
	{
		try {

			for(int i=0; i<fields.length; i++){
				EditText currentField=fields[i];

				currentField.setText("");

			}
			for(int j=0;j<text.length;j++)
			{
				TextView t=text[j];
				t.setText("");
			}

		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return true;

	}

	private boolean addlistener(EditText[] fields)
	{

		try {

			for(int i=0; i<fields.length; i++)
			{
				EditText currentField=fields[i];
				currentField.addTextChangedListener(new TextWatcher() {

					@Override
					public void onTextChanged(CharSequence s, int start, int before, int count) {
						// TODO Auto-generated method stub

					}

					@Override
					public void beforeTextChanged(CharSequence s, int start, int count,
							int after) {
						// TODO Auto-generated method stub

					}

					@Override
					public void afterTextChanged(Editable s) {
						// TODO Auto-generated method stub
						confirmbtn.setVisibility(View.VISIBLE);
						submitbtn.setVisibility(View.GONE);
					}
				});
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return true;

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}


	@Override
	public void onClick(View v) 
	{


		switch (v.getId()) 
		{
		case R.id.AI_Skip:
			SkipService();
			break;

		default:
			break;
		}

	}

	private void SkipService()
	{
		try {


			XmlDoc=new StringBuilder();
			XmlDoc.append("<IsAI>0</IsAI>");

			db.open();
			String xml=db.getSingleValue("select XMLDATA from Farmer_FullDetails where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"' and Farmer_Aadhaar='"+FarmerAdhaar+"'");
			xml=xml+XmlDoc.toString();
			db.execSQL("UPDATE Farmer_FullDetails set XMLDATA='"+xml+"' where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
			db.close();

			Intent i=new Intent(Artificial_Insemination_Act.this,Deworming_Act.class);
			i.putExtra("UniqueID",UniqueID);
			i.putExtra("Farmer_Name",FarmerName);
			i.putExtra("Farmer_Aadhaar",FarmerAdhaar);
			i.putExtra("skip_Xml",skip_Xml+"0");
			startActivity(i);
			Artificial_Insemination_Act.this.finish();

		}catch (Exception e) 
		{
			Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
		}
	}


	public void LogoutAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{

				try 
				{
					db.open();
					db.execSQL("DELETE FROM Farmer_FullDetails  where RowID='"+UniqueID+"' and  Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
					db.execSQL("DELETE FROM Diagnosis_Treatment_Details  where UniqueID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
					db.close();

					Intent i=new Intent(Artificial_Insemination_Act.this,HomePage.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					finish();


				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}


				dialog.dismiss();

			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	@Override
	public void onBackPressed() 
	{
		try 
		{
			LogoutAlert("Are you sure Exit this Farmer","exit");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
