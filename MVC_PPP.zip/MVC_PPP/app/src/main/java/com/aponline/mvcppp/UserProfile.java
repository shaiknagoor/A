package com.aponline.mvcppp;

import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class UserProfile extends AppCompatActivity
{
	private static int LOGOUT=11;
	DBAdapter db;
	ActionBar ab;
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_account);

		ab=getSupportActionBar();
		ab.setTitle("Profile");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#26A69A")));
		ab.setDisplayHomeAsUpEnabled(true);


		db=new DBAdapter(this);
		loadUserDetails();
	}

	private void loadUserDetails() 
	{
		try {

			String designationID="",districtID="",divisionID="",mandalID="",intitutionTypeID="",intitutionLocationID="";
			db.open();
			Cursor cursor=db.getTableDataCursor("select * from Login_UserDetails where UserID='"+HomeData.userID+"'");
			if(cursor.getCount()>0)
			{
				cursor.moveToFirst();
				((TextView)findViewById(R.id.userDetails_empName_Tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeName")));
				//designationID=cursor.getString(cursor.getColumnIndex("Designation"));
				//((TextView)findViewById(R.id.userDetails_empID_Tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeID")));
				((TextView)findViewById(R.id.userDetails_empAadhrNo_Tv)).setText(cursor.getString(cursor.getColumnIndex("AadhaarNo")));
				((TextView)findViewById(R.id.EmpMobileTv)).setText(cursor.getString(cursor.getColumnIndex("MobileNo")));
				//			String gender=cursor.getString(cursor.getColumnIndex("Gender"));
				//			if(gender.equalsIgnoreCase("1"))
				//				gender="Male";
				//			else
				//				gender="Female";
				((TextView)findViewById(R.id.userDetails_gender_Tv)).setText(cursor.getString(cursor.getColumnIndex("Gender")));

				((TextView)findViewById(R.id.userDetails_empDesig_Tv)).setText(cursor.getString(cursor.getColumnIndex("DesignationName")));
				((TextView)findViewById(R.id.userDetails_District_tv)).setText(cursor.getString(cursor.getColumnIndex("DistrictName")));
				((TextView)findViewById(R.id.userDetails_Division_tv)).setText(cursor.getString(cursor.getColumnIndex("DivisionName")));
				//((TextView)findViewById(R.id.userDetails_mandal_tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeID")));
				//((TextView)findViewById(R.id.userDetails_IntitutionType_tv)).setText(cursor.getString(cursor.getColumnIndex("EmployeeID")));
				((TextView)findViewById(R.id.userDetails_IntitutionLocation_tv)).setText(cursor.getString(cursor.getColumnIndex("MVCLocationName")));



				//			districtID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				//			divisionID=cursor.getString(cursor.getColumnIndex("DivisionID"));
				//			mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				//			intitutionTypeID=cursor.getString(cursor.getColumnIndex("TypeOfInstitution"));
				//			intitutionLocationID=cursor.getString(cursor.getColumnIndex("LocationOfInstitutionID"));
			}
			cursor.close();
			db.close();

			//		String designation=db.getSingleValue("select  DesignationName from Master_Designation where DesignationID='"+designationID+"'");
			//		String district=db.getSingleValue("select distinct District_Name from District_Master where District_ID='"+districtID+"'");
			//		String division=db.getSingleValue("select distinct Division_Name from Division_Master where Division_ID='"+divisionID+"' and District_ID='"+districtID+"'");
			//		String mandal=db.getSingleValue("select distinct Mandal_Name from Mandal_Master where Mandal_ID='"+mandalID+"' and District_ID='"+districtID+"' and Division_ID='"+divisionID+"'");
			//		String intitutionType=db.getSingleValue("select distinct Institution_Type_Name from Master_Institution_Types where Institution_TypeID='"+intitutionTypeID+"'");
			//		String intitutionLocation=db.getSingleValue("select Institute_Location from Master_Institutions where InstituteID='"+intitutionLocationID+"'");
			//		db.close();
			//
			//		((TextView)findViewById(R.id.userDetails_empDesig_Tv)).setText(designation);
			//		((TextView)findViewById(R.id.userDetails_District_tv)).setText(district);
			//		((TextView)findViewById(R.id.userDetails_Division_tv)).setText(division);
			//		((TextView)findViewById(R.id.userDetails_mandal_tv)).setText(mandal);
			//		((TextView)findViewById(R.id.userDetails_IntitutionType_tv)).setText(intitutionType);
			//		((TextView)findViewById(R.id.userDetails_IntitutionLocation_tv)).setText(intitutionLocation);


		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void LogoutAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("AP Checkpost");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				if(type.equalsIgnoreCase("logout"))
				{

					HomeData.isLogOut(UserProfile.this);
					Intent i=new Intent(UserProfile.this,Login_Page.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					// setResult(LOGOUT);
					finish();
				}
				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	//	@Override
	//	public boolean onCreateOptionsMenu(Menu menu)
	//	{
	//		// Inflate the menu; this adds items to the action bar if it is present.
	//		getMenuInflater().inflate(R.menu.main, menu);
	//		return true;
	//	}
	//	@Override
	//	public boolean onOptionsItemSelected(MenuItem item) 
	//	{
	//		switch (item.getItemId())
	//		{
	//		case android.R.id.home:
	//			super.onBackPressed();
	//			return true; 
	//		case R.id.logout:
	//			LogoutAlert("Do you want to Logout","logout");	
	//			return true;
	//		default:
	//
	//			return super.onOptionsItemSelected(item);
	//		}  
	//	}

	@Override
	public void onBackPressed() 
	{
		super.onBackPressed();
	}

}
