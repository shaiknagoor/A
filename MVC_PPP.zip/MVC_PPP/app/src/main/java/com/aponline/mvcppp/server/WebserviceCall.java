package com.aponline.mvcppp.server;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import com.aponline.mvcppp.HomeData;
import com.aponline.mvcppp.database.DBAdapter;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class WebserviceCall implements ErrorCodes
{

	/**
	 * Variable Decleration................
	 * 
	 */
	// http://www.sandbyshg.ap.gov.in/SandTabDownLoadFile/DownloadFile.aspx
	String TransDate;
	String TotalTrans;
	public static String Error,Data,msg;
	StringBuilder stringBuilder;
	String namespace = "http://tempuri.org/";
	private String url;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	Context paramContext;
	DBAdapter db;
	public static String serverResponse;
	public static int serverUploadcount;
	public static String reachId;
	public static String districtId;
	public static String ppcId;
	public static String LatestAppversion;

	public static HashMap<String, String> paramList=new HashMap<String, String>();


	public WebserviceCall(Context paraContext) 
	{
		this.paramContext = paraContext;
		db = new DBAdapter(paraContext);
		this.url = HomeData.url;
	}

	public int ValidateUserDetails(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="ValidateUserDetails_MVCS";
			Log.e("Method Name", methodName);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//password=test@123; UserID=693767192760; VersionID=1;
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			request.addProperty("VersionID",HomeData.sAppVersion);


			//request.addProperty("VersionID","1.0");
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get Login Details", result);
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()>0)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					//					if(Data.equalsIgnoreCase("Update Version"))
					//					{
					return mUpdateVersion;
					//	}
				}
				if(!jsonObject.equals(null))
				{
					ContentValues contentValues=new ContentValues();
					contentValues.put("UserID", paramList.get("UserID"));
					contentValues.put("Password", paramList.get("password"));
					contentValues.put("AadhaarNo", jsonObject.optString("AadhaarNo"));
					contentValues.put("EmployeeName",jsonObject.optString("EmployeeName"));
					contentValues.put("DesignationName",jsonObject.optString("DesignationName"));
					contentValues.put("DesignationID",jsonObject.optString("DesignationID"));
					contentValues.put("RoleName",jsonObject.optString("RoleName"));
					contentValues.put("DistrictName",jsonObject.optString("DistrictName"));
					contentValues.put("DistrictID",jsonObject.optString("DistrictID"));
					contentValues.put("DivisionName ",jsonObject.optString("DivisionName"));
					contentValues.put("DivisionID",jsonObject.optString("DivisionID"));
					contentValues.put("MVCLocationName ",jsonObject.optString("MVCLocationName"));
					contentValues.put("LocationID",jsonObject.optString("LocationID"));
					contentValues.put("MobileNo",jsonObject.optString("MobileNo1"));
					contentValues.put("Gender",jsonObject.optString("Gender"));
					contentValues.put("RoleID",jsonObject.optString("RoleID"));

					db.open();
					db.deleteTableData("Login_UserDetails", "UserID='"+paramList.get("UserID")+"'");
					db.insertTableDate("Login_UserDetails", contentValues);
					db.close();
					return mSuccess;
				}
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}
	public int GetForgotPassword() 
	{
		try 
		{
			String methodName="GetForgotPassword";
			Log.e("Method Name", methodName);
			Log.e("Device ID", HomeData.sDeviceId);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("userID", "");
			request.addProperty("deviceID",HomeData.sDeviceId);
			request.addProperty("versionID",HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			if(result.contains("Error"))
			{
				JSONArray jsonArray=new JSONArray(result);
				if(jsonArray.length()>0)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(0);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.optString("Error"); 
						if(Error.equalsIgnoreCase("UPDATE NEW VERSION"))
						{
							return 500;
						}
						return 100;
					}
					if(!jsonObject.equals(null))
					{
					}
				}
			}
			if(result.contains("Data"))
			{
				JSONArray jsonArray=new JSONArray(result);
				if(jsonArray.length()>0)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(0);
					Data=jsonObject.optString("Data").toString(); 
					if(Data.equalsIgnoreCase("Update Version"))
					{
						return 500;
					}
				}
			}
			if(result.equalsIgnoreCase("true"))
			{
				return 12;
			}
			else
			{
				return 13;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return 10;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int InsertUserRegistrationDetails(HashMap<String, String> paramList)
	{ 
		try 
		{
			String methodName="InsertUserRegistrationDetails_Mobile";  //VOLOGIN METHOD
			Log.e("Method Name", methodName);
			Log.e("Device ID", HomeData.sDeviceId);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			//request.addProperty("DeviceId",HomeData.sDeviceId);
			request.addProperty("VersionID",HomeData.sAppVersion);
			//DeviceID=865770025678661; XML=<DeptUserRegistraion><AADHARNo>654321098766</AADHARNo><DistrictID>4</DistrictID><DivisionID>5</DivisionID><MandalID></MandalID><LocationOfInstitutionID></LocationOfInstitutionID><TypeOfInstitution></TypeOfInstitution><EmployeeName>anshu</EmployeeName><Designation>5</Designation><MobileNo>9870878078</MobileNo><EmployeeID>empansh1</EmployeeID><BankName></BankName><AccountNo></AccountNo><IFSCCode></IFSCCode><BranchName></BranchName><Gender>1</Gender><Longitude>78.3679631</Longitude><Latitude>17.4589151</Latitude><Image></Image></DeptUserRegistraion>; VersionID=1;			



			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true; 
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 
			androidHttpTransport.call(SOAP_ACTION, envelope);
			serverResponse = envelope.getResponse().toString();//[{"Message":"True"}]
			//[{"Error":"Parameter is not valid."}]
			//[{"Error":"User Alredy Exists"}]
			Log.d("InsertUserReistratin", serverResponse);//58546543688
			JSONArray jArray= new JSONArray(serverResponse);

			if(jArray.length()>0)
			{
				JSONObject jsonObject=jArray.getJSONObject(0);
				if(jsonObject.has("Message"))
				{
					msg=jsonObject.optString("Message");
					if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exist"))
					{
						return mSuccess;
					}
					else
					{
						WebserviceCall.Error="Upload Failed, Please Try Again!!";
						return mFailure;
					}

				}
				else if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				else if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 

					return mUpdateVersion;

				}

			}
			else
			{
				Error="Upload Failed,please try again";
				return mFailure;
			}
			//			if(result.equalsIgnoreCase("True")||result.equalsIgnoreCase("Exist"))
			//			{
			//				return mSuccess;
			//			}
			//			else
			//			{

			//				return mFailure; 
			//			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;

	}
	public int UploadOfflineData(HashMap<String, String> paramList)
	{

		serverUploadcount=0;
		ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();

		try 
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("Select distinct AUTO_ID,METHOD_NAME,Aadhaar_No,XMLDATA,UniqueID from UPLOAD_OFFLINEDATA where CreatedBy='"+HomeData.userID+"' and UPLOAD_STATUS='N'");
			if(cursor.getCount()>0)
			{
				if(cursor.moveToFirst())
				{
					do
					{
						ArrayList<String> localArrayList=new ArrayList<String>();
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("METHOD_NAME"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("Aadhaar_No"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("XMLDATA"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("AUTO_ID"))));
						localArrayList.add(cursor.getString(cursor.getColumnIndex(("UniqueID"))));
						data.add(localArrayList);
					}while(cursor.moveToNext());
				}
			}
			cursor.close(); 
			db.close();
			if(data.size()<=0)  
			{
				Error="All Records are Uploaded";

				return mErrorResFromWebServices;
			}
			for(int i=0;i<data.size();i++)
			{
				ArrayList<String> localArrayList=data.get(i);
				String methodName=localArrayList.get(0);
				String aadharNo=localArrayList.get(1);
				String xmldoc=localArrayList.get(2);
				String autoId=localArrayList.get(3);
				String UniqueID=localArrayList.get(4);
				Log.e("Method Name", methodName);
				Log.d("XMLDOC",xmldoc);

				SOAP_ACTION = namespace + methodName;
				request = new SoapObject(namespace, methodName);
				//				for ( String key : paramList.keySet() )
				//				{
				//					request.addProperty(key,paramList.get(key));
				//					Log.e(key, paramList.get(key));
				//				}
				request.addProperty("XML", xmldoc);
				request.addProperty("UserID", HomeData.userID);
				request.addProperty("DeviceID", HomeData.sDeviceId);
				request.addProperty("VersionID", HomeData.sAppVersion);
				//DeviceID=865770025678661; UserID=693767192760; XML=<FarmerUserRegistraion><AADHARNo>908765432123</AADHARNo><FarmerName>asdf</FarmerName><Gender>1</Gender><MobileNo>9858785482</MobileNo><VillageID>926</VillageID><SocialStatusID>1</SocialStatusID><BankName>gtegj</BankName><AccNo>1235</AccNo><IFSCCode>hh56</IFSCCode><BranchName>hyd</BranchName><WhiteCattleMale>5</WhiteCattleMale><WhiteCattleFemale>4</WhiteCattleFemale><BuffaloesMale>5</BuffaloesMale><BuffaloesFemale>4</BuffaloesFemale><Sheep>1</Sheep><Goats>1</Goats><Pigs>1</Pigs><Dogs>1</Dogs><Backyardpoultry>1</Backyardpoultry><commercialLayers>1</commercialLayers><commercialBroilers>1</commercialBroilers><Ducks>1</Ducks><FodderCultivated>10</FodderCultivated><CattleShedAttached>true</CattleShedAttached><CowMilkProduced>20</CowMilkProduced><CowMilkSold>20</CowMilkSold><BuffeloMilkProduced>20</BuffeloMilkProduced><BuffeloMilkSold>20</BuffeloMilkSold></FarmerUserRegistraion>; VersionID=1;
				envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
				envelope.dotNet=true;
				envelope.setOutputSoapObject(request); 
				// Make the soap call.
				androidHttpTransport = new HttpTransportSE(url,70000);
				androidHttpTransport.debug = true;
				androidHttpTransport.call(SOAP_ACTION, envelope);
				serverResponse = envelope.getResponse().toString();
				Log.d("InserFMDDetails", serverResponse);

				JSONArray jArray= new JSONArray(serverResponse);

				if(jArray.length()>0)
				{
					JSONObject jsonObject=jArray.getJSONObject(0);
					if(jsonObject.has("Message"))
					{
						msg=jsonObject.optString("Message");
						if(msg.equalsIgnoreCase("True")||msg.equalsIgnoreCase("Exist"))
						{
							serverUploadcount++;
							ContentValues data1=new ContentValues();
							data1.put("UPLOAD_STATUS", "Y");
							db.open();
							db.updateTableData("UPLOAD_OFFLINEDATA", data1, "AUTO_ID='"+autoId+"'");

							if(methodName.equalsIgnoreCase("MVCS_Attendance_Travel_Insert"))
							{
								ContentValues data2=new ContentValues();
								data2.put("Status", "Y");

								db.updateTableData("Attendance_Travel_Details", data2, "RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");

							}
							else if(methodName.equalsIgnoreCase("MVCS_Medicine_Details_Insert")) 
							{
								ContentValues data3=new ContentValues();
								data3.put("Status", "Y");
								db.updateTableData("Medicine_Received_Details", data3, "UniqueID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
							}
							else if(methodName.equalsIgnoreCase("MVCS_Farmer_Diagnosis_Deworming_Vaccine_Insert")) 
							{
								ContentValues Mdata=new ContentValues();
								Mdata.put("Final_Status", "Y");

								db.updateTableData("Farmer_FullDetails", Mdata, "RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");

								db.execSQL("UPDATE Diagnosis_Treatment_Details set Status='Y' where UniqueID='"+UniqueID+"' and  CreatedBy='"+HomeData.userID+"'");
								db.execSQL("UPDATE Artificial_Insemination_Details set Status='Y' where UniqueID='"+UniqueID+"' and  CreatedBy='"+HomeData.userID+"'");
								db.execSQL("UPDATE Dewormings set Status='Y' where UniqueID='"+UniqueID+"' and  CreatedBy='"+HomeData.userID+"'");
								db.execSQL("UPDATE Vaccination_Details set Status='Y' where UniqueID='"+UniqueID+"' and  CreatedBy='"+HomeData.userID+"'");
								db.execSQL("UPDATE MVC_Diagnosis__Treatment_AnimalDetails set Status='Y' where UniqueID='"+UniqueID+"' and  CreatedBy='"+HomeData.userID+"'");
							}
							
							else if(methodName.equalsIgnoreCase("MVCS_HQReadingDetails_Insert")) 
							{
								ContentValues Mdata=new ContentValues();
								Mdata.put("Status", "Y");

								db.updateTableData("HeadQuarter_Travel_Details", Mdata, "Auto_ID='"+UniqueID+"' and UserID='"+HomeData.userID+"'");

							}

							db.close();
						}

					}
					else if(jsonObject.has("Error"))
					{
						Error=jsonObject.optString("Error"); 
						return mErrorResFromWebServices;
					}
					else if(jsonObject.has("Data"))
					{
						Data=jsonObject.optString("Data").toString(); 

						return mUpdateVersion;

					}

				}
			}
			if(serverUploadcount>0)
			{
				return mSuccess;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mFailure;
	}

	public int Download_VillageData(HashMap<String, String> paramList)
	{
		try 
		{
			serverUploadcount=0;

			String methodName="MVCS_GetMasterMandalsVillages";
			Log.e("Method Name", methodName);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//password=test@123; UserID=693767192760; VersionID=1;
			//			for ( String key : paramList.keySet() )
			//			{
			//				request.addProperty(key,paramList.get(key));
			//				Log.e(key, paramList.get(key));
			//			}
			request.addProperty("UserID", HomeData.userID);
			request.addProperty("VersionID",HomeData.sAppVersion);


			//request.addProperty("VersionID","1.0");
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get Login Details", result);
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()>0)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					//					if(Data.equalsIgnoreCase("Update Version"))
					//					{
					return mUpdateVersion;
					//	}
				}

//				ArrayList<String> VillageIDAL=new ArrayList<String>();
//
//
//
//				db.open();
//				//Cursor cursor=db.getTableDataCursor("select distinct VillageID from Master_MVC_New ");//where DistrictID='"+1+"' and DivisionID='"+1+"' and MVCHeadQuarterID='"+1+"'");
//				Cursor cursor=db.getTableDataCursor("SELECT  VillageID from Master_MVC_New where DistrictID=(select DistrictID from Login_UserDetails where AadhaarNo='"+HomeData.userID+"') and DivisionID=(select DivisionID from Login_UserDetails where AadhaarNo='"+HomeData.userID+"')");
//				if(cursor.getCount()>0)
//				{
//					for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
//					{
//						VillageIDAL.add(cursor.getString(cursor.getColumnIndex(("VillageID"))));
//					}
//				}
//				cursor.close(); 
//				db.close();

				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject1=jsonArray.getJSONObject(i);

					if (!jsonObject1.equals(null)) 
					{
						
						if(i==0)
						{
							db.open();
							db.deleteTableData("Master_MVC_New","");
							db.close();
						}

//						if(!VillageIDAL.contains(jsonObject1.optString("VillageID")))
//						{
							ContentValues contentValues=new ContentValues();
							contentValues.put("DistrictID", jsonObject1.optString("DistrictID"));
							contentValues.put("District_Name",jsonObject1.optString("District"));
							contentValues.put("DivisionID", jsonObject1.optString("DivisionID"));
							contentValues.put("Division_Name",jsonObject1.optString("Division"));
							contentValues.put("MVCHeadQuarterID",jsonObject1.optString("MVCLocationID"));
							contentValues.put("MVCHeadQuarter_Name",jsonObject1.optString("MVCHeadQuarter"));
							contentValues.put("MandalID",jsonObject1.optString("MandalID"));
							contentValues.put("VillageID",jsonObject1.optString("VillageID"));
							contentValues.put("Village_Name",jsonObject1.optString("Village"));
							contentValues.put("DayoftheWeek",jsonObject1.optString("DayoftheWeek"));
							contentValues.put("Distance_from_HQ ",jsonObject1.optString("DistanceHQ"));
							contentValues.put("ShiftTime",jsonObject1.optString("ShiftTime"));
							contentValues.put("IsActive",jsonObject1.optString("IsActive"));


							db.open();
							db.insertTableDate("Master_MVC_New", contentValues);
							db.close();

							serverUploadcount++;


						//}

					}

				}

				return mSuccess;
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		return mException;
	}






	public int Download_MedicineMaster(HashMap<String, String> paramList)
	{
		try 
		{
			serverUploadcount=0;

			String methodName="MVCS_GetMasterMedicineDetails";
			Log.e("Method Name", methodName);

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//password=test@123; UserID=693767192760; VersionID=1;
			//			for ( String key : paramList.keySet() )
			//			{
			//				request.addProperty(key,paramList.get(key));
			//				Log.e(key, paramList.get(key));
			//			}
			request.addProperty("UserID", HomeData.userID);
			request.addProperty("VersionID",HomeData.sAppVersion);


			//request.addProperty("VersionID","1.0");
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,70000);
			androidHttpTransport.debug = true; 

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			Log.d("Get Login Details", result);
			JSONArray jsonArray=new JSONArray(result);

			if(jsonArray.length()>0)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.optString("Error"); 
					return mErrorResFromWebServices;
				}
				if(jsonObject.has("Data"))
				{
					Data=jsonObject.optString("Data").toString(); 
					//					if(Data.equalsIgnoreCase("Update Version"))
					//					{
					return mUpdateVersion;
					//	}
				}



				for(int i=0;i<jsonArray.length();i++)
				{

					JSONObject jsonObject1=jsonArray.getJSONObject(i);
					if (!jsonObject1.equals(null)) 
					{

						if(i==0)
						{
							db.open();
							db.deleteTableData("Master_Medicine","");
							db.close();
						}

						ContentValues Master_Medicinecv=new ContentValues();
						
						Master_Medicinecv.put("Roll_Id", jsonObject1.optString("MVCTradeID"));
						Master_Medicinecv.put("Drug_Code",jsonObject1.optString("Drugcode"));
						Master_Medicinecv.put("Trade_Name",jsonObject1.optString("TradeName"));
						Master_Medicinecv.put("Firm_Name",jsonObject1.optString("Firm"));
						Master_Medicinecv.put("Packing",jsonObject1.optString("Packing"));
						Master_Medicinecv.put("Unit_Price", jsonObject1.optString("UnitPrice"));

						db.open();
						long rowid=	db.insertTableDate("Master_Medicine",Master_Medicinecv);
						db.close();
						serverUploadcount++;


					}
				}

				return mSuccess;
			}
			else
			{
				Error= "Data Not Found";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		return mException;
	}
}
