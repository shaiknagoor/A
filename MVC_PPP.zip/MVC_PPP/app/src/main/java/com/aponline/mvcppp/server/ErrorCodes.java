package com.aponline.mvcppp.server;

public interface ErrorCodes
{
	int mParseJSONFailure = 11;
	int mParseJSONSuccess = 12;
	int mParseJSONSuccessSecond = 14;
	int mParseWrongJSON = 13;

	/*************************************************************/
	/**********             Error Codes                ***********/
	/*************************************************************/
	int mSuccess = 100;
	int mFailure = 101;
	int mException = 102;
	int mIOException = 103;
	int mSocketTimeoutException=104;
	int mXmlPullParserException = 105;
	int mJSONException = 106;
	int mHandlerFailure = 107;

	
	int mErrorResFromWebServices = 110;
	
	int mUpdateVersion = 500;
	
	public static final String nXmlPullParserException = "Failed to load the data, Please Tryagain later!!";
	public static final String nException = "Couldn't communicate with PayBills server,Tryagain later!!";
	public static final String nSocketTimeoutException = "Timeout to communicate with PayBills server,Please Tryagain later!!";

	
}

