package com.aponline.mvcppp.database;

public class CreateTablesData 
{
	public static String USER_LOGIN_DETAILS="CREATE TABLE USER_LOGIN_DETAILS("
			+ "USER_NAME VARCHAR(20),"
			+ "PASSWORD VARCHAR(20),"
			+ "IS_ACTIVE VARCHAR(2));";
	
	public static String VETERINARY_HOSPITAL_MANAGEMENT="CREATE TABLE  VETERINARY_HOSPITAL_MANAGEMENT("
			+"AUTO_ID integer primary key autoincrement,"
			+"UserId TEXT," 
			+"Password TEXT," 
			+"Provision_Type TEXT," 
			+"Kind_of_Animal TEXT," 
			+"Digestive_Disorders TEXT," 
			+"Respiratory_Disorders TEXT,"
			+"Reproductive_Disorders TEXT," 
			+"Uro_Genital_Problems TEXT,"
			+"Metabolic_Diseases TEXT,"
			+"Others TEXT,"
			+"Major TEXT," 
			+"Minor TEXT," 
			+"Number TEXT,"
			+"Total TEXT,"
			+"STATUS VARCHAR(2) default 'N',"
			+"CREATED_DATE default current_timestamp);";
	
	public static String MVC_Diagnosis__Treatment_AnimalDetails="CREATE TABLE if not exists MVC_Diagnosis__Treatment_AnimalDetails ("
			+ "UniqueID TEXT  NULL,"
			+ "FarmerName TEXT  NULL,"
			+ "Farmer_Adhaar TEXT  NULL,"
			+ "Animal_Name TEXT  NULL,"
			+ "AnimalID TEXT  NULL,"
			+ "Identification_marks TEXT  NULL,"
			+ "Diseas_Diagnosed TEXT  NULL,"
			+ "NoofAnimals_Birds TEXT  NULL,"
			+ "CreatedBy TEXT  NULL,"
			+ "Status TEXT DEFAULT 'N' NULL);";
}


