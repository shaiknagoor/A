package com.aponline.mvcppp;

import com.aponline.mvcppp.R;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

public class Help extends AppCompatActivity implements OnClickListener
{
	ActionBar ab;

	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);

		ab=getSupportActionBar();
		ab.setTitle("Contact Us");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#26A69A")));
		ab.setDisplayHomeAsUpEnabled(true);

		findViewById(R.id.mailtoTv).setOnClickListener(this);
		findViewById(R.id.Venkateswatlu_CallLL).setOnClickListener(this);
		findViewById(R.id.Venugopal_CallLL).setOnClickListener(this);
		findViewById(R.id.Victor_callLL).setOnClickListener(this);
	}
	@Override
	public void onBackPressed() 
	{
		super.onBackPressed();
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:

			return super.onOptionsItemSelected(item);
		}  
	}
	@Override
	public void onClick(View v) 
	{

		switch (v.getId()) 
		{
		case R.id.mailtoTv:


			//Alertbox("", "mail");
			Intent intent = new Intent (Intent.ACTION_VIEW , Uri.parse("mailto:" + "aponline.ahd@tcs.com"));
			//intent.putExtra(Intent.EXTRA_SUBJECT, "your_subject");
			//intent.putExtra(Intent.EXTRA_TEXT, "your_text");
			startActivity(intent);

			break;
		case R.id.Venkateswatlu_CallLL:


			Alertbox("Dr V.Venkateswatlu\n(Asst Director (A.H) MVC) \n 7702775070", "Venkateswatlu_CallLL");


			break;
		case R.id.Venugopal_CallLL:


			Alertbox("Dr P. Venugopal Choudary\n(Vety Asst Surgeon)  \n 8106982424", "Venugopal_CallLL");


			break;
		case R.id.Victor_callLL:


			Alertbox("Purna Chandra Rao  \n(Technical Support, APOnline)  \n 7032708701", "Victor_callLL");


			break;

		default:
			break;
		}
	}



	public void Alertbox(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("CALL",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{

				try 
				{
					if(type.equalsIgnoreCase("mail"))
					{
						Intent intent = new Intent (Intent.ACTION_VIEW , Uri.parse("mailto:" + "aponline.ahd@tcs.com"));
						//intent.putExtra(Intent.EXTRA_SUBJECT, "your_subject");
						//intent.putExtra(Intent.EXTRA_TEXT, "your_text");
						startActivity(intent);
					}
					else if(type.equalsIgnoreCase("Venugopal_CallLL"))
					{
						Intent intent = new Intent(Intent.ACTION_DIAL);
						intent.setData(Uri.parse("tel:8106982424"));
						startActivity(intent);
					}
					else if(type.equalsIgnoreCase("Venkateswatlu_CallLL"))
					{
						Intent intent = new Intent(Intent.ACTION_DIAL);
						intent.setData(Uri.parse("tel:7702775070"));
						startActivity(intent);
					}
					else if(type.equalsIgnoreCase("Victor_callLL"))
					{
						Intent intent = new Intent(Intent.ACTION_DIAL);
						intent.setData(Uri.parse("tel:7032708701"));
						startActivity(intent);
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("CANCEL",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}
}
