package com.aponline.mvcppp;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.RequestServer;
import com.aponline.mvcppp.server.ServerResponseListener;
import com.aponline.mvcppp.server.WebserviceCall;

import android.R.integer;
import android.R.string;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


@SuppressLint("NewApi")
public class HomePage extends Activity implements OnClickListener,ServerResponseListener
{

	Context context;
	DBAdapter db;

	LinearLayout slideMenuLL;
	RelativeLayout userDetailsLL;
	LocationManager locationManager;
	TextView NoofSheepDewormedTv,NoofGoatDewormedTv,TotalDewormedTv,NoofFarmerBenefitedtTv,userId;
	String VillageStatus,MedicineStatus;

	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.homepage_new);
		context=this;
		locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);
		db=new DBAdapter(this);

		try 
		{
			db.createDataBase();
			db.close();

		} 
		catch (IOException e) 
		{

			e.printStackTrace();
			db.close();
		}



		try 
		{
			db.open();

			db.execSQL("CREATE TABLE IF NOT EXISTS [HeadQuarter_Travel_Details] ([Auto_ID] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,"
					+ "[UserID] TEXT  NULL,[HQID] TEXT  NULL,[HQ_OpeningReading] TEXT  NULL,[HQ_ClosingReading] TEXT  NULL,[Total_Km] TEXT  NULL,"
					+ "[Day] TEXT  NULL,[Date_Time] TEXT  NULL,[GPS_Coordinates] TEXT  NULL,[Status] TEXT  NULL,[CreatedDate] TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL)");

			MedicineStatus=db.getSingleValue("select distinct IFNULL(ISActive,'false') from Master_Medicine");
			VillageStatus=db.getSingleValue("select  distinct IFNULL(IsActive,'false')  from Master_MVC_New");
			db.close();

			if(MedicineStatus.equalsIgnoreCase("1"))
			{
				RequestServer request1=new RequestServer(HomePage.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(HomePage.this, "Download_MedicineMaster");
			}
			if(VillageStatus.equalsIgnoreCase("false"))
			{
				RequestServer request1=new RequestServer(HomePage.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(HomePage.this, "Download_VillageData");
			}




		} catch (Exception e) 
		{
			e.printStackTrace();
		}

		try 
		{
			db.open();
			String DignType=db.getSingleValue("select DesignationName from Login_UserDetails where  UserID='"+HomeData.userID+"'");
			db.close();

			if(DignType.equalsIgnoreCase("VET(VAS)"))
			{
				findViewById(R.id.ServicesBt).setVisibility(View.VISIBLE);
			}
			else if (DignType.equalsIgnoreCase("Paravets (P)") || DignType.equalsIgnoreCase("Attendar (P)")) 
			{
				findViewById(R.id.ServicesBt).setVisibility(View.GONE);
			}else 
			{
				findViewById(R.id.ServicesBt).setVisibility(View.GONE);
			}


		} catch (Exception e) 
		{
			e.printStackTrace();
		}


		userId=(TextView) findViewById(R.id.userId);

		findViewById(R.id.homepage_slideclose_Iv).setOnClickListener(this);
		findViewById(R.id.homepage_userDetailsClose_Iv).setOnClickListener(this);
		slideMenuLL=(LinearLayout) findViewById(R.id.home_slidemenu_LL);
		slideMenuLL.setVisibility(8);
		userDetailsLL=(RelativeLayout) findViewById(R.id.home_UserDetails_LL);
		userDetailsLL.setVisibility(8);

		findViewById(R.id.TreatmentTv).setOnClickListener(this);
		findViewById(R.id.AttendanceTv).setOnClickListener(this);
		findViewById(R.id.ServicesBt).setOnClickListener(this);
		findViewById(R.id.Artificial_InseminationTv).setOnClickListener(this);
		findViewById(R.id.DewormingsTv).setOnClickListener(this);
		findViewById(R.id.VaccinationsTv).setOnClickListener(this);
		findViewById(R.id.MedicinesReceivedTv).setOnClickListener(this);
		findViewById(R.id.HomeTv).setOnClickListener(this);
		findViewById(R.id.Kms_TravelledBt).setOnClickListener(this);
		findViewById(R.id.DataUpload).setOnClickListener(this);

		try
		{
			db.open();
			String	UserName=db.getSingleValue("SELECT EmployeeName from Login_UserDetails where UserID='"+HomeData.userID+"'");

			db.close();

			userId.setText("Welcome To  : "+UserName);
			userId.startAnimation((Animation)AnimationUtils.loadAnimation(HomePage.this,R.anim.text_translate));



		} catch (Exception e) {
			e.printStackTrace();
		}

		PendingCount();



	}

	@Override
	public void onClick(View v)
	{

		Intent i;

		switch (v.getId()) 
		{
		case R.id.MedicinesReceivedTv:
			i=new Intent(this,MedicinesReceive.class);
			startActivity(i);
			break;
		case R.id.AttendanceTv:
			i=new Intent(this,Attendance_Act.class);
			startActivity(i);
			break;

		case R.id.Kms_TravelledBt:
			i=new Intent(this,Travelled_Kms.class);
			startActivity(i);
			break;

		case R.id.TreatmentTv:
			i=new Intent(this,Farmer_Details.class);
			startActivity(i);
			break;
			//		case R.id.Artificial_InseminationTv:
			//			i=new Intent(this,Hospitalmanagement.class);
			//			i.putExtra("Treatment_Type", "Artificial_InseminationTv");
			//			startActivity(i);
			//			break;
			//		case R.id.DewormingsTv:
			//			i=new Intent(this,Hospitalmanagement.class);
			//			i.putExtra("Treatment_Type","DewormingsTv");
			//			startActivity(i);
			//			break;
			//		case R.id.VaccinationsTv:
			//			i=new Intent(this,Hospitalmanagement.class);
			//			i.putExtra("Treatment_Type","VaccinationsTv");
			//			startActivity(i);
			//			break;
		case R.id.ExtensionTv:

			break;
		case R.id.HomeTv:

			//			i=new Intent(this,DashBoard_Act.class);
			//			startActivity(i);
			onBackPressed();

			break;
		case R.id.DataUpload:
			LogoutAlert("Are you sure you want to Upload Offline Data","UploadOfflineData");
			break;


		case R.id.ServicesBt:

			i=new Intent(this,Farmer_Details.class);
			startActivity(i);
			//			if(((LinearLayout)findViewById(R.id.SubmenuLL)).getVisibility()==View.GONE)
			//			{
			//				Drawable Dr1 = getResources().getDrawable(R.drawable.technical_service_van);
			//				Drawable Dr2 = getResources().getDrawable(R.drawable.keyboard_arrow_up_black_27x27);
			//				((TextView) findViewById(R.id.ServicesBt)).setCompoundDrawablesWithIntrinsicBounds(Dr1, null, Dr2, null);
			//				((LinearLayout)findViewById(R.id.SubmenuLL)).setVisibility(View.VISIBLE);
			//			}else 
			//			{
			//				Drawable Dr1 = getResources().getDrawable(R.drawable.keyboard_arrow_down_black_27x27);
			//				Drawable Dr2 = getResources().getDrawable(R.drawable.technical_service_van);
			//				((TextView) findViewById(R.id.ServicesBt)).setCompoundDrawablesWithIntrinsicBounds(Dr2, null, Dr1, null);
			//				((LinearLayout)findViewById(R.id.SubmenuLL)).setVisibility(View.GONE);
			//			}
			break;

			//case R.id.DataUploadBt:
			//i=new Intent(this,Hospitalmanagement.class);
			//i.putExtra("Vaccinations", "Vaccinations");
			//startActivity(i);
			//	break;
			//		case R.id.ContactUsBt:
			//			i=new Intent(this,Help.class);
			//			i.putExtra("Artificial_Insemination", "Artificial_Insemination");
			//			startActivity(i);
			//	break;
			//		case R.id.CalvesBornBt:
			//			i=new Intent(this,Hospitalmanagement.class);
			//			i.putExtra("CalvesBorn", "CalvesBorn");
			//			startActivity(i);
			//			break;
			//		case R.id.devicemgntBt:
			//			RequestServer request1=new RequestServer(HomePage.this);
			//			request1.addParam("DeviceID", HomeData.sDeviceId);
			//			request1.ProccessRequest(HomePage.this, "UploadOfflineData");			
			//			break;
			//		case R.id.user_logout_btn:
			//			LogoutAlert("Do you want to Logout");
			//			break;
			//		case R.id.CastrationsBt:
			//			i=new Intent(this,Hospitalmanagement.class);
			//			i.putExtra("Castrations", "Castrations");
			//			startActivity(i);
			//			break;
			//		case R.id.profileTv:
			//			profile(true);
			//			break;
			//		case R.id.menuTv:
			//			slideMenu(true);
			//			break;
			//		case R.id.homepage_slideclose_Iv:
			//			slideMenu(false);
			//			break;
			//		case R.id.homepage_userDetailsClose_Iv:
			//			profile(false);
			//			break;
			//
			//		case R.id.VaccinationsBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("Vaccinations", "Vaccinations");
			//			startActivity(intentReport);
			//			break;
			//
			//		case R.id.DewormingsBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("Dewormings", "Dewormings");
			//			startActivity(intentReport);
			//			break;
			//		case R.id.CastrationsBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("Castrations", "Castrations");
			//			startActivity(intentReport);
			//			break;
			//		case R.id.Artificial_InseminationBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("Artificial_Insemination", "Artificial_Insemination");
			//			startActivity(intentReport);
			//			break;
			//		case R.id.CalvesBornBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("CalvesBorn", "CalvesBorn");
			//			startActivity(intentReport);
			//			break;
			//		case R.id.OperationsBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("Surgery", "Surgery");
			//			startActivity(intentReport);
			//			break;
			//		case R.id.AnimalsTreatedBt_Report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("AnimalsTreated", "AnimalsTreated");
			//			startActivity(intentReport);
			//			break;
			//			
			//		case R.id.AbstractBt_report:
			//			intentReport=new Intent(this,Reports_page.class);
			//			intentReport.putExtra("AbstractBt_report", "AbstractBt_report");
			//			startActivity(intentReport);
			//			break;
			//			



		default:
			break;
		}	

	}


	public void Success(String response) 
	{
		Dialogs.AlertDialogs(HomePage.this,"Information!!", ""+WebserviceCall.serverUploadcount+" Record's Successfully Uploaded");

		PendingCount();

	}
	@Override 
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(HomePage.this,"Information!!", response);
	}
	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(HomePage.this,"Information!!", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		//		startActivity(new Intent(HomePage.this,AppUpdatePage.class));
		//		finish();
		AlertDialogs("Information!!", "Plz Update latest version","AppUpdate");
		return;
	}

	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{
					if(Type.equalsIgnoreCase("Gps"))
					{
						launchGPSOptions();
					}
					if(Type.equalsIgnoreCase("AppUpdate"))
					{
						final String appPackageName = getPackageName(); // package name of the app
						try 
						{
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
						} catch (android.content.ActivityNotFoundException anfe) {
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
						}

					}

					dialog.dismiss();
					finish();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	private void launchGPSOptions() 
	{
		try
		{

			Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
			startActivity(intent);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	} 

	public void LogoutAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				//				if(type.equalsIgnoreCase("logout"))
				//				{
				//					HomeData.isLogOut(HomePage.this);
				//					Intent i=	new Intent(HomePage.this,Login_Page.class);
				//					startActivity(i);
				//					HomePage.this.finish();
				//				}
				if (type.equalsIgnoreCase("UploadOfflineData")) 
				{
					RequestServer request1=new RequestServer(HomePage.this);
					request1.addParam("DeviceID", HomeData.sDeviceId);
					request1.ProccessRequest(HomePage.this, "UploadOfflineData");	
				}
				//				else if (type.equalsIgnoreCase("DownloadData")) 
				//				{
				//					RequestServer request1=new RequestServer(HomePage.this);
				//					request1.addParam("UserId", HomeData.userID);
				//					request1.ProccessRequest(HomePage.this, "DownloadData");	
				//				}

			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}




	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}



	@Override
	protected void onRestart() 
	{
		super.onRestart();
		PendingCount();
	}

	private void PendingCount() 
	{
		try 
		{
			db.open();
			String count=	db.getSingleValue("select count(*) from UPLOAD_OFFLINEDATA where UPLOAD_STATUS='N' and CreatedBy='"+HomeData.userID+"' ");
			db.close();
			((TextView)findViewById(R.id.PendingUploadCountTv)).setText("Upload Pending Count : "+count+"");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}

	}

	@Override
	public void onBackPressed() 
	{

		super.onBackPressed();

	}

}
