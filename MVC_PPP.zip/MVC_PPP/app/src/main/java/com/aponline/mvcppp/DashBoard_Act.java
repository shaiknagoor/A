package com.aponline.mvcppp;

import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.CreateTablesData;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.RequestServer;
import com.aponline.mvcppp.server.ServerResponseListener;

public class DashBoard_Act extends Activity implements OnClickListener,ServerResponseListener
{

	Context context;
	DBAdapter db;
	ActionBar ab;
	LinearLayout slideMenuLL;
	RelativeLayout userDetailsLL;
	TextView AddAnimalTv,NoofSheepDewormedTv,NoofGoatDewormedTv,TotalDewormedTv,NoofFarmerBenefitedtTv,userId;
	TableLayout tl ;
	String VillageStatus,MedicineStatus;
	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.dashboard);
		context=this;

		userId=(TextView) findViewById(R.id.DuserId);
		userId.startAnimation((Animation)AnimationUtils.loadAnimation(DashBoard_Act.this,R.anim.text_translate));

		((TextView)findViewById(R.id.D_versionId)).setText("V "+HomeData.sAppVersionName);
		db=new DBAdapter(this);
		try 
		{
			db.createDataBase();
			db.close();

		} 
		catch (IOException e) 
		{

			e.printStackTrace();
			db.close();
		}

		
		try 
		{
			db.open();
			db.execSQL(CreateTablesData.MVC_Diagnosis__Treatment_AnimalDetails);
			//String ss=db.getSingleValue("select NoofAnimals_Birds from Diagnosis_Treatment_Details");
			db.close();
		} catch (Exception e) 
		{
//			db.open();
//			db.execSQL("ALTER TABLE Diagnosis_Treatment_Details ADD NoofAnimals_Birds TEXT DEFAULT '1' NULL ");
//			db.close();
			e.printStackTrace();
		}
		
		DashBoard();
		try 
		{
			db.open();

			db.execSQL("CREATE TABLE IF NOT EXISTS [HeadQuarter_Travel_Details] ([Auto_ID] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,"
					+ "[UserID] TEXT  NULL,[HQID] TEXT  NULL,[HQ_OpeningReading] TEXT  NULL,[HQ_ClosingReading] TEXT  NULL,[Total_Km] TEXT  NULL,"
					+ "[Day] TEXT  NULL,[Date_Time] TEXT  NULL,[GPS_Coordinates] TEXT  NULL,[Status] TEXT  NULL,[CreatedDate] TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL)");

			MedicineStatus=db.getSingleValue("select distinct IFNULL(ISActive,'false') from Master_Medicine");
			VillageStatus=db.getSingleValue("select  distinct IFNULL(IsActive,'false')  from Master_MVC_New");
			db.close();

			if(MedicineStatus.equalsIgnoreCase("1"))
			{
				RequestServer request1=new RequestServer(DashBoard_Act.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(DashBoard_Act.this, "Download_MedicineMaster");
			}
			if(VillageStatus.equalsIgnoreCase("false"))
			{
				RequestServer request1=new RequestServer(DashBoard_Act.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(DashBoard_Act.this, "Download_VillageData");
			}




		} catch (Exception e) 
		{
			e.printStackTrace();
		}




		slideMenuLL=(LinearLayout) findViewById(R.id.home_slidemenu_LL);
		if(slideMenuLL.getVisibility()==View.VISIBLE)
		{
			slideMenuLL.setVisibility(8);
			Animation slide21 = AnimationUtils.loadAnimation(this, R.anim.slid_middle_left);
			slideMenuLL.setAnimation(slide21);
			return;
		}




		//		((TextView)findViewById(R.id.Day_ATTv)).setText(": "+Day_ATTv);
		//		((TextView)findViewById(R.id.Day_AITv)).setText(": "+Day_AITv);
		//		((TextView)findViewById(R.id.Day_DewormingTv)).setText(": "+Day_DewormingTv);
		//		((TextView)findViewById(R.id.Day_VacciTv)).setText(": "+Day_VacciTv);
		//		((TextView)findViewById(R.id.Day_FarmerBTv)).setText(": "+Day_FarmerBTv);
		//		((TextView)findViewById(R.id.Day_KmTv)).setText(": "+Day_KmTv);
		//		
		//		
		//		((TextView)findViewById(R.id.Cumulative_ATTv)).setText(": "+Cumulative_ATTv);
		//		((TextView)findViewById(R.id.Cumulative_AITv)).setText(": "+Cumulative_AITv);
		//		((TextView)findViewById(R.id.Cumulative_DewormingTv)).setText(": "+Cumulative_DewormingTv);
		//		((TextView)findViewById(R.id.Cumulative_VaccTv)).setText(": "+Cumulative_VaccTv);
		//		((TextView)findViewById(R.id.Vaccination_DoneTv)).setText(": "+Vaccination_DoneTv);
		//		((TextView)findViewById(R.id.Cumulative_FarmerBenifitedTv)).setText(": "+Cumulative_FarmerBenifitedTv);
		//		((TextView)findViewById(R.id.Cumulative_KmTv)).setText(": "+Cumulative_KmTv);



		//		slideMenuLL=(LinearLayout) findViewById(R.id.home_slidemenu_LL);
		//		slideMenuLL.setVisibility(View.GONE);
		//		userDetailsLL=(RelativeLayout) findViewById(R.id.home_UserDetails_LL);
		//		userDetailsLL.setVisibility(8);

		findViewById(R.id.SideMenuTv).setOnClickListener(this);
		findViewById(R.id.slideMenuclose_Iv).setOnClickListener(this);
		findViewById(R.id.HomeBt).setOnClickListener(this);
		findViewById(R.id.ContactUsBt).setOnClickListener(this);
		findViewById(R.id.LogoutBt).setOnClickListener(this);
		findViewById(R.id.userIV).setOnClickListener(this);
	}


	public void DashBoard()
	{
		try {


			db.open();
			db.execSQL("DELETE FROM Farmer_FullDetails  where   Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
			String	UserName=db.getSingleValue("SELECT EmployeeName from Login_UserDetails where UserID='"+HomeData.userID+"'");

			String Villages_Covered=db.getSingleValue("select IFNULL(Count(Attendance_VillageName),0) from Attendance_Travel_Details  where CreatedBy='"+HomeData.userID+"'");
			String Animals_TreatedTv=db.getSingleValue("select IFNULL(sum(NoofAnimals_Birds),0) from MVC_Diagnosis__Treatment_AnimalDetails   where CreatedBy='"+HomeData.userID+"'");
			//String Animals_TreatedTv=db.getSingleValue("select IFNULL(count(AnimalID),0) from Diagnosis_Treatment_Details   where CreatedBy='"+HomeData.userID+"'");
			String AI_DoneTv=db.getSingleValue("select IFNULL(sum(Number),0) from Artificial_Insemination_Details  where CreatedBy='"+HomeData.userID+"'");
			String Deworming_DoneTv=db.getSingleValue("select IFNULL(sum(Number),0) from Dewormings  where CreatedBy='"+HomeData.userID+"'");
			String Vaccination_DoneTv=db.getSingleValue("select IFNULL(sum(Number),0) from Vaccination_Details  where CreatedBy='"+HomeData.userID+"'");
			String Farmers_benefitedTv=db.getSingleValue("select IFNULL(Count(Farmer_Aadhaar),0) from Farmer_FullDetails  where CreatedBy='"+HomeData.userID+"'");
			String Kilometres_travelledTv=db.getSingleValue("select IFNULL(sum(Total_Km),0) from HeadQuarter_Travel_Details  where UserID='"+HomeData.userID+"'");


			//		String Day_ATTv=db.getSingleValue("select IFNULL(Count(AnimalID),0) from Diagnosis_Treatment_Details   where CreatedBy='"+HomeData.userID+"'");
			//		String Day_AITv=db.getSingleValue("select IFNULL(Count(AnimalKindID),0) from Artificial_Insemination_Details  where CreatedBy='"+HomeData.userID+"'");
			//		String Day_DewormingTv=db.getSingleValue("select IFNULL(Count(AnimalKindID),0) from Dewormings  where CreatedBy='"+HomeData.userID+"'");
			//		String Day_VacciTv=db.getSingleValue("select IFNULL(Count(AnimalKindID),0) from Vaccination_Details  where CreatedBy='"+HomeData.userID+"'");
			//		String Day_FarmerBTv=db.getSingleValue("select IFNULL(Count(Farmer_Aadhaar),0) from Farmer_FullDetails  where CreatedBy='"+HomeData.userID+"'");
			//		String Day_KmTv=db.getSingleValue("select IFNULL(sum(Travel_Travelled_Km),0) from Attendance_Travel_Details  where CreatedBy='"+HomeData.userID+"'");
			//		
			//		String Cumulative_ATTv=db.getSingleValue("select IFNULL(Count(AnimalID),0) from Diagnosis_Treatment_Details   where CreatedBy='"+HomeData.userID+"'");
			//		String Cumulative_AITv=db.getSingleValue("select IFNULL(Count(AnimalKindID),0) from Artificial_Insemination_Details  where CreatedBy='"+HomeData.userID+"'");
			//		String Cumulative_DewormingTv=db.getSingleValue("select IFNULL(Count(AnimalKindID),0) from Dewormings  where CreatedBy='"+HomeData.userID+"'");
			//		String Cumulative_VaccTv=db.getSingleValue("select IFNULL(Count(AnimalKindID),0) from Vaccination_Details  where CreatedBy='"+HomeData.userID+"'");
			//		String Cumulative_FarmerBenifitedTv=db.getSingleValue("select IFNULL(Count(Farmer_Aadhaar),0) from Farmer_FullDetails  where CreatedBy='"+HomeData.userID+"'");
			//		String Cumulative_KmTv=db.getSingleValue("select IFNULL(sum(Travel_Travelled_Km),0) from Attendance_Travel_Details  where CreatedBy='"+HomeData.userID+"'");
			//		
			db.close();

			userId.setText("Welcome To  : "+UserName);

			if(UserName.equalsIgnoreCase("0"))
			{
				HomeData.isLogOut(DashBoard_Act.this);
				Intent i= new Intent(DashBoard_Act.this,Login_Page.class);
				startActivity(i);
				DashBoard_Act.this.finish();
			}

			((TextView)findViewById(R.id.Villages_CoveredTv)).setText(": "+Villages_Covered);
			((TextView)findViewById(R.id.Animals_TreatedTv)).setText(": "+Animals_TreatedTv);
			((TextView)findViewById(R.id.AI_DoneTv)).setText(": "+AI_DoneTv);
			((TextView)findViewById(R.id.Deworming_DoneTv)).setText(": "+Deworming_DoneTv);
			((TextView)findViewById(R.id.Vaccination_DoneTv)).setText(": "+Vaccination_DoneTv);
			((TextView)findViewById(R.id.Farmers_benefitedTv)).setText(": "+Farmers_benefitedTv);
			((TextView)findViewById(R.id.Kilometres_travelledTv)).setText(": "+Kilometres_travelledTv);

		} catch (Exception e) 
		{
			e.printStackTrace();
		}

	}


	private void slideMenu(Boolean visible) 
	{
		if(visible)
		{

			slideMenuLL.setVisibility(View.VISIBLE);
			Animation slide1 = AnimationUtils.loadAnimation(this, R.anim.slid_left_middle);
			slideMenuLL.setAnimation(slide1);
		}
		else
		{
			slideMenuLL.setVisibility(View.GONE);
			Animation slide2 = AnimationUtils.loadAnimation(this, R.anim.slid_middle_left);
			slideMenuLL.setAnimation(slide2);
		}
	}

	public void LogoutAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				if(type.equalsIgnoreCase("logout"))
				{

					HomeData.isLogOut(DashBoard_Act.this);
					Intent i=new Intent(DashBoard_Act.this,Login_Page.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					// setResult(LOGOUT);
					finish();
				}
				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	@Override
	public void Success(String response) 
	{
		//		if(response.equalsIgnoreCase("Download_VillageData"))
		//		{
		//			if(MedicineStatus.equalsIgnoreCase("1"))
		//			{
		//				RequestServer request1=new RequestServer(DashBoard_Act.this);
		//				request1.addParam("DeviceID", HomeData.sDeviceId);
		//				request1.ProccessRequest(DashBoard_Act.this, "Download_MedicineMaster");
		//			}
		//
		//		}

	}
	@Override
	public void Fail(String response) 
	{
		//		if(response.equalsIgnoreCase("Download_VillageData"))
		//		{
		//			if(MedicineStatus.equalsIgnoreCase("1"))
		//			{
		//				RequestServer request1=new RequestServer(DashBoard_Act.this);
		//				request1.addParam("DeviceID", HomeData.sDeviceId);
		//				request1.ProccessRequest(DashBoard_Act.this, "Download_MedicineMaster");
		//			}
		//
		//		}

	}
	@Override
	public void NetworkNotAvail() {
		// TODO Auto-generated method stub

	}
	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub

	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId())
		{

		case R.id.SideMenuTv:
			slideMenu(true);
			break;
		case R.id.slideMenuclose_Iv:
			slideMenu(false);
			break;

		case R.id.HomeBt:
			slideMenuLL.setVisibility(8);
			startActivity(new Intent(this, HomePage.class));
			break;
		case R.id.ContactUsBt:
			startActivity(new Intent(this, Help.class));
			break;
		case R.id.LogoutBt:
			LogoutAlert("Do you want to Logout","logout");
			break;
		case R.id.userIV:
			startActivity(new Intent(this, UserProfile.class));
			break;


		default:
			break;
		}

	}

	boolean doubleBackToExitPressedOnce = false;
	@Override
	public void onBackPressed() 
	{

		try 
		{

			if(slideMenuLL.getVisibility()==View.VISIBLE)
			{
				slideMenuLL.setVisibility(8);
				Animation slide21 = AnimationUtils.loadAnimation(this, R.anim.slid_middle_left);
				slideMenuLL.setAnimation(slide21);
				return;
			}


			if (doubleBackToExitPressedOnce)
			{
				super.onBackPressed();

				return;
			}
			this.doubleBackToExitPressedOnce = true;

			Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();

			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					doubleBackToExitPressedOnce=false;
				}
			}, 2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	protected void onRestart() 
	{
		super.onRestart();
		DashBoard();
	}
	//	@Override
	//	protected void onResume() {
	//		// TODO Auto-generated method stub
	//		super.onResume();
	//		System.out.println("----resume-");
	//		DashBoard();
	//	}


}
