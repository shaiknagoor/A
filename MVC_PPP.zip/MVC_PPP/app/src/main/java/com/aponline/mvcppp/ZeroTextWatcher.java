package com.aponline.mvcppp;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class ZeroTextWatcher implements TextWatcher 
{


	private EditText mEditText;
	public ZeroTextWatcher(EditText e) 
	{ 
		mEditText = e;
	}
	public void beforeTextChanged(CharSequence s, int start, int count, int after) 
	{	    	

	}   
	public void onTextChanged(CharSequence s, int start, int before, int count) 
	{

		if (s.length()>0 && s.subSequence(0, 1).toString().equalsIgnoreCase(" ")) 
		{
			mEditText.setText("");               
		}
		String tmp = mEditText.getText().toString().trim();
		if(tmp.length()==1 && tmp.equals("0"))
			mEditText.setText("");
	}

	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub

	}

}
