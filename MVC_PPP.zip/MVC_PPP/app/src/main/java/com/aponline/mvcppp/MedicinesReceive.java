package com.aponline.mvcppp;

import java.sql.RowId;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.RequestServer;
import com.aponline.mvcppp.server.ServerResponseListener;
import com.aponline.mvcppp.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;


public class MedicinesReceive extends AppCompatActivity implements OnClickListener,OnItemSelectedListener,ServerResponseListener 
{
	String blockCharacterSet = ",<>";
	ActionBar ab;
	Spinner MedicineSp;
	TextView AddBatchTv;
	StringBuilder XmlDoc;
	String DewormingDate,ManufacturingDate="",ExpiryDate="",Date="",MedicineName="",MedicineManufacturerName="",Drug_ReceivedDate="",MedicinID,MedicineManufacturerId;
	private int year,month,day;
	EditText  DrugNameEt,DrugManufacturerEt,BatchNoEt,ManufacturingDateEt,ExpiryDateEt,QuantityReceivedEt,Drug_ReceivedDateEt;
	TableLayout tl ;
	DBAdapter db;
	long Rowid;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.medicines_receive);

		db=new DBAdapter(this);

		ab=getSupportActionBar();
		ab.setTitle("Medicines Received Details");
		ab.setHomeButtonEnabled(true);ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(true);



		tl = (TableLayout)findViewById(R.id.BatchTable_data);
		MedicineSp=(Spinner) findViewById(R.id.MedicineNameSp);
		AddBatchTv=(TextView) findViewById(R.id.AddBatchTv);

		//		DrugNameEt=(EditText) findViewById(R.id.DrugNameEt);
		//		DrugManufacturerEt=(EditText) findViewById(R.id.DrugManufacturerEt);
		//BatchNoEt=(EditText) findViewById(R.id.BatchNoEt);
		//ManufacturingDateEt=(EditText) findViewById(R.id.ManufacturingaDateEt);
		//ExpiryDateEt=(EditText) findViewById(R.id.ExpiryDateaEt);
		//QuantityReceivedEt=(EditText) findViewById(R.id.QuantityReceivedEt);
		//Drug_ReceivedDateEt=(EditText) findViewById(R.id.Drug_ReceivedDateEt);
		findViewById(R.id.DewormerFianlSubmit).setOnClickListener(this);


		//Drug_ReceivedDateEt.setOnClickListener(this);
		//ManufacturingDateEt.setOnClickListener(this);
		//ExpiryDateEt.setOnClickListener(this);
		MedicineSp.setOnItemSelectedListener(this);


		//Drug_ReceivedDateEt.addTextChangedListener(new CustomTextWatcher(Drug_ReceivedDateEt));
		//BatchNoEt.addTextChangedListener(new CustomTextWatcher(BatchNoEt));
		//ManufacturingDateEt.addTextChangedListener(new CustomTextWatcher(ManufacturingDateEt));
		//ExpiryDateEt.addTextChangedListener(new CustomTextWatcher(ExpiryDateEt));
		//QuantityReceivedEt.addTextChangedListener(new CustomTextWatcher(QuantityReceivedEt));

		//QuantityReceivedEt.addTextChangedListener(new ZeroTextWatcher(QuantityReceivedEt));
		//BatchNoEt.addTextChangedListener(new ZeroTextWatcher(BatchNoEt));


		//BatchNoEt.setFilters(new InputFilter[] { filter });

		try 
		{
			db.open();
			String MedicineStatus=db.getSingleValue("select distinct IFNULL(ISActive,'false') from Master_Medicine");
			db.close();

			if(MedicineStatus.equalsIgnoreCase("1"))
			{
				RequestServer request1=new RequestServer(MedicinesReceive.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(MedicinesReceive.this, "Download_MedicineMaster");
			}

		} catch (Exception e) 
		{
			e.printStackTrace();
		}




		loadSpinnerData("select distinct Trade_Name from Master_Medicine order by Trade_Name", MedicineSp);

		addNewBatch();
		AddBatchTv.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0)
			{

				if(MedicineSp.getSelectedItemPosition()==0)
				{
					MedicineSp.requestFocusFromTouch();
					//AlertDialogs("Information!!", "Please Select Medicine Name", "Add");
					return;
				}else 
				{
					Batch_Validation();
				}


			}


		});
	}

	private InputFilter filter = new InputFilter() {

		@Override
		public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

			if (source != null && blockCharacterSet.contains(("" + source))) {
				return "";
			}

			return null;
		}


	};
	protected void addNewBatch() 
	{


		try {


			final View tr = getLayoutInflater().inflate(R.layout.add_batchreceive_row, null);
			TextView remove=(TextView)tr.findViewById(R.id.RemoveBatchTv);
			EditText BatchNoEt=(EditText)tr.findViewById(R.id.BatchNoEt);
			EditText ManufacturingDateEt=(EditText)tr.findViewById(R.id.ManufacturingaDateEt);
			EditText ExpiryDateEt=(EditText)tr.findViewById(R.id.ExpiryDateaEt);
			EditText QuantityReceivedEt=(EditText)tr.findViewById(R.id.QuantityReceivedEt);
			EditText Drug_ReceivedDateEt=(EditText)tr.findViewById(R.id.Drug_ReceivedDateEt);

			BatchNoEt.addTextChangedListener(new CustomTextWatcher(Drug_ReceivedDateEt));
			ManufacturingDateEt.addTextChangedListener(new CustomTextWatcher(BatchNoEt));
			ExpiryDateEt.addTextChangedListener(new CustomTextWatcher(ManufacturingDateEt));
			QuantityReceivedEt.addTextChangedListener(new CustomTextWatcher(ExpiryDateEt));
			Drug_ReceivedDateEt.addTextChangedListener(new CustomTextWatcher(QuantityReceivedEt));
			
			if(tl.getChildCount()==0)
			{
				remove.setVisibility(View.GONE);
				
			}

			Drug_ReceivedDateEt.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{
					DateFunction("DrugReceivedEt",(EditText) v);
				}
			});
			ManufacturingDateEt.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{
					DateFunction("ManufacturingDateEt",(EditText) v);
				}
			});
			ExpiryDateEt.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{
					DateFunction("ExpiryDateEt",(EditText) v);
				}
			});

			remove.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					View row = (View) v.getParent();
					ViewGroup container = ((ViewGroup)row.getParent());
					View view = ((ViewGroup) row).getChildAt(0);
					container.removeView(row);
					container.invalidate();
				}
			});
			tl.addView(tr);

		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void Batch_Validation()
	{
		try 
		{
			if(tl.getChildCount()!=0)
			{
				View child = tl.getChildAt(tl.getChildCount()-1);


				float f1=0;

				EditText BatchNoEt=(EditText)child.findViewById(R.id.BatchNoEt);
				EditText ManufacturingDateEt=(EditText)child.findViewById(R.id.ManufacturingaDateEt);
				EditText ExpiryDateEt=(EditText)child.findViewById(R.id.ExpiryDateaEt);
				EditText QuantityReceivedEt=(EditText)child.findViewById(R.id.QuantityReceivedEt);
				EditText Drug_ReceivedDateEt=(EditText)child.findViewById(R.id.Drug_ReceivedDateEt);

				String BatchNo1=BatchNoEt.getText().toString();

				String ManufacturingDate=ManufacturingDateEt.getText().toString();
				String ExpiryDate=ExpiryDateEt.getText().toString();

				String	QuantityReceived=QuantityReceivedEt.getText().toString();
				String Drug_ReceivedDate=Drug_ReceivedDateEt.getText().toString();

				if(!QuantityReceived.equalsIgnoreCase("") && !QuantityReceived.equalsIgnoreCase("."))
				{
					f1 = Float.valueOf(QuantityReceived.trim()).floatValue();
				}

				if ((((EditText)child.findViewById(R.id.BatchNoEt)).getText().toString()).equalsIgnoreCase("") )
				{
					((EditText)child.findViewById(R.id.BatchNoEt)).requestFocus();
					((EditText)child.findViewById(R.id.BatchNoEt)).setError("Enter Batch No.");

					return;
				}
				else if ((((EditText)child.findViewById(R.id.ManufacturingaDateEt)).getText().toString()).equalsIgnoreCase("") )
				{
					((EditText)child.findViewById(R.id.ManufacturingaDateEt)).requestFocus();
					((EditText)child.findViewById(R.id.ManufacturingaDateEt)).setError("Enter Manufacturing Date");

					return;
				}
				else if ((((EditText)child.findViewById(R.id.ExpiryDateaEt)).getText().toString()).equalsIgnoreCase("") )
				{
					((EditText)child.findViewById(R.id.ExpiryDateaEt)).requestFocus();
					((EditText)child.findViewById(R.id.ExpiryDateaEt)).setError("Enter Expiry Date");

					return;
				}
				else if ((((EditText)child.findViewById(R.id.QuantityReceivedEt)).getText().toString()).equalsIgnoreCase("") )
				{
					((EditText)child.findViewById(R.id.QuantityReceivedEt)).requestFocus();
					((EditText)child.findViewById(R.id.QuantityReceivedEt)).setError("Enter Quantity Received");

					return;
				}
				else if ( !(f1>0) )
				{
					((EditText)child.findViewById(R.id.QuantityReceivedEt)).requestFocus();
					((EditText)child.findViewById(R.id.QuantityReceivedEt)).setError("Enter valid Quantity ");

					return;
				}
				else  if ((((EditText)child.findViewById(R.id.Drug_ReceivedDateEt)).getText().toString()).equalsIgnoreCase("") || ((((EditText)child.findViewById(R.id.Drug_ReceivedDateEt)).getText().toString()).equalsIgnoreCase(null)))
				{
					((EditText)child.findViewById(R.id.Drug_ReceivedDateEt)).requestFocus();
					((EditText)child.findViewById(R.id.Drug_ReceivedDateEt)).setError("Enter Date");

					return;
				}else 
				{
					addNewBatch();
				}



				//				for(HashMap<String, String> hm:DoctorDataAl)
				//				{
				//					if(hm.get("Batch_Number").contains(BatchNo1))
				//					{
				//						BatchNoEt.setError("Batch No. Repeated");
				//						BatchNoEt.requestFocus();
				//						//Dialogs.AlertDialogs(this,"Information!!","Batch No. Repeated");
				//						return;
				//					}
				//
				//				}

			}} 
		catch (Exception e)
		{
			
			e.printStackTrace();
			
		}

	}
	public void init()
	{
		((Spinner) findViewById(R.id.MedicineNameSp)).setSelection(0);
		//	((Spinner) findViewById(R.id.ManufacturerDrugSP)).setSelection(0);

		//		((EditText) findViewById(R.id.DrugNameEt)).setText("");
		//		((EditText) findViewById(R.id.DrugManufacturerEt)).setText("");



		((EditText) findViewById(R.id.BatchNoEt)).setText("");
		((EditText) findViewById(R.id.ManufacturingaDateEt)).setText("");
		((EditText) findViewById(R.id.ExpiryDateaEt)).setText("");
		((EditText) findViewById(R.id.QuantityReceivedEt)).setText("");
		((EditText) findViewById(R.id.Drug_ReceivedDateEt)).setText("");

		tl.removeAllViews();

	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id)
	{
		switch (parent.getId()) 
		{


		case R.id.MedicineNameSp:

			try {

				MedicineName=parent.getSelectedItem().toString().trim();
				if(!MedicineName.equalsIgnoreCase("--Select--"))
				{			
					db.open();
					Cursor cursor=db.getTableDataCursor("select distinct Roll_Id,Firm_Name,Packing from Master_Medicine  where Trade_Name='"+MedicineName+"'");
					if(cursor.getCount()>0)
					{
						cursor.moveToFirst();
						MedicinID=cursor.getString(cursor.getColumnIndex("Roll_Id"));
						//MedicineManufacturerId=cursor.getString(cursor.getColumnIndex("Medicine_Manufacturer_ID"));
						MedicineManufacturerName=cursor.getString(cursor.getColumnIndex("Firm_Name"));
						String unitPacks=cursor.getString(cursor.getColumnIndex("Packing"));;
						((TextView)findViewById(R.id.UnitPacksTv)).setText(unitPacks);
						((TextView)findViewById(R.id.ManufacturerDrugTv)).setText(MedicineManufacturerName);
					}
					cursor.close();
					db.close();
				}
				else
				{
					((TextView)findViewById(R.id.UnitPacksTv)).setText("");
					((TextView)findViewById(R.id.ManufacturerDrugTv)).setText("");

				}

			} catch (Exception e) 
			{
				e.printStackTrace();
			}
			break;
		}
	}



	public static void resetForm(ViewGroup group) 
	{
		try {


			for (int i = 0, count = group.getChildCount(); i < count; ++i)
			{
				View view = group.getChildAt(i);
				if (view instanceof EditText)
				{
					((EditText) view).getText().clear();
				}
				if (view instanceof RadioGroup) 
				{
					((RadioButton)((RadioGroup) view).getChildAt(0)).setChecked(false);
					((RadioButton)((RadioGroup) view).getChildAt(1)).setChecked(false);
				}
				if (view instanceof Spinner) 
				{
					((Spinner) view).setSelection(0);
				}
				if (view instanceof ViewGroup && (((ViewGroup) view).getChildCount() > 0))
					resetForm((ViewGroup) view);
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}


	public void DateFunction(final String Type,final EditText edittext)
	{
		final Calendar c = Calendar.getInstance();
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH);
		day = c.get(Calendar.DAY_OF_MONTH);



		DatePickerDialog dpd=new DatePickerDialog(MedicinesReceive.this, new DatePickerDialog.OnDateSetListener() 
		{

			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) 
			{

				String dateSelected=(monthOfYear+1)+"/"+dayOfMonth+"/"+Integer.toString(year);

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				try 
				{
					Date rdate = (Date)sdf.parse(dateSelected);
					String	edate= new SimpleDateFormat("dd-MMM-yyyy").format(rdate);

					edittext.setText(edate);

				} catch (ParseException e) 
				{

					e.printStackTrace();
				}
				//

			}
		}, year, month, day);
		dpd.getDatePicker().setCalendarViewShown(false);
		dpd.show();	

		if(Type.equalsIgnoreCase("ExpiryDateEt")) 
		{
			dpd.getDatePicker().setMinDate(c.getTimeInMillis());
		}else {
			dpd.getDatePicker().setMaxDate(System.currentTimeMillis());
		}

	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			//	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(FarmerRegistration.this,android.R.layout.simple_spinner_item, lables);
			//	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}


	public void loadSpinnerDataStatic(ArrayList<String> lables, Spinner spinner) 
	{
		try
		{


			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}




	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{


		case R.id.ManufacturingaDateEt:
			DateFunction("ManufacturingDateEt",(EditText) v);

			break;
		case R.id.ExpiryDateaEt:
			DateFunction("ExpiryDateEt",(EditText) v);

			break;

		case R.id.Drug_ReceivedDateEt:
			DateFunction("DrugReceivedEt",(EditText) v);

			break;

		case R.id.DewormerFianlSubmit:
			CheckValidation();
			//resetForm((ViewGroup)findViewById(R.id.MainParent));;
			break;

		default:
			break;
		}

	}

	@SuppressLint("DefaultLocale")
	private String GenerateUniqueID()
	{
		String strSecretCode = "";
		try
		{
			UUID uuid = UUID.randomUUID();    
			String strguid = uuid.toString();
			strSecretCode = strguid.substring(strguid.lastIndexOf("-") + 1);
			strSecretCode = strSecretCode.toUpperCase().replace('O', 'W').replace('0', '4');
			strSecretCode = strSecretCode.substring(0, 11);
			strSecretCode = "MED" + strSecretCode;
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			//
		}
		return strSecretCode;
	}
	private void CheckValidation() 
	{
		String BatchNo,QuantityReceived;
		float f=0;
		//BatchNo=BatchNoEt.getText().toString();
		//ManufacturingDate=ManufacturingDateEt.getText().toString();
		//ExpiryDate=ExpiryDateEt.getText().toString();
		//QuantityReceived=QuantityReceivedEt.getText().toString();

		//Drug_ReceivedDate=Drug_ReceivedDateEt.getText().toString();


//		if(!QuantityReceived.equalsIgnoreCase("") && !QuantityReceived.equalsIgnoreCase("."))
//		{
//			f = Float.valueOf(QuantityReceived.trim()).floatValue();
//		}

		if (MedicineName.equalsIgnoreCase("--Select--"))
		{
			MedicineSp.requestFocusFromTouch();
			return;
		}
		//		else if (MedicineManufacturerName.equalsIgnoreCase("--Select--") )
		//		{
		//			ManufacturerSp.requestFocusFromTouch();
		//			return;
		//		}

//		else if (BatchNo.equalsIgnoreCase("") )
//		{
//			BatchNoEt.setError("Enter Batch No.");
//			BatchNoEt.requestFocus();
//			return;
//		}
//		else if (ManufacturingDate.equalsIgnoreCase("") )
//		{
//			ManufacturingDateEt.setError("Enter Manufacturing Date");
//			ManufacturingDateEt.requestFocus();
//			return;
//		}
//		else if (ExpiryDate.equalsIgnoreCase("") )
//		{
//			ExpiryDateEt.setError("Enter Expiry Date");
//			ExpiryDateEt.requestFocus();
//			return;
//		}
//		else if (QuantityReceived.equalsIgnoreCase(""))
//		{
//			QuantityReceivedEt.setError("Enter Quantity Received");
//			QuantityReceivedEt.requestFocus();
//			return;
//		}
//		else if ( !(f>0) )
//		{
//			QuantityReceivedEt.setError("Enter valid Quantity ");
//			QuantityReceivedEt.requestFocus();
//			return;
//		}
//		else  if (Drug_ReceivedDate.equalsIgnoreCase("") || Drug_ReceivedDate.equalsIgnoreCase(null))
//		{
//			Drug_ReceivedDateEt.setError("Enter Date");
//			Drug_ReceivedDateEt.requestFocus();
//			return;
//		}
		else 
		{
			String uniqueID=GenerateUniqueID();

			ArrayList<HashMap<String, String>> DoctorDataAl=new ArrayList<HashMap<String,String>>();
			HashMap<String, String> docHm=new HashMap<String, String>();

			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			Date date;

//			try 
//			{
//				date = (Date)sdf.parse(ManufacturingDate);
//				ManufacturingDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
//				date = (Date)sdf.parse(ExpiryDate);
//				ExpiryDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
//				date = (Date)sdf.parse(Drug_ReceivedDate);
//				Drug_ReceivedDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
//
//
//				docHm.put("Batch_Number",BatchNo);
//				docHm.put("ManufacturingDate",ManufacturingDate);
//				docHm.put("ExpiryDate",ExpiryDate);
//				docHm.put("Quantity_Received",QuantityReceived);
//				docHm.put("Medicine_ReceivedDate",Drug_ReceivedDate);
//				docHm.put("Medicine_Balance_Count",QuantityReceived);
//				docHm.put("Temp_Bal",QuantityReceived);
//				DoctorDataAl.add(docHm);
//
//			} 
//			catch (ParseException e1) 
//			{
//				e1.printStackTrace();
//			}

			if(tl.getChildCount()!=0)
			{
				for (int i = 0; i < tl.getChildCount(); i++) 
				{


					View child = tl.getChildAt(i);

					try 
					{
						float f1=0;

						EditText BatchNoEt=(EditText)child.findViewById(R.id.BatchNoEt);
						EditText ManufacturingDateEt=(EditText)child.findViewById(R.id.ManufacturingaDateEt);
						EditText ExpiryDateEt=(EditText)child.findViewById(R.id.ExpiryDateaEt);
						EditText QuantityReceivedEt=(EditText)child.findViewById(R.id.QuantityReceivedEt);
						EditText Drug_ReceivedDateEt=(EditText)child.findViewById(R.id.Drug_ReceivedDateEt);

						String BatchNo1=BatchNoEt.getText().toString();
						System.out.println("----BatchNo1-"+BatchNo1);
						String ManufacturingDate=ManufacturingDateEt.getText().toString();
						String ExpiryDate=ExpiryDateEt.getText().toString();
						QuantityReceived=QuantityReceivedEt.getText().toString();
						String Drug_ReceivedDate=Drug_ReceivedDateEt.getText().toString();

						if(!QuantityReceived.equalsIgnoreCase("") && !QuantityReceived.equalsIgnoreCase("."))
						{
							f1 = Float.valueOf(QuantityReceived.trim()).floatValue();
						}

						try 
						{

							if (BatchNo1.equalsIgnoreCase("") )
							{
								BatchNoEt.setError("Enter Batch No.");
								BatchNoEt.requestFocus();
								return;
							}
							else if (ManufacturingDate.equalsIgnoreCase("") )
							{
								ManufacturingDateEt.setError("Enter Manufacturing Date");
								ManufacturingDateEt.requestFocus();
								return;
							}
							else if (ExpiryDate.equalsIgnoreCase("") )
							{
								ExpiryDateEt.setError("Enter Expiry Date");
								ExpiryDateEt.requestFocus();
								return;
							}
							else if (QuantityReceived.equalsIgnoreCase("") )
							{
								QuantityReceivedEt.setError("Enter Quantity Received");
								QuantityReceivedEt.requestFocus();
								return;
							}
							else if ( !(f1>0) )
							{
								QuantityReceivedEt.setError("Enter valid Quantity ");
								QuantityReceivedEt.requestFocus();
								return;
							}
							else  if (Drug_ReceivedDate.equalsIgnoreCase("") || Drug_ReceivedDate.equalsIgnoreCase(null))
							{
								Drug_ReceivedDateEt.setError("Enter Date");
								Drug_ReceivedDateEt.requestFocus();
								return;
							}

							date = (Date)sdf.parse(ManufacturingDate);
							ManufacturingDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
							date = (Date)sdf.parse(ExpiryDate);
							ExpiryDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
							date = (Date)sdf.parse(Drug_ReceivedDate);
							Drug_ReceivedDate= new SimpleDateFormat("MM/dd/yyyy").format(date);

							for(HashMap<String, String> hm:DoctorDataAl)
							{
								if(hm.get("Batch_Number").contains(BatchNo1))
								{
									BatchNoEt.setError("Batch No. Repeated");
									BatchNoEt.requestFocus();
									//Dialogs.AlertDialogs(this,"Information!!","Batch No. Repeated");
									return;
								}

							}


							docHm=new HashMap<String, String>();
							docHm.put("Batch_Number",BatchNo1);
							docHm.put("ManufacturingDate",ManufacturingDate);
							docHm.put("ExpiryDate",ExpiryDate);
							docHm.put("Quantity_Received",QuantityReceived);
							docHm.put("Medicine_ReceivedDate",Drug_ReceivedDate);
							docHm.put("Medicine_Balance_Count",QuantityReceived);
							docHm.put("Temp_Bal",QuantityReceived);
							DoctorDataAl.add(docHm);

						} 
						catch (ParseException e1) 
						{
							e1.printStackTrace();
						}
					} 
					catch (Exception e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
						break;
					}


				}
			}


			try 
			{

				XmlDoc=new StringBuilder();

				XmlDoc.append("<MVCS_DeowormingInfo>");

				XmlDoc.append("<MedicineID>"+MedicinID+"</MedicineID>");
				//XmlDoc.append("<ManfacturerID>"+MedicinID+"</ManfacturerID>");
				XmlDoc.append("<BatchNoDetails>");
				for(HashMap<String, String> hm:DoctorDataAl)
				{
					XmlDoc.append("<BatchNoData>");
					XmlDoc.append("<BatchNo>"+hm.get("Batch_Number")+"</BatchNo>");
					XmlDoc.append("<ManfacturingDate>"+hm.get("ManufacturingDate")+"</ManfacturingDate>");
					XmlDoc.append("<ExpiringDate>"+hm.get("ExpiryDate")+"</ExpiringDate>");
					XmlDoc.append("<QuantityRecieved>"+hm.get("Quantity_Received")+"</QuantityRecieved>");
					XmlDoc.append("<RecievedDate>"+hm.get("Medicine_ReceivedDate")+"</RecievedDate>");
					XmlDoc.append("</BatchNoData>");
				}
				XmlDoc.append("</BatchNoDetails>");
				XmlDoc.append("</MVCS_DeowormingInfo>");


				for(HashMap<String, String> hm:DoctorDataAl)
				{
					ContentValues MedicinCv=new ContentValues();
					MedicinCv.put("CreatedBy", HomeData.userID);
					MedicinCv.put("MedicineName",MedicineName);
					MedicinCv.put("Medicine_ID",MedicinID);
					MedicinCv.put("ManufactureName",MedicineManufacturerName);
					//MedicinCv.put("ManufactureID",MedicineManufacturerId);
					MedicinCv.put("Batch_Number",hm.get("Batch_Number"));
					MedicinCv.put("ManufacturingDate",hm.get("ManufacturingDate"));
					MedicinCv.put("ExpiryDate",hm.get("ExpiryDate"));
					MedicinCv.put("Quantity_Received",hm.get("Quantity_Received"));
					MedicinCv.put("Medicine_ReceivedDate",hm.get("Medicine_ReceivedDate"));
					MedicinCv.put("Medicine_Balance_Count",hm.get("Medicine_Balance_Count"));
					MedicinCv.put("Temp_Bal",hm.get("Temp_Bal"));

					MedicinCv.put("UniqueID",uniqueID);

					db.open();
					Rowid=db.insertTableDate("Medicine_Received_Details",MedicinCv);
					db.close();

				}
				ContentValues data=new ContentValues();
				data.put("METHOD_NAME", "MVCS_Medicine_Details_Insert");
				data.put("XMLDATA", XmlDoc.toString());
				data.put("CreatedBy", HomeData.userID);
				data.put("UniqueID",uniqueID);

				db.open();
				db.insertTableDate("UPLOAD_OFFLINEDATA",data);
				db.close();

				AlertDialogs("Information!!", "Successfully Submitted","submit");

			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
			}
		}

	}




	public void YesNoAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();

				if (type.equalsIgnoreCase("DownloadMedicineMaster")) 
				{
					RequestServer request1=new RequestServer(MedicinesReceive.this);
					request1.addParam("DeviceID", HomeData.sDeviceId);
					request1.ProccessRequest(MedicinesReceive.this, "Download_MedicineMaster");		
				}

			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}


	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				if(Type.equalsIgnoreCase("Add"))
				{
					MedicineSp.requestFocusFromTouch();
				}
				
				if(Type.equalsIgnoreCase("DownloadMedicine") || Type.equalsIgnoreCase("submit"))
				{
					startActivity(new Intent(MedicinesReceive.this, MedicinesReceive.class));
					finish();
				}
				//				try 
				//				{
				//					Thread.sleep(1000);
				//					finish();
				//					startActivity(getIntent());
				//				} 
				//				catch (InterruptedException e) 
				//				{
				//					e.printStackTrace();
				//				}
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		getMenuInflater().inflate(R.menu.main, menu);
		MenuItem item=menu.findItem(R.id.logout);
		item.setVisible(false);
		MenuItem item1=menu.findItem(R.id.village_download);
		item1.setVisible(true);
		return super.onCreateOptionsMenu(menu);
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int i=item.getItemId();

		if(i==R.id.village_download)
		{

			YesNoAlert("you want to Download Medicine Details","DownloadMedicineMaster");

		}

		return super.onOptionsItemSelected(item);
	}

	//	@Override
	//	public boolean onOptionsItemSelected(MenuItem item) 
	//	{
	//		switch (item.getItemId())
	//		{
	//		case android.R.id.home:
	//			super.onBackPressed();
	//			return true; 
	//		default:
	//
	//			return super.onOptionsItemSelected(item);
	//		}  
	//	}



	public void Success(String response) 
	{
		//		Dialogs.AlertDialogs(MedicinesReceive.this,"Information!!", ""+WebserviceCall.serverUploadcount+" Record's Successfully Uploaded");
		//		startActivity(new Intent(MedicinesReceive.this, MedicinesReceive.class));
		//		this.finish();

		if(WebserviceCall.serverUploadcount>0)
		{
			AlertDialogs("Information!!",""+WebserviceCall.serverUploadcount+" Record's Successfully Updated","DownloadMedicine");
		}else 
		{
			AlertDialogs("Information!!", "No New Medicines To Download","DownloadMedicine");
		}
	}
	@Override 
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(MedicinesReceive.this,"Information!!", response);
	}
	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(MedicinesReceive.this,"Information!!", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(MedicinesReceive.this,AppUpdatePage.class));
		finish();
		return;
	}


	@Override
	public void onBackPressed() 
	{

		super.onBackPressed();
		//		Intent i=	new Intent(Dewormer_Details.this,HomePage.class);
		//		startActivity(i);
		//		Dewormer_Details.this.finish();

	}
}
