package com.aponline.mvcppp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;
public class Farmer_Details extends AppCompatActivity implements OnClickListener,OnItemSelectedListener
{

	DBAdapter db;
	RadioGroup GenderRg;
	Spinner Social_StatusSP,CategorySp;
	EditText Farmer_NameEt,Farmer_HabitationEt,F_MobileNoEt,F_Aadhaar_NoEt;
	TextView F_villageTv;
	ArrayList<String> CategoryAL;
	ContentValues visitedAreaDetailsCV;
	String SocialStatusID,CategoryName,Gender,F_VillageID,Aadhar,Date_Time;
	long Rowid=1;
	ActionBar ab;
	StringBuilder XmlDoc;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		db=new DBAdapter(this);
		setContentView(R.layout.farmer_details);


		ab=getSupportActionBar();
		ab.setTitle("Farmer Details");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(true); 


		Farmer_NameEt=(EditText) findViewById(R.id.Farmer_NameEt);
		Farmer_HabitationEt=(EditText) findViewById(R.id.Farmer_HabitationEt);
		F_MobileNoEt=(EditText) findViewById(R.id.F_MobileNoEt);
		F_Aadhaar_NoEt=(EditText) findViewById(R.id.F_Aadhaar_NoEt);

		GenderRg=(RadioGroup) findViewById(R.id.GenderRg);
		Social_StatusSP=(Spinner) findViewById(R.id.Social_StatusSP);
		CategorySp=(Spinner) findViewById(R.id.CategorySp);
		F_villageTv=(TextView) findViewById(R.id.F_villageTv);

		Social_StatusSP.setOnItemSelectedListener(this);
		CategorySp.setOnItemSelectedListener(this);


		((Button)findViewById(R.id.proceedBt)).setOnClickListener(this);
		findViewById(R.id.MaleRB).setOnClickListener(this);
		findViewById(R.id.FemaleRB).setOnClickListener(this);
		Farmer_NameEt.addTextChangedListener(new CustomTextWatcher(Farmer_NameEt));
		Farmer_HabitationEt.addTextChangedListener(new CustomTextWatcher(Farmer_HabitationEt));

		Farmer_NameEt.addTextChangedListener(new ZeroTextWatcher(Farmer_NameEt));
		Farmer_HabitationEt.addTextChangedListener(new ZeroTextWatcher(Farmer_HabitationEt));


		CategoryAL=new ArrayList<String>();
		CategoryAL.add("--Select--");
		CategoryAL.add("AL");
		CategoryAL.add("MF");
		CategoryAL.add("SF");

		Calendar calendar = Calendar.getInstance();
		//date format is:  "Date-Month-Year Hour:Minutes am/pm"
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); //Date and time
		Date_Time = sdf.format(calendar.getTime());

		try {

			db.open();

			int medicinCount=db.getRowCount("select Count(Medicine_Id) from Medicine_Received_Details where CreatedBy='"+HomeData.userID+"'");
			String Attendance_Status=db.getSingleValue("select Count(RowID) from Attendance_Travel_Details where CreatedBy='"+HomeData.userID+"' and Attendance_Visit_Date='"+Date_Time+"'");
			//String Travel_Status=db.getSingleValue("select distinct Travel_Status from Attendance_Travel_Details where  Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
			String Travel_Status=db.getSingleValue("select ifnull(Status,0) from HeadQuarter_Travel_Details where UserID='"+HomeData.userID+"' and Date_Time='"+Date_Time+"'  and Status='P'");

			F_VillageID=db.getSingleValue("select distinct Attendance_VillageID from Attendance_Travel_Details where   CreatedBy='"+HomeData.userID+"'  and Attendance_Visit_Date='"+Date_Time+"' order by RowID DESC LIMIT 1");
			F_villageTv.setText(db.getSingleValue("select distinct Attendance_VillageName from Attendance_Travel_Details where   CreatedBy='"+HomeData.userID+"'  and Attendance_Visit_Date='"+Date_Time+"' order by RowID DESC LIMIT 1"));

			db.close();



			if(Travel_Status.equalsIgnoreCase("0"))
			{
				AlertDialogs("Information!!", "Enter Travel Details ","Travel_Status");
				return;
			}  
			if(Attendance_Status.equalsIgnoreCase("0") )
			{

				AlertDialogs("Information!!", "Enter Attendance Details ","Attendance_Status");
				return;
			}
			if(medicinCount==0)
			{
				AlertDialogs("Information!!", "Plz Enter Medicines Received Details","Drug_Status");
				//Dialogs.AlertDialogs(this,"Information!!","You have not Registered Medicines. Enter  Medicines in Medicines Received Details");
				return;
			}

		} catch (Exception e) 
		{
			e.printStackTrace();
		}


		loadSpinnerData("select distinct  SocialStatusName from Master_SocialStatus", Social_StatusSP,"");
		loadSpinnerDataStatic(CategoryAL, CategorySp,"");



		F_Aadhaar_NoEt.addTextChangedListener(new TextWatcher() 
		{
			private static final char space = '-';

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {}

			@Override
			public void afterTextChanged(Editable s) 
			{
				try
				{
					// Remove spacing char
					if (s.length() > 0 && (s.length() % 5) == 0)
					{
						final char c = s.charAt(s.length() - 1);
						if (space == c)
						{
							s.delete(s.length() - 1, s.length());
						}
					}
					// Insert char where needed.
					if (s.length() > 0 && (s.length() % 5) == 0) 
					{
						char c = s.charAt(s.length() - 1);
						// Only if its a digit where there should be a space we insert a space
						if (Character.isDigit(c) && TextUtils.split(s.toString(), String.valueOf(space)).length <= 3) {
							s.insert(s.length() - 1, String.valueOf(space));
						}
					}

					String aadhar=F_Aadhaar_NoEt.getText().toString();

					if(aadhar.length()==14)
					{
						aadhar=aadhar.replace("-", "");
						//Exist_Farmer_Details(aadhar);
						if(validateAadharNumber(aadhar)==true)
						{
							Exist_Farmer_Details(aadhar);
						}else 
						{
							F_Aadhaar_NoEt.setError("Enter Valid Aadhaar No.");
							F_Aadhaar_NoEt.requestFocus();
							return;	
						}

					}else 
					{
						Farmer_NameEt.setText("");
						Farmer_HabitationEt.setText("");
						F_MobileNoEt.setText("");

						((RadioButton)findViewById(R.id.MaleRB)).setChecked(false);

						((RadioButton)findViewById(R.id.FemaleRB)).setChecked(false);

						Social_StatusSP.setSelection(0);
						CategorySp.setSelection(0);

						//					loadSpinnerData("select distinct  SocialStatusName from Master_SocialStatus", Social_StatusSP,"");
						//					loadSpinnerDataStatic(CategoryAL, CategorySp,"");
						//					
					}
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}




		});

	}
	public void Exist_Farmer_Details(String aadhar) 
	{
		try {


			db.open();
			Cursor cursor=db.getTableDataCursor("select Farmer_Name,Farmer_Habitation,Farmer_SocialStatus,Farmer_Gender,Farmer_Category,Farmer_Mobile from Farmer_FullDetails where Farmer_Aadhaar='"+aadhar+"' order by RowID DESC LIMIT 1");
			if (cursor.getCount() > 0) 
			{
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) 
				{
					Farmer_NameEt.setText(cursor.getString(cursor.getColumnIndex("Farmer_Name")));
					Farmer_HabitationEt.setText(cursor.getString(cursor.getColumnIndex("Farmer_Habitation")));
					F_MobileNoEt.setText(cursor.getString(cursor.getColumnIndex("Farmer_Mobile")));

					String gnder=cursor.getString(cursor.getColumnIndex("Farmer_Gender"));

					if(gnder.equalsIgnoreCase("1"))
					{
						((RadioButton)findViewById(R.id.MaleRB)).setChecked(true);
						Gender="1";
					}
					else if(gnder.equalsIgnoreCase("2"))
					{
						((RadioButton)findViewById(R.id.FemaleRB)).setChecked(true);
						Gender="2";
					}

					String SS=db.getSingleValue("select  SocialStatusName from Master_SocialStatus where SocialStatusID='"+cursor.getString(cursor.getColumnIndex("Farmer_SocialStatus"))+"'");

					loadSpinnerData("select distinct  SocialStatusName from Master_SocialStatus", Social_StatusSP,SS);
					loadSpinnerDataStatic(CategoryAL, CategorySp,cursor.getString(cursor.getColumnIndex("Farmer_Category")));

				}

			}
			cursor.close();
			db.close();

		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id)
	{
		switch (parent.getId()) 
		{
		case R.id.Social_StatusSP:

			//	SocialStatusName=parent.getSelectedItem().toString().trim();

			if(!parent.getSelectedItem().toString().trim().equalsIgnoreCase("--Select--"))
			{
				db.open();
				SocialStatusID=db.getSingleValue("select SocialStatusID from Master_SocialStatus where SocialStatusName='"+parent.getSelectedItem().toString().trim()+"'");
				db.close();


			}
			break;

		case R.id.CategorySp:
			//CategoryName=parent.getSelectedItem().toString().trim();

			if(!parent.getSelectedItem().toString().trim().equalsIgnoreCase("--Select--"))
			{

				CategoryName=parent.getSelectedItem().toString().trim();

			}
			break;

		default:
			break;
		}

	}
	@Override
	public void onNothingSelected(AdapterView<?> parent)
	{
		// TODO Auto-generated method stub

	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.MaleRB:
			Gender="1";

			break;

		case R.id.FemaleRB:
			Gender="2";

			break;
		case R.id.proceedBt:
			FinalValidation();

			break;

		default:
			break;
		}

	}

	public void FinalValidation()
	{
		Aadhar=F_Aadhaar_NoEt.getText().toString();
		Aadhar=Aadhar.replace("-", "");
		String temp=F_MobileNoEt.getText().toString();

		if(!(temp.equalsIgnoreCase(""))){
			temp=temp.substring(0,1);
		}

		if (Aadhar.equalsIgnoreCase("") || Aadhar.equalsIgnoreCase(null))
		{
			F_Aadhaar_NoEt.setError("Enter Aadhaar No.");
			F_Aadhaar_NoEt.requestFocus();
			return;
		}
		else if (validateAadharNumber(Aadhar)==false)
		{
			F_Aadhaar_NoEt.setError("Enter Valid Aadhaar No.");
			F_Aadhaar_NoEt.requestFocus();
			return;
		}
		else if(Farmer_NameEt.getText().toString().equalsIgnoreCase(""))
		{
			Farmer_NameEt.requestFocus();
			Farmer_NameEt.setError("Farmer Name");
			return;
		}
		//		else if (Farmer_HabitationEt.getText().toString().equalsIgnoreCase(""))
		//		{
		//			Farmer_HabitationEt.requestFocus();
		//			Farmer_HabitationEt.setError("Farmer Habitation");
		//			return;
		//		}
		else if (Social_StatusSP.getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		{
			Social_StatusSP.requestFocusFromTouch();
			return;
		}
		else if (GenderRg.getCheckedRadioButtonId() == -1)
		{
			GenderRg.requestFocusFromTouch();

			Toast toast = null;
			toast=Toast.makeText(this, "Select Gender", Toast.LENGTH_SHORT);
			View view1 = toast.getView();
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();

			return;
		}
		else if (CategorySp.getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		{
			CategorySp.requestFocusFromTouch();
			return;

		}
		else if(!((F_MobileNoEt.getText().toString()).equalsIgnoreCase("")) && (F_MobileNoEt.getText().toString()).length()<10)
		{
			F_MobileNoEt.setError("Enter 10 digits Mobile No.");
			F_MobileNoEt.requestFocus();

			return;

		}
		else if(!((F_MobileNoEt.getText().toString()).equalsIgnoreCase("")) && !(temp.equalsIgnoreCase("7") || temp.equalsIgnoreCase("8") || temp.equalsIgnoreCase("9")))
		{
			Toast toast = null;
			toast=Toast.makeText(Farmer_Details.this, "Mobile No Should Start With 7 or 8 or 9",Toast.LENGTH_SHORT);
			View view = toast.getView();
			toast.setGravity(Gravity.CENTER, 0, 0);
			view.setBackgroundResource(R.color.red);
			toast.show();

			F_MobileNoEt.requestFocus();
			return;

		}

		else 
		{

			try {



				XmlDoc=new StringBuilder();
				XmlDoc.append("<MVCS_Details>");


				XmlDoc.append("<Farmer_Details>");
				XmlDoc.append("<Farmer_Name>"+Farmer_NameEt.getText().toString()+"</Farmer_Name>");
				XmlDoc.append("<Farmer_VillageID>"+F_VillageID+"</Farmer_VillageID>");
				XmlDoc.append("<Farmer_Habbitation>"+Farmer_HabitationEt.getText().toString()+"</Farmer_Habbitation>");
				XmlDoc.append("<Farmer_Gender>"+Gender+"</Farmer_Gender>");
				XmlDoc.append("<Farmer_Category>"+CategorySp.getSelectedItem().toString()+"</Farmer_Category>");
				XmlDoc.append("<Farmer_SocialStatus>"+SocialStatusID+"</Farmer_SocialStatus>");
				XmlDoc.append("<Farmer_Mobile>"+F_MobileNoEt.getText().toString()+"</Farmer_Mobile>");
				XmlDoc.append("<Farmer_Aadhaar>"+Aadhar+"</Farmer_Aadhaar>");
				XmlDoc.append("</Farmer_Details>");

				ContentValues	FarmerDetailsCV=new ContentValues();

				FarmerDetailsCV.put("Farmer_Name",Farmer_NameEt.getText().toString());
				FarmerDetailsCV.put("Farmer_VillageID",F_VillageID);
				FarmerDetailsCV.put("Farmer_Habitation",Farmer_HabitationEt.getText().toString());
				FarmerDetailsCV.put("Farmer_SocialStatus",SocialStatusID);
				FarmerDetailsCV.put("Farmer_Gender",Gender);
				FarmerDetailsCV.put("Farmer_Category",CategorySp.getSelectedItem().toString());
				FarmerDetailsCV.put("Farmer_Mobile",F_MobileNoEt.getText().toString());
				FarmerDetailsCV.put("Farmer_Aadhaar",Aadhar);
				FarmerDetailsCV.put("Farmer_Status","D");
				FarmerDetailsCV.put("Final_Status","p");
				FarmerDetailsCV.put("XMLDATA",XmlDoc.toString());
				FarmerDetailsCV.put("CreatedBy",HomeData.userID);

				db.open();
				db.execSQL("DELETE FROM Farmer_FullDetails  where   Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
				Rowid=db.insertTableDate("Farmer_FullDetails",FarmerDetailsCV);			
				db.close();
				AlertDialogs("Information!!", "Farmer Details Successfully Submitted ","DataSubmit");

			}	catch (Exception e) 
			{
				Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
			}
		}
	}
	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{

					if(Type.equalsIgnoreCase("Travel_Status"))
					{
						Intent intent = new Intent(Farmer_Details.this, Travelled_Kms.class);
						startActivity(intent);
						Farmer_Details.this.finish();
					}
					if(Type.equalsIgnoreCase("DataSubmit"))
					{

						Intent i=new Intent(Farmer_Details.this,Treatment_Act.class);
						i.putExtra("UniqueID",String.valueOf(Rowid));
						i.putExtra("Farmer_Name",Farmer_NameEt.getText().toString());
						i.putExtra("Farmer_Aadhaar",Aadhar);
						startActivity(i);
					}
					if(Type.equalsIgnoreCase("Attendance_Status"))
					{
						Intent intent = new Intent(Farmer_Details.this, Attendance_Act.class);
						startActivity(intent);
						Farmer_Details.this.finish();
					}
					if(Type.equalsIgnoreCase("Drug_Status"))
					{
						Intent intent = new Intent(Farmer_Details.this, MedicinesReceive.class);
						startActivity(intent);
						Farmer_Details.this.finish();
					}
					dialog.dismiss();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void loadSpinnerDataStatic(ArrayList<String> lables, Spinner spinner,String position) 
	{
		try
		{
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);

			if(!position.equalsIgnoreCase(""))
			{
				int spinnerPosition = spinnerArrayAdapter.getPosition(position);
				spinner.setSelection(spinnerPosition);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void loadSpinnerData(String query, Spinner spinner,String position) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);

			if(!position.equalsIgnoreCase(""))
			{
				int spinnerPosition = spinnerArrayAdapter.getPosition(position);
				spinner.setSelection(spinnerPosition);
			}
		}
		catch(Exception e)
		{

			e.printStackTrace();
		}
	}
	public static boolean validateAadharNumber(String aadharNumber)
	{
		Pattern aadharPattern = Pattern.compile("\\d{12}");
		boolean isValidAadhar = aadharPattern.matcher(aadharNumber).matches();
		if(isValidAadhar)
		{
			isValidAadhar = VerhoeffAlgorithm.validateVerhoeff(aadharNumber);
		}
		return isValidAadhar;
	} 

	@SuppressLint("NewApi")
	@Override
	public void onBackPressed() 
	{
		super.onBackPressed();
	}
}