package com.aponline.mvcppp;

import java.io.ByteArrayOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.kobjects.base64.Base64;

import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.RequestServer;
import com.aponline.mvcppp.server.ServerResponseListener;
import com.aponline.mvcppp.server.WebserviceCall;


import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class Attendance_Act extends AppCompatActivity implements OnClickListener,OnItemSelectedListener,ServerResponseListener,GoogleApiClient.ConnectionCallbacks,
GoogleApiClient.OnConnectionFailedListener,LocationListener
{

	DBAdapter db;
	GPSTracker gps;
	LocationManager locationManager;
	Bitmap photo,bmp;
	private static final int CAMERA_REQUEST = 1888; 
	private static int RESULT_LOAD_IMAGE = 1;
	ArrayList<String> distAl,DivAL,HeadQuarterAl,DayAl,VillageAL,TimeAL,TreatmentTypeAl;
	Spinner DistSp,DivSp,HeadQuarterSp,DaySp,VillageSP,TimeSp,TreatmentTypeSp,Social_StatusSP,AnimalTypeSp;
	HashMap<String, String> KMHM,VillageHM;
	String villageName,villageID,DistID,DivID,HQID,Attendance_Date,AnimalTypeName,TreatmentType,SocialStatus,Mobile,Gender,selection_position,DayName,SheduleTime,Remarks,Latitude="",Longitude,DayID;

	TextView visitTv,HeadQuarterTv;
	ImageView photoIV;
	EditText Aadhaar_NoEt,TimeEt,DateEt,Attendance_ClosingReadingEt;
	ContentValues AttendanceDetailsCV;
	String Photodata="",Date_Time,Day;
	private int year,month,day;
	ActionBar ab;
	Context context;
	StringBuilder XmlDoc;

	private Location mylocation;
	private GoogleApiClient googleApiClient;
	private final static int REQUEST_CHECK_SETTINGS_GPS=0x1;
	private final static int REQUEST_ID_MULTIPLE_PERMISSIONS=0x2;

	private int mYear, mMonth, mDay, mHour, mMinute;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		context=this;
		db=new DBAdapter(this);
		setContentView(R.layout.attendance);
		locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);

		ab=getSupportActionBar();
		ab.setTitle("Attendance Details");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(true); 

		setUpGClient();
		//DaySp=(Spinner) findViewById(R.id.DaySP);

		VillageSP=(Spinner) findViewById(R.id.VillageSP);
		photoIV=(ImageView) findViewById(R.id.photoIV);
		//DateEt=(EditText) findViewById(R.id.Attendance_DateEt);
		//TimeEt=(EditText) findViewById(R.id.TimeEt);
		HeadQuarterTv=(TextView) findViewById(R.id.HeadQuarterTv);
		Attendance_ClosingReadingEt=(EditText) findViewById(R.id.Attendance_ClosingReadingEt);

		VillageSP.setOnItemSelectedListener(this);
		//DaySp.setOnItemSelectedListener(this);

		//TimeEt.setOnClickListener(this);
		//DateEt.setOnClickListener(this);
		photoIV.setOnClickListener(this);

		//DateEt.addTextChangedListener(new CustomTextWatcher(DateEt));
		//TimeEt.addTextChangedListener(new CustomTextWatcher(TimeEt));

		((Button)findViewById(R.id.LocationSubmitBt)).setOnClickListener(this);


		Boolean timeStatus=	isTimeAutomatic(context);

		if(timeStatus==false)
		{
			AlertDialogs("Information!!", "Enable Auto date & time ","AutoDateTime");
		}



		Calendar calendar = Calendar.getInstance();
		//date format is:  "Date-Month-Year Hour:Minutes am/pm"
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); //Date and time
		Date_Time = sdf.format(calendar.getTime());

		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy"); //Date and time
		String Showdate = sdf1.format(calendar.getTime());


		SimpleDateFormat sdf_ = new SimpleDateFormat("EEEE"); 
		Date date = new Date();
		Day = sdf_.format(date);



		((TextView)findViewById(R.id.DateTimeTv)).setText(Day+" "+Showdate);

		try 
		{			
			db.open();
			String VillageStatus=db.getSingleValue("select  distinct IFNULL(IsActive,'false')  from Master_MVC_New");
			String HQ_Travel_Status=db.getSingleValue("select IFNULL(Status,0) from HeadQuarter_Travel_Details where UserID='"+HomeData.userID+"' and Date_Time='"+Date_Time+"'  and Status='P'");
			db.close();


			if(VillageStatus.equalsIgnoreCase("false"))
			{
				RequestServer request1=new RequestServer(Attendance_Act.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(Attendance_Act.this, "Download_VillageData");
			}
			if(HQ_Travel_Status.equalsIgnoreCase("0"))
			{
				AlertDialogs("Information!!", "Enter Travel Details ","Travel_Status");
			}




		} catch (Exception e) 
		{
			e.printStackTrace();
		}


		setUpGClient();

		/*if(!locationManager.isProviderEnabled(locationManager.GPS_PROVIDER))
		{
			//AlertDialogs("Information!!","Your GPS seems to be disabled,Please enable it ?","Gps");
		turnGPSOn();
		}*/

		DayAl=new ArrayList<String>();
		DayAl.add("--Select--");
		DayAl.add("Monday");
		DayAl.add("Tuesday");
		DayAl.add("Wednesday");
		DayAl.add("Thursday");
		DayAl.add("Friday");
		DayAl.add("Saturday");

		//loadSpinnerDataStatic(DayAl, DaySp);
		//loadSpinnerData("select distinct WeekDay from Master_WeekDay", DaySp);




		try {


			db.open();
			Cursor cursor=db.getTableDataCursor("SELECT DistrictID,DivisionID from Login_UserDetails where UserID='"+HomeData.userID+"'");
			if (cursor.getCount() > 0) 
			{
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) 
				{
					DistID=cursor.getString(0);
					DivID=cursor.getString(1);
					//MandalID=cursor.getString(2);
				}
				//MandalTv.setText(db.getSingleValue("select distinct MandalName from Master_Mandal where DistrictID='"+DistID+"' and DivisionID='"+DivID+"' and MandalID='"+MandalID+"'"));
			}
			cursor.close();
			db.close();

			db.open();
			((TextView)findViewById(R.id.DistrictTV)).setText(db.getSingleValue("select distinct District_Name from Master_MVC_New where DistrictID='"+DistID+"'"));

			((TextView)findViewById(R.id.DivisionTv)).setText(db.getSingleValue("select distinct Division_Name from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"'"));

			HeadQuarterTv.setText(db.getSingleValue("select distinct MVCHeadQuarter_Name from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"'"));

			HQID=db.getSingleValue("select distinct MVCHeadQuarterID from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"' and MVCHeadQuarter_Name='"+HeadQuarterTv.getText().toString()+"'");
			db.close();

		} catch (Exception e) 
		{
			e.printStackTrace();
		}

		loadSpinnerData("select distinct Village_Name from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"'  order by Village_Name", VillageSP);

	}
	private synchronized void setUpGClient()
	{
		if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)||(Latitude==null||Latitude.isEmpty()))
		{
			googleApiClient = new GoogleApiClient.Builder(this)//.enableAutoManage(this, 0, this)
			.addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API)
			.build();
			googleApiClient.connect();
		}

	}

	public static boolean isLocationEnabled(Context context)
	{
		int locationMode = 0;
		String locationProviders;

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) 
		{
			try 
			{
				locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);

			} catch (Exception e) 
			{
				e.printStackTrace();
			}

			return locationMode != Settings.Secure.LOCATION_MODE_OFF;

		}else 
		{
			locationProviders = Settings.Secure.getString(context.getContentResolver(),Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
			return !TextUtils.isEmpty(locationProviders);
		}

	}

	@SuppressLint("NewApi")
	public static boolean isTimeAutomatic(Context c) 
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) 
		{
			return Settings.Global.getInt(c.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
		} else 
		{
			return android.provider.Settings.System.getInt(c.getContentResolver(), android.provider.Settings.System.AUTO_TIME, 0) == 1;
		}
	}
	private void timegg() 
	{
		final Calendar c = Calendar.getInstance();
		mHour = c.get(Calendar.HOUR_OF_DAY);
		mMinute = c.get(Calendar.MINUTE);

		try {

			// Launch Time Picker Dialog
			TimePickerDialog timePickerDialog = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {

				@Override
				public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
					boolean isPM = (hourOfDay >= 12);
					TimeEt.setText(String.format("%02d:%02d %s", (hourOfDay == 12 || hourOfDay == 0) ? 12 : hourOfDay % 12, minute, isPM ? "PM" : "AM"));

				}
			}, mHour, mMinute, false);
			timePickerDialog.show();

		} catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	private boolean turnGPSOn()
	{
		PackageManager pacman = getPackageManager();
		PackageInfo pacInfo = null;

		try {
			pacInfo = pacman.getPackageInfo("com.android.settings", PackageManager.GET_RECEIVERS);
		} catch (NameNotFoundException e) {
			return false; //package not found
		}

		if(pacInfo != null){
			for(ActivityInfo actInfo : pacInfo.receivers){
				//test if recevier is exported. if so, we can toggle GPS.
				if(actInfo.name.equals("com.android.settings.widget.SettingsAppWidgetProvider") && actInfo.exported){
					return true;
				}
			}
		}

		return false; //default
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) 
	{

		switch (parent.getId()) 
		{

		//		case R.id.DaySP:
		//
		//			DayName=parent.getSelectedItem().toString().trim();
		//			if(!(parent.getSelectedItem().toString().trim()).equalsIgnoreCase("--Select--"))
		//			{
		//				db.open();
		//				DayID=db.getSingleValue("select DayID from Master_WeekDay  where WeekDay='"+parent.getSelectedItem().toString().trim()+"'");
		//				db.close();
		//				loadSpinnerData("select distinct Village_Name from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"'  order by Village_Name", VillageSP);
		//			}
		//			break;

		case R.id.VillageSP:

			//SheduleTime=parent.getSelectedItem().toString().trim();
			if(!(parent.getSelectedItem().toString().trim()).equalsIgnoreCase("--Select--"))
			{

				try {


					db.open();
					villageID=db.getSingleValue("select distinct VillageID from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"' and Village_Name='"+parent.getSelectedItem().toString().trim()+"'");
					String VillageId=db.getSingleValue("select Attendance_VillageID from Attendance_Travel_Details where CreatedBy='"+HomeData.userID+"' and Attendance_Visit_Date='"+Date_Time+"' and  Attendance_VillageID='"+villageID+"'");// and Travel_Status='P'");
					db.close();


					if(VillageId.equalsIgnoreCase(villageID))
					{

						Calendar calendar = Calendar.getInstance();
						SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy"); //Date and time
						String Showdate1 = sdf1.format(calendar.getTime());
						AlertDialogs("Information!!", parent.getSelectedItem().toString().trim()  +" \n Attendance Already Captured for Date :"+Showdate1,"VilladeDone");
					}

				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			break;


		default:
			break;
		}

	}
	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{

		case R.id.photoIV:
			takePhoto();
			break;

			//		case R.id.Attendance_DateEt:
			//
			//			DateFunction("");
			//
			//			break;
			//
			//		case R.id.TimeEt:
			//
			//			//			final Calendar c = Calendar.getInstance();
			//			//			mHour = c.get(Calendar.HOUR_OF_DAY);
			//			//			mMinute = c.get(Calendar.MINUTE);
			//
			//			// Launch Time Picker Dialog
			//
			//			try {
			//
			//
			//				TimePickerDialog timePickerDialog = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {
			//
			//					@Override
			//					public void onTimeSet(TimePicker view, int hourOfDay, int minute) 
			//					{
			//						boolean isPM = (hourOfDay >= 12);
			//						TimeEt.setText(String.format("%02d:%02d %s", (hourOfDay == 12 || hourOfDay == 0) ? 12 : hourOfDay % 12, minute, isPM ? "PM" : "AM"));
			//
			//					}
			//
			//				}, mHour, mMinute, false);
			//				timePickerDialog.show();
			//
			//			} catch (Exception e) 
			//			{
			//				e.printStackTrace();
			//			}
			//
			//
			//			break;

		case R.id.LocationSubmitBt:

			Attendance_Validation();
			break;

		default:
			break;
		}

	}


	public void loadSpinnerDataStatic(ArrayList<String> lables, Spinner spinner) 
	{
		try
		{
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}
	private void takePhoto()
	{
		/*

		gps=new GPSTracker(this);
		Latitude=String.valueOf(gps.getLatitude());
		Longitude=String.valueOf(gps.getLongitude());

		 */
		setUpGClient();

		if((Latitude.equalsIgnoreCase("0.0") && Longitude.equalsIgnoreCase("0.0"))||Latitude.isEmpty())
		{
			setUpGClient();

			Toast toast = null;
			toast=Toast.makeText(Attendance_Act.this,"Device Location not ready,plz wait for gps connection ",Toast.LENGTH_SHORT);
			View view = toast.getView();
			toast.setGravity(Gravity.CENTER, 0, 0);
			//view.setBackgroundResource(R.color.blue);
			toast.show();
			return;
		}
		else 
		{
			Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(cameraIntent,CAMERA_REQUEST);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		try 
		{

			super.onActivityResult(requestCode, resultCode, data);
			if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) 
			{  

				Photodata="";
				ByteArrayOutputStream out1 = new ByteArrayOutputStream();
				photo = (Bitmap) data.getExtras().get("data"); 
				photoIV.setImageBitmap(photo);
				photo.compress(Bitmap.CompressFormat.PNG, 100, out1);
				byte[] ba1 = out1.toByteArray();
				Photodata=Base64.encode(ba1);

			}
			if (requestCode == REQUEST_CHECK_SETTINGS_GPS && resultCode == Activity.RESULT_OK) 
			{
				getMyLocation();
			}
			if (requestCode == REQUEST_CHECK_SETTINGS_GPS && resultCode == Activity.RESULT_CANCELED) 
			{
				//finish();
			}



		} catch (Exception e) 
		{
			e.printStackTrace();
		}

	}
	private void Attendance_Validation() 
	{
		float Attendance_villageKm=0,LatestKm=0;

		if(!(Attendance_ClosingReadingEt.getText().toString()).equalsIgnoreCase("") && !(Attendance_ClosingReadingEt.getText().toString()).equalsIgnoreCase("."))
		{
			Attendance_villageKm= Float.valueOf(Attendance_ClosingReadingEt.getText().toString().trim()).floatValue();
			db.open();

			//String HqKm=db.getSingleValue("select HQ_OpeningReading from HeadQuarter_Travel_Details where UserID='"+HomeData.userID+"' and Date_Time='"+Date_Time+"' and  Status='P'");
			String HqKm=db.getSingleValue("select max(v.OpeningReading) as highestReading from (select HQ_OpeningReading as OpeningReading from HeadQuarter_Travel_Details "
					+ "where UserID='"+HomeData.userID+"'  and  Date_Time='"+Date_Time+"' and Status='P' union all select Travel_Closing_Km from Attendance_Travel_Details where CreatedBy='"+HomeData.userID+"'  "
					+ "and  Attendance_Visit_Date='"+Date_Time+"' and Travel_Status='P' )v");
			db.close();
			LatestKm= Float.valueOf(HqKm).floatValue();
		}



		//		locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);

		//		if (((EditText)findViewById(R.id.Attendance_DateEt)).getText().toString().equalsIgnoreCase("") || ((EditText)findViewById(R.id.Attendance_DateEt)).getText().toString().equalsIgnoreCase(null))
		//		{
		//			((EditText)findViewById(R.id.Attendance_DateEt)).setError("Enter Date");
		//			((EditText)findViewById(R.id.Attendance_DateEt)).requestFocus();
		//			return;
		//		}
		//		else  if(DaySp.getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		//		{
		//			DaySp.requestFocusFromTouch();
		//			return;
		//		}
		//		else 

		if (VillageSP.getSelectedItem().toString().equalsIgnoreCase("--Select--")) 
		{
			VillageSP.requestFocusFromTouch();
			return;
		}
		//		else if (TimeEt.getText().toString().equalsIgnoreCase(""))
		//		{
		//			TimeEt.setError("Enter Time");
		//			TimeEt.requestFocus();
		//			return;
		//		}
		else if (Attendance_ClosingReadingEt.getText().toString().equalsIgnoreCase(""))
		{
			Attendance_ClosingReadingEt.setError("Enter Reading at Village");
			Attendance_ClosingReadingEt.requestFocus();
			return;
		}
		else if (!(Attendance_villageKm>0))
		{
			Attendance_ClosingReadingEt.setError("Enter Valid Kms");
			Attendance_ClosingReadingEt.requestFocus();
			return;
		}
		else if (!(Attendance_villageKm > LatestKm))
		{
			Attendance_ClosingReadingEt.setError("Village Reading Kms < Previous Kms "+LatestKm);
			Attendance_ClosingReadingEt.requestFocus();
			return;
		}
		else if (Photodata.equalsIgnoreCase("")) 
		{
			Toast toast=Toast.makeText(this, "Capture Photo", Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
			return;
		}

		else if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
		{
			AlertDialogs("Information!!","Your GPS seems to be disabled,Please enable it ?","Gps");
			return;
		}
		else if(Latitude.equalsIgnoreCase("0.0") && Longitude.equalsIgnoreCase("0.0"))
		{

			setUpGClient();
			Toast toast = null;
			toast=Toast.makeText(Attendance_Act.this,"Your Device Location not ready,plz wait for gps connection ",Toast.LENGTH_SHORT);
			View view = toast.getView();
			toast.setGravity(Gravity.CENTER, 0, 0);
			//view.setBackgroundResource(R.color.blue);
			toast.show();
			return;
		}

		else 
		{


			try {



				Calendar calendar = Calendar.getInstance();
				//date format is:  "Date-Month-Year Hour:Minutes am/pm"
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); //Date and time
				String SQLDate_Time = sdf.format(calendar.getTime());

				SimpleDateFormat sdf_ = new SimpleDateFormat("EEEE"); 
				Date date = new Date();
				Day = sdf_.format(date);

				SimpleDateFormat time=new SimpleDateFormat("hh:mm a");
				String currentDateTimeString = time.format(date);

				db.open();
				DayID=db.getSingleValue("select  DayID from Master_WeekDay where   WeekDay='"+Day+"'");
				db.close();




				XmlDoc=new StringBuilder();

				XmlDoc.append("<MVCS_Details>");

				XmlDoc.append("<Attendance_Details>");
				XmlDoc.append("<Attendance_DistID>"+DistID+"</Attendance_DistID>");
				XmlDoc.append("<Attendance_DivId>"+DivID+"</Attendance_DivId>");
				XmlDoc.append("<Attendance_HQID>"+HQID+"</Attendance_HQID>");
				XmlDoc.append("<Attendance_VisitDate>"+SQLDate_Time+"</Attendance_VisitDate>");
				XmlDoc.append("<Attendance_Day>"+DayID+"</Attendance_Day>");
				XmlDoc.append("<Attendance_VillageID>"+villageID+"</Attendance_VillageID>");
				XmlDoc.append("<Attendance_Visit_Time>"+currentDateTimeString+"</Attendance_Visit_Time>");
				XmlDoc.append("<Attendance_Photo>"+Photodata+"</Attendance_Photo>");
				XmlDoc.append("<Attendance_GPS_Coordinates>"+Latitude+","+Longitude+"</Attendance_GPS_Coordinates>");
				XmlDoc.append("</Attendance_Details>");

				XmlDoc.append("<Travel_Details>");
				XmlDoc.append("<Travel_Opening_Km>"+"00"+"</Travel_Opening_Km>");
				XmlDoc.append("<Travel_Closing_Km>"+Attendance_ClosingReadingEt.getText().toString()+"</Travel_Closing_Km>");
				XmlDoc.append("<Travel_Total_Km>"+"00"+"</Travel_Total_Km>");
				XmlDoc.append("</Travel_Details>");

				XmlDoc.append("</MVCS_Details>");

				AttendanceDetailsCV=new ContentValues();

				AttendanceDetailsCV.put("Attendance_DistID",DistID);
				AttendanceDetailsCV.put("Attendance_DivID",DivID);
				AttendanceDetailsCV.put("Attendance_HQID",HQID);
				AttendanceDetailsCV.put("Attendance_Visit_Date",SQLDate_Time);
				AttendanceDetailsCV.put("Attendance_Day",DayID);
				AttendanceDetailsCV.put("Attendance_VillageName",VillageSP.getSelectedItem().toString());
				AttendanceDetailsCV.put("Attendance_VillageID",villageID);
				AttendanceDetailsCV.put("Attendance_Visit_Time",currentDateTimeString);
				AttendanceDetailsCV.put("Attendance_Photo",Photodata);
				AttendanceDetailsCV.put("Travel_Closing_Km",Attendance_ClosingReadingEt.getText().toString());
				AttendanceDetailsCV.put("Attendance_GPS_Coordinates",Latitude+","+Longitude);
				//AttendanceDetailsCV.put("Attendance_Status","D");
				//AttendanceDetailsCV.put("Farmer_Status","p");
				AttendanceDetailsCV.put("Travel_Status","P");
				//AttendanceDetailsCV.put("Final_Status","p");
				AttendanceDetailsCV.put("CreatedBy",HomeData.userID);

				db.open();
				//db.execSQL("UPDATE Attendance_Travel_Details set Attendance_Status='N',Travel_Status='N',Final_Status='N' where  CreatedBy='"+HomeData.userID+"' and Final_Status='p'");

				long RowID=db.insertTableDate("Attendance_Travel_Details",AttendanceDetailsCV);
				if(RowID!=-1)
				{
					ContentValues data=new ContentValues();
					data.put("METHOD_NAME", "MVCS_Attendance_Travel_Insert");
					data.put("XMLDATA", XmlDoc.toString());
					data.put("CreatedBy", HomeData.userID);
					data.put("UniqueID",RowID);


					RowID=db.insertTableDate("UPLOAD_OFFLINEDATA",data);
					db.close();
				}
				if(RowID!=-1)
				{

					AlertDialogs("Information!!", "Attendance Details Successfully Submitted ","DataSubmit");
				}
			}

			catch (Exception e) 
			{
				e.printStackTrace();
				Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
			}
		}

	}

	public void DateFunction(final String Type)
	{
		final Calendar c = Calendar.getInstance();
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH);
		day = c.get(Calendar.DAY_OF_MONTH);



		DatePickerDialog dpd=new DatePickerDialog(Attendance_Act.this, new DatePickerDialog.OnDateSetListener() 
		{

			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) 
			{
				try 
				{
					String dateSelected=(monthOfYear+1)+"/"+dayOfMonth+"/"+Integer.toString(year);

					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

					Date rdate = (Date)sdf.parse(dateSelected);
					String	edate= new SimpleDateFormat("dd-MMM-yyyy").format(rdate);

					//					date = (Date)sdf.parse(ManufacturingDate);
					//					ManufacturingDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
					//		((EditText)findViewById(R.id.Attendance_DateEt)).setText(edate);
					Attendance_Date=dateSelected;

				} catch (ParseException e) 
				{

					e.printStackTrace();
				}


			}
		}, year, month, day);
		dpd.getDatePicker().setCalendarViewShown(false);
		dpd.show();	
		dpd.getDatePicker().setMaxDate(System.currentTimeMillis());


	}




	public void YesNoAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();

				if (type.equalsIgnoreCase("Download_VillageData")) 
				{
					RequestServer request1=new RequestServer(Attendance_Act.this);
					request1.addParam("DeviceID", HomeData.sDeviceId);
					request1.ProccessRequest(Attendance_Act.this, "Download_VillageData");		
				}

			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{

					if(Type.equalsIgnoreCase("VilladeDone"))
					{
						VillageSP.setSelection(0);
					}
					if(Type.equalsIgnoreCase("Travel_Status"))
					{
						Intent intent = new Intent(Attendance_Act.this, Travelled_Kms.class);
						startActivity(intent);
						Attendance_Act.this.finish();
					}
					if(Type.equalsIgnoreCase("AutoDateTime")){

						startActivityForResult(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS), 0);
					}

					if(Type.equalsIgnoreCase("DataSubmit"))
					{
						//						Intent intent = new Intent(Attendance_Act.this, HomePage.class);
						//						startActivity(intent);
						//						Attendance_Act.this.finish();
						Submit();
					}
					if(Type.equalsIgnoreCase("Gps"))
					{
						launchGPSOptions();
					}
					if(Type.equalsIgnoreCase("DownloadVillage"))
					{
						startActivity(new Intent(Attendance_Act.this, Attendance_Act.class));
						finish();
					}
					if(Type.equalsIgnoreCase("AppUpdate"))
					{
						final String appPackageName = getPackageName(); // package name of the app
						try 
						{
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
						}
						catch (android.content.ActivityNotFoundException anfe) 
						{
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
						}
					}
					dialog.dismiss();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	private void launchGPSOptions() 
	{
		try
		{

			Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
			startActivity(intent);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	} 

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		getMenuInflater().inflate(R.menu.main, menu);
		MenuItem item=menu.findItem(R.id.logout);
		item.setVisible(false);
		MenuItem item1=menu.findItem(R.id.village_download);
		item1.setVisible(true);
		return super.onCreateOptionsMenu(menu);
	}



	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int i=item.getItemId();

		if(i==R.id.village_download)
		{
			YesNoAlert("you want to Download New Villages","Download_VillageData");
			//			RequestServer request1=new RequestServer(Attendance_Act.this);
			//			request1.addParam("DeviceID", HomeData.sDeviceId);
			//			request1.ProccessRequest(Attendance_Act.this, "Download_VillageData");	
		}

		return super.onOptionsItemSelected(item);
	}



	public void Success(String response) 
	{
		//Dialogs.AlertDialogs(Attendance_Act.this,"Information!!", ""+WebserviceCall.serverUploadcount+" Record's Successfully Uploaded");
		if(WebserviceCall.serverUploadcount>0)
		{
			AlertDialogs("Information!!", ""+WebserviceCall.serverUploadcount+" Villages Successfully Updated","DownloadVillage");
		}else 
		{
			AlertDialogs("Information!!", "No New Villages To Download","DownloadVillage");
		}

	}
	@Override 
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(Attendance_Act.this,"Information!!", response);
	}
	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(Attendance_Act.this,"Information!!", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		//		startActivity(new Intent(Attendance_Act.this,AppUpdatePage.class));
		//		finish();
		AlertDialogs("Information!!", "Plz Update latest version","AppUpdate");
		return;
	}

	@Override
	public void onBackPressed() 
	{
		super.onBackPressed();
	}
	public void Submit()
	{
		super.onBackPressed();
	}

	@Override
	protected void onRestart() 
	{
		super.onRestart();
		Boolean timeStatus=	isTimeAutomatic(context);

		if(timeStatus==false)
		{
			AlertDialogs("Information!!", "Enable Auto date & time ","AutoDateTime");
		}
	}
	@Override
	public void onLocationChanged(Location location) {
		mylocation = location;
		if (mylocation != null)
		{
			Latitude=Double.toString(mylocation.getLatitude());
			Longitude=Double.toString(mylocation.getLongitude());
			
			Toast toast = null;
			toast=Toast.makeText(Attendance_Act.this,"Your Device Location not ready,plz wait for gps connection ",Toast.LENGTH_SHORT);
			View view = toast.getView();
			toast.setGravity(Gravity.CENTER, 0, 0);
			//view.setBackgroundResource(R.color.blue);
			toast.show();
			//System.out.println("------------lll-"+Latitude+","+Longitude);

		}
	}


	@Override
	public void onConnected(Bundle bundle) 
	{
		checkPermissions();
	}

	@Override
	public void onConnectionSuspended(int i) {
		//Do whatever you need
		//You can display a message here
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult)
	{
		//You can display a message here
	}
	private void checkPermissions()
	{
		int permissionLocation = ContextCompat.checkSelfPermission(Attendance_Act.this,android.Manifest.permission.ACCESS_FINE_LOCATION);
		List<String> listPermissionsNeeded = new ArrayList<>();
		if (permissionLocation != PackageManager.PERMISSION_GRANTED) 
		{
			listPermissionsNeeded.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
			if (!listPermissionsNeeded.isEmpty()) 
			{
				ActivityCompat.requestPermissions(this,listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_ID_MULTIPLE_PERMISSIONS);
			}
		}else
		{
			getMyLocation();
		}

	}
	private void getMyLocation()
	{
		if(googleApiClient!=null) 
		{
			if (googleApiClient.isConnected())
			{
				int permissionLocation = ContextCompat.checkSelfPermission(Attendance_Act.this,Manifest.permission.ACCESS_FINE_LOCATION);
				if (permissionLocation == PackageManager.PERMISSION_GRANTED)
				{
					mylocation =LocationServices.FusedLocationApi.getLastLocation(googleApiClient);

					LocationRequest locationRequest = new LocationRequest();
					locationRequest.setInterval(3000);
					locationRequest.setFastestInterval(3000);
					locationRequest.setPriority(LocationRequest.PRIORITY_NO_POWER);
					LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
					builder.setAlwaysShow(true);

					LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);
					PendingResult<LocationSettingsResult> result =LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());

					result.setResultCallback(new ResultCallback<LocationSettingsResult>() 
							{

						@Override
						public void onResult(LocationSettingsResult result) {
							final Status status = result.getStatus();
							switch (status.getStatusCode()) {
							case LocationSettingsStatusCodes.SUCCESS:
								// All location settings are satisfied.
								// You can initialize location requests here.
								int permissionLocation = ContextCompat.checkSelfPermission(Attendance_Act.this,Manifest.permission.ACCESS_FINE_LOCATION);
								if (permissionLocation == PackageManager.PERMISSION_GRANTED) 
								{
									mylocation = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);
								}
								break;
							case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
								// Location settings are not satisfied.
								// But could be fixed by showing the user a dialog.
								try {
									// Show the dialog by calling startResolutionForResult(),
									// and check the result in onActivityResult().
									// Ask to turn on GPS automatically
									status.startResolutionForResult(Attendance_Act.this,REQUEST_CHECK_SETTINGS_GPS);
								} catch (IntentSender.SendIntentException e) 
								{
									// Ignore the error.
								}
								break;
							case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
								// Location settings are not satisfied. 
								// However, we have no way               
								// to fix the
								// settings so we won't show the dialog.
								// finish();
								break;
							}
						}
							});
				}
			}
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults)
	{
		int permissionLocation = ContextCompat.checkSelfPermission(Attendance_Act.this,Manifest.permission.ACCESS_FINE_LOCATION);
		if (permissionLocation == PackageManager.PERMISSION_GRANTED) {
			getMyLocation();
		}
	}
	//	public void onStatusChanged(String provider, int status, Bundle extras) 
	//	{
	//		// TODO Auto-generated method stub
	//		Log.d("dddd", "onStatusChanged...."+provider);
	//		
	//	}
	//	public void onProviderEnabled(String provider) 
	//	{
	//		Log.d("dddd", "onProviderEnabled...."+provider);
	//		
	//	}
	//	public void onProviderDisabled(String provider)
	//	{
	//		Log.d("dddd", "onProviderDisabled...."+provider);
	//		
	//	}

}
