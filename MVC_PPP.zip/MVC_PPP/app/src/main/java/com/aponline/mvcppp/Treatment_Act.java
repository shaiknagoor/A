package com.aponline.mvcppp;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Telephony.Mms.Draft;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.ServerResponseListener;

public class Treatment_Act extends AppCompatActivity implements OnClickListener,ServerResponseListener,OnItemSelectedListener
{

	Context context;
	DBAdapter db;
	ActionBar ab;
	LinearLayout slideMenuLL;
	RelativeLayout userDetailsLL;
	TextView AddAnimalTv,NoofSheepDewormedTv,NoofGoatDewormedTv,TotalDewormedTv,NoofFarmerBenefitedtTv,userId,AddDrugTv;
	Spinner AnimalTypeSp,Treatment_DrugSp;
	TableLayout treatment_AnimalTL,treatment_Animal_MedicineTL ;
	String MID,villageName,villageID,FarmerName,FarmerAdhaar,UniqueID,Rowid;
	StringBuilder XmlDoc,ChildXml;
	//ArrayList<String> Batch_ValidationAL=new ArrayList<String>();

	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.treatment);
		db=new DBAdapter(this);
		context=this;

		ab=getSupportActionBar();
		ab.setTitle("Diagnosis and Treatment");
		ab.setHomeButtonEnabled(false);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(false); 

		try {

			Intent intent = getIntent(); 
			if(!(intent.getStringExtra("UniqueID")==null) && !(intent.getStringExtra("Farmer_Name")==null) && !(intent.getStringExtra("Farmer_Aadhaar")==null) )
			{

				UniqueID=intent.getStringExtra("UniqueID").toString();
				FarmerName=intent.getStringExtra("Farmer_Name").toString();
				FarmerAdhaar=intent.getStringExtra("Farmer_Aadhaar").toString();

			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}

		treatment_AnimalTL = (TableLayout)findViewById(R.id.treatment_AnimalTL);
		treatment_Animal_MedicineTL=(TableLayout) findViewById(R.id.treatment_Animal_MedicineTL);
		AddAnimalTv=(TextView) findViewById(R.id.AddAnimalTv);
		AnimalTypeSp=(Spinner) findViewById(R.id.AnimalTypeSp);
		Treatment_DrugSp=(Spinner) findViewById(R.id.Treatment_DrugSp);
		//AddDrugTv=(TextView) findViewById(R.id.AddDrugTv);

		findViewById(R.id.proceedBt).setOnClickListener(this);
		findViewById(R.id.AddAnimalTv).setOnClickListener(this);
		findViewById(R.id.Treatment_Skip).setOnClickListener(this);
		Treatment_DrugSp.setOnItemSelectedListener(this);
		AddAnimalTv.setOnClickListener(this);
		//AddDrugTv.setOnClickListener(this);

		AnimalTypeSp.setOnItemSelectedListener(this);



		addNewAnimal();
		//addMedicine();

		db.open();
		int medicinCount=db.getRowCount("select Count(Medicine_Id) from Medicine_Received_Details where CreatedBy='"+HomeData.userID+"'");

		db.close();

		if(medicinCount==0)
		{
			Dialogs.AlertDialogs(this,"Information!!","You have not Registered Medicines. Enter  Medicines in Medicines Received Details");
			return;
		}



		//loadSpinnerData("select distinct AnimalKindName from Master_Animal_Kind order by AnimalKindName",AnimalTypeSp);
		//loadSpinnerData("select distinct MedicineName from Medicine_Received_Details  order by MedicineName", Treatment_DrugSp);
	}
	public void loadSpinnerDataStatic(ArrayList<String> lables, Spinner spinner) 
	{
		try
		{
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			//	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(FarmerRegistration.this,android.R.layout.simple_spinner_item, lables);
			//	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			//CommonFunctions.writeLog("FarmerRegistration", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}

	protected void addNewAnimal() 
	{

		try {

			//Batch_ValidationAL=new ArrayList<String>();
			final View tr = getLayoutInflater().inflate(R.layout.treatment_row, null);

			final TableLayout tb=(TableLayout)tr.findViewById(R.id.treatment_Animal_MedicineTL);
			final View mr =getLayoutInflater().inflate(R.layout.animal_medicine_row,null );

			TextView remove=(TextView)tr.findViewById(R.id.RemoveAnimalTv);
			Spinner AnimalTypeSp=(Spinner)tr.findViewById(R.id.AnimalTypeSp);
			EditText NoofAnimalsEt=(EditText)tr.findViewById(R.id.NoofAnimalsEt);
			EditText Identification_MarksEt=(EditText)tr.findViewById(R.id.Identification_MarksEt);
			EditText Disease_DiagnosedEt=(EditText)tr.findViewById(R.id.Disease_DiagnosedEt);
			final Spinner DrugSp=(Spinner)mr.findViewById(R.id.Treatment_DrugSp);
			final Spinner BatchSp=(Spinner)mr.findViewById(R.id.Treatment_BatchSp);
			final EditText ExpenditureEt=(EditText)mr.findViewById(R.id.ExpenditureEt);
			//final TextView BalanceEt=(TextView)tr.findViewById(R.id.BalanceEt);
			EditText AdvisesEt=(EditText)mr.findViewById(R.id.AdvisesEt);
			final TextView BalanceUnitTypeEt=(TextView)mr.findViewById(R.id.BalanceUnitTypeEt);
			final TextView ExpenditureUnitTypeEt=(TextView)mr.findViewById(R.id.ExpenditureUnitTypeEt);
			final TextView Removedrug=(TextView)mr.findViewById(R.id.Removedrug);
			final TextView add_drug=(TextView)tr.findViewById(R.id.add_drug);


			Disease_DiagnosedEt.addTextChangedListener(new CustomTextWatcher(Disease_DiagnosedEt));
			Disease_DiagnosedEt.addTextChangedListener(new ZeroTextWatcher(Disease_DiagnosedEt));

			//final View tr1 = getLayoutInflater().inflate(R.layout.animal_medicine_row, null);

			if(treatment_AnimalTL.getChildCount()==0)
			{
				remove.setVisibility(View.GONE);
				Removedrug.setVisibility(View.GONE);
			}
			if(tb.getChildCount()==0)
			{
				//remove.setVisibility(View.GONE);
				Removedrug.setVisibility(View.GONE);
			}
			tb.addView(mr);

			loadSpinnerData("select distinct AnimalKindName from Master_Animal_Kind order by AnimalKindName",AnimalTypeSp);
			loadSpinnerData("select distinct MedicineName from Medicine_Received_Details  where CreatedBy='"+HomeData.userID+"' order by MedicineName", DrugSp);

			//		BatchNoEt.addTextChangedListener(new CustomTextWatcher(Drug_ReceivedDateEt));
			//		ManufacturingDateEt.addTextChangedListener(new CustomTextWatcher(BatchNoEt));
			//		ExpiryDateEt.addTextChangedListener(new CustomTextWatcher(ManufacturingDateEt));
			//		QuantityReceivedEt.addTextChangedListener(new CustomTextWatcher(ExpiryDateEt));
			//		Drug_ReceivedDateEt.addTextChangedListener(new CustomTextWatcher(QuantityReceivedEt));
			add_drug.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					if(drugValidation()==true)
					{
						final View mr =getLayoutInflater().inflate(R.layout.animal_medicine_row,null );
						final TableLayout tb=(TableLayout)tr.findViewById(R.id.treatment_Animal_MedicineTL);

						final TextView Removedrug=(TextView)mr.findViewById(R.id.Removedrug);
						final Spinner DrugSp=(Spinner)mr.findViewById(R.id.Treatment_DrugSp);
						final Spinner BatchSp=(Spinner)mr.findViewById(R.id.Treatment_BatchSp);
						final TextView ExpenditureUnitTypeEt=(TextView)mr.findViewById(R.id.ExpenditureUnitTypeEt);
						final TextView BalanceUnitTypeEt=(TextView)mr.findViewById(R.id.BalanceUnitTypeEt);
						loadSpinnerData("select distinct MedicineName from Medicine_Received_Details  where CreatedBy='"+HomeData.userID+"' order by MedicineName", DrugSp);

						if(tb.getChildCount()==0)
						{
							//remove.setVisibility(View.GONE);
							Removedrug.setVisibility(View.GONE);
						}

						tb.addView(mr);

						Removedrug.setOnClickListener(new OnClickListener() 
						{

							@Override
							public void onClick(View v) 
							{

								View row = (View) v.getParent();
								ViewGroup container = ((ViewGroup)row.getParent());

								container.removeView(row);
								container.invalidate();
							}
						});

						DrugSp.setOnItemSelectedListener(new OnItemSelectedListener() 
						{

							@Override
							public void onItemSelected(AdapterView<?> parent, View view,int position, long id) 
							{
								if(!parent.getSelectedItem().toString().trim().equalsIgnoreCase("--Select--"))
								{

									db.open();
									//final TextView BalanceUnitTypeEt=(TextView)mr.findViewById(R.id.BalanceUnitTypeEt);
									MID=db.getSingleValue("select  Medicine_Id from Medicine_Received_Details where MedicineName='"+parent.getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
									String UType=db.getSingleValue("select distinct Packing from Master_Medicine where rowid='"+MID+"'");

									String[] part = UType.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");


									db.close();
									loadSpinnerData("select distinct Batch_Number from Medicine_Received_Details  where  Medicine_Id='"+MID+"' and Medicine_Balance_Count <>0  and CreatedBy='"+HomeData.userID+"'",BatchSp);
									if(part.length>=2)
										ExpenditureUnitTypeEt.setText(part[1]);

									//System.out.println("--------"+part[1]);
								}

							}

							@Override
							public void onNothingSelected(AdapterView<?> parent) {
								// TODO Auto-generated method stub

							}
						});

						BatchSp.setOnItemSelectedListener(new OnItemSelectedListener() 
						{

							@Override
							public void onItemSelected(AdapterView<?> parent, View view, int position, long id) 
							{
								if(!parent.getSelectedItem().toString().trim().equalsIgnoreCase("--Select--"))
								{
									db.open();
									String BatchBalanceQty=db.getSingleValue("select Temp_Bal from Medicine_Received_Details where Medicine_ID='"+MID+"' and Batch_Number='"+BatchSp.getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
									//BalanceEt.setText(BatchBalanceQty);
									//ExpenditureUnitTypeEt.setText(BalanceUnitTypeEt.getText().toString());
									db.close();
								}

							}

							@Override
							public void onNothingSelected(AdapterView<?> parent) 
							{

							}
						});

					}
				}
			});


			AnimalTypeSp.setOnItemSelectedListener(new OnItemSelectedListener() 
			{

				@Override
				public void onItemSelected(AdapterView<?> parent,View view, int position, long id) 
				{
					String	AnimalType=parent.getSelectedItem().toString().trim();
					if(!AnimalType.equalsIgnoreCase("--Select--"))
					{


					}

				}

				@Override
				public void onNothingSelected(AdapterView<?> parent) {
					// TODO Auto-generated method stub

				}
			} ); 

			DrugSp.setOnItemSelectedListener(new OnItemSelectedListener() 
			{

				@Override
				public void onItemSelected(AdapterView<?> parent, View view,int position, long id) 
				{
					if(!parent.getSelectedItem().toString().trim().equalsIgnoreCase("--Select--"))
					{




						db.open();

						MID=db.getSingleValue("select  Medicine_Id from Medicine_Received_Details where MedicineName='"+parent.getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
						String UType=db.getSingleValue("select distinct Packing from Master_Medicine where rowid='"+MID+"'");

						String[] part = UType.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
						if(part.length>=2)
							//BalanceUnitTypeEt.setText(part[1]);
							ExpenditureUnitTypeEt.setText(part[1]);
						db.close();
						loadSpinnerData("select distinct Batch_Number from Medicine_Received_Details  where  Medicine_Id='"+MID+"' and Medicine_Balance_Count <>0  and CreatedBy='"+HomeData.userID+"'",BatchSp);

					}

				}

				@Override
				public void onNothingSelected(AdapterView<?> parent) {
					// TODO Auto-generated method stub

				}
			});

			BatchSp.setOnItemSelectedListener(new OnItemSelectedListener() 
			{

				@Override
				public void onItemSelected(AdapterView<?> parent, View view, int position, long id) 
				{
					if(!parent.getSelectedItem().toString().trim().equalsIgnoreCase("--Select--"))
					{
						db.open();
						String BatchBalanceQty=db.getSingleValue("select Temp_Bal from Medicine_Received_Details where Medicine_ID='"+MID+"' and Batch_Number='"+BatchSp.getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
						//BalanceEt.setText(BatchBalanceQty);
						//ExpenditureUnitTypeEt.setText(BalanceUnitTypeEt.getText().toString());
						db.close();
					}

				}

				@Override
				public void onNothingSelected(AdapterView<?> parent) 
				{

				}
			});
			//		ExpenditureEt.addTextChangedListener(new TextWatcher() {
			//
			//			@Override
			//			public void onTextChanged(CharSequence s, int start, int before, int count) {
			//				// TODO Auto-generated method stub
			//
			//			}
			//
			//			@Override
			//			public void beforeTextChanged(CharSequence s, int start, int count,
			//					int after) {
			//				// TODO Auto-generated method stub
			//
			//			}
			//
			//			@Override
			//			public void afterTextChanged(Editable s) 
			//			{
			//				String ExpenditureQty=ExpenditureEt.getText().toString();
			//				//String BalanceQty=BalanceEt.getText().toString();
			//				if(ExpenditureQty.equalsIgnoreCase(""))
			//				{
			//					//ExpenditureEt.setText("0");
			//					ExpenditureEt.setError("Enter Valid Quantity");
			//					return;
			//				}else if(Integer.valueOf(BalanceQty)>=Integer.valueOf(ExpenditureQty))
			//				{
			//					//					String bal=String.valueOf(Integer.valueOf(BalanceQty)-Integer.valueOf(ExpenditureQty));
			//					//					db.open();
			//					//					String BatchBalanceQty=db.getSingleValue("select Medicine_Balance_Count from Medicine_Received_Details where Medicine_ID='"+MID+"' and Batch_Number='"+BatchSp.getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
			//					//					db.execSQL("UPDATE Medicine_Received_Details set Medicine_Balance_Count='"+bal+"' where Medicine_ID='"+MID+"' and Batch_Number='"+BatchSp.getSelectedItem().toString().trim()+"' and  CreatedBy='"+HomeData.userID+"'");
			//					//					db.close();
			//
			//				}else 
			//				{
			//
			//					ExpenditureEt.setError("Enter Valid Quantity");
			//					return;
			//					//					Toast toast = null;
			//					//					toast=Toast.makeText(Treatment_Act.this, "You have  "+BatchBalanceQty+UnitTypeEt.getText().toString()+"Only", Toast.LENGTH_SHORT);
			//					//					View view1 = toast.getView();
			//					//					toast.setGravity(Gravity.CENTER, 0, 0);
			//					//					toast.show();
			//				}
			//
			//			}
			//			//			db.open();
			//			//			String BatchBalanceQty=db.getSingleValue("select Medicine_Balance_Count from Medicine_Received_Details where Medicine_ID='"+MID+"' and Batch_Number='"+BatchSp.getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
			//			//
			//			//			db.close();
			//		});
			Removedrug.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					View row = (View) v.getParent();
					ViewGroup container = ((ViewGroup)row.getParent());

					container.removeView(row);
					container.invalidate();
				}
			});

			remove.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					View row = (View) v.getParent();
					ViewGroup container = ((ViewGroup)row.getParent());

					container.removeView(row);
					container.invalidate();


					//				String RemoveExpcount=((EditText)container.findViewById(R.id.ExpenditureEt)).getText().toString();
					//				String T_DrugSp=((Spinner)container.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString().trim();
					//				String BalanceEt=((TextView)container.findViewById(R.id.BalanceEt)).getText().toString();
					//				String T_BatchSp=((Spinner)container.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString().trim();



					//				if((Integer.valueOf(RemoveExpcount))!=0 && T_DrugSp.equalsIgnoreCase("--Select--")  && T_BatchSp.equalsIgnoreCase("--Select--"))
					//				{
					//					System.out.println("-----------------------ff-"+((EditText)container.findViewById(R.id.ExpenditureEt)).getText().toString());
					//					db.open();
					//
					//					String RMID=db.getSingleValue("select  Medicine_ID from Medicine_Received_Details where MedicineName='"+((Spinner)container.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString().trim()+"' and CreatedBy='"+HomeData.userID+"'");
					//					db.execSQL("update Medicine_Received_Details set Temp_Bal=Temp_Bal + '"+RemoveExpcount+"' where Medicine_ID='"+RMID+"' and Batch_Number='"+((Spinner)container.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString().trim()+"' and  CreatedBy='"+HomeData.userID+"'");
					//
					//					db.close();
					//				}
				}
			});
			treatment_AnimalTL.addView(tr);

		} catch (Exception e) 
		{
			e.printStackTrace();
		}

	}



	private void CheckValidation() 
	{
		try {



			if(treatment_AnimalTL.getChildCount()!=0)
			{
				//				for (int i = 0; i < treatment_AnimalTL.getChildCount(); i++) 
				//				{

				View child = treatment_AnimalTL.getChildAt(treatment_AnimalTL.getChildCount()-1);
				TableLayout tt=(TableLayout)child.findViewById(R.id.treatment_Animal_MedicineTL);


				View Child_Drug = tt.getChildAt(tt.getChildCount()-1);

				String ss=((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).getText().toString();
				String NoofAnimals=((EditText)child.findViewById(R.id.NoofAnimalsEt)).getText().toString();

				float ExpnCount=0;
				int animalCount = 0;
				if(!ss.equalsIgnoreCase("") && !ss.equalsIgnoreCase("."))
				{
					ExpnCount= Float.valueOf(ss.trim()).floatValue();
				}
				if(!NoofAnimals.equalsIgnoreCase(""))
				{
					animalCount= Integer.valueOf(NoofAnimals);
				}



				if ((((Spinner)child.findViewById(R.id.AnimalTypeSp)).getSelectedItem().toString()).equalsIgnoreCase("--Select--"))
				{
					((Spinner)child.findViewById(R.id.AnimalTypeSp)).requestFocusFromTouch();
					return;
				}
				else if ((((EditText)child.findViewById(R.id.NoofAnimalsEt)).getText().toString()).equalsIgnoreCase(""))
				{
					((EditText)child.findViewById(R.id.NoofAnimalsEt)).setError("Enter No.of Animals/Birds");
					((EditText)child.findViewById(R.id.NoofAnimalsEt)).requestFocus();

					return;
				}
				else if (!(animalCount>0))
				{
					((EditText)child.findViewById(R.id.NoofAnimalsEt)).setError("Enter Valid Number");
					((EditText)child.findViewById(R.id.NoofAnimalsEt)).requestFocus();

					return;
				}
				else if ((((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).getText().toString()).equalsIgnoreCase(""))
				{
					((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).setError("Enter Disease Diagnosed");
					((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).requestFocus();

					return;
				}

				else if ((((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()).equalsIgnoreCase("--Select--")) 
				{
					((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).requestFocusFromTouch();
					return;
				}
				else if ((((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString()).equalsIgnoreCase("--Select--")) 
				{
					((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();
					return;
				}
				else if ((((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).getText().toString()).equalsIgnoreCase("0") || (((EditText)child.findViewById(R.id.ExpenditureEt)).getText().toString()).equalsIgnoreCase(""))
				{
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).setError("Enter Expenditure");
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).requestFocus();

					return;

				}else if (!(ExpnCount>0))
				{
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).setError("Enter Valid Quantity");
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).requestFocus();

					return;

				}
				//				else if(Batch_ValidationAL.size()!=0 && Batch_ValidationAL.contains(((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()+"@"+((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString()))
				//				{
				//
				//					((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();
				//
				//					Toast toast = null;
				//					toast=Toast.makeText(Treatment_Act.this, "Same Batch Entered",Toast.LENGTH_SHORT);
				//					View view = toast.getView();
				//					toast.setGravity(Gravity.CENTER, 0, 0);
				//					view.setBackgroundResource(R.color.red);
				//					toast.show();
				//					return ;
				//				}

				else {

					addNewAnimal();

					//drugValidation();
				}


			}

		} catch (Exception e) 
		{
			e.printStackTrace();	
		}


	}

	public boolean drugValidation()
	{
		try {

			if(treatment_AnimalTL.getChildCount()!=0)
			{

				View child = treatment_AnimalTL.getChildAt(treatment_AnimalTL.getChildCount()-1);
				TableLayout tt=(TableLayout)child.findViewById(R.id.treatment_Animal_MedicineTL);

				int dds=tt.getChildCount();
				View Child_Drug = tt.getChildAt(tt.getChildCount()-1);


				String ss=((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).getText().toString();

				float ExpnCount=0;
				if(!ss.equalsIgnoreCase("") && !ss.equalsIgnoreCase("."))
				{
					ExpnCount= Float.valueOf(ss.trim()).floatValue();
				}

				if ((((Spinner)child.findViewById(R.id.AnimalTypeSp)).getSelectedItem().toString()).equalsIgnoreCase("--Select--"))
				{
					((Spinner)child.findViewById(R.id.AnimalTypeSp)).requestFocusFromTouch();
					return false;
				}

				else if ((((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).getText().toString()).equalsIgnoreCase(""))
				{
					((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).setError("Enter Disease Diagnosed");
					((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).requestFocus();

					return false;
				}

				else if ((((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()).equalsIgnoreCase("--Select--")) 
				{
					((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).requestFocusFromTouch();
					return false;
				}
				else if ((((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString()).equalsIgnoreCase("--Select--")) 
				{
					((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();
					return false;
				}
				else if ((((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).getText().toString()).equalsIgnoreCase("0") || (((EditText)child.findViewById(R.id.ExpenditureEt)).getText().toString()).equalsIgnoreCase(""))
				{
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).setError("Enter Expenditure");
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).requestFocus();

					return false;

				}else if (!(ExpnCount > 0))
				{
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).setError("Enter Valid Quantity");
					((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).requestFocus();

					return false;

				}
				//				else if(Batch_ValidationAL.size()!=0 && Batch_ValidationAL.contains(((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()+"@"+((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString()))
				//				{
				//
				//					((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();
				//
				//					Toast toast = null;
				//					toast=Toast.makeText(Treatment_Act.this, "Same Batch Entered",Toast.LENGTH_SHORT);
				//					View view = toast.getView();
				//					toast.setGravity(Gravity.BOTTOM, 0, 0);
				//					view.setBackgroundResource(R.color.red);
				//					toast.show();
				//					return false;
				//				}
				else 
				{
					//Batch_ValidationAL.add(((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()+"@"+((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString());
					return true;
				}


			}

		} catch (Exception e) 
		{
			e.printStackTrace();	
		}
		return false;

	}



	private void FinalSubmit()
	{

		try {

			ArrayList<HashMap<String, String>> TreatmentAL=new ArrayList<HashMap<String,String>>();
			ArrayList<HashMap<String, String>> TreatmentAnimalDetailsAL=new ArrayList<HashMap<String,String>>();

			if(treatment_AnimalTL.getChildCount()!=0)
			{
				for (int i = 0; i < treatment_AnimalTL.getChildCount(); i++) 
				{
					View child = treatment_AnimalTL.getChildAt(i);
					try 
					{
						String AnimalTypeSp=((Spinner)child.findViewById(R.id.AnimalTypeSp)).getSelectedItem().toString();

						String IdentidficationMarks=((EditText)child.findViewById(R.id.Identification_MarksEt)).getText().toString();


						if (AnimalTypeSp.equalsIgnoreCase("--Select--") || AnimalTypeSp.equalsIgnoreCase(""))
						{
							((Spinner)child.findViewById(R.id.AnimalTypeSp)).requestFocusFromTouch();
							return;
						}
						if ((((EditText)child.findViewById(R.id.NoofAnimalsEt)).getText().toString()).equalsIgnoreCase(""))
						{
							((EditText)child.findViewById(R.id.NoofAnimalsEt)).setError("Enter No.of Animals/Birds");
							((EditText)child.findViewById(R.id.NoofAnimalsEt)).requestFocus();

							return;
						}

						String NoofAnimals=((EditText)child.findViewById(R.id.NoofAnimalsEt)).getText().toString();

						int animalCount = 0;

						if(!NoofAnimals.equalsIgnoreCase(""))
						{
							animalCount= Integer.valueOf(NoofAnimals);
						}

						if (!(animalCount>0))
						{
							((EditText)child.findViewById(R.id.NoofAnimalsEt)).setError("Enter Valid Number");
							((EditText)child.findViewById(R.id.NoofAnimalsEt)).requestFocus();

							return;
						}
						String Disease_Diagnosed=((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).getText().toString();
						if (Disease_Diagnosed.equalsIgnoreCase(""))
						{
							((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).setError("Enter Disease Diagnosed");
							((EditText)child.findViewById(R.id.Disease_DiagnosedEt)).requestFocus();

							return;
						} 

						db.open();
						String animal_ID=db.getSingleValue("select AnimalKindID from Master_Animal_Kind where AnimalKindName='"+AnimalTypeSp+"'");
						db.close();


						HashMap<String, String> AnimalHM=new HashMap<String, String>();

						AnimalHM.put("Animal_Name",AnimalTypeSp);
						AnimalHM.put("animalID",animal_ID);
						AnimalHM.put("NoofAnimals",NoofAnimals);
						AnimalHM.put("IdentidficationMarks",IdentidficationMarks);
						AnimalHM.put("Disease",Disease_Diagnosed);

						TreatmentAnimalDetailsAL.add(AnimalHM);


						TableLayout tt=(TableLayout)child.findViewById(R.id.treatment_Animal_MedicineTL);


						ArrayList<String> CheckRepeatDrug=new ArrayList<String>();
						for (int j = 0; j < tt.getChildCount(); j++) 
						{


							//View Child_Drug = tt.getChildAt(tt.getChildCount()-1);
							View Child_Drug = tt.getChildAt(j);


							String Treatment_DrugSp=((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString();
							if (Treatment_DrugSp.equalsIgnoreCase("--Select--")) 
							{
								((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).requestFocusFromTouch();
								return;
							}

							String Treatment_BatchSp=((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString();
							if (Treatment_BatchSp.equalsIgnoreCase("--Select--")) 
							{
								((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();
								return;
							}


							String Expenditure=((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).getText().toString();
							float ExpnCount=0;

							if(!Expenditure.equalsIgnoreCase("") && !Expenditure.equalsIgnoreCase("."))
							{
								ExpnCount= Float.valueOf(Expenditure.trim()).floatValue();
							}

							if ( Expenditure.equalsIgnoreCase(""))
							{
								((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).setError("Enter Expenditure");
								((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).requestFocus();

								return;

							}
							if ( !(ExpnCount>0))
							{
								((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).setError("Enter Valid Quantity");
								((EditText)Child_Drug.findViewById(R.id.ExpenditureEt)).requestFocus();

								return;

							}
							if(CheckRepeatDrug.size()!=0 && j!=0 && CheckRepeatDrug.contains(((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()+"@"+((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString()))
							{

								((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();

								Toast toast = null;
								toast=Toast.makeText(Treatment_Act.this, "Same Batch Entered",Toast.LENGTH_SHORT);
								View view = toast.getView();
								toast.setGravity(Gravity.CENTER, 0, 0);
								view.setBackgroundResource(R.color.red);
								toast.show();
								return ;
							}

							else
							{



								String Advise=((EditText)Child_Drug.findViewById(R.id.AdvisesEt)).getText().toString();
								db.open();
								String animalID=db.getSingleValue("select AnimalKindID from Master_Animal_Kind where AnimalKindName='"+AnimalTypeSp+"'");
								String DrugID=db.getSingleValue("select Medicine_ID from Medicine_Received_Details where MedicineName='"+Treatment_DrugSp+"' and CreatedBy='"+HomeData.userID+"'");

								db.close();

								//								for(HashMap<String, String> hm:TreatmentAL)
								//								{
								//									if(hm.get("DrugID").contains(DrugID) && hm.get("BatchNo").contains(Treatment_BatchSp))
								//									{
								//										((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).requestFocusFromTouch();
								//										
								//										Dialogs.AlertDialogs(this,"Information!!","Batch No. Repeated");
								//										return;
								//									}
								//								}
								HashMap<String, String> localHM=new HashMap<String, String>();

								localHM.put("animalID",animalID);
								//localHM.put("NoofAnimals",NoofAnimals);
								localHM.put("DrugID",DrugID);
								localHM.put("IdentidficationMarks",IdentidficationMarks);
								localHM.put("Disease",Disease_Diagnosed);
								localHM.put("BatchNo",Treatment_BatchSp);
								localHM.put("Expenditure",Expenditure);
								localHM.put("Advise",Advise);

								TreatmentAL.add(localHM);
								CheckRepeatDrug.add(((Spinner)Child_Drug.findViewById(R.id.Treatment_DrugSp)).getSelectedItem().toString()+"@"+((Spinner)Child_Drug.findViewById(R.id.Treatment_BatchSp)).getSelectedItem().toString());

							}

						}


					}
					catch (Exception e) 
					{
						e.printStackTrace();
						break;
					}

				}
				XmlDoc=new StringBuilder();
				XmlDoc.append("<IsDiagnosis>1</IsDiagnosis>");

				//	------------Animal details
				XmlDoc.append("<Diagnosis_Treatment_Animals>");
				for(HashMap<String, String> hm:TreatmentAnimalDetailsAL)
				{

					XmlDoc.append("<Diagnosis_Animals>");
					
					XmlDoc.append("<AnimalID>"+hm.get("animalID")+"</AnimalID>");
					XmlDoc.append("<NoofAnimals_Birds>"+hm.get("NoofAnimals")+"</NoofAnimals_Birds>");
					XmlDoc.append("<IdentificationMarks>"+hm.get("IdentidficationMarks")+"</IdentificationMarks>");
					XmlDoc.append("<Disease>"+hm.get("Disease")+"</Disease>");
					
					XmlDoc.append("</Diagnosis_Animals>");		


					ContentValues cv=new ContentValues();
					cv.put("Animal_Name",hm.get("Animal_Name"));
					cv.put("AnimalID",hm.get("animalID"));
					cv.put("NoofAnimals_Birds",hm.get("NoofAnimals"));
					cv.put("Identification_marks",hm.get("IdentidficationMarks"));
					cv.put("Diseas_Diagnosed",hm.get("Disease"));
					cv.put("UniqueID",UniqueID);
					cv.put("FarmerName",FarmerName);
					cv.put("Farmer_Adhaar",FarmerAdhaar);
					cv.put("CreatedBy",HomeData.userID);
					cv.put("Status","N");

					db.open();
					db.insertTableDate("MVC_Diagnosis__Treatment_AnimalDetails", cv);
					//db.execSQL("Medicine_Received_Details set Medicine_Balance_Count=Medicine_Balance_Count-'"+hm.get("Expenditure")+"'  where Medicine_ID='"+hm.get("DrugID")+"' and Batch_Number='"+hm.get("BatchNo")+"' and  CreatedBy='"+HomeData.userID+"'");
					db.close();
				}
				XmlDoc.append("</Diagnosis_Treatment_Animals>");
				//				------------Animal details close

				XmlDoc.append("<Diagnosis_Treatment_Details>");
				for(HashMap<String, String> hm:TreatmentAL)
				{

					XmlDoc.append("<Diagnosis_Treatment>");

					XmlDoc.append("<AnimalID>"+hm.get("animalID")+"</AnimalID>");
					//XmlDoc.append("<NoofAnimals_Birds>"+hm.get("NoofAnimals")+"</NoofAnimals_Birds>");
					XmlDoc.append("<IdentificationMarks>"+hm.get("IdentidficationMarks")+"</IdentificationMarks>");
					XmlDoc.append("<Disease>"+hm.get("Disease")+"</Disease>");
					XmlDoc.append("<DrugID>"+hm.get("DrugID")+"</DrugID>");
					XmlDoc.append("<BatchNo>"+hm.get("BatchNo")+"</BatchNo>");
					XmlDoc.append("<Expenditure>"+hm.get("Expenditure")+"</Expenditure>");
					XmlDoc.append("<Advise>"+hm.get("Advise")+"</Advise>");

					XmlDoc.append("</Diagnosis_Treatment>");


					ContentValues cv=new ContentValues();
					cv.put("AnimalID",hm.get("animalID"));
					//cv.put("NoofAnimals_Birds",hm.get("NoofAnimals"));
					cv.put("DrugID",hm.get("DrugID"));
					cv.put("Identification_marks",hm.get("IdentidficationMarks"));
					cv.put("Diseas_Diagnosed",hm.get("Disease"));
					cv.put("BatchNo",hm.get("BatchNo"));
					cv.put("Expenditure",hm.get("Expenditure"));
					cv.put("Advise",hm.get("Advise"));
					cv.put("UniqueID",UniqueID);
					cv.put("FarmerName",FarmerName);
					cv.put("Farmer_Adhaar",FarmerAdhaar);
					cv.put("CreatedBy",HomeData.userID);
					cv.put("Status","N");

					db.open();
					db.insertTableDate("Diagnosis_Treatment_Details", cv);
					//db.execSQL("Medicine_Received_Details set Medicine_Balance_Count=Medicine_Balance_Count-'"+hm.get("Expenditure")+"'  where Medicine_ID='"+hm.get("DrugID")+"' and Batch_Number='"+hm.get("BatchNo")+"' and  CreatedBy='"+HomeData.userID+"'");
					db.close();
				}
				XmlDoc.append("</Diagnosis_Treatment_Details>");

				db.open();
				String xml=db.getSingleValue("select XMLDATA from Farmer_FullDetails where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"' and Farmer_Aadhaar='"+FarmerAdhaar+"'");
				xml=xml+XmlDoc.toString();
				db.execSQL("UPDATE Farmer_FullDetails set XMLDATA='"+xml+"' where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
				db.close();


				AlertDialogs("Information!!", "Treatment Details Successfully Submitted","DataSubmit");

			}
		}catch (Exception e) 
		{
			Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
		}

	}

	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{
					if(Type.equalsIgnoreCase("DataSubmit"))
					{
						Intent i=new Intent(Treatment_Act.this,Artificial_Insemination_Act.class);
						i.putExtra("UniqueID",UniqueID);
						i.putExtra("Farmer_Name",FarmerName);
						i.putExtra("Farmer_Aadhaar",FarmerAdhaar);
						i.putExtra("skip_Xml","1");
						startActivity(i);
					}
					dialog.dismiss();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.proceedBt:
			FinalSubmit();
			break;
		case R.id.AddAnimalTv:
			CheckValidation();
			//addNewAnimal();

			break;
			//		case R.id.AddDrugTv:
			//			//CheckValidation("Drug");
			//			//addMedicine();
			//			addNewAnimal();
			//			break;

		case R.id.Treatment_Skip:

			SkipService();
			break;


		default:
			break;
		}

	}

	private void SkipService()
	{
		try {


			XmlDoc=new StringBuilder();
			XmlDoc.append("<IsDiagnosis>0</IsDiagnosis>");

			db.open();
			String xml=db.getSingleValue("select XMLDATA from Farmer_FullDetails where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"' and Farmer_Aadhaar='"+FarmerAdhaar+"'");
			xml=xml+XmlDoc.toString();
			db.execSQL("UPDATE Farmer_FullDetails set XMLDATA='"+xml+"' where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
			db.close();

			Intent i=new Intent(Treatment_Act.this,Artificial_Insemination_Act.class);
			i.putExtra("UniqueID",UniqueID);
			i.putExtra("Farmer_Name",FarmerName);
			i.putExtra("Farmer_Aadhaar",FarmerAdhaar);
			i.putExtra("skip_Xml","0");
			startActivity(i);
			Treatment_Act.this.finish();

		}catch (Exception e) 
		{
			Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
		}
	}
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) 
	{
		// TODO Auto-generated method stub

	}
	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}

	public void LogoutAlert(String msg1)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{

				try 
				{
					db.open();
					db.execSQL("DELETE FROM Farmer_FullDetails  where RowID='"+UniqueID+"' and  Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
					db.close();

					Intent i=new Intent(Treatment_Act.this,HomePage.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					finish();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}


				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}



	@Override
	public void Success(String response) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Fail(String response) {
		// TODO Auto-generated method stub

	}

	@Override
	public void NetworkNotAvail() {
		// TODO Auto-generated method stub

	}

	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub

	}
	@Override
	public void onBackPressed() 
	{
		try 
		{
			LogoutAlert("Are you sure Exit this Farmer");
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}


}
