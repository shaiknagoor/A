package com.aponline.mvcppp.Adapter;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.mvcppp.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class Report_Adapter extends BaseAdapter
{
	ArrayList<HashMap<String,String>> localArrayList=new ArrayList<HashMap<String,String>>();
	Context mContext;
	private LayoutInflater mInflater;
	private Holder mHolder;
	public String reportType="";

	public Report_Adapter(Context baseContext,ArrayList<HashMap<String,String>> data,String report)
	{
		this.mContext=baseContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(baseContext);
		this.reportType=report;
	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position)
	{
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(convertView == null)
		{
			convertView=this.mInflater.inflate(R.layout.report_list, null);

			this.mHolder= new Holder();
			this.mHolder.sno=(TextView) convertView.findViewById(R.id.snoRL);
			this.mHolder.wc=(TextView) convertView.findViewById(R.id.wcRL);
			this.mHolder.buff=(TextView) convertView.findViewById(R.id.buffRL);
			this.mHolder.sheep=(TextView) convertView.findViewById(R.id.sheepRL);
			this.mHolder.goats=(TextView) convertView.findViewById(R.id.goatsRL);
			this.mHolder.dogs=(TextView) convertView.findViewById(R.id.dogsRL);
			this.mHolder.pigs=(TextView) convertView.findViewById(R.id.pigsRL);
			this.mHolder.poulrty=(TextView) convertView.findViewById(R.id.poultryRL);
			this.mHolder.others=(TextView) convertView.findViewById(R.id.othersRL);
			this.mHolder.date=(TextView) convertView.findViewById(R.id.dateRL);





			convertView.setTag(mHolder);
		}
		else
			this.mHolder=(Holder)convertView.getTag();

		HashMap<String, String> data=this.localArrayList.get(position);

		if(reportType.equalsIgnoreCase("Artificial_Insemination_Details") || reportType.equalsIgnoreCase("Castration_Details") || reportType.equalsIgnoreCase("Dewormings") || reportType.equalsIgnoreCase("Vaccination_Details"))
		{
			this.mHolder.sheep.setVisibility(8);
			this.mHolder.wc.setVisibility(8);
			this.mHolder.sno.setText(Integer.toString(position+1));
			this.mHolder.wc.setText(data.get("AnimalKindName"));
			this.mHolder.buff.setText(data.get("Number"));
			//		this.mHolder.sheep.setText(data.get("DISTRICTCODE"));
			//		this.mHolder.goats.setText(data.get("DISTRICTNAME"));
			//		this.mHolder.pigs.setText(data.get("College"));
			//		this.mHolder.dogs.setText(data.get("DISTRICTCODE"));
			//		this.mHolder.poulrty.setText(data.get("DISTRICTNAME"));
			//		this.mHolder.pigs.setText(data.get("College"));
			//		this.mHolder.others.setText(data.get("DISTRICTCODE"));
			this.mHolder.date.setText(data.get("EntryDate"));


		}else if(reportType.equalsIgnoreCase("Calves_Born_Details") ||reportType.equalsIgnoreCase("Operation_Details"))
		{
			this.mHolder.sheep.setVisibility(0);
			this.mHolder.wc.setVisibility(8);
			this.mHolder.sno.setText(Integer.toString(position+1));
			//this.mHolder.wc.setText(data.get("AnimalKindName"));
			this.mHolder.buff.setText(data.get("Male"));
			this.mHolder.sheep.setText(data.get("Female"));
			//		this.mHolder.goats.setText(data.get("DISTRICTNAME"));
			//		this.mHolder.pigs.setText(data.get("College"));
			//		this.mHolder.dogs.setText(data.get("DISTRICTCODE"));
			//		this.mHolder.poulrty.setText(data.get("DISTRICTNAME"));
			//		this.mHolder.pigs.setText(data.get("College"));
			//		this.mHolder.others.setText(data.get("DISTRICTCODE"));
			this.mHolder.date.setText(data.get("EntryDate"));


		}
		else if(reportType.equalsIgnoreCase("Animals_Treated"))
		{
			this.mHolder.sheep.setVisibility(0);
			this.mHolder.goats.setVisibility(0);
			this.mHolder.dogs.setVisibility(0);
			this.mHolder.poulrty.setVisibility(0);
			this.mHolder.pigs.setVisibility(0);
			this.mHolder.others.setVisibility(0);
			this.mHolder.wc.setVisibility(8);

			this.mHolder.sno.setText(Integer.toString(position+1));
			//this.mHolder.wc.setText(data.get("1"));
			this.mHolder.buff.setText(data.get("2"));
			this.mHolder.sheep.setText(data.get("3"));
			this.mHolder.goats.setText(data.get("4"));
			this.mHolder.pigs.setText(data.get("5"));
			this.mHolder.dogs.setText(data.get("6"));
			this.mHolder.poulrty.setText(data.get("7"));
			this.mHolder.others.setText(data.get("8"));
			this.mHolder.date.setText(data.get("EntryDate"));


		}else if(reportType.equalsIgnoreCase("AbstractBt_report"))
		{
			this.mHolder.sheep.setVisibility(0);
			this.mHolder.goats.setVisibility(0);
			this.mHolder.dogs.setVisibility(0);
			this.mHolder.poulrty.setVisibility(0);
			this.mHolder.pigs.setVisibility(0);
			this.mHolder.others.setVisibility(0);
			this.mHolder.wc.setVisibility(8);
			this.mHolder.date.setVisibility(0);

			this.mHolder.sno.setText(Integer.toString(position+1));
			//this.mHolder.wc.setText(data.get("1"));
			
			this.mHolder.buff.setText(data.get("animalT"));
			this.mHolder.sheep.setText(data.get("deworming"));
			this.mHolder.goats.setText(data.get("surgeries"));
			this.mHolder.pigs.setText(data.get("vaccination"));
			this.mHolder.dogs.setText(data.get("artificial"));
			this.mHolder.poulrty.setText(data.get("calvesBorn"));
			this.mHolder.others.setText(data.get("castration"));
			this.mHolder.date.setText(data.get("EntryDate"));
			
//			this.mHolder.wc.setText(data.get("animalT"));
//			this.mHolder.buff.setText(data.get("deworming"));
//			this.mHolder.sheep.setText(data.get("surgeries"));
//			this.mHolder.goats.setText(data.get("vaccination"));
//			this.mHolder.pigs.setText(data.get("artificial"));
//			this.mHolder.dogs.setText(data.get("calvesBorn"));
//			this.mHolder.poulrty.setText(data.get("castration"));
//			this.mHolder.date.setText(data.get("EntryDate"));
			


		}

		


		return convertView;

	}
	public class Holder
	{
		TextView sno,wc,buff,sheep,goats,pigs,dogs,poulrty,others,date;

	}
}