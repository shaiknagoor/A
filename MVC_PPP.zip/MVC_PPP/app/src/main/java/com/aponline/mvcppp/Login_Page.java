package com.aponline.mvcppp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.CheckConnection;
import com.aponline.mvcppp.server.RequestServer;
import com.aponline.mvcppp.server.ServerResponseListener;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class Login_Page extends Activity implements OnClickListener,ServerResponseListener
{
	protected static final String MY_PREFS_NAME = null;
	Button loginBt;
	EditText loginpage_userEt,loginpage_pswEt;
	public static String UserName,Password;
	TextView errorMsg,termsandConditions;
	ProgressDialog progressDialog;
	Handler mHandler;
	Boolean isSubmited=false;
	Context context;
	EditText name,emails,cpwd;
	DBAdapter db;
	CheckBox mCbShowPwd;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);





		mCbShowPwd = (CheckBox) findViewById(R.id.cbShowPwd);


		if (Build.VERSION.SDK_INT >= 23)
		{
			requestPermissions();

		}
		else
		{
			init();
		}

		mCbShowPwd.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) 
			{
				if(isChecked)
				{
					loginpage_pswEt.setTransformationMethod(null);
				}else 
				{
					loginpage_pswEt.setTransformationMethod(new PasswordTransformationMethod());

				}
				loginpage_pswEt.setSelection(loginpage_pswEt.getText().length());


			}
		});


	}
	public void init()
	{

		HomeData.readDeviceDetails(this);
		db=new DBAdapter(this);
		try 
		{
			db.createDataBase();
			db.open();
			db.createNewTable();
			db.close();

		} 
		catch (IOException e) 
		{

			e.printStackTrace();
			db.close();
		}


		try {
			
			db.open();

			String ss=db.getSingleValue("select RoleID from Login_UserDetails");
			db.close();



		} catch (Exception e) {
			db.open();
			db.execSQL("ALTER TABLE Login_UserDetails ADD RoleID TEXT ");
			db.close();
		}


		if(HomeData.isLogin(this))
		{
			Intent i= new Intent (Login_Page.this,DashBoard_Act.class);
			startActivity(i);
			Login_Page.this.finish();
			return;
		}

		loginpage_userEt=(EditText)findViewById(R.id.loginpage_userEt);
		loginpage_pswEt=(EditText)findViewById(R.id.loginpage_pswEt);
		loginBt=(Button)findViewById(R.id.loginBt);
		findViewById(R.id.registerBt).setOnClickListener(this);
		findViewById(R.id.forgotpswTv).setOnClickListener(this);
		((TextView)findViewById(R.id.versionId)).setText("V "+HomeData.sAppVersionName);

		loginBt.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(loginpage_pswEt.getWindowToken(), 0);
				UserName=loginpage_userEt.getText().toString();
				Password=loginpage_pswEt.getText().toString();

				if(UserName.equals(""))
				{
					loginpage_userEt.setError("Enter User Name");
					loginpage_userEt.requestFocus();
					return;
				}
				if(Password.equals(""))
				{
					loginpage_pswEt.setError("Enter Password"); 
					loginpage_pswEt.requestFocus();
					return; 
				}
				HomeData.userID=UserName;
				//		startActivity(new Intent(Login_Page.this, Home.class));
				//		Login_Page.this.finish();

				if(CheckConnection.isNetworkAvailable(Login_Page.this))
				{
					RequestServer request=new RequestServer(Login_Page.this);
					request.addParam("UserID", UserName);
					request.addParam("password", Password);
					request.ProccessRequest(Login_Page.this, "ValidateUserDetails");
				}
				else
				{
					CheckWithLocalDbData();
//					Toast toast = null;
//					toast=Toast.makeText(Login_Page.this,"Pl check Internet connection ",Toast.LENGTH_SHORT);
//					View view = toast.getView();
//					toast.setGravity(Gravity.CENTER, 0, 0);
//					view.setBackgroundResource(R.color.red);
//					toast.show();
					return;
				}

				//				HomeData.SaveCreadentials(Login_Page.this,UserName,Password);
				//				Intent i= new Intent (Login_Page.this,Home_Page.class);
				//				startActivity(i);
				//				Login_Page.this.finish();
			}
		});

	}




	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("Write enternal Contacts");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("camera");

		if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
			permissionsNeeded.add("Access Fine Location");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
			permissionsNeeded.add("Access Coarse Location");


		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				// Need Rationale
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				try
				{

					ActivityCompat.requestPermissions(Login_Page.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
					return;

				} catch (Resources.NotFoundException e) {
					e.printStackTrace();
				}

				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}
		init();
	}


	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}
		return true;
	}

	@Override
	public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){

		switch (permsRequestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			// Initial
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.GET_ACCOUNTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);

			// Fill with results
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			// Check for ACCESS_FINE_LOCATION
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
			{
				init();
			}
			else
			{
				// Permission Denied
				Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
				.show();
			}
		}
		break;
		default:
			super.onRequestPermissionsResult(permsRequestCode, permissions, grantResults);
		}
	}

	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{

		case R.id.forgotpswTv:

		default:
			break;
		}
	}

	boolean doubleBackToExitPressedOnce = false;
	@Override
	public void onBackPressed() 
	{
		try 
		{
			if (doubleBackToExitPressedOnce)
			{
				super.onBackPressed();
				return;
			}
			this.doubleBackToExitPressedOnce = true;

			Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					doubleBackToExitPressedOnce=false;
				}
			}, 2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.profile_alertbox1);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	protected void CheckWithLocalDbData() 
	{
		db.open();
		String username = null,password = null;
		Cursor loginDetails=db.getTableDataCursor("Select UserID,Password from Login_UserDetails where UserID='"+UserName+"'");
		if(loginDetails.getCount()>0)
		{
			if(loginDetails.moveToFirst())
			{
				username=loginDetails.getString(loginDetails.getColumnIndex("UserID"));
				password=loginDetails.getString(loginDetails.getColumnIndex("Password"));
			}
		}
		else
		{
			loginDetails.close();
			db.close();      
			Dialogs.AlertDialogs(Login_Page.this, "Information!!", "Offline Data Not Found , Plz Login Online");
			return; 
		}
		loginDetails.close(); 
		db.close();

		if(!username.equalsIgnoreCase(UserName))
		{
			loginpage_userEt.setError("Enter Valid User Name");
			loginpage_userEt.requestFocus();    
			return;
		}
		if(password==null)    
		{
			AlertDialogs("Information!!", "First Time Must Login in Online");
			return;
		} 
		if(!password.equalsIgnoreCase(Password))    
		{
			loginpage_pswEt.setError("Enter Valid Password");
			loginpage_pswEt.requestFocus();
			return;
		} 
		HomeData.userID=UserName; 
		HomeData.SaveCreadentials(Login_Page.this,UserName,Password);
		Intent i= new Intent (Login_Page.this,DashBoard_Act.class);
		startActivity(i);
		Login_Page.this.finish();

	}
	@Override
	public void Success(String response)
	{
		HomeData.SaveCreadentials(Login_Page.this,UserName,Password);
		Intent i= new Intent (Login_Page.this,DashBoard_Act.class);
		startActivity(i);
		Login_Page.this.finish();
	}
	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(Login_Page.this,"Information!!", response);
	}
	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		//		startActivity(new Intent(Login_Page.this,AppUpdatePage.class));
		//		finish();

		AlertDialogs("Information!!", "Plz Update latest version","AppUpdate");
		return;
	}


	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{
					if(Type.equalsIgnoreCase("AppUpdate"))
					{
						final String appPackageName = getPackageName(); // package name of the app
						try 
						{
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
						} catch (android.content.ActivityNotFoundException anfe) {
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
						}


						//Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id="+ Check_Updates.this.getPackageName()));



					}


					dialog.dismiss();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
}