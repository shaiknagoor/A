package com.aponline.mvcppp;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.aponline.mvcppp.R;
import com.aponline.mvcppp.database.DBAdapter;
import com.aponline.mvcppp.server.RequestServer;
import com.aponline.mvcppp.server.ServerResponseListener;
import com.aponline.mvcppp.server.WebserviceCall;

public class Travelled_Kms extends AppCompatActivity implements OnClickListener,ServerResponseListener
{


	Context context;
	DBAdapter db;
	ActionBar ab;
	LinearLayout slideMenuLL;
	RelativeLayout userDetailsLL;
	TextView Total_KmsEt;
	EditText Opening_KmsEt,Closing_KmsEt;
	TableLayout tl ;
	String Attendance_Status;
	StringBuilder XmlDoc,ChildXml;
	String MID,villageName,villageID,FarmerName,FarmerAdhaar,UniqueID,DistID,DivID,HQ_OpeningKm,Day,Date_Time,HQID,DayID,Pending_HQ_Km_AutoID;
	@SuppressLint("NewApi")
	protected void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.travelled_kms);
		context=this;


		db=new DBAdapter(this);
		ab=getSupportActionBar();
		ab.setTitle("Travel Details");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal)));
		ab.setDisplayHomeAsUpEnabled(true);

		Opening_KmsEt=(EditText) findViewById(R.id.Opening_KmsEt);
		Closing_KmsEt=(EditText) findViewById(R.id.Closing_KmsEt);
		Total_KmsEt=(TextView) findViewById(R.id.Total_KmsEt);
		findViewById(R.id.KmSubmitBt).setOnClickListener(this);


		Boolean timeStatus=	isTimeAutomatic(context);

		if(timeStatus==false)
		{
			AlertDialogs("Information!!", "Enable Auto date & time ","AutoDateTime");

		}


		Calendar calendar = Calendar.getInstance();
		//date format is:  "Date-Month-Year Hour:Minutes am/pm"

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); //Date and time
		Date_Time = sdf.format(calendar.getTime());

		SimpleDateFormat sdf_ = new SimpleDateFormat("EEEE"); 
		Date date = new Date();
		Day = sdf_.format(date);

		try {


			db.open();
			Cursor cursor=db.getTableDataCursor("SELECT DistrictID,DivisionID from Login_UserDetails where UserID='"+HomeData.userID+"'");
			if (cursor.getCount() > 0) 
			{
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) 
				{
					DistID=cursor.getString(0);
					DivID=cursor.getString(1);
					//MandalID=cursor.getString(2);
				}
				//MandalTv.setText(db.getSingleValue("select distinct MandalName from Master_Mandal where DistrictID='"+DistID+"' and DivisionID='"+DivID+"' and MandalID='"+MandalID+"'"));
			}
			cursor.close();
			db.close();

			db.open();

			((TextView)findViewById(R.id.HeadQuarterTv)).setText("Head Quarter Name : "+db.getSingleValue("select distinct MVCHeadQuarter_Name from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"'"));
			HQID=db.getSingleValue("select distinct MVCHeadQuarterID from Master_MVC_New where DistrictID='"+DistID+"' and DivisionID='"+DivID+"' ");

			db.close();

			if(HQID.equalsIgnoreCase("0"))
			{
				RequestServer request1=new RequestServer(Travelled_Kms.this);
				request1.addParam("DeviceID", HomeData.sDeviceId);
				request1.ProccessRequest(Travelled_Kms.this, "Download_VillageData");
			}

		} catch (Exception e) 
		{
			e.printStackTrace();
		}


		try 
		{
			db.open();

			HQ_OpeningKm=db.getSingleValue("select IFNULL(HQ_OpeningReading,'false') from HeadQuarter_Travel_Details where UserID='"+HomeData.userID+"' and  Date_Time='"+Date_Time+"' and Status='P' order by Auto_ID DESC LIMIT 1");


			Cursor cursor=db.getTableDataCursor("select  Auto_ID,HQ_OpeningReading,Date_Time from HeadQuarter_Travel_Details where UserID='"+HomeData.userID+"'  and Status='P' and Date_Time NOT LIKE '"+Date_Time+"'");
			if (cursor.getCount() > 0) 
			{
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) 
				{


					AlertDialogs("Information!!","Your not enter Closing Km for this Date :"+cursor.getString(2),"Travel_Pending");
					Pending_HQ_Km_AutoID=cursor.getString(0);
					HQ_OpeningKm=cursor.getString(1);
					Date_Time=cursor.getString(2);

					Closing_KmsEt.setError("Kms for This Date "+cursor.getString(2));
					Closing_KmsEt.requestFocus();
					//String ss=cursor.getString(cursor.getColumnIndex("HQ_OpeningReading"));
				}

			}
			cursor.close();
			db.close();
		} catch (Exception e) 
		{
			e.printStackTrace();
		}

		if(HQ_OpeningKm.equalsIgnoreCase("0"))
		{
			((LinearLayout)findViewById(R.id.HQ_ClosingReadingll)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.HQ_totalKmll)).setVisibility(View.GONE);
		}else 
		{
			Opening_KmsEt.setText(HQ_OpeningKm);
			Opening_KmsEt.setEnabled(false);
			((LinearLayout)findViewById(R.id.HQ_ClosingReadingll)).setVisibility(View.VISIBLE);
			((LinearLayout)findViewById(R.id.HQ_totalKmll)).setVisibility(View.VISIBLE);
		}



		//Settings.Global.putInt(getContentResolver(),Settings.Global.AUTO_TIME_ZONE, autoZoneEnabled ? 1 : 0);
		//startActivityForResult(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS), 0);










		//		try {
		//
		//
		//
		//			db.open();
		//			Attendance_Status=db.getSingleValue("select distinct Attendance_Status from Attendance_Travel_Details where Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
		//			String Travel_Status=db.getSingleValue("select distinct Travel_Status from Attendance_Travel_Details where  Final_Status='p' and CreatedBy='"+HomeData.userID+"'");
		//
		//			db.close();
		//
		//
		//			if(!Attendance_Status.equalsIgnoreCase("D"))
		//			{
		//
		//				AlertDialogs("Information!!", "Enter Attendance Details","Attendance_Status");
		//
		//			}else if(Travel_Status.equalsIgnoreCase("D"))
		//			{
		//				AlertDialogs("Information!!", "Already Travel Details Entered","Travel_Status");
		//
		//			}
		//
		//		} catch (Exception e) 
		//		{
		//			e.printStackTrace();
		//		}

		Opening_KmsEt.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,int after) 
			{


			}

			@Override
			public void afterTextChanged(Editable s)
			{

				try {

					if(findViewById(R.id.HQ_totalKmll).getVisibility()==View.VISIBLE)

					{

						String Opening_Kms=Opening_KmsEt.getText().toString();
						String Closing_Kms=Closing_KmsEt.getText().toString();

						if(Opening_Kms.equalsIgnoreCase(""))
							Opening_Kms="0";

						if(Closing_Kms.equalsIgnoreCase(""))
							Closing_Kms="0";

						//				if(!Opening_Kms.equalsIgnoreCase("0"))
						//				{

						if(!Closing_Kms.equalsIgnoreCase("0") && Float.parseFloat(Closing_Kms)>Float.parseFloat(Opening_Kms))
						{
							Total_KmsEt.setText(Float.toString(Float.parseFloat(Closing_Kms)-Float.parseFloat(Opening_Kms)));
						}else 
						{
							Closing_KmsEt.requestFocus();
							Closing_KmsEt.setError("Enter Valid Data");
							Total_KmsEt.setText("");
						}


					}

					//				}else {
					//					Opening_KmsEt.requestFocus();
					//					Opening_KmsEt.setError("");
					//				}
				} catch (Exception e) 
				{
					e.printStackTrace();
				}


			}

		});

		Closing_KmsEt.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,int after) 
			{


			}

			@Override
			public void afterTextChanged(Editable s) 
			{

				try {


					String Opening_Kms=Opening_KmsEt.getText().toString();
					String Closing_Kms=Closing_KmsEt.getText().toString();

					if(Opening_Kms.equalsIgnoreCase(""))
						Opening_Kms="0";

					if(Closing_Kms.equalsIgnoreCase(""))
						Closing_Kms="0";

					//				if(!Opening_Kms.equalsIgnoreCase("0"))
					//				{

					if(!Closing_Kms.equalsIgnoreCase("0") && Float.parseFloat(Closing_Kms)>Float.parseFloat(Opening_Kms))
					{
						Total_KmsEt.setText(Float.toString(Float.parseFloat(Closing_Kms)-Float.parseFloat(Opening_Kms)));
					}else 
					{
						Closing_KmsEt.requestFocus();
						Closing_KmsEt.setError("Enter Valid Data");
						Total_KmsEt.setText("");
					}



					//				}else 
					//				{
					//					Opening_KmsEt.requestFocus();
					//					Opening_KmsEt.setError("Enter Opening kms");
					//				}


				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	@SuppressLint("NewApi")

	public static boolean isTimeAutomatic(Context c) 
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) 
		{
			return Settings.Global.getInt(c.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
		} else 
		{
			return android.provider.Settings.System.getInt(c.getContentResolver(), android.provider.Settings.System.AUTO_TIME, 0) == 1;

		}
	}

	private void Travel_Validation() 
	{

		float Opening_Kms=0,Latest_Kms=0,closing_Kms=0;

		if(!Opening_KmsEt.getText().toString().equalsIgnoreCase("") && !Opening_KmsEt.getText().toString().equalsIgnoreCase("."))
		{
			Opening_Kms= Float.valueOf(Opening_KmsEt.getText().toString().trim()).floatValue();


		}
		if(((LinearLayout)findViewById(R.id.HQ_ClosingReadingll)).getVisibility()==View.VISIBLE && !Closing_KmsEt.getText().toString().equalsIgnoreCase("") && !Closing_KmsEt.getText().toString().equalsIgnoreCase("."))
		{
			try {


				closing_Kms= Float.valueOf(Closing_KmsEt.getText().toString().trim()).floatValue();
				db.open();

				//String HqKm=db.getSingleValue("select HQ_OpeningReading from HeadQuarter_Travel_Details where UserID='"+HomeData.userID+"' and Date_Time='"+Date_Time+"' and  Status='P'");
				String HqKm=db.getSingleValue("select max(v.OpeningReading) as highestReading from (select HQ_OpeningReading as OpeningReading from HeadQuarter_Travel_Details "
						+ "where UserID='"+HomeData.userID+"'  and  Date_Time='"+Date_Time+"' and Status='P' union all select Travel_Closing_Km from Attendance_Travel_Details where CreatedBy='"+HomeData.userID+"'  "
						+ "and  Attendance_Visit_Date='"+Date_Time+"' and Travel_Status='P')v");
				db.close();
				Latest_Kms= Float.valueOf(HqKm).floatValue();

			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}

		if (Opening_KmsEt.getText().toString().equalsIgnoreCase("") )
		{
			Opening_KmsEt.setError("Enter Opening Kms");
			Opening_KmsEt.requestFocus();
			return;
		}
		else if (!(Opening_Kms >=1))
		{
			Opening_KmsEt.setError("Enter Valid Kms");
			Opening_KmsEt.requestFocus();

			return ;

		}
		else if (((LinearLayout)findViewById(R.id.HQ_ClosingReadingll)).getVisibility()==View.VISIBLE && Closing_KmsEt.getText().toString().equalsIgnoreCase(""))
		{
			Closing_KmsEt.setError("Enter Closing Reading Kms");
			Closing_KmsEt.requestFocus();

			return ;

		}
		else if (((LinearLayout)findViewById(R.id.HQ_ClosingReadingll)).getVisibility()==View.VISIBLE && !(closing_Kms >Latest_Kms))
		{
			Closing_KmsEt.setError("Closing Reading Kms < Latest Kms "+Latest_Kms);
			Closing_KmsEt.requestFocus();

			return ;

		}
		else if (((LinearLayout)findViewById(R.id.HQ_ClosingReadingll)).getVisibility()==View.VISIBLE && Closing_KmsEt.getText().toString().equalsIgnoreCase(""))
		{
			Closing_KmsEt.setError("Enter Closing Kms");
			Closing_KmsEt.requestFocus();
			return;
		}
		else if (((LinearLayout)findViewById(R.id.HQ_totalKmll)).getVisibility()==View.VISIBLE && Total_KmsEt.getText().toString().equalsIgnoreCase(""))
		{
			Closing_KmsEt.setError("Enter Valid Data");
			Closing_KmsEt.requestFocus();
			return;
		}

		else 
		{

			try {



				//				Calendar calendar = Calendar.getInstance();
				//				//date format is:  "Date-Month-Year Hour:Minutes am/pm"
				//				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm a"); //Date and time
				//				String SQLDate_Time = sdf.format(calendar.getTime());

				SimpleDateFormat sdf_ = new SimpleDateFormat("EEEE"); 
				Date date = new Date();
				Day = sdf_.format(date);

				db.open();
				DayID=db.getSingleValue("select  DayID from Master_WeekDay where   WeekDay='"+Day+"'");
				db.close();

				ContentValues TravelKmDetailsCV=new ContentValues();

				if((findViewById(R.id.HQ_ClosingReadingll)).getVisibility()==View.VISIBLE && (findViewById(R.id.HQ_totalKmll)).getVisibility()==View.VISIBLE)
				{

					TravelKmDetailsCV.put("HQ_ClosingReading",Closing_KmsEt.getText().toString());
					TravelKmDetailsCV.put("Total_Km",Total_KmsEt.getText().toString());
					TravelKmDetailsCV.put("Status","D");


					db.open();

					db.updateTableData("HeadQuarter_Travel_Details", TravelKmDetailsCV, "UserID='"+HomeData.userID+"' and  Date_Time='"+Date_Time+"' and Status='P'");
					db.execSQL("UPDATE Attendance_Travel_Details SET Travel_Status = 'D' WHERE CreatedBy ='"+HomeData.userID+"' and Travel_Status='P' and Attendance_Visit_Date='"+Date_Time+"'");
					db.close();





					XmlDoc=new StringBuilder();
					db.open();
					Cursor cursor=db.getTableDataCursor("select Auto_ID,UserID,HQID,HQ_OpeningReading,HQ_ClosingReading,Total_Km,Day"
							+ ",Date_Time from HeadQuarter_Travel_Details where Status='D' and UserID='"+HomeData.userID+"'");
					if (cursor.getCount() > 0) 
					{
						for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) 
						{
							UniqueID=cursor.getString(cursor.getColumnIndex("Auto_ID"));


							XmlDoc.append("<HQ_Travel_Details>");

							XmlDoc.append("<UserID>"+cursor.getString(cursor.getColumnIndex("UserID"))+"</UserID>");
							XmlDoc.append("<HQID>"+cursor.getString(cursor.getColumnIndex("HQID"))+"</HQID>");
							XmlDoc.append("<HQ_OpeningReading>"+cursor.getString(cursor.getColumnIndex("HQ_OpeningReading"))+"</HQ_OpeningReading>");
							XmlDoc.append("<HQ_ClosingReading>"+cursor.getString(cursor.getColumnIndex("HQ_ClosingReading"))+"</HQ_ClosingReading>");
							XmlDoc.append("<Total_Km>"+cursor.getString(cursor.getColumnIndex("Total_Km"))+"</Total_Km>");
							XmlDoc.append("<Day>"+cursor.getString(cursor.getColumnIndex("Day"))+"</Day>");
							XmlDoc.append("<Date_Time>"+cursor.getString(cursor.getColumnIndex("Date_Time"))+"</Date_Time>");

							XmlDoc.append("</HQ_Travel_Details>");


						}
					}
					cursor.close();

					ContentValues data=new ContentValues();
					data.put("METHOD_NAME", "MVCS_HQReadingDetails_Insert");
					data.put("XMLDATA", XmlDoc.toString());
					data.put("CreatedBy", HomeData.userID);
					data.put("UniqueID",UniqueID);


					long rowid= db.insertTableDate("UPLOAD_OFFLINEDATA",data);
					db.execSQL("UPDATE HeadQuarter_Travel_Details SET Status = 'N' WHERE UserID='"+HomeData.userID+"' and  Status='D'");
					db.close();

					AlertDialogs("Information!!", "Head Quarter Closing Kms Details Successfully Submitted ","DataSubmit");
				}
				else {



					TravelKmDetailsCV.put("UserID", HomeData.userID);
					TravelKmDetailsCV.put("HQ_OpeningReading",Opening_KmsEt.getText().toString());
					TravelKmDetailsCV.put("HQID",HQID);
					TravelKmDetailsCV.put("Day",DayID);
					TravelKmDetailsCV.put("Date_Time",Date_Time);
					TravelKmDetailsCV.put("Status","P");


					db.open();
					db.insertTableDate("HeadQuarter_Travel_Details",TravelKmDetailsCV);
					//db.updateTableData("Attendance_Travel_Details", TravelKmDetailsCV, "CreatedBy='"+HomeData.userID+"' and Attendance_Status='D' and Final_Status='p'");
					db.close();
					AlertDialogs("Information!!", "Head Quarter Opening Kms Details Successfully Submitted ","DataSubmit");
				}







				//db.execSQL("UPDATE Mobile_Veterinary_Clinics_FullDetails set Final_Status='N' where RowID='"+UniqueID+"' and CreatedBy='"+HomeData.userID+"'");
				//db.close();

			}
			catch (Exception e) 
			{
				Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show();
			}
		}
	}


	public void AlertDialogs(String title, String msg,final String Type)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				try 
				{

					if(Type.equalsIgnoreCase("DownloadVillage"))
					{
						startActivity(new Intent(Travelled_Kms.this, Travelled_Kms.class));
						finish();
					}
					if(Type.equalsIgnoreCase("Travel_Pending"))
					{

						//startActivityForResult(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS), 0);
					}

					if(Type.equalsIgnoreCase("AutoDateTime")){

						startActivityForResult(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS), 0);
					}

					if(Type.equalsIgnoreCase("Attendance_Status")){

						Intent intent = new Intent(Travelled_Kms.this, Attendance_Act.class);
						startActivity(intent);
						Travelled_Kms.this.finish();
					}

					if(Type.equalsIgnoreCase("DataSubmit") || Type.equalsIgnoreCase("Travel_Status")){

						//						Intent intent = new Intent(Travelled_Kms.this, HomePage.class);
						//						startActivity(intent);
						//						Travelled_Kms.this.finish();
						
//						Intent intent = new Intent(Travelled_Kms.this, HomePage.class);
//						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//						startActivity(intent);
						Submit();
					}


					dialog.dismiss();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		getMenuInflater().inflate(R.menu.main, menu);
		MenuItem item=menu.findItem(R.id.logout);
		item.setVisible(false);
		MenuItem item1=menu.findItem(R.id.village_download);
		item1.setVisible(true);
		return super.onCreateOptionsMenu(menu);
	}


	public void YesNoAlert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("MVC (PPP MODE)");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();

				if (type.equalsIgnoreCase("Download_VillageData")) 
				{
					RequestServer request1=new RequestServer(Travelled_Kms.this);
					request1.addParam("DeviceID", HomeData.sDeviceId);
					request1.ProccessRequest(Travelled_Kms.this, "Download_VillageData");		
				}

			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int i=item.getItemId();

		if(i==R.id.village_download)
		{
			YesNoAlert("you want to Download New Villages","Download_VillageData");

		}

		return super.onOptionsItemSelected(item);
	}



	public void Success(String response) 
	{
		//Dialogs.AlertDialogs(Attendance_Act.this,"Information!!", ""+WebserviceCall.serverUploadcount+" Record's Successfully Uploaded");
		if(WebserviceCall.serverUploadcount>0)
		{
			AlertDialogs("Information!!", ""+WebserviceCall.serverUploadcount+" Villages Successfully Updated","DownloadVillage");
		}else 
		{
			AlertDialogs("Information!!", "No New Villages To Download","DownloadVillage");
		}

	}
	@Override
	public void Fail(String response) 
	{
		
		Toast toast=Toast.makeText(this, "No Villages Available", Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.show();

	}
	@Override
	public void NetworkNotAvail() {
		// TODO Auto-generated method stub

	}
	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub

	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.KmSubmitBt:
			Travel_Validation();
			break;

		default:
			break;
		}

	}
	@Override
	protected void onRestart() 
	{
		super.onRestart();
		Boolean timeStatus=	isTimeAutomatic(context);
		if(timeStatus==false)
		{
			AlertDialogs("Information!!", "Enable Auto date & time ","AutoDateTime");

		}

	}

	@Override
	public void onBackPressed() 
	{
		super.onBackPressed();
	}
	public void Submit()
	{
		super.onBackPressed();
	}
}
