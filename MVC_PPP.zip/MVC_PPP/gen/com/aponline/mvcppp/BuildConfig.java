/** Automatically generated file. DO NOT MODIFY */
package com.aponline.mvcppp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}