/** Automatically generated file. DO NOT MODIFY */
package com.aponline.cropsurvey;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}