package com.aponline.cropsurvey;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aponline.cropsurvey.database.DBAdapter;
import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class Home_Screen  extends AppCompatActivity 
{
	Spinner financial_year,season;
	Button submit;
	DBAdapter db;
	ProgressDialog progressDialog;
	Handler mHandler;
	Context context;
	ActionBar ab;
	ContentValues cv;
	CheckConnection conn_obj;
	String headquarter_id,district_id,user_id,adh;
	String fin_year;
	List Season_list;
	List Fin_year_list;
	ArrayAdapter<String> seasonAdapter;
	ArrayAdapter<String> finYearAdapter;
	private void Loaddata(final String methodName,final ContentValues cv)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{


					ContentValues cv2=new ContentValues();
					cv2.put("strDistrictId",district_id);
					cv2.put("strHeadQuarterId",headquarter_id);
					cv2.put("strfinyear",financial_year.getSelectedItem().toString());
					cv2.put("strADH",adh);
					cv2.put("strseason",season.getSelectedItem().toString());
					cv2.put("strareatype","AA");
					cv2.put("USER_ID",user_id.trim());
					Loaddata("GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS", cv2);
				}
				if(paramMessage.what==22)
				{


					db.open();

					ContentValues cv2=new ContentValues();
					cv2.put("USER_ID",user_id);
					cv2.put("STATUS","Y");
					cv2.put("SEASON",season.getSelectedItem().toString());
					cv2.put("FIN_YEAR",financial_year.getSelectedItem().toString());
					db.insertTableDate("LOGIN_CHECK_MASTER",cv2);
					db.close();


					HomeData.SaveSeasonFinancial(Home_Screen.this,season.getSelectedItem().toString(),financial_year.getSelectedItem().toString());
					Intent intent=new Intent(Home_Screen.this,CropDataEntry.class);								
					startActivity(intent);

				}

				if(paramMessage.what==15)
				{
					if(cv.getAsString("STATUS").equalsIgnoreCase("true"))
					{
						if(cv.size()>3)
						{
							if(cv.getAsString("NORMALAREA_STATUS").equalsIgnoreCase("Y"))
							{
								db.open();							
								String check_status=db.getSingleValue("select STATUS from LOGIN_CHECK_MASTER where USER_ID='"+user_id.trim()+"' and SEASON='"+season.getSelectedItem().toString()+"' and FIN_YEAR='"+financial_year.getSelectedItem().toString()+"'");
								db.close();
								if(check_status.equalsIgnoreCase("Y"))
								{

									HomeData.SaveSeasonFinancial(Home_Screen.this,season.getSelectedItem().toString(),financial_year.getSelectedItem().toString());
									Intent intent=new Intent(Home_Screen.this,CropDataEntry.class);								
									startActivity(intent);
								}
								else
								{

									ContentValues cv2=new ContentValues();
									cv2.put("strDistrictId",cv.getAsString("DISTRICT_ID"));
									cv2.put("strHeadQuarterId",cv.getAsString("HEADQUARTER_ID"));
									cv2.put("strfinyear",financial_year.getSelectedItem().toString());
									cv2.put("strADH",adh);
									cv2.put("strseason",season.getSelectedItem().toString());
									cv2.put("strareatype","NA");
									cv2.put("USER_ID",user_id.trim());
									Loaddata("GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS", cv2);
								}
							}
							else
							{
								HomeData.SaveSeasonFinancial(Home_Screen.this,season.getSelectedItem().toString(),financial_year.getSelectedItem().toString());
								Intent intent=new Intent(Home_Screen.this,CropRegistration.class);								
								startActivity(intent);
							}
						}
					}
					else
					{
						Toast toast = null;
						toast=Toast.makeText(Home_Screen.this, "Please Enter Correct Username/Password",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}

				}
				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(Home_Screen.this, "Please Try Agian",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.BOTTOM, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Home_Screen.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==	98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Home_Screen.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Home_Screen.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName,cv);
		this.conn_obj.checkNetworkAvailability();
		return;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_screen);
		financial_year=(Spinner)findViewById(R.id.homescreen_financial_year);
		season=(Spinner)findViewById(R.id.homescreen_season);
		submit=(Button)findViewById(R.id.homescreen_btn);
		db=new DBAdapter(this);
		context=this;
		SharedPreferences prefs1= getSharedPreferences("Login",MODE_PRIVATE);		
		headquarter_id=	prefs1.getString("headquarter_id","");	
		district_id=	prefs1.getString("district_id","");	
		user_id=prefs1.getString("user_id","");	
		adh=prefs1.getString("adh","");
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		this.ab=getSupportActionBar();
		ab.setTitle("Fin year & Season Selection");
		ab.setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_gradient_shape));
		ab.setHomeButtonEnabled(true);
		ab.setDisplayHomeAsUpEnabled(true);
		Season_list=new ArrayList<String>();
		Fin_year_list=new ArrayList<String>();

		final Date d=new Date();
		final SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate1 = df.format(d);
		try
		{
//			if( d.after( df.parse("01/11/2016")) && d.before(df.parse("28/02/2017")))
//			{
//				Season_list.add("KHARIF");
//				Season_list.add("RABI");
//				//season="RABI";
//
//			}
//			if(d.after(df.parse("01/03/2017")) && d.before(df.parse("30/06/2017")))
//			{
//				Season_list.add("SUMMER");
//				Season_list.add("RABI");
//				//season="SUMMER";
//
//			}
//			if(d.after(df.parse("01/07/2017")) && d.before(df.parse("31/10/2017")))
//			{
//				Season_list.add("SUMMER");
//				Season_list.add("KHARIF");
//				//season="KHARIF";
//
//			}
//			if(d.after(df.parse("1/11/2017")) &&  d.before(df.parse("28/2/2018")))
//			{
//				Season_list.add("KHARIF");
//				Season_list.add("RABI");
//				//season="RABI";
//
//			}
//			if(d.after(df.parse("01/03/2018")) && d.before(df.parse("30/06/2018")))
//			{
//				Season_list.add("SUMMER");
//				Season_list.add("RABI");
//				//season="SUMMER";
//
//			}
//			if(d.after(df.parse("01/07/2018")) && d.before(df.parse("31/10/2018")))
//			{
//				Season_list.add("SUMMER");
//				Season_list.add("KHARIF");
//				//season="KHARIF";
//
//			}
//			if(d.after(df.parse("1/11/2018")) &&  d.before(df.parse("28/2/2019")))
//			{
//				Season_list.add("RABI");
//				Season_list.add("KHARIF");
//				//season="RABI";
//
//			}
			if(d.after(df.parse("29/02/2016")) && d.before(df.parse("01/03/2017")))
			{
				fin_year="2016-2017";
				Fin_year_list.add("--Select--");
				Fin_year_list.add("2016-2017");
			}
			if(d.after(df.parse("28/02/2017")) && d.before(df.parse("01/03/2018")))
			{
				fin_year="2017-2018";
				if(d.after(df.parse("01/07/2017")) && d.before(df.parse("28/02/2018")))
				{
					Fin_year_list.add("--Select--");			
					Fin_year_list.add("2017-2018");
				}
				else
				{
					Fin_year_list.add("--Select--");
					Fin_year_list.add("2016-2017");
					Fin_year_list.add("2017-2018");
				}
	
			}
			if(d.after(df.parse("28/02/2018")) && d.before(df.parse("01/03/2019")))
			{
				fin_year="2018-2019";
				if(d.after(df.parse("01/08/2018")) && d.before(df.parse("28/02/2019")))
				{
					Fin_year_list.add("--Select--");			
					Fin_year_list.add("2018-2019");
				}
				else
				{
					Fin_year_list.add("--Select--");
					Fin_year_list.add("2017-2018");
					Fin_year_list.add("2018-2019");				
				}

			}
		}
		catch(Exception e)
		{

		}

		finYearAdapter = new ArrayAdapter<String>(Home_Screen.this,android.R.layout.simple_spinner_item,Fin_year_list);
		finYearAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		financial_year.setAdapter(finYearAdapter);

		seasonAdapter = new ArrayAdapter<String>(Home_Screen.this,android.R.layout.simple_spinner_item,Season_list);
		seasonAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		season.setAdapter(seasonAdapter);

		financial_year.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				int i=(int)arg3;
				Season_list.clear();
				season.setAdapter(null);
				if(i!=0)
				{
					
					if(financial_year.getSelectedItem().toString().equalsIgnoreCase("2016-2017"))
					{
						try
						{

							if(d.after(df.parse("28/02/2017")) && d.before(df.parse("30/06/2017")))
							{		
								Season_list.add("--Select--");
							
								Season_list.add("RABI");						

							}

						}catch(Exception e)
						{

						}
					}
					if(financial_year.getSelectedItem().toString().equalsIgnoreCase("2017-2018"))
					{
						try
						{
							
						if(d.after(df.parse("28/02/2017")) && d.before(df.parse("30/06/2017")))
						{
							Season_list.add("--Select--");
							Season_list.add("SUMMER");	
						}
						else if(d.after(df.parse("01/07/2017")) && d.before(df.parse("31/10/2017")))
						{
							Season_list.add("--Select--");
							Season_list.add("KHARIF");
							Season_list.add("SUMMER");
					
						}
						else if(d.after(df.parse("1/11/2017")) &&  d.before(df.parse("28/2/2018")))
						{
							Season_list.add("--Select--");
							Season_list.add("RABI");
							Season_list.add("KHARIF");	

						}
						else
						{
							Season_list.add("RABI");
						}

						}
						
						catch(Exception e)
						{
							
						}
					}
						if(financial_year.getSelectedItem().toString().equalsIgnoreCase("2018-2019"))
						{
							try
							{
								if(d.after(df.parse("28/02/2018")) && d.before(df.parse("30/06/2018")))
								{
									Season_list.add("--Select--");
									Season_list.add("SUMMER");
	
								}
								else if(d.after(df.parse("01/07/2018")) && d.before(df.parse("31/10/2018")))
								{
									Season_list.add("--Select--");
									Season_list.add("KHARIF");
									Season_list.add("SUMMER");
									
									//season="KHARIF";

								}
								else if(d.after(df.parse("1/11/2018")) &&  d.before(df.parse("28/2/2019")))
								{
									Season_list.add("--Select--");
									Season_list.add("RABI");
									Season_list.add("KHARIF");

								}
							
							}
							catch(Exception e)
							{
								
							}
					}
					
	
				}
				seasonAdapter = new ArrayAdapter<String>(Home_Screen.this,android.R.layout.simple_spinner_item,Season_list);
				seasonAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				season.setAdapter(seasonAdapter);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {


			}
		});
		season.setOnItemSelectedListener(new OnItemSelectedListener() 
		{

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3)
			{


			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) 
			{


			}
		});


		submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) 
			{

				if(financial_year.getSelectedItemPosition()==0)
				{
					financial_year.requestFocusFromTouch();
					return;
				}
				if(season.getSelectedItemPosition()==0)
				{
					season.requestFocusFromTouch();
					return;
				}

				db.open();							
				String check_status=db.getSingleValue("select STATUS from LOGIN_CHECK_MASTER where USER_ID='"+user_id+"' and SEASON='"+season.getSelectedItem().toString()+"' and FIN_YEAR='"+financial_year.getSelectedItem().toString()+"'");
				db.close();
				if(check_status.equalsIgnoreCase("Y"))
				{
					HomeData.SaveSeasonFinancial(Home_Screen.this,season.getSelectedItem().toString(),financial_year.getSelectedItem().toString());
					Intent intent=new Intent(Home_Screen.this,CropDataEntry.class);								
					startActivity(intent);
				}
				else
				{
					boolean a=	CheckConnection.isNetworkAvailable(Home_Screen.this);
					if(a==false)
					{
						Toast toast = null;
						toast=Toast.makeText(Home_Screen.this, "Please Submit Online for Current Selection of Season and Financial Year",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
					else
					{
						ContentValues cv=new ContentValues();
						cv.put("UserId",user_id);
						cv.put("Password","PASSWORD");
						cv.put("strseason",season.getSelectedItem().toString());
						cv.put("strfinyear",financial_year.getSelectedItem().toString());
						Loaddata("CheckVegAppUserAuthentication",cv);
					}

				}

			}
		});

	}

}
