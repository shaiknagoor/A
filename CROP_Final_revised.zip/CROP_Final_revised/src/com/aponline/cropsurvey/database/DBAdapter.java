package com.aponline.cropsurvey.database;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;





import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

public class DBAdapter 
{
	private static final String TAG = "DBAdapter";

	public static  String DATABASE_NAME ="CROP_SURVEY_DB1.db";
	//public static  String DATABASE_NAME = "";
	private static final int DATABASE_VERSION = 1;
	private static String DB_PATH = ""; 
	private final Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase db;


	public DBAdapter(Context ctx)   
	{
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}

	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		DatabaseHelper(Context context)
		{
			
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			Log.d(TAG, "DATABASE Successfully Created");
			if(android.os.Build.VERSION.SDK_INT >= 17)
			{
				DB_PATH = context.getApplicationInfo().dataDir + "/databases/";         
			}
			else
			{
				DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
			}

			System.out.println("-----"+DB_PATH);
		}
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			try
			{
				Log.d(TAG, "Table Successfully Created");
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{
			Log.w(TAG, oldVersion + " to " + newVersion+ ", which will destroy all old data");

		
			if (newVersion > oldVersion) {
				System.out.println("----------entered");
				
			}
		}
	}
	public void createNewTable()
	{
		Log.w(TAG, "::::::Inside Create New Table::::::");
	
		System.out.println("----after ");
	}
	public DBAdapter open() throws SQLException 
	{
		db = DBHelper.getWritableDatabase();
		return this;
	}

	public void close()
	{
		DBHelper.close();
	}

	public synchronized long insertTableDate(String TableName, ContentValues contentValues)
	{
		//Log.d(TAG, "DATA INSERTED");
		return db.insert(TableName, null, contentValues);
	}
	public synchronized void execSQL(String query)
	{
		db.execSQL(query);
	}
	public synchronized void AlterTable(String query)
	{
		db.execSQL(query);
	}
	//	public long updateTableDate(String TableName, ContentValues contentValues,String whereClause)
	//	{	
	//		return db.update(TableName, contentValues, whereClause, null);
	//	}
	public synchronized boolean deleteTableData(String tableName,String whereClause) 
	{
		return db.delete(tableName, whereClause, null) > 0;
	}

	public Cursor getAllTableData(String tableName,String[] columnNames) 
	{
		System.out.println("-------------bable-=============");
		return db.query(tableName,columnNames, null, null, null, null, null);

	}

	public Cursor getAllTableData(String tableName,String[] columnNames,String whereCondition) throws SQLException
	{
		Cursor mCursor = db.query(true, tableName,columnNames, whereCondition,null, null, null, null, null);
		if (mCursor != null)
		{
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	public synchronized boolean updateTableData(String tableName,ContentValues values,String whereCondition)
	{
		return db.update(tableName, values,whereCondition, null) > 0;
	}

	public List<String> getSpinnerDatacrop(String query)
	{
		List<String> data = new ArrayList<String>();

		// Select All Query


		Cursor cursor = db.rawQuery(query, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst())
		{

			do {
				data.add(cursor.getString(0));
			} while (cursor.moveToNext());
		}
		db.close();


		// closing connection
		cursor.close();

		// returning lables
		return data;
	}
	public List<String> getSpinnerData(String query)
	{
		List<String> data = new ArrayList<String>();
		data.add("---Select---");
		// Select All Query
		System.out.println(query);
		Cursor cursor = db.rawQuery(query, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst())
		{

			do {
				data.add(cursor.getString(0));
			} while (cursor.moveToNext());
		}
		db.close();
		// closing connection
		cursor.close();
		// returning lables
		return data;
	}
	public Cursor getTableDataCursor(String query)
	{
		Cursor cursor = null;
		try
		{
			System.out.println("*****Query::::"+query);
			cursor = db.rawQuery(query, null);
		}
		catch(Exception localException)
		{
			localException.printStackTrace();
		}
		return cursor; 
	}

	public String getSingleValue(String query)
	{
		String value = "0";
		System.out.println(query);
		Cursor cursor = db.rawQuery(query, null);
		try
		{
			cursor.moveToFirst();
			value=cursor.getString(0);
		} catch (Exception e) {
		} finally {

			cursor.close();
		}
		return value;
	}
	public int getRowCount(String query)
	{
		int value = 0;
		System.out.println(query);

		Cursor cursor = db.rawQuery(query, null);
		try
		{
			cursor.moveToFirst();
			value=cursor.getInt(0);
		} catch (Exception e) {
		} finally {

			cursor.close();
		}
		return value;
	}
	public void createDataBase() throws IOException
	{
		boolean mDataBaseExist = checkDataBase();
		System.out.println("----"+mDataBaseExist);
		if(!mDataBaseExist)
		{
			db = DBHelper.getWritableDatabase();
			this.close();
			try 
			{
				//Copy the database from assests
				copyDataBase();
				Log.e(TAG, "----createDatabase database created");
			} 
			catch (IOException mIOException) 
			{
				throw new Error("ErrorCopyingDataBase");
			}
		}
	}
	//Check that the database exists here: /data/data/your package/databases/Da Name
	private boolean checkDataBase()
	{
		File dbFile = new File(DB_PATH + DATABASE_NAME);

		Log.v("dbFile", dbFile + "   "+ dbFile.exists());
		return dbFile.exists();
	}

	//Copy the database from assets
	private void copyDataBase() throws IOException
	{
		InputStream mInput = context.getAssets().open(DATABASE_NAME);
		String outFileName = DB_PATH +DATABASE_NAME;
		OutputStream mOutput = new FileOutputStream(outFileName);
		byte[] mBuffer = new byte[1024];
		int mLength;
		while ((mLength = mInput.read(mBuffer))>0)
		{
			mOutput.write(mBuffer, 0, mLength);
		}
		mOutput.flush();
		mOutput.close();
		mInput.close();
	}

	public void exportDB() {
		String DB_PATH = "";
		//DATABASE_NAME = "APMIP3.db";
		if (android.os.Build.VERSION.SDK_INT >= 17) {
			DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
		} else {
			DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
		}
		// File sd = Environment.getExternalStorageDirectory();
		// File data = Environment.getDataDirectory();
		FileChannel source = null;
		FileChannel destination = null;
		String currentDBPath = DB_PATH + DATABASE_NAME;
		String backupDBPath = Environment.getExternalStorageDirectory()
				+ "/APVeg/" + DATABASE_NAME;
		File currentDB = new File(currentDBPath);
		createDirIfNotExists(Environment.getExternalStorageDirectory()
				+ "/APVeg/");
		File backupDB = new File(backupDBPath);

		try {
			source = new FileInputStream(currentDB).getChannel();
			destination = new FileOutputStream(backupDB).getChannel();
			destination.transferFrom(source, 0, source.size());
			source.close();
			destination.close(); // Toast.makeText(this, "DB Exported!",
			// Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean createDirIfNotExists(String path) {
		boolean ret = true;

		File file = new File(path);
		if (!file.exists()) {
			if (!file.mkdirs()) {
				ret = false;
			}
		}
		
		return ret;
	}
}
