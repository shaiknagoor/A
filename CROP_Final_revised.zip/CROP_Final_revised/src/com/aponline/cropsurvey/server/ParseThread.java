package com.aponline.cropsurvey.server;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class ParseThread extends Thread
{

	Handler mUIHandler;
	Context mContext;
	String searchType;
	String methodName;
	String searchNo;
	ContentValues cv;
	String paramString1,paramString2,paramString3,paramString4,paramString5;
	ArrayList<ContentValues>a;
	public ParseThread(Context paramContext,Handler paramHandler, String methodName,String serchType,String searchNo)
	{
		this.mUIHandler = paramHandler;
		this.mContext=paramContext;
		this.methodName=methodName;
		this.searchType=serchType;
		this.searchNo=searchNo;
	}
	
	public ParseThread(Context paramContext,Handler paramHandler, String methodName,String paramString1,String paramString2,String paramString3,String paramString4) 
	{
		this.mUIHandler = paramHandler;
		this.mContext=paramContext;
		this.methodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
		this.paramString3=paramString3;
		this.paramString4=paramString4;
	}
	public ParseThread(Context paramContext,Handler paramHandler, String methodName,String paramString1,String paramString2,String paramString3,String paramString4,String paramString5) 
	{
		this.mUIHandler = paramHandler;
		this.mContext=paramContext;
		this.methodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
		this.paramString3=paramString3;
		this.paramString4=paramString4;
		this.paramString5=paramString5;
	}
	public ParseThread(Context mcontext, Handler mHandler, String methodName)
	{
		this.mUIHandler = mHandler;
		this.mContext=mcontext;
		this.methodName=methodName;
	}
	public ParseThread(Context mcontext, Handler mHandler, String methodName,
			ContentValues cv) {
		this.mUIHandler = mHandler;
		this.mContext=mcontext;
		this.methodName=methodName;
		this.cv=cv;
	}
	public ParseThread(Context mcontext, Handler mHandler, String methodName,
			ArrayList<ContentValues> a) {
		this.mUIHandler = mHandler;
		this.mContext=mcontext;
		this.methodName=methodName;
		this.a=a;
	}
	public void run()
	{
		Message localMessage = new Message();
		try {

			System.out.println("***********Inside Parsethread**********");
			//WebserviceCall com=new WebserviceCall(mContext);
			WebserviceCall com=new WebserviceCall(mContext);
			int i = 0;
	
			if(methodName.equalsIgnoreCase("GetHorticultureCROPDetails"))
			{	
				// i=com.GetHorticultureCROPDetails();				
			}
			if(methodName.equalsIgnoreCase("CheckAppVersion"))
			{	
				 i=com.CheckAppVersion();				
			}
			if(methodName.equalsIgnoreCase("GetVegitableCropDetails"))
			{	
				 i=com.GetVegitableCropDetails();				
			}
			if(methodName.equalsIgnoreCase("GetDistrictwiseHQ_MandalDetails"))
			{	
				 i=com.GetDistrictwiseHQ_MandalDetails();				
			}
			if(methodName.equalsIgnoreCase("InsertVegitableTotalAreaDetails"))
			{	
				 i=com.InsertVegitableTotalAreaDetails(a);				
			}
			if(methodName.equalsIgnoreCase("InsertVegitableActualAreaDetails"))
			{	
				 i=com.InsertVegitableActualAreaDetails(a);				
			}
			if(methodName.equalsIgnoreCase("UploadInsertVegitableActualAreaDetails"))
			{	
				 i=com.UploadInsertVegitableActualAreaDetails(cv);				
			}
			if(methodName.equalsIgnoreCase("UploadInsertVegitableTotalAreaDetails"))
			{	
				 i=com.UploadInsertVegitableTotalAreaDetails(cv);				
			}
			if(methodName.equalsIgnoreCase("GET_DistrictWise_CropDetails"))
			{	
				 i=com.GET_DistrictWise_CropDetails(cv);				
			}
			if(methodName.equalsIgnoreCase("Get_District_Mandal_HeadQuarter_Details"))
			{	
				 i=com.Get_District_Mandal_HeadQuarter_Details();				
			}
			if(methodName.equalsIgnoreCase("CheckVegAppUserAuthentication"))
			{	
				 i=com.CheckVegAppUserAuthentication(cv);				
			}
			if(methodName.equalsIgnoreCase("GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS"))
			{	
				 i=com.GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS(cv);				
			}
			if(methodName.equalsIgnoreCase("UpdateInsertVegitableTotalAreaDetails"))
			{	
				 i=com.UpdateInsertVegitableTotalAreaDetails(a);				
			}
			if(methodName.equalsIgnoreCase("Get_District_Mandal_HeadQuarter_Details"))
			{	
				 i=com.Get_District_Mandal_HeadQuarter_Details();				
			}
			
			Log.d("cricbuzz", "JSON PARSED");
			localMessage.what = i;
			if (this.mUIHandler != null)
			{
				Log.d("cricbuzz", "JSON SENT");
				this.mUIHandler.sendMessage(localMessage);
				Log.d("cricbuzz", "JSON AFTER SENT");
			}
			return;
		}catch (Exception e) 
		{
			while (true)
			{
				e.printStackTrace();
				localMessage.what = 98;
				return;
			}
		}
	}
}
