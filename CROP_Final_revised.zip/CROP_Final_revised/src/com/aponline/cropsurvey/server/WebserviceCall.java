package com.aponline.cropsurvey.server;


import java.io.IOException;


import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import com.aponline.cropsurvey.HomeData;
import com.aponline.cropsurvey.Login;
import com.aponline.cropsurvey.database.DBAdapter;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.preference.PreferenceManager;
import android.util.Log;


public class WebserviceCall extends Thread
{

	/**
	 * Variable Declaration................
	 * 
	 */
	public static String Error; 
	//	String namespace = "http://localhost/uatwebland/";http://crda.ap.gov.in/APCRDAWebservice/CRDA.asmx
	//private String url="http://webland.ap.gov.in/wspahani.asmx?";//wsdl

	//delete from DISTRICT_MASTER where DISTRICT_ID='00

	String namespace = "http://tempuri.org/";
//private String url="http://horticulturedept.ap.gov.in/gps/Hrtcvegitableappservice.asmx"; //live url
	
	private String url="http://61.246.226.123:8080/GPS/Hrtcvegitableappservice.asmx";//test url
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	Context paramContext;
	public static int serverUploadcount;
	public static String serverResponse,VersionNo,FidStatus;
	DBAdapter db;
	public static ArrayList<HashMap<String,String>> reports_data;
	String headquarter_id,district_id,user_id,adh;
	//	ArrayList<ArrayList<String>> mandaldata;
	//	ArrayList<ArrayList<String>> villagedata;
	//	ArrayList<ArrayList<String>> panchayatdata;
	//	public static ArrayList<HashMap<String, String>>data ;
	public WebserviceCall(Context paraContext)
	{
		this.paramContext=paraContext;
		db=new DBAdapter(paraContext); 

		//		SharedPreferences prefs1= paraContext.getSharedPreferences("Login",MODE_PRIVATE);		
		//		headquarter_id=	prefs1.getString("headquarter_id","");	
		//		district_id=	prefs1.getString("district_id","");	
		//		user_id=prefs1.getString("user_id","");	
		//		adh=prefs1.getString("adh","");

	}
	public int CheckAppVersion() {
		try
		{

			String methodName="CheckAppVersion";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace,methodName);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.


			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION,envelope);	


			String result1 = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result1);
			if(jsonArray.length()!=0)
			{ 
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return 100;
				}
				if(jsonObject.has("CurrentVersion"))
				{
					VersionNo=jsonObject.getString("CurrentVersion").toString();
				}
			}
			return 15;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			System.out.println("----"+androidHttpTransport.requestDump);
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}
	public int GetVegitableCropDetails() {

		try
		{

			String methodName="GetVegitableCropDetails";
			db.open();
			db.execSQL("delete from CROP_MASTER");
			db.close();
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					ContentValues contentValues=new ContentValues();
					if(jsonObject.has("CROP_CODE"))
					{
						contentValues.put("CROP_CODE", jsonObject.getString("CROP_CODE").trim());

					}if(jsonObject.has("CROP_NAME"))
					{
						contentValues.put("CROP_NAME",jsonObject.getString("CROP_NAME").trim());
					}



					if(contentValues!=null)
					{
						db.open();
						db.insertTableDate("CROP_MASTER",contentValues);			
						db.close();

					}
				}

			}


			return 32;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}
	public int GetDistrictwiseHQ_MandalDetails() 
	{
		try
		{

			String methodName="GetDistrictwiseHQ_MandalDetails";
			db.open();
			db.execSQL("delete from DISTRICT_HQ_MANDAL");
			db.close();
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("strdistrictid","");
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					ContentValues contentValues=new ContentValues();
					if(jsonObject.has("DISTRICT_ID"))
					{
						contentValues.put("DISTRICT_ID", jsonObject.getString("DISTRICT_ID").trim());

					}
					if(jsonObject.has("DISTRICT_DESCRIPTION"))
					{
						contentValues.put("DISTRICT_DESCRIPTION",jsonObject.getString("DISTRICT_DESCRIPTION").trim());
					}
					if(jsonObject.has("MANDAL_ID"))
					{
						contentValues.put("MANDAL_ID",jsonObject.getString("MANDAL_ID").trim());
					}

					if(jsonObject.has("MANDAL_NAME"))
					{
						contentValues.put("MANDAL_NAME",jsonObject.getString("MANDAL_NAME").trim());
					}
					if(jsonObject.has("HEADQUARTER_ID"))
					{
						contentValues.put("HEADQUARTER_ID",jsonObject.getString("HEADQUARTER_ID").trim());
					}
					if(jsonObject.has("HEADQUARTER_NAME"))
					{
						contentValues.put("HEADQUARTER_NAME",jsonObject.getString("HEADQUARTER_NAME").trim());
					}
					if(jsonObject.has("ADH"))
					{
						contentValues.put("ADH",jsonObject.getString("ADH").trim());
					}
					System.out.println("---"+i);
					if(contentValues!=null)
					{
						db.open();
						db.insertTableDate("DISTRICT_HQ_MANDAL",contentValues);			
						db.close();

					}
				}

			}


			return 32;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}

	public int InsertVegitableTotalAreaDetails(ArrayList<ContentValues> a) {

		try
		{

			for (int i = 0; i < a.size(); i++) 
			{
				ContentValues cv=a.get(i);
				String methodName="InsertVegitableTotalAreaDetails";

				SOAP_ACTION = namespace + methodName;
				request = new SoapObject(namespace, methodName);	

				request.addProperty("strdistrictid",cv.get("DISTRICT_ID"));
				request.addProperty("strheadquarterId",cv.get("HEADQUARTER_ID"));
				request.addProperty("strmandalid",cv.get("MANDAL_ID"));
				request.addProperty("strcropid",cv.get("CROP_ID"));							
				request.addProperty("strseason",cv.get("SEASON"));
				request.addProperty("strIMEInumber",cv.get("DEVICE_ID"));
				request.addProperty("strstatusmode","OL");
				request.addProperty("strcreateddate",cv.get("DATE"));
				request.addProperty("strcreatedby",cv.get("USER_ID"));
				request.addProperty("stradh",cv.get("ADH"));
				request.addProperty("strcroparea",cv.get("CROP_AREA"));	
				request.addProperty("strfinyear",cv.get("FIN_YEAR"));	
				envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
				envelope.dotNet=true;
				envelope.setOutputSoapObject(request);
				// Make the soap call.
				androidHttpTransport = new HttpTransportSE(url,120000);
				androidHttpTransport.debug = true;
				androidHttpTransport.call(SOAP_ACTION, envelope);
				String result = envelope.getResponse().toString();
				try
				{
					JSONArray jsonArray=new JSONArray(result);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse =jsonObject.getString("Message");
							if(serverResponse.equalsIgnoreCase("success"))
							{
								cv.put("STATUS","Y");
								db.open();
								db.insertTableDate("CROP_REGISTRATION_DATA",cv);	
							}
							else
							{
								cv.put("STATUS","N");
								db.open();
								db.insertTableDate("CROP_REGISTRATION_DATA",cv);
							}
							//db.exportDB();
							db.close();
						}
					}
				}catch(Exception e)
				{
					cv.put("STATUS","N");
					db.open();
					db.insertTableDate("CROP_REGISTRATION_DATA",cv);
					db.close();
				}

			}


			return 15;


		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int InsertVegitableActualAreaDetails(ArrayList<ContentValues> a) {
		try
		{
			for (int i = 0; i < a.size(); i++) 
			{
				ContentValues cv=a.get(i);
				String methodName="InsertVegitableActualAreaDetails";

				SOAP_ACTION = namespace + methodName;
				request = new SoapObject(namespace, methodName);	

				request.addProperty("strdistrictid",cv.get("DISTRICT_ID"));
				request.addProperty("strheadquarterId",cv.get("HEADQUARTER_ID"));
				request.addProperty("strmandalid",cv.get("MANDAL_ID"));
				request.addProperty("strcropid",cv.get("CROP_ID"));
				request.addProperty("strseason",cv.get("SEASON"));
				request.addProperty("strIMEInumber",cv.get("DEVICE_ID"));
				request.addProperty("strstatusmode","OL");
				request.addProperty("strcreateddate",cv.get("DATE"));
				request.addProperty("strcreatedby",cv.get("USER_ID"));
				request.addProperty("stradh",cv.get("ADH"));
				request.addProperty("strcroparea",cv.get("CROP_AREA"));
				request.addProperty("strfinyear",cv.get("FIN_YEAR"));	
				envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
				envelope.dotNet=true;
				envelope.setOutputSoapObject(request);
				// Make the soap call.
				androidHttpTransport = new HttpTransportSE(url,120000);
				androidHttpTransport.debug = true;
				androidHttpTransport.call(SOAP_ACTION, envelope);
				String result = envelope.getResponse().toString();
				try
				{
					JSONArray jsonArray=new JSONArray(result);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse =jsonObject.getString("Message"); 
							if(serverResponse.equalsIgnoreCase("success"))
							{
								cv.put("STATUS","Y");
								db.open();
								db.insertTableDate("CROP_ACTUAL_AREA_MASTER",cv);	
							}
							else
							{
								if(serverResponse.equalsIgnoreCase("exists"))
								{
									return 32;
								}
//								cv.put("STATUS","N");
//								db.open();
//								db.insertTableDate("CROP_ACTUAL_AREA_MASTER",cv);
							}
							db.close();
						}
					}
				}
				catch(Exception e)
				{
					cv.put("STATUS","N");
					db.open();
					db.insertTableDate("CROP_ACTUAL_AREA_MASTER",cv);
					db.close();
				}
			}



			return 15;


		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int UploadInsertVegitableActualAreaDetails(ContentValues cv) {

		ArrayList<HashMap<String,String>> offlineData=new ArrayList<HashMap<String,String>>();

		db.open();
		Cursor cursor=db.getTableDataCursor("select  AUTO_ID,USER_ID,DISTRICT_ID,HEADQUARTER_ID,MANDAL_ID,CROP_ID,DATE,DEVICE_ID,STATUS,SEASON,ADH,CROP_AREA,FIN_YEAR from CROP_ACTUAL_AREA_MASTER where STATUS='N'  and USER_ID='"+cv.getAsString("userid")+"' ");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				do
				{
					HashMap<String, String> uploadDetailsHashMap=new HashMap<String, String>();
					uploadDetailsHashMap=new HashMap<String, String>();
					uploadDetailsHashMap.put("AUTO_ID",cursor.getString(0));
					uploadDetailsHashMap.put("USER_ID", cursor.getString(1));
					uploadDetailsHashMap.put("DISTRICT_ID",cursor.getString(2));
					uploadDetailsHashMap.put("HEADQUARTER_ID", cursor.getString(3));
					uploadDetailsHashMap.put("MANDAL_ID",cursor.getString(4));
					uploadDetailsHashMap.put("CROP_ID",cursor.getString(5));
					uploadDetailsHashMap.put("DATE",cursor.getString(6));
					uploadDetailsHashMap.put("DEVICE_ID",cursor.getString(7));
					uploadDetailsHashMap.put("STATUS",cursor.getString(8));
					uploadDetailsHashMap.put("SEASON",cursor.getString(9));
					uploadDetailsHashMap.put("ADH",cursor.getString(10));
					uploadDetailsHashMap.put("CROP_AREA",cursor.getString(11));
					uploadDetailsHashMap.put("FIN_YEAR",cursor.getString(12));
					offlineData.add(uploadDetailsHashMap);
				}while(cursor.moveToNext());
			}
		}
		cursor.close();
		db.close();
		if(offlineData.size()>0)
		{
			for(int i=0;i<offlineData.size();i++)
			{
				try 
				{
					serverUploadcount=0;
					HashMap<String, String> uploadDetailsHashMap=offlineData.get(i);

					String methodName="InsertVegitableActualAreaDetails";
					Log.e("Method Name", methodName);
					SOAP_ACTION = namespace + methodName;
					request = new SoapObject(namespace, methodName);

					request.addProperty("strdistrictid",uploadDetailsHashMap.get("DISTRICT_ID"));
					request.addProperty("strheadquarterId",uploadDetailsHashMap.get("HEADQUARTER_ID"));
					request.addProperty("strmandalid",uploadDetailsHashMap.get("MANDAL_ID"));
					request.addProperty("strcropid",uploadDetailsHashMap.get("CROP_ID"));
					request.addProperty("strseason",uploadDetailsHashMap.get("SEASON"));
					request.addProperty("strIMEInumber",uploadDetailsHashMap.get("DEVICE_ID"));
					request.addProperty("strstatusmode","OF");
					request.addProperty("strcreateddate",uploadDetailsHashMap.get("DATE"));
					request.addProperty("strcreatedby",uploadDetailsHashMap.get("USER_ID"));
					request.addProperty("stradh",uploadDetailsHashMap.get("ADH"));
					request.addProperty("strcroparea",uploadDetailsHashMap.get("CROP_AREA"));
					request.addProperty("strfinyear",uploadDetailsHashMap.get("FIN_YEAR"));	
					envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
					envelope.dotNet=true;
					envelope.setOutputSoapObject(request);
					// Make the soap call.
					androidHttpTransport = new HttpTransportSE(url,120000);
					androidHttpTransport.debug = true;
					androidHttpTransport.call(SOAP_ACTION, envelope);
					String result1 = envelope.getResponse().toString();
					System.out.println("---"+result1);

					JSONArray jsonArray=new JSONArray(result1);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse=jsonObject.getString("Message").toString();
						}
					}

					try
					{
						if(serverResponse.equalsIgnoreCase("success")||serverResponse.equalsIgnoreCase("Exists"))
						{

							db.open();
							db.execSQL("UPDATE CROP_ACTUAL_AREA_MASTER SET STATUS ='Y' WHERE STATUS='N' and AUTO_ID='"+uploadDetailsHashMap.get("AUTO_ID")+"' ");
							db.close();
							serverUploadcount++;
						}
					}catch(Exception e)
					{

					}

				}
				catch (SocketTimeoutException e)
				{
					e.printStackTrace();

				} catch (IOException e) 
				{
					e.printStackTrace();

				} catch (XmlPullParserException e) 
				{
					e.printStackTrace();

				}catch (Exception e) 
				{
					e.printStackTrace();

				}
			}
		}

		return 22;

	}
	public int UploadInsertVegitableTotalAreaDetails(ContentValues cv) {

		ArrayList<HashMap<String,String>> offlineData=new ArrayList<HashMap<String,String>>();

		db.open();
		Cursor cursor=db.getTableDataCursor("select  AUTO_ID,USER_ID,DISTRICT_ID,HEADQUARTER_ID,MANDAL_ID,CROP_ID,DATE,DEVICE_ID,STATUS,SEASON,ADH,CROP_AREA,FIN_YEAR from CROP_REGISTRATION_DATA where STATUS='N'  and USER_ID='"+cv.getAsString("userid")+"' ");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				do
				{
					HashMap<String, String> uploadDetailsHashMap=new HashMap<String, String>();
					uploadDetailsHashMap=new HashMap<String, String>();
					uploadDetailsHashMap.put("AUTO_ID",cursor.getString(0));
					uploadDetailsHashMap.put("USER_ID", cursor.getString(1));
					uploadDetailsHashMap.put("DISTRICT_ID",cursor.getString(2));
					uploadDetailsHashMap.put("HEADQUARTER_ID", cursor.getString(3));
					uploadDetailsHashMap.put("MANDAL_ID",cursor.getString(4));
					uploadDetailsHashMap.put("CROP_ID",cursor.getString(5));
					uploadDetailsHashMap.put("DATE",cursor.getString(6));
					uploadDetailsHashMap.put("DEVICE_ID",cursor.getString(7));
					uploadDetailsHashMap.put("STATUS",cursor.getString(8));
					uploadDetailsHashMap.put("SEASON",cursor.getString(9));
					uploadDetailsHashMap.put("ADH",cursor.getString(10));
					uploadDetailsHashMap.put("CROP_AREA",cursor.getString(11));
					uploadDetailsHashMap.put("FIN_YEAR",cursor.getString(12));
					offlineData.add(uploadDetailsHashMap);
				}while(cursor.moveToNext());
			}
		}
		cursor.close();
		db.close();
		if(offlineData.size()>0)
		{
			for(int i=0;i<offlineData.size();i++)
			{
				try 
				{
					serverUploadcount=0;
					HashMap<String, String> uploadDetailsHashMap=offlineData.get(i);

					String methodName="InsertVegitableTotalAreaDetails";
					Log.e("Method Name", methodName);
					SOAP_ACTION = namespace + methodName;
					request = new SoapObject(namespace, methodName);

					request.addProperty("strdistrictid",uploadDetailsHashMap.get("DISTRICT_ID"));
					request.addProperty("strheadquarterId",uploadDetailsHashMap.get("HEADQUARTER_ID"));
					request.addProperty("strmandalid",uploadDetailsHashMap.get("MANDAL_ID"));
					request.addProperty("strcropid",uploadDetailsHashMap.get("CROP_ID"));
					request.addProperty("strseason",uploadDetailsHashMap.get("SEASON"));
					request.addProperty("strIMEInumber",uploadDetailsHashMap.get("DEVICE_ID"));
					request.addProperty("strstatusmode","OF");
					request.addProperty("strcreateddate",uploadDetailsHashMap.get("DATE"));
					request.addProperty("strcreatedby",uploadDetailsHashMap.get("USER_ID"));
					request.addProperty("stradh",uploadDetailsHashMap.get("ADH"));
					request.addProperty("strcroparea",uploadDetailsHashMap.get("CROP_AREA"));
					request.addProperty("strfinyear",uploadDetailsHashMap.get("FIN_YEAR"));	

					envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
					envelope.dotNet=true;
					envelope.setOutputSoapObject(request);
					// Make the soap call.
					androidHttpTransport = new HttpTransportSE(url,120000);
					androidHttpTransport.debug = true;
					androidHttpTransport.call(SOAP_ACTION, envelope);
					String result1 = envelope.getResponse().toString();
					System.out.println("---"+result1);

					JSONArray jsonArray=new JSONArray(result1);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse=jsonObject.getString("Message").toString();
						}
					}

					try
					{
						if(serverResponse.equalsIgnoreCase("success")||serverResponse.equalsIgnoreCase("Exists"))
						{

							db.open();
							db.execSQL("UPDATE CROP_REGISTRATION_DATA SET STATUS ='Y' WHERE STATUS='N' and AUTO_ID='"+uploadDetailsHashMap.get("AUTO_ID")+"' ");
							db.close();
							serverUploadcount++;
						}
					}catch(Exception e)
					{

					}

				}
				catch (SocketTimeoutException e)
				{
					e.printStackTrace();

				} catch (IOException e) 
				{
					e.printStackTrace();

				} catch (XmlPullParserException e) 
				{
					e.printStackTrace();

				}catch (Exception e) 
				{
					e.printStackTrace();

				}
			}
		}

		return 22;
	}
	public int GET_DistrictWise_CropDetails(ContentValues cv) {

		try
		{

			String methodName="GET_DistrictWise_CropDetails";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);


			request.addProperty("strfinyear",cv.get("strfinyear"));
			request.addProperty("strdistrict",cv.get("strdistrict"));
			request.addProperty("strHQid",cv.get("strHQid"));
			request.addProperty("strseason",cv.get("strseason"));
			
			if(cv.getAsString("strtype").equalsIgnoreCase("MV"))
			{
				request.addProperty("strmandal",null);
			}
			else
			{
				request.addProperty("strmandal",cv.get("strmandal"));
			}
			request.addProperty("strtype",cv.get("strtype"));
			request.addProperty("strADH",cv.get("ADH"));
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			reports_data=new ArrayList<HashMap<String,String>>();
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					HashMap<String,String> local=new HashMap<String,String>();
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					if(jsonObject.has("DISTRICT_DESCRIPTION"))
					{
						local.put("District",jsonObject.getString("DISTRICT_DESCRIPTION").trim()); 

					}
					if(jsonObject.has("MANDAL_NAME"))
					{
						local.put("MANDAL",jsonObject.getString("MANDAL_NAME").trim()); 

					}
					if(jsonObject.has("CROP_NAME"))
					{
						local.put("CROP",jsonObject.getString("CROP_NAME").trim());
					}

					if(jsonObject.has("NORMAL_AREA"))
					{
						local.put("NORMAL_AREA",jsonObject.getString("NORMAL_AREA").trim()); 

					}
					if(jsonObject.has("ACTUAL_AREA"))
					{
						local.put("ACTUAL_AREA",jsonObject.getString("ACTUAL_AREA").trim()); 

					}
					reports_data.add(local);

				}

			}


			return 32;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int Get_District_Mandal_HeadQuarter_Details() {

		try
		{

			String methodName="Get_District_Mandal_HeadQuarter_Details";
			db.open();
			db.execSQL("delete from LOGIN_MASTER");
			db.close();
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("strdistrict","");
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}
					ContentValues contentValues=new ContentValues();
					if(jsonObject.has("USERID"))
					{
						contentValues.put("USER_ID", jsonObject.getString("USERID").trim());

					}
					if(jsonObject.has("PASSWORD"))
					{
						contentValues.put("PASSWORD",jsonObject.getString("PASSWORD").trim());
					}
					if(jsonObject.has("HEADQUARTER_ID"))
					{
						contentValues.put("HEADQUARTER_ID",jsonObject.getString("HEADQUARTER_ID").trim());
					}
					if(jsonObject.has("DISTRICT_ID"))
					{
						contentValues.put("DISTRICT_ID",jsonObject.getString("DISTRICT_ID").trim());
					}
					if(jsonObject.has("ROLE_ID"))
					{
						contentValues.put("ROLE_ID",jsonObject.getString("ROLE_ID").trim());
					}
					if(jsonObject.has("ADH"))
					{
						contentValues.put("ADH",jsonObject.getString("ADH").trim());
					}
					if(contentValues!=null)
					{
						db.open();
						db.insertTableDate("LOGIN_MASTER",contentValues);			
						db.close();

					}
				}
				

			}


			return 32;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int CheckVegAppUserAuthentication(ContentValues cv) {
		try
		{
			String methodName="CheckVegAppUserAuthentication";
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace,methodName);	
			request.addProperty("UserId",cv.get("UserId").toString());
			request.addProperty("Password",cv.get("Password").toString());
			request.addProperty("strseason",cv.get("strseason").toString());
			request.addProperty("strfinyear",cv.get("strfinyear").toString());
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}
					if(jsonObject.has("DISTRICT_ID"))
					{
						cv.put("DISTRICT_ID",jsonObject.getString("DISTRICT_ID").trim()); 
					}
					if(jsonObject.has("DISTRICTNAME"))
					{
						cv.put("DISTRICTNAME",jsonObject.getString("DISTRICTNAME").trim());
					}
					if(jsonObject.has("MANDAL_ID"))
					{
						cv.put("MANDAL_ID",jsonObject.getString("MANDAL_ID").trim());
					}
					if(jsonObject.has("MANDAL_NAME"))
					{
						cv.put("MANDAL_NAME",jsonObject.getString("MANDAL_NAME").trim()); 
					}
					if(jsonObject.has("HEADQUARTER_ID"))
					{
						cv.put("HEADQUARTER_ID",jsonObject.getString("HEADQUARTER_ID").trim()); 
					}
					if(jsonObject.has("STATUS"))
					{
						cv.put("STATUS",jsonObject.getString("STATUS").trim()); 
					}
					if(jsonObject.has("NORMALAREA_STATUS"))
					{
						cv.put("NORMALAREA_STATUS",jsonObject.getString("NORMALAREA_STATUS").trim()); 
					}
				}
			}
			return 15;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS(ContentValues cv) {
		try
		{
			String methodName="GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS";

			SOAP_ACTION = namespace + methodName;
			if(cv.getAsString("strareatype").equalsIgnoreCase("NA"))
			{
				db.open();
				db.deleteTableData("CROP_REGISTRATION_DATA","USER_ID='"+cv.getAsString("USER_ID")+"' and SEASON='"+cv.get("strseason").toString()+"' and FIN_YEAR='"+cv.get("strfinyear").toString()+"'");
				db.close();
			}
			else
			{
				db.open();
				db.deleteTableData("CROP_ACTUAL_AREA_MASTER","USER_ID='"+cv.getAsString("USER_ID")+"' and SEASON='"+cv.get("strseason").toString()+"' and FIN_YEAR='"+cv.get("strfinyear").toString()+"'");
				db.close();
			}
			request = new SoapObject(namespace, methodName);
			request.addProperty("strDistrictId",cv.get("strDistrictId").toString());
			request.addProperty("strHeadQuarterId",cv.get("strHeadQuarterId").toString());
			request.addProperty("strfinyear",cv.get("strfinyear").toString());
			request.addProperty("strADH",cv.get("strADH").toString());
			request.addProperty("strseason",cv.get("strseason").toString());
			request.addProperty("strareatype",cv.get("strareatype").toString());			


			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			if(cv.getAsString("strareatype").equalsIgnoreCase("AA"))
			{
				if(result.equalsIgnoreCase("anyType{}"))
				{
					return 22;
				}
				else
				{
					
				}
			}
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					ContentValues cv1=new ContentValues();
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					if(jsonObject.has("DISTRICT_ID"))
					{
						cv1.put("DISTRICT_ID",jsonObject.getString("DISTRICT_ID").trim()); 

					}
					if(jsonObject.has("HEADQUARTER_ID"))
					{
						cv1.put("HEADQUARTER_ID",jsonObject.getString("HEADQUARTER_ID").trim()); 

					}
					if(jsonObject.has("MANDAL_ID"))
					{
						cv1.put("MANDAL_ID",jsonObject.getString("MANDAL_ID").trim());
					}

					if(jsonObject.has("CROP_ID"))
					{
						cv1.put("CROP_ID",jsonObject.getString("CROP_ID").trim()); 

					}
					if(jsonObject.has("ACTUAL_AREA"))
					{
						cv1.put("CROP_AREA",jsonObject.getString("ACTUAL_AREA").trim()); 

					}
					if(jsonObject.has("NORMAL_AREA"))
					{
						cv1.put("CROP_AREA",jsonObject.getString("NORMAL_AREA").trim()); 

					}
					if(jsonObject.has("SEASON"))
					{
						cv1.put("SEASON",jsonObject.getString("SEASON").trim()); 

					}
					if(jsonObject.has("CREATED_BY"))
					{
						cv1.put("USER_ID",jsonObject.getString("CREATED_BY").trim()); 

					}
					if(jsonObject.has("FIN_YEAR"))
					{
						cv1.put("FIN_YEAR",jsonObject.getString("FIN_YEAR").trim()); 

					}
					if(jsonObject.has("IMEI_NO"))
					{
						cv1.put("DEVICE_ID",jsonObject.getString("IMEI_NO").trim()); 

					}
					if(jsonObject.has("ADH"))
					{
						cv1.put("ADH",jsonObject.getString("ADH").trim()); 

					}
					if(jsonObject.has("Crop_Name"))
					{
						cv1.put("CROP_NAME",jsonObject.getString("Crop_Name").trim()); 

					}
					if(jsonObject.has("MANDAL_NAME"))
					{
						cv1.put("MANDAL_NAME",jsonObject.getString("MANDAL_NAME").trim()); 

					}
					if(jsonObject.has("CREATED_DATE"))
					{
						cv1.put("D_DATE",jsonObject.getString("CREATED_DATE").trim()); 

					}

					if(cv.getAsString("strareatype").equalsIgnoreCase("AA"))
					{
						db.open();
						cv1.put("STATUS","Y");
						long count=	db.insertTableDate("CROP_ACTUAL_AREA_MASTER",cv1);
						System.out.println("count"+count);
						db.close();
					}
					else
					{
						db.open();
						cv1.put("STATUS","Y");
						db.insertTableDate("CROP_REGISTRATION_DATA",cv1);
						db.close();
					}

				}

			}


			if(cv.getAsString("strareatype").equalsIgnoreCase("NA"))
			{
				return 32;
			}
			else
			{
				db.open();
				db.exportDB();
				db.close();
				return 22;
				
			}

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
	public int UpdateInsertVegitableTotalAreaDetails(ArrayList<ContentValues> a) 
	{
		try
		{

			for (int i = 0; i < a.size(); i++) 
			{
				ContentValues cv=a.get(i);
				String methodName="InsertVegitableTotalAreaDetails";
				if(i==0)
				{
					db.open();	
					db.deleteTableData("CROP_REGISTRATION_DATA","USER_ID='"+cv.get("USER_ID")+"' and SEASON='"+cv.get("SEASON").toString()+"' and FIN_YEAR='"+cv.getAsString("FIN_YEAR")+"' and MANDAL_NAME='"+cv.getAsString("MANDAL_NAME")+"' " );
					db.close();
				}			
				SOAP_ACTION = namespace + methodName;
				request = new SoapObject(namespace, methodName);	

				request.addProperty("strdistrictid",cv.get("DISTRICT_ID"));
				request.addProperty("strheadquarterId",cv.get("HEADQUARTER_ID"));
				request.addProperty("strmandalid",cv.get("MANDAL_ID"));
				request.addProperty("strcropid",cv.get("CROP_ID"));							
				request.addProperty("strseason",cv.get("SEASON"));
				request.addProperty("strIMEInumber",cv.get("DEVICE_ID"));
				request.addProperty("strstatusmode","OL");
				request.addProperty("strcreateddate",cv.get("DATE"));
				request.addProperty("strcreatedby",cv.get("USER_ID"));
				request.addProperty("stradh",cv.get("ADH"));
				request.addProperty("strcroparea",cv.get("CROP_AREA"));	
				request.addProperty("strfinyear",cv.get("FIN_YEAR"));	
				envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
				envelope.dotNet=true;
				envelope.setOutputSoapObject(request);
				// Make the soap call.
				androidHttpTransport = new HttpTransportSE(url,120000);
				androidHttpTransport.debug = true;
				androidHttpTransport.call(SOAP_ACTION, envelope);
				String result = envelope.getResponse().toString();
				try
				{
				JSONArray jsonArray=new JSONArray(result);
				if(jsonArray.length()!=0)
				{      

					JSONObject jsonObject=jsonArray.getJSONObject(0);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}
					if(jsonObject.has("Message"))
					{
						serverResponse =jsonObject.getString("Message");
						if(serverResponse.equalsIgnoreCase("success"))
						{
							cv.put("STATUS","Y");
							db.open();
							db.insertTableDate("CROP_REGISTRATION_DATA",cv);	
						}
						else
						{
							cv.put("STATUS","N");
							db.open();
							db.insertTableDate("CROP_REGISTRATION_DATA",cv);
						}
						//db.exportDB();
						db.close();
					}
				}
				}
				catch(Exception e)
				{
					cv.put("STATUS","N");
					db.open();
					db.insertTableDate("CROP_REGISTRATION_DATA",cv);
					db.close();
				}

			}


			return 15;


		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}
















}