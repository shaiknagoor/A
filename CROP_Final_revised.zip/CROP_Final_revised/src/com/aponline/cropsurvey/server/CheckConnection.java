package com.aponline.cropsurvey.server;


import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.widget.ProgressBar;


public class CheckConnection
{
	Display Disp;
	AlertDialog.Builder builder;
	Handler mHandler;
	ProgressBar mInProgress;
	String mParseMethod;
	Context mcontext;
	Object obj;
	int position = 0;
	Message localMessage;
	String MethodName,UserName,Password;
	String paramString1,paramString2,paramString3,paramString4,paramString5;
	ContentValues cv;
	ArrayList<ContentValues> a;
	public CheckConnection(Context paramContext, Handler paramHandler,String methodName)
	{
		this.mcontext = paramContext;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = paramHandler;
		this.MethodName=methodName;
	}
	public CheckConnection(Context paramContext, Handler paramHandler,String methodName,String paramString1,String paramString2)
	{
		this.mcontext = paramContext;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = paramHandler;
		this.MethodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
	}
	public CheckConnection(Context paramContext, Handler paramHandler,String methodName,String paramString1,String paramString2,String paramString3,String paramString4)
	{
		this.mcontext = paramContext;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = paramHandler;
		this.MethodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
		this.paramString3=paramString3;
		this.paramString4=paramString4;
	}
	public CheckConnection(Context paramContext, Handler paramHandler,String methodName,String paramString1,String paramString2,String paramString3,String paramString4,String paramString5)
	{
		this.mcontext = paramContext;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = paramHandler;
		this.MethodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
		this.paramString3=paramString3;
		this.paramString4=paramString4;
		this.paramString5=paramString5;
	}
	public CheckConnection(Context context, Handler mHandler2,
			String methodName2, ContentValues cv)
	{
		this.mcontext = context;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = mHandler2;
		this.MethodName=methodName2;
		this.cv=cv;
	}
	public CheckConnection(Context context, Handler mHandler2,
			String methodName2, ArrayList<ContentValues> a)
	{
		this.mcontext = context;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = mHandler2;
		this.MethodName=methodName2;
		this.a=a;
	}
	public CheckConnection(Context context, Handler mHandler2,
			String methodName2, ArrayList<ContentValues> a,ContentValues cv)
	{
		this.mcontext = context;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = mHandler2;
		this.MethodName=methodName2;
		this.a=a;
		this.cv=cv;
	}
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}

	public boolean checkNetworkAvailability()
	{
		if (!isNetworkAvailable(this.mcontext))
		{
			showdialog("no_connection");

			return false;

		}   
		
		if(MethodName.equalsIgnoreCase("GetHorticultureCROPDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName).start();
		}
		if(MethodName.equalsIgnoreCase("CheckAppVersion"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName).start();
		}
		if(MethodName.equalsIgnoreCase("GetVegitableCropDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName).start();
		}
		if(MethodName.equalsIgnoreCase("GetDistrictwiseHQ_MandalDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName).start();
		}
		if(MethodName.equalsIgnoreCase("InsertVegitableTotalAreaDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.a).start();
		}
		if(MethodName.equalsIgnoreCase("InsertVegitableActualAreaDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.a).start();
		}
		if(MethodName.equalsIgnoreCase("UploadInsertVegitableActualAreaDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.cv).start();
		}
		if(MethodName.equalsIgnoreCase("UploadInsertVegitableTotalAreaDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.cv).start();
		}
		if(MethodName.equalsIgnoreCase("GET_DistrictWise_CropDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.cv).start();
		}
		if(MethodName.equalsIgnoreCase("Get_District_Mandal_HeadQuarter_Details"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.cv).start();
		}
		if(MethodName.equalsIgnoreCase("CheckVegAppUserAuthentication"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.cv).start();
		}
		if(MethodName.equalsIgnoreCase("GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.cv).start();
		}
		if(MethodName.equalsIgnoreCase("UpdateInsertVegitableTotalAreaDetails"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName,this.a).start();
		}
		if(MethodName.equalsIgnoreCase("Get_District_Mandal_HeadQuarter_Details"))
		{
			new ParseThread(this.mcontext, this.mHandler, MethodName).start();
		}
		 
		
		return true;
	}
	public void showdialog(String paramString)
	{
		if (paramString.equals("no_connection"))
		{
			this.builder.setTitle("No Internet");
			this.builder.setMessage("No Internet Connection Available. Do you want to Continue?");
		}
		else
		{
			this.builder.setTitle("Server unavailable");
			this.builder.setMessage("Oops! Could not communicate with APONLINE Servers. Do you wish to retry?");
		}
		while (true)
		{

			this.builder.setPositiveButton("YES", new DialogInterface.OnClickListener(/*paramString*/)
			{
				public void onClick(DialogInterface paramDialogInterface, int paramInt)
				{
					localMessage=new Message();
					localMessage.what = 2;
					mHandler.sendMessage(localMessage);
					if (this.equals("no_connection"))
						CheckConnection.this.checkNetworkAvailability();
					//CheckConnection.this.fetchHomeData();
					return;
				}
			});
			this.builder.setNegativeButton("NO", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface paramDialogInterface, int paramInt)
				{
					CheckConnection.this.builder.create().dismiss();
					((Activity)CheckConnection.this.mcontext).finish();
					return;
				}
			});
			this.builder.show();
			return;
		}
	}
}
