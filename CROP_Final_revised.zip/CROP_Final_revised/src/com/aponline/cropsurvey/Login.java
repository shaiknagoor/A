package com.aponline.cropsurvey;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.aponline.cropsurvey.database.DBAdapter;
import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;
import android.Manifest;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity 
{
	Context context;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	Button login_btn;
	DBAdapter db;
	EditText username_et,password_et;
	String season;
	ContentValues cv;
	//public static String headquarter_id,district_id,user_id,adh;
	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
	String fin_year;
	private void Loaddata(final String methodName,final ContentValues cv)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{
					db.open();
					String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					String headquarter_id=db.getSingleValue("select HEADQUARTER_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					String	district_id=db.getSingleValue("select DISTRICT_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					//String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					db.close();
					ContentValues cv2=new ContentValues();
					cv2.put("strDistrictId",district_id);
					cv2.put("strHeadQuarterId",headquarter_id);
					cv2.put("strfinyear",fin_year);
					cv2.put("strADH",adh);
					cv2.put("strseason",season);
					cv2.put("strareatype","AA");
					cv2.put("USER_ID",username_et.getText().toString().trim());
					Loaddata("GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS", cv2);
				}
				if(paramMessage.what==22)
				{


					db.open();
					String headquarter_id=db.getSingleValue("select HEADQUARTER_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					String	district_id=db.getSingleValue("select DISTRICT_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
					String	user_id=username_et.getText().toString();

					ContentValues cv1=new ContentValues();
					cv1.put("USER_ID",user_id);
					cv1.put("DISTRICT_ID",district_id);
					cv1.put("HEADQUARTER_ID",headquarter_id);
					cv1.put("PASSWORD",password_et.getText().toString().trim().toUpperCase());
					cv1.put("SEASON",season);
					cv1.put("FIN_YEAR",fin_year);
					db.insertTableDate("LOGIN_TEST",cv1);
					ContentValues cv2=new ContentValues();
					cv2.put("USER_ID",user_id);
					cv2.put("STATUS","Y");
					cv2.put("SEASON",season);
					cv2.put("FIN_YEAR",fin_year);
					db.insertTableDate("LOGIN_CHECK_MASTER",cv2);
					db.close();

					SharedPreferences preferences1 = getSharedPreferences("Login",MODE_PRIVATE);
					SharedPreferences.Editor editor1 = preferences1.edit();
					editor1.putString("headquarter_id",headquarter_id);	
					editor1.putString("district_id",district_id);	
					editor1.putString("user_id",user_id);	
					editor1.putString("adh",adh);	
					editor1.apply();
					Intent intent=new Intent(Login.this,CropDataEntry.class);								
					startActivity(intent);

				}

				if(paramMessage.what==15)
				{
					if(cv.getAsString("STATUS").equalsIgnoreCase("true"))
					{
						if(cv.size()>3)
						{
							if(cv.getAsString("NORMALAREA_STATUS").equalsIgnoreCase("Y"))
							{
								db.open();							
								String check_status=db.getSingleValue("select STATUS from LOGIN_CHECK_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and SEASON='"+season+"' and FIN_YEAR='"+fin_year+"'");
								db.close();
								if(check_status.equalsIgnoreCase("Y"))
								{
									db.open();
									String headquarter_id=db.getSingleValue("select HEADQUARTER_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									String	district_id=db.getSingleValue("select DISTRICT_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									String	user_id=username_et.getText().toString();
									db.close();
									SharedPreferences preferences1 = getSharedPreferences("Login",MODE_PRIVATE);
									SharedPreferences.Editor editor1 = preferences1.edit();
									editor1.putString("headquarter_id",headquarter_id);	
									editor1.putString("district_id",district_id);	
									editor1.putString("user_id",user_id);	
									editor1.putString("adh",adh);	
									editor1.apply();
									Intent intent=new Intent(Login.this,CropDataEntry.class);								
									startActivity(intent);
								}
								else
								{
									db.open();
									String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									db.close();
									ContentValues cv2=new ContentValues();
									cv2.put("strDistrictId",cv.getAsString("DISTRICT_ID"));
									cv2.put("strHeadQuarterId",cv.getAsString("HEADQUARTER_ID"));
									cv2.put("strfinyear",fin_year);
									cv2.put("strADH",adh);
									cv2.put("strseason",season);
									cv2.put("strareatype","NA");
									cv2.put("USER_ID",username_et.getText().toString().trim());
									Loaddata("GET_District_HQ_Mandal_NORMAL_ACTUAL_AREA_DETAILS", cv2);
								}
							}
							else
							{
								db.open();

								String headquarter_id=db.getSingleValue("select HEADQUARTER_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
								String	district_id=db.getSingleValue("select DISTRICT_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
								String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
								String	user_id=username_et.getText().toString();
								SharedPreferences preferences1 = getSharedPreferences("Login",MODE_PRIVATE);
								SharedPreferences.Editor editor1 = preferences1.edit();
								editor1.putString("headquarter_id",headquarter_id);	
								editor1.putString("district_id",district_id);	
								editor1.putString("user_id",user_id);	
								editor1.putString("adh",adh);	
								editor1.apply();
								ContentValues cv1=new ContentValues();
								cv1.put("USER_ID",user_id);
								cv1.put("DISTRICT_ID",district_id);
								cv1.put("HEADQUARTER_ID",headquarter_id);
								cv1.put("PASSWORD",password_et.getText().toString().trim().toUpperCase());
								cv1.put("SEASON",season);
								cv1.put("FIN_YEAR",fin_year);
								db.insertTableDate("LOGIN_TEST",cv1);
								Intent intent=new Intent(Login.this,CropRegistration.class);								
								startActivity(intent);
							}
						}
					}
					else
					{
						Toast toast = null;
						toast=Toast.makeText(Login.this, "Please Enter Correct Username/Password",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}

				}
				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(Login.this, "Please Try Agian",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.BOTTOM, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Login.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==	98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Login.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Login.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName,cv);
		this.conn_obj.checkNetworkAvailability();
		return;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		context=this;
		login_btn=(Button)findViewById(R.id.loginBtt1);

		db=new DBAdapter(this);
		username_et=(EditText)findViewById(R.id.username_et);
		password_et=(EditText)findViewById(R.id.pwd_et);
		Date d=new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate1 = df.format(d);

		if (Build.VERSION.SDK_INT >= 23)
		{
			requestPermissions();
		}	
		else
		{
			HomeData.readDeviceDetails(context);
			try
			{
				db.createDataBase();
			} 
			catch (IOException e) 
			{

				e.printStackTrace();
			}
//db.open();
//db.exportDB();
//db.close();
			login_btn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0)
				{
					if(username_et.getText().toString().trim().equalsIgnoreCase("")|| password_et.getText().toString().trim().equalsIgnoreCase(""))
					{
						Toast toast = null;
						toast=Toast.makeText(Login.this, "Please Enter Username/Password",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
						return;
					}
					else
					{	

			
								db.open();
								int i=	db.getRowCount("select Count(*) from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
								db.close();
								if(i!=0)
								{
									db.open();
									String headquarter_id=db.getSingleValue("select HEADQUARTER_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									String	district_id=db.getSingleValue("select DISTRICT_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									String	user_id=username_et.getText().toString();
									
									SharedPreferences preferences1 = getSharedPreferences("Login",MODE_PRIVATE);
									SharedPreferences.Editor editor1 = preferences1.edit();
									editor1.putString("headquarter_id",headquarter_id);	
									editor1.putString("district_id",district_id);	
									editor1.putString("user_id",user_id);	
									editor1.putString("adh",adh);	
									editor1.apply();
									db.close();
									HomeData.SaveCreadentialsLogin(context,headquarter_id,district_id,user_id,adh);
									startActivity(new Intent(Login.this,Home_Screen.class));
									//finish();
								}
								else
								{
									Toast toast = null;
									toast=Toast.makeText(Login.this, "Please Enter Correct Username/Password",Toast.LENGTH_SHORT);
									View view = toast.getView();
									toast.setGravity(Gravity.CENTER, 0, 0);
									view.setBackgroundResource(R.color.red);
									toast.show();
								}
							}
						}

			});


		}


	}

	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("Write enternal Contacts");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("camera");
		if (!addPermission(permissionsList, Manifest.permission.GET_ACCOUNTS))
			permissionsNeeded.add("get Accounts");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
			permissionsNeeded.add("Access Fine Location");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
			permissionsNeeded.add("Access Coarse Location");


		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				// Need Rationale
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				try
				{
					final Dialog dialog = new Dialog(this);
					dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
					dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
					dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
					dialog.setContentView(R.layout.alert_dialog);
					Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
					TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
					msgTv.setText(message);
					Button yes =(Button)dialog.findViewById(R.id.ok_button);
					yes.startAnimation(shake);

					yes.setOnClickListener(new View.OnClickListener()
					{
						@Override
						public void onClick(View v)
						{
							dialog.dismiss();
							ActivityCompat.requestPermissions(Login.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
							return;
						}
					});
					if(!dialog.isShowing())
						dialog.show();
				} catch (Resources.NotFoundException e) {
					e.printStackTrace();
				}

				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}

		HomeData.readDeviceDetails(Login.this);
	}

	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}
		return true;
	}
	@SuppressLint("NewApi")
	@Override
	public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){

		switch (permsRequestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			// Initial
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.GET_ACCOUNTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			// Fill with results
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			// Check for ACCESS_FINE_LOCATION
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
			{
				// All Permissions Granted



				HomeData.readDeviceDetails(context);
				try
				{
					db.createDataBase();
				} 
				catch (IOException e) 
				{

					e.printStackTrace();
				}

				login_btn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0)
					{
						if(username_et.getText().toString().trim().equalsIgnoreCase("")|| password_et.getText().toString().trim().equalsIgnoreCase(""))
						{
							Toast toast = null;
							toast=Toast.makeText(Login.this, "Please Enter Username/Password",Toast.LENGTH_SHORT);
							View view = toast.getView();
							toast.setGravity(Gravity.CENTER, 0, 0);
							view.setBackgroundResource(R.color.red);
							toast.show();
							return;
						}
						else
						{	

					
									db.open();
									int i=	db.getRowCount("select Count(*) from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
									db.close();
									if(i!=0)
									{
										db.open();
										String headquarter_id=db.getSingleValue("select HEADQUARTER_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
										String	district_id=db.getSingleValue("select DISTRICT_ID from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
										String	adh=db.getSingleValue("select ADH from LOGIN_MASTER where USER_ID='"+username_et.getText().toString().trim()+"' and PASSWORD='"+password_et.getText().toString().trim().toUpperCase()+"'");
										String	user_id=username_et.getText().toString();
										
										SharedPreferences preferences1 = getSharedPreferences("Login",MODE_PRIVATE);
										SharedPreferences.Editor editor1 = preferences1.edit();
										editor1.putString("headquarter_id",headquarter_id);	
										editor1.putString("district_id",district_id);	
										editor1.putString("user_id",user_id);	
										editor1.putString("adh",adh);	
										editor1.apply();
										db.close();
										HomeData.SaveCreadentialsLogin(context,headquarter_id,district_id,user_id,adh);
										startActivity(new Intent(Login.this,Home_Screen.class));
										//finish();
									}
									else
									{
										Toast toast = null;
										toast=Toast.makeText(Login.this, "Please Enter Correct Username/Password",Toast.LENGTH_SHORT);
										View view = toast.getView();
										toast.setGravity(Gravity.CENTER, 0, 0);
										view.setBackgroundResource(R.color.red);
										toast.show();
									}
								}
							}

				});


		



			}
			else
			{
				// Permission Denied
				Toast toast = null;
				toast=Toast.makeText(Login.this, "Some Permission are Denied",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();

			}
		}
		break;
		default:
			super.onRequestPermissionsResult(permsRequestCode, permissions, grantResults);
		}
	}
}
