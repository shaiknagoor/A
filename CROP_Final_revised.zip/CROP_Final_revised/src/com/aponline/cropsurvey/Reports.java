package com.aponline.cropsurvey;

import java.util.ArrayList;
import java.util.List;










import com.aponline.cropsurvey.adpater.ReportAdapter;
import com.aponline.cropsurvey.database.DBAdapter;
import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;










import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Reports  extends AppCompatActivity
{
	Context context;
	DBAdapter db;
	ActionBar ab;
	ArrayAdapter<String> district_adapter,headquater_adapter,mandal_adapter;
	List<String> headquaterlist,mandallist;//districtlist,
	Spinner financial_year_sp,mandal_sp,report_type,season_sp;//district_sp,headquarter_sp
	Button Report_btn;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	ContentValues cv;
	ReportAdapter reportAdapter;
	ListView report_crop_lv;
	String headquarter_id,district_id,user_id,adh;
	private void Loaddata(final String methodName,final ContentValues cv)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{
					if(WebserviceCall.reports_data.size()>0)
					{
						((HorizontalScrollView)findViewById(R.id.report_entire_hs)).setVisibility(0);
						if(cv.getAsString("strtype").equalsIgnoreCase("MV"))
						{
							reportAdapter=new ReportAdapter(Reports.this, WebserviceCall.reports_data,"MV");
							report_crop_lv.setAdapter(reportAdapter);
							((TextView)findViewById(R.id.r_crop)).setVisibility(8);
						}
						else
						{
							reportAdapter=new ReportAdapter(Reports.this, WebserviceCall.reports_data,"CV");
							report_crop_lv.setAdapter(reportAdapter);
							((TextView)findViewById(R.id.r_crop)).setVisibility(0);
						}
					}
					else
					{

					}

				}
				if(paramMessage.what==22)
				{

				}

				if(paramMessage.what==15)
				{



				}
				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(Reports.this, "No Data Available",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Reports.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==	98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Reports.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Reports.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName,cv);
		this.conn_obj.checkNetworkAvailability();
		return;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.reports);
		context=this;
		db=new DBAdapter(this);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		this.ab=getSupportActionBar();
		ab.setTitle("Reports");
		ab.setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_gradient_shape));
		ab.setHomeButtonEnabled(true);
		ab.setDisplayHomeAsUpEnabled(true);
		financial_year_sp=(Spinner)findViewById(R.id.financial_year_sp);
		season_sp=(Spinner)findViewById(R.id.season_sp);
		//district_sp=(Spinner)findViewById(R.id.report_district_sp);
		//headquarter_sp=(Spinner)findViewById(R.id.report_headquarter_sp);
		mandal_sp=(Spinner)findViewById(R.id.report_mandal_sp);		
		report_type=(Spinner)findViewById(R.id.report_reporttype_sp);
		Report_btn=(Button)findViewById(R.id.get_reports_btn);
		report_crop_lv=(ListView)findViewById(R.id.report_crop_lv);
		SharedPreferences prefs1= getSharedPreferences("Login",MODE_PRIVATE);		
		headquarter_id=	prefs1.getString("headquarter_id","");	
		district_id=	prefs1.getString("district_id","");	
		user_id=prefs1.getString("user_id","");	
		adh=prefs1.getString("adh","");
		mandallist=new ArrayList<String>();
		db.open();
		mandallist=db.getSpinnerData("select Distinct MANDAL_NAME from DISTRICT_HQ_MANDAL   where HEADQUARTER_ID='"+headquarter_id+"' and DISTRICT_ID='"+district_id+"' and ADH='"+adh+"' order by MANDAL_NAME");
		db.close();
		mandal_adapter = new ArrayAdapter<String>(Reports.this,android.R.layout.simple_spinner_item,mandallist);
		mandal_adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		mandal_sp.setAdapter(mandal_adapter);


		mandal_sp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				if(arg3!=0)
				{
					((HorizontalScrollView)findViewById(R.id.report_entire_hs)).setVisibility(8);    
				}
				else
				{
					report_type.setSelection(0);
					((HorizontalScrollView)findViewById(R.id.report_entire_hs)).setVisibility(8);
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});
		report_type.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				if(arg3!=0)
				{

					if(report_type.getSelectedItem().toString().equalsIgnoreCase("Crop Wise"))
					{
						((LinearLayout)findViewById(R.id.mandal_reportll)).setVisibility(0);
					}
					else
					{
						((LinearLayout)findViewById(R.id.mandal_reportll)).setVisibility(8);
					}
					((HorizontalScrollView)findViewById(R.id.report_entire_hs)).setVisibility(8);    
				}
				else
				{
					((LinearLayout)findViewById(R.id.mandal_reportll)).setVisibility(8);
					((HorizontalScrollView)findViewById(R.id.report_entire_hs)).setVisibility(8);
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});
		Report_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				boolean a=	CheckConnection.isNetworkAvailable(Reports.this);
				if(a==false)
				{
					Toast toast = null;
					toast=Toast.makeText(Reports.this, "Check Internet Connection",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
					return;
				}

				//				if(district_sp.getSelectedItemPosition()==0)
				//				{
				//					district_sp.requestFocusFromTouch();
				//					return;
				//				}
				//				if(headquarter_sp.getSelectedItemPosition()==0)
				//				{
				//					headquarter_sp.requestFocusFromTouch();
				//					return;
				//				}

				if(report_type.getSelectedItemPosition()==0)
				{
					report_type.requestFocusFromTouch();
					return;
				}
				if(season_sp.getSelectedItemPosition()==0)
				{
					season_sp.requestFocusFromTouch();
					return;
				}
				if(financial_year_sp.getSelectedItemPosition()==0)
				{
					financial_year_sp.requestFocusFromTouch();
					return;
				}
				String mandal_id;
				ContentValues cv=new ContentValues();
				if(report_type.getSelectedItem().toString().equalsIgnoreCase("Crop Wise"))
				{
					if(mandal_sp.getSelectedItemPosition()==0)
					{
						mandal_sp.requestFocusFromTouch();
						return;
					}
					db.open();
					//String district_id=	db.getSingleValue("select Distinct DISTRICT_ID  from DISTRICT_HQ_MANDAL  where DISTRICT_DESCRIPTION='"+district_sp.getSelectedItem().toString()+"' ");
					mandal_id=	db.getSingleValue("select Distinct MANDAL_ID  from DISTRICT_HQ_MANDAL  where MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"' ");
					//String headquarter_id=	db.getSingleValue("select Distinct HEADQUARTER_ID  from DISTRICT_HQ_MANDAL  where HEADQUARTER_NAME='"+headquarter_sp.getSelectedItem().toString()+"'");
					db.close();
					cv.put("strmandal",mandal_id);
				}		
				
				if(financial_year_sp.getSelectedItemPosition()==1)
				{
					cv.put("strfinyear","2016-2017");
				}
				else if(financial_year_sp.getSelectedItemPosition()==2)
				{
					cv.put("strfinyear","2017-2018");
				}
				else if(financial_year_sp.getSelectedItemPosition()==3)
				{
					cv.put("strfinyear","2018-2019");
				}
				cv.put("strseason",season_sp.getSelectedItem().toString());
				
				cv.put("strdistrict",district_id);
				cv.put("strHQid",headquarter_id);
				cv.put("ADH",adh);
				if(report_type.getSelectedItemPosition()==1)
				{
					cv.put("strtype","MV");
					cv.put("strmandal","");
				}
				else
				{
					cv.put("strtype","CV");
				}
				((HorizontalScrollView)findViewById(R.id.report_entire_hs)).setVisibility(8);
				report_crop_lv.setAdapter(null);
				Loaddata("GET_DistrictWise_CropDetails",cv);

			}
		});

	}
	@Override
	public void onBackPressed() {
		Intent i =new Intent(Reports.this,CropDataEntry.class);
		startActivity(i);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.report, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int id = item.getItemId();
		if (id == android.R.id.home) 
		{
			Intent i =new Intent(Reports.this,CropDataEntry.class);
			startActivity(i);
		}
		return super.onOptionsItemSelected(item);
	}

}
