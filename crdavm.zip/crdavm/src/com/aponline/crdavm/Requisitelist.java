package com.aponline.crdavm;



import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Requisitelist extends Activity 
{

	ListView lv;
	Button B1;
	ImageButton minus,pluse;
	int date;
	int year;
	int month;
	TextView t1;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.requisitelist);

		lv=(ListView)findViewById(R.id.listview_1);
		B1=(Button)findViewById(R.id.logout);
		minus=(ImageButton)findViewById(R.id.minus1);
		pluse=(ImageButton)findViewById(R.id.pulse1);
		t1=(TextView)findViewById(R.id.DATE_TV);





		t1.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub


				DatePickerDialog dpd=
						new DatePickerDialog(Requisitelist.this,
								new DatePickerDialog.OnDateSetListener()
						{

							public void onDateSet(DatePicker view, int year,int month,int date) 
							{

							}
						},2016,9,13);
				dpd.show();	
			}
		});


		minus.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{
				// TODO Auto-generated method stub

				DatePickerDialog dpd=
						new DatePickerDialog(Requisitelist.this,
								new DatePickerDialog.OnDateSetListener()
						{

							public void onDateSet(DatePicker view, int year,int month,int date) 
							{

							}
						},2016,9,13);
				dpd.show();	


			}
		});



		pluse.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{
				// TODO Auto-generated method stub

				DatePickerDialog dpd=
						new DatePickerDialog(Requisitelist.this,
								new DatePickerDialog.OnDateSetListener()
						{

							public void onDateSet(DatePicker view, int year,int month,int date) 
							{

							}
						},2016,9,13);
				dpd.show();	


			}
		});



	}

}

