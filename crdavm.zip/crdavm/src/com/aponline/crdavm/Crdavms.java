package com.aponline.crdavm;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;

@SuppressLint("NewApi")
public class Crdavms extends AppCompatActivity
{
	Button b1;
	TextView E1;
	ImageButton I1;

	@Override
	public void onCreate(Bundle savedInstanceState )
	{   
		super.onCreate(savedInstanceState);
		setContentView(R.layout.crdavms);
		b1=(Button)findViewById(R.id.button1);
		E1=(TextView)findViewById(R.id.TEXTView_E1);
		I1=(ImageButton)findViewById(R.id.CALENDER);
		I1.setOnClickListener(new OnClickListener() 
				{
			public void onClick(View v) 
			{
				DatePickerDialog dpd=
						new DatePickerDialog(Crdavms.this,
								new DatePickerDialog.OnDateSetListener()
						{

							public void onDateSet(DatePicker view, int year,int month,int date) 
							{

							}
						},2016,9,8);
				dpd.show();	

			}
		});;


		b1.setOnClickListener(new OnClickListener()
		{

			public void onClick(View v)

			{


			}
		});





	}








}
