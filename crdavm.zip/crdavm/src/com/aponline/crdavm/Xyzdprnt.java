package com.aponline.crdavm;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Xyzdprnt  extends Activity
{

	EditText E1,E2,E3,E4;
	Button B1,B2;
	ImageButton I1;
	String date,persons,travel,purpose;


	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xyzdprnt);
		E1=(EditText)findViewById(R.id.EDITTEXT_1);
		E2=(EditText)findViewById(R.id.EDITTEXT_2);
		E3=(EditText)findViewById(R.id.EDITTEXT_3);
		E4=(EditText)findViewById(R.id.EDITTEXT_4);
		B1=(Button)findViewById(R.id.SUBMIT_BT);
		B2=(Button)findViewById(R.id.logout);
	//	I1=(ImageButton)findViewById(R.id.IMAGEBUTT);

		B1.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				// TODO Auto-generated method stub
				date=E1.getText().toString();
				persons=E2.getText().toString();
				travel=E3.getText().toString();
				purpose=E3.getText().toString();
			}
		});

		I1.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View v)
			{
				// TODO Auto-generated method stub

				DatePickerDialog dpd=
						new DatePickerDialog(Xyzdprnt.this,
								new DatePickerDialog.OnDateSetListener()
						{

							public void onDateSet(DatePicker view, int year,int month,int date) 
							{

							}
						},2016,9,13);
				dpd.show();	


			}
		});

		B2.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub

				AlertDialog.Builder builder1 = new AlertDialog.Builder(Xyzdprnt.this);
				builder1.setMessage("You Want To Logout");
				builder1.setCancelable(true);

				builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
				{
					public void onClick(DialogInterface dialog, int id) 
					{
						dialog.cancel();
						Intent i=new Intent(Xyzdprnt.this,Loginpage.class);
						startActivity(i);
						Xyzdprnt.this.finish();
					}
				});

				builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
				{
					public void onClick(DialogInterface dialog, int id) 
					{
						dialog.cancel();

					}
				});

				AlertDialog alert11 = builder1.create();
				alert11.show();




			}
		});



	}








}
