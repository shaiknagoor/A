package com.aponline.crdavm;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.Toast;

public class crdavmsdetiles  extends Activity implements OnItemSelectedListener
{

	Button b1,b2,b3;


	public void onCreate(Bundle S)
	{
		super.onCreate(S);
		setContentView(R.layout.crdavmsdetiles);
		b1=(Button)findViewById(R.id.Approve_bt);
		b2=(Button)findViewById(R.id.Reject_bt);
		b3=(Button)findViewById(R.id.LOGIN_BT);

		b1.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub

			}
		});

		b2.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub
				

			}
		});



		b3.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub

			}
		});


	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
	{
		// TODO Auto-generated method stub
		if( id!=0)
		{
			Toast.makeText(this,"POSITION",Toast.LENGTH_LONG).show();

		}
	}




	@Override
	public void onNothingSelected(AdapterView<?> parent)
	{
		// TODO Auto-generated method stub

	}



}
