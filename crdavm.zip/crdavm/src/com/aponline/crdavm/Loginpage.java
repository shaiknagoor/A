package com.aponline.crdavm;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Loginpage extends Activity
{
	Button b;
	EditText e1,e2;
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loginpage);
		b=(Button)findViewById(R.id.LOGIN_BT);
		e1=(EditText)findViewById(R.id.E1);
		e2=(EditText)findViewById(R.id.E2);
		b.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				String eID=e1.getText().toString();
				String psw=e2.getText().toString();
				if (eID.equals ("")&& psw.equals(""))
				{
					Toast.makeText(Loginpage.this,"Please Enter Valid UserName/ Password",Toast.LENGTH_LONG).show();
					
				}

				else if(eID.equalsIgnoreCase("crda")&& psw.equalsIgnoreCase("1234"))
				{
					Toast.makeText(Loginpage.this,"Login success",Toast.LENGTH_LONG).show();
					Intent i=new Intent(Loginpage.this,Xyzdprnt.class);
					startActivity(i);
					Loginpage.this.finish();
				}
				else if(eID.equalsIgnoreCase("crda")&& psw.equalsIgnoreCase("1122"))
				{
					Toast.makeText(Loginpage.this,"Login success",Toast.LENGTH_LONG).show();
					Intent i=new Intent(Loginpage.this,crdavmsdetiles .class);
					startActivity(i);
					
				}
				else 
				{
					Toast.makeText(Loginpage.this,"Invalid UserID/ Password",Toast.LENGTH_LONG).show();
				}
			}
		});


	}


}



