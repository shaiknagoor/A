package com.aponline.Hc.server;

import java.io.IOException;
import java.io.StringWriter;
import java.net.SocketTimeoutException;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;


import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.xmlpull.v1.XmlPullParserException;

import com.aponline.Hc.database.DBAdapter;
import com.aponline.horticulture.CommonFunctions;
import com.aponline.horticulture.HomeData;
import com.aponline.horticulture.Login_Page;
import com.aponline.rdservices.model.DeviceInfo;
import com.aponline.rdservices.model.Opts;
import com.aponline.rdservices.model.PidData;
import com.aponline.rdservices.model.PidOptions;
import com.aponline.rdservices.model.Skey;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Base64;
import android.util.Log;


public class RequestAadhaar implements ErrorCodes
{
	ServerResponseListener listener;
	Handler mUIHandler;
	ProgressDialog progressDialog;
	String userID;
	String schoolsID;
	DBAdapter db;
	PidData pidData; 
	public static String AadharStatus;
	public static String AadharResponse;
	public static String AadhaarIRISbase64EncodedData;
	Context mContext;
	String UID;
	String ReqType;
	public 	static String aadhar_result;
	String is_User;
	String verifyAttempt;
	String userType,verifyType; 
	String methodName;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport; 
	String pincode,maritalStatus,spouseAadahrno;

	String namespace ="http://tempuri.org/";//"http://tempuri.org/";

	//Live 
	private String url;
	public void Verify(Context paramContext,ServerResponseListener listener,String methodName,PidData pidData,String aadhaarID,String maritalStatus,String pincode,String spouseAadahrno,String verifyAttempt,String verifyType)
	{
		//url="http://61.246.226.123:8080/gps/FarmerRegistration.asmx";
url="http://horticulturedept.ap.gov.in/gps/FarmerRegistration.asmx";
		this.listener=listener;
		this.mContext=paramContext;
		this.UID=aadhaarID;
		this.methodName=methodName;
		this.verifyAttempt=verifyAttempt;
		this.verifyType=verifyType;
		this.pidData=pidData;
		this.pincode=pincode;
		this.maritalStatus=maritalStatus;
		this.spouseAadahrno=spouseAadahrno;
		if(isNetworkAvailable(mContext))
		{
			Loaddata();
		}
		else
		{
			this.listener.NetworkNotAvail();
		}
		db=new DBAdapter(mContext);
	}	
	private void Loaddata()
	{
		progressDialog=new ProgressDialog(mContext);
		try 
		{
			Handler localHadler=new Handler()
			{
				public void dispatchMessage(Message paramMessage)
				{
					super.dispatchMessage(paramMessage);

					if(progressDialog.isShowing())
						progressDialog.dismiss();
					if(paramMessage.what==mSuccess)
					{
						listener.Success(AadharResponse);
					}
					else if(paramMessage.what==mErrorResFromWebServices)
					{
						listener.Fail(WebserviceCall.Error);
					}
					else if(paramMessage.what==mFailure)
					{
						listener.Fail("Failed to transfer the data to server");
					}
					else if(paramMessage.what==mXmlPullParserException)
					{
						listener.Fail("Data parsing error, Please try again!!");
					} 
					else if(paramMessage.what==mException||paramMessage.what==mIOException)
					{
						listener.Fail("Failed to connect to the server");
					}
					else if(paramMessage.what==mHandlerFailure||paramMessage.what==mSocketTimeoutException)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==mUpdateVersion)
					{
						listener.AppUpdate();
					}
					else if(paramMessage.what==5)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					while(true)
					{
						return;
					}
				}
			};
			this.mUIHandler=localHadler;
			progressDialog.setCancelable(false);
			progressDialog.setMessage("Verifying with Aaadhaar,Please Wait......");
			if(!progressDialog.isShowing())
				progressDialog.show();
			//progressDialog.setContentView(setCustomeLayout());
			new AadhaarThread().start();
			return;
		} 
		catch (Exception e) 
		{
			//CommonFunctions.writeLog(mContext, "Loaddata", e.getMessage());
			e.printStackTrace();
		}
	}
	private class AadhaarThread extends Thread
	{
		public void run()
		{
			Message localMessage = new Message();
			try 
			{
				int i = 0;

				i = requestAUAServer();

				localMessage.what = i;
				if (mUIHandler != null)
				{

					mUIHandler.sendMessage(localMessage);

				}
				return;
			}catch (Exception e) 
			{
				while (true)
				{
					e.printStackTrace();
					mUIHandler.sendMessage(localMessage);
					localMessage.what = mSocketTimeoutException;
					//CommonFunctions.writeLog(mContext, "run", e.getMessage());
					return;
				}
			}
		}

	}

	public int requestAUAServer()
	{
		try
		{


			DeviceInfo deviceInfo=pidData._DeviceInfo;
			Skey skey=pidData._Skey; 

			Calendar c = Calendar.getInstance(); 					
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss.SSS"); 
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			String createdDate = sdf.format(c.getTime());
			createdDate="UKC:"+createdDate+HomeData.sDeviceId;
			SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			String srt = sdf1.format(c.getTime());

			SOAP_ACTION = namespace+methodName; 
			request = new SoapObject(namespace,methodName);

			request.addProperty("struid",UID);
			request.addProperty("strtransid",createdDate);
			request.addProperty("struniquedevicecode",HomeData.sDeviceId);
			request.addProperty("strip","NA");
			request.addProperty("strsrt",srt);
			request.addProperty("strcrt",srt);
			request.addProperty("strskey", skey.data);
			request.addProperty("strpid", pidData._Data);
			request.addProperty("strhmac", pidData._Hmac);
			request.addProperty("strcivalue",skey.ci);//ci=20191230
			request.addProperty("strpincode",pincode);	
			request.addProperty("strattemptcount",verifyAttempt);
			request.addProperty("strrdsid",deviceInfo.rdsId);
			request.addProperty("strrdsversion",deviceInfo.rdsVer);
			request.addProperty("strregistereddeviceprovider",deviceInfo.dpId);
			request.addProperty("struniqueregisterdevicecode",deviceInfo.dc);
			request.addProperty("strrdmodelid",deviceInfo.mi);
			request.addProperty("strmc",deviceInfo.mc);



			//request.addProperty("attempt",verifyAttempt);

			request.addProperty("strmaritalstatus",maritalStatus);
			request.addProperty("strspouseaadahrno",spouseAadahrno);	
			request.addProperty("strcreatedby",Login_Page.UserId);	
			request.addProperty("strroleid",WebserviceCall.Login_Details.get("ROLE_ID"));	
			request.addProperty("strlogindistrictid",WebserviceCall.Login_Details.get("DistrictId"));	


			//CommonFunctions.writeLog(mContext,"uid",request.getPropertyAsString("struid"));



			CommonFunctions.writeLog(mContext,"uid","AADHAAR_FINGER_AUTHENTICATION-result :-"+request.toString());

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11); 
			envelope.dotNet=true;  			
			envelope.setOutputSoapObject(request);
			androidHttpTransport = new HttpTransportSE(url,100000); 
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION,envelope);
			String result = envelope.getResponse().toString();//FINGER_AUTH|815365525372|Biometric Mismatch (300)|Fingerprint data is not given properly or Fingerprint Mismatch
			CommonFunctions.writeLog(mContext,"result",result);

			AadharResponse=result;
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      

				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{

					return mFailure;
				}
				if(jsonObject.has("ERROR_CODE"))
				{
					if(jsonObject.getString("ERROR_CODE").equalsIgnoreCase("00"))
					{
						AadharResponse="Sucessfully Authenticated";
					}
					else
					{
						AadharResponse=result;
					}

				}
				if(jsonObject.has("ERROR_DESC"))
				{
					aadhar_result=jsonObject.getString("ERROR_DESC");

				}
			}
			//			if(!result.equalsIgnoreCase("anyType{}"))
			//			{
			//				JSONArray jArray=
			//				
			//				
			//			}
			//			
			//			
			//			// Make the soap call.
			//			
			//			
			//			//Data truncation
			//			//FINGER_AUTH|237210669874|Attendance already Captured|Sucessfully Verified
			//			AadharResponse=result.replace("|", ",");
			//			//CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-result :-"+result);
			//
			//			Calendar c1 = Calendar.getInstance(); 
			//			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			//			String endrt = sdf2.format(c1.getTime());
			//			try 
			//			{
			//				String finalResult;
			//				if(AadharResponse.contains(","))
			//				{
			//					finalResult=AadharResponse.split(",")[2];
			//					if(finalResult.equalsIgnoreCase("Please Update Your Device Version"))
			//					{
			//						return mUpdateVersion;
			//					}
			//				}
			//				else
			//				{
			//					finalResult="INAVALID RESPONSE";
			//				}
			//			} 
			//			catch (Exception e)
			//			{
			//				//	CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-IOException :-"+e.getMessage());
			//				//	CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			//				e.printStackTrace();
			//			}

			return mSuccess;//"Success"; 
			//} 

		} 
		catch (SocketTimeoutException e)
		{
			CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			CommonFunctions.writeLog(mContext,"result","AADHAAR_FINGER_AUTHENTICATION-IOException :-"+e.getMessage());
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			CommonFunctions.writeLog(mContext, "result", e.getMessage());
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			CommonFunctions.writeLog(mContext, "result", e.getMessage());
			return mException;
		}

	}


	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}


	public static String getPIDOptions(String verifyType) 
	{
		try 
		{
			int iCount=0;
			int fingerCount = 0;
			String pidVer ="";
			if(verifyType.equalsIgnoreCase("IIR"))
			{
				iCount=1;
				pidVer ="1.0";
			}
			else
			{
				fingerCount=1;
				pidVer ="2.0";
			}


			String timeOut = "12000";
			String posh = "UNKNOWN";


			Opts opts = new Opts();
			opts.fCount = String.valueOf(fingerCount);
			opts.fType = "0";
			opts.iCount = String.valueOf(iCount);
			opts.iType = "0";
			opts.pCount = "0";
			opts.pType = "0";
			opts.format = "0";
			opts.pidVer = "2.0";
			opts.timeout = timeOut;
			opts.posh = posh;
			//opts.wadh="rhVuL7SnJi2W2UmsyukVqY7c93JWyL9O/kVKgdNMfv8=";
			opts.wadh="+0njvZli4IkkbxG9yNKSWNMG7RNY6OhyWBUf/n5Dag4=";
			//opts.wadh = sha256("2.1"+"F"+"Y"+"Y"+"N"+"N"); // SHA-256(ver+ra+rc+lr+de+pfr)//"MglkKtwVbnGyKvqcYO4XXIfaxYmXgxev2R2B3nqeLnc=";//
			String env = "P";
			opts.env = env;

			PidOptions pidOptions = new PidOptions();
			pidOptions.ver = pidVer;
			pidOptions.Opts = opts;

			Serializer serializer = new Persister();
			StringWriter writer = new StringWriter();
			serializer.write(pidOptions, writer);
			return writer.toString();
		} 
		catch (Exception e) 
		{
			Log.e("Error", e.toString());
		}
		return null;
	}


	public static String sha256(String base) 
	{
		try
		{
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(base.getBytes("UTF-8"));
			String hexString=Base64.encodeToString(hash, Base64.DEFAULT) ;
			//	        StringBuffer hexString = new StringBuffer();
			//
			//	        for (int i = 0; i < hash.length; i++) {
			//	            String hex = Integer.toHexString(0xff & hash[i]);
			//	            if(hex.length() == 1) hexString.append('0');
			//	            hexString.append(hex);
			//	        }

			return hexString.toString();
		}
		catch(Exception ex)
		{
			throw new RuntimeException(ex);
		}
	}
}
