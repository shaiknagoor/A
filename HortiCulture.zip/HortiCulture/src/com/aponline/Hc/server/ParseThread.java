package com.aponline.Hc.server;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class ParseThread extends Thread
{

	Handler mUIHandler;
	Context mContext;
	String searchType;
	String methodName;
	String searchNo;
	String paramString1,paramString2,paramString3,paramString4,paramString5;
	public ParseThread(Context paramContext,Handler paramHandler, String methodName,String serchType,String searchNo)
	{
		this.mUIHandler = paramHandler;
		this.mContext=paramContext;
		this.methodName=methodName;
		this.searchType=serchType;
		this.searchNo=searchNo;
	}
	public ParseThread(Context paramContext,Handler paramHandler, String methodName,String paramString1,String paramString2,String paramString3,String paramString4) 
	{
		this.mUIHandler = paramHandler;
		this.mContext=paramContext;
		this.methodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
		this.paramString3=paramString3;
		this.paramString4=paramString4;
	}
	public ParseThread(Context paramContext,Handler paramHandler, String methodName,String paramString1,String paramString2,String paramString3,String paramString4,String paramString5) 
	{
		this.mUIHandler = paramHandler;
		this.mContext=paramContext;
		this.methodName=methodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
		this.paramString3=paramString3;
		this.paramString4=paramString4;
		this.paramString5=paramString5;
	}
	public ParseThread(Context mcontext, Handler mHandler, String methodName)
	{
		this.mUIHandler = mHandler;
		this.mContext=mcontext;
		this.methodName=methodName;
	}
	public void run()
	{
		Message localMessage = new Message();
		try {

			System.out.println("***********Inside Parsethread**********");
			//WebserviceCall com=new WebserviceCall(mContext);
			WebserviceCall com=new WebserviceCall(mContext);
			int i = 0;
			
			
//			
			
			if(methodName.equalsIgnoreCase("UploadInserGPSCoordinates"))
			{	
				 i=com.UploadInserGPSCoordinates();
				
			}
			if(methodName.equalsIgnoreCase("InsertInspectionDetails"))
			{	
				 i=com.InsertInspectionDetails();
				
			}
			if(methodName.equalsIgnoreCase("CheckUserAuthentication"))
			{	
				 i=com.CheckUserAuthentication();
				
			}
			if(methodName.equalsIgnoreCase("GetFarmerBasicDetails"))
			{	
				i = com.GetFarmerBasicDetails();
				
			}
			if(methodName.equalsIgnoreCase("InserGPSCoordinates"))
			{	
				i = com.InserGPSCoordinates();
				
			}
			if(methodName.equalsIgnoreCase("GPSCoordinatesReport"))
			{	
				i = com.GPSCoordinatesReport();
				
			}
			if(methodName.equalsIgnoreCase("Check_Version"))
			{
				i=com.Check_Version();
			}
			if(methodName.equalsIgnoreCase("InsertTraingingDetails"))
			{
				i=com.InsertTraingingDetails();
			}
			if(methodName.equalsIgnoreCase("UploadInsertTraingingDetails"))
			{
				i=com.UploadInsertTraingingDetails();
			}
			if(methodName.equalsIgnoreCase("GETGEOGRAPHICDETAILS"))
			{
				i=com.GETGEOGRAPHICDETAILS();
			}
			if(methodName.equalsIgnoreCase("crop"))
			{	
				 i=com.crop();
				
			}
			if(methodName.equalsIgnoreCase("GetMICompaniesList"))
			{	
				 i=com.GetMICompaniesList();
				
			}
			
			Log.d("cricbuzz", "JSON PARSED");
			localMessage.what = i;
			if (this.mUIHandler != null)
			{
				Log.d("cricbuzz", "JSON SENT");
				this.mUIHandler.sendMessage(localMessage);
				Log.d("cricbuzz", "JSON AFTER SENT");
			}
			return;
		}catch (Exception e) 
		{
			while (true)
			{
				e.printStackTrace();
				localMessage.what = 98;
				return;
			}
		}
	}
}
