package com.aponline.Hc.server;


import java.io.IOException;


import java.net.SocketTimeoutException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;


import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import com.aponline.Hc.database.DBAdapter;
import com.aponline.horticulture.Get_FormerDetails;
import com.aponline.horticulture.Home_Act;
import com.aponline.horticulture.Home_Act1;
import com.aponline.horticulture.Login_Page;
import com.aponline.horticulture.MiSurveySystemAct;
import com.aponline.horticulture.Training_Details;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;


public class WebserviceCall extends Thread
{

	/**
	 * Variable Decleration................
	 * 
	 */
	public static String Error; 
	

	String namespace = "http://HRTS.in/webservices/";
	//private String url="http://http://61.246.226.123/GPS/GPSCoordinatesService.asmx"; 
	//private String url="http://61.246.226.123:8080/GPS/GPSCoordinatesService.asmx";//new Test url

	private String url="http://horticulturedept.ap.gov.in/GPS/GPSCoordinatesService.asmx"; //new live url
	

	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	Context paramContext;
	public static int serverUploadcount;
	public static String serverResponse,VersionNo,FidStatus;
	DBAdapter db;
	ArrayList<ArrayList<String>> mandaldata;
	ArrayList<ArrayList<String>> villagedata;
	ArrayList<ArrayList<String>> panchayatdata;
	public static ArrayList<ContentValues> InspectionStaff_Cv;
	public static HashMap<String, String> Login_Details;
	public static HashMap<String, String> FarmerId_list,report_data,StaffDetailsHm;
	public static ArrayList<HashMap<String, String>> data,report;
	public static ArrayList<String> StaffDataSP_AL;

	public WebserviceCall(Context paraContext)
	{
		this.paramContext=paraContext;
		db=new DBAdapter(paraContext);  
	}

	public int GetInspectionStaffDetails() 
	{

		try
		{
			String methodName="GetInspectionDetails";
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("strDistrictId",Login_Details.get("DistrictId"));
			request.addProperty("strRoleId",Login_Details.get("ROLE_ID"));
			request.addProperty("strFLAG","I");

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				InspectionStaff_Cv=new ArrayList<ContentValues>();
				StaffDetailsHm=new HashMap<String, String>();
				StaffDataSP_AL=new ArrayList<String>();
				StaffDataSP_AL.add("---Select---");

				for(int i=0;i<jsonArray.length();i++)
				{
					ContentValues localCv=new ContentValues();
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}
					if(jsonObject.has("SNO") && jsonObject.has("Name") )
					{
						StaffDetailsHm.put(jsonObject.getString("Name"),jsonObject.getString("SNO"));
						localCv.put("Staff_Name", jsonObject.getString("Name"));
						localCv.put("Staff_ID", jsonObject.getString("SNO"));
						localCv.put("User_Name", Login_Page.UserId);
					}if(jsonObject.has("Name"))
					{
						StaffDataSP_AL.add(jsonObject.getString("Name"));

					}
					InspectionStaff_Cv.add(localCv);

				}

			}

			//Log.d("UPLOADIMAGE", result);
			return 22;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}

	public int mic() 
	{

		try
		{

			String methodName="GetMISURVEYComponentDetails";
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//			request.addProperty("UserId",Login_Page.UserId);
			//			request.addProperty("Password",Login_Page.PWd);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			db.open();
			db.deleteTableData("MI_Components_Prices", null);
			db.close();
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					ContentValues contentValues=new ContentValues();
					if(jsonObject.has("ComponentName"))
					{
						contentValues.put("Component_Name", jsonObject.getString("ComponentName"));

					}if(jsonObject.has("ComponentSize"))
					{
						contentValues.put("Component_Size",jsonObject.getString("ComponentSize"));
					}
					if(jsonObject.has("ComponentPrice"))
					{
						contentValues.put("Component_Price",jsonObject.getString("ComponentPrice"));
					}

					if(contentValues!=null)
					{
						db.open();
						db.insertTableDate("MI_Components_Prices",contentValues);
						String ff=db.getSingleValue("select Count(Component_Price) from MI_Components_Prices");
						System.out.println("---------------count----"+ff);
						db.close();
					}
				}

			}
//db.open();
//db.exportDB();
//db.close();
			//GetInspectionStaffDetails();
			return 22;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}
	public int crop() 
	{

		try
		{
			String methodName="GetCROPDetails";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			//			request.addProperty("UserId",Login_Page.UserId);
			//			request.addProperty("Password",Login_Page.PWd);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					ContentValues contentValues=new ContentValues();
					if(jsonObject.has("Crop_Type_Code"))
					{
						contentValues.put("Crop_Type_Code", jsonObject.getString("Crop_Type_Code"));

					}if(jsonObject.has("Crop_Type_Description"))
					{
						contentValues.put("Crop_Type_Description",jsonObject.getString("Crop_Type_Description"));
					}
					if(jsonObject.has("Crop_Code"))
					{
						contentValues.put("Crop_Code",jsonObject.getString("Crop_Code"));
					}
					if(jsonObject.has("Crop_Description"))
					{
						contentValues.put("Crop_Description",jsonObject.getString("Crop_Description"));
					}

					if(contentValues!=null)
					{
						db.open();
						db.insertTableDate("Crop_Master",contentValues);
						String ff=db.getSingleValue("select Count(Crop_Code) from Crop_Master");
						System.out.println("---------------count----"+ff);
						db.close();

					}
				}

			}

			//GetInspectionDetails();
			return 200;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}
	public int CheckUserAuthentication() 
	{

		try
		{
			String methodName="CheckUserAuthentication";
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			request.addProperty("UserId",Login_Page.UserId);
			request.addProperty("Password",Login_Page.PWd);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				Login_Details=new HashMap<String, String>();
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return 100;
				}
				if(jsonObject.has("DistrictId"))
				{
					Login_Details.put("DistrictId",jsonObject.getString("DistrictId"));
				}
				if(jsonObject.has("ROLE_ID"))
				{
					Login_Details.put("ROLE_ID",jsonObject.getString("ROLE_ID"));
				}
				if(jsonObject.has("STATUS"))
				{
					Login_Details.put("STATUS",jsonObject.getString("STATUS"));
				}
			}
			mic();
			GetInspectionStaffDetails();
			return 22;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}
	public int GetFarmerBasicDetails()
	{
		try
		{

			String methodName="GetFarmerBasicDetails";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);


			if(Home_Act1.Farmer_ID.equalsIgnoreCase("") || Home_Act1.Farmer_ID.equalsIgnoreCase("null"))
			{
				request.addProperty("UserId",Login_Page.UserId);
				request.addProperty("Password",Login_Page.PWd);
				request.addProperty("DistrictId",Get_FormerDetails.HDist_id);
				request.addProperty("MandalId",Get_FormerDetails.HMandal_id);
				request.addProperty("PanchayatId",Get_FormerDetails.HPanchayat_id);
				request.addProperty("VillageId",Get_FormerDetails.HViialge_id);
				request.addProperty("FarmerId","");
				request.addProperty("statuscode",Get_FormerDetails.HFId_status);
			}else {

				request.addProperty("UserId",Login_Page.UserId);
				request.addProperty("Password",Login_Page.PWd);
				request.addProperty("DistrictId","");
				request.addProperty("MandalId","");
				request.addProperty("PanchayatId","");
				request.addProperty("VillageId","");
				request.addProperty("FarmerId",Home_Act1.Farmer_ID);
				request.addProperty("statuscode","");
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();


			JSONArray jsonArray=new JSONArray(result);
			data =new ArrayList<HashMap<String, String>>();
			if(jsonArray.length()!=0)
			{      
				int p=0;
				for(int i=0;i<jsonArray.length();i++)
				{
					FarmerId_list=new HashMap<String, String>();
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}
					FarmerId_list.put("sno", Integer.toString(p+1));
					if(jsonObject.has("Farmer_Id"))
					{
						FarmerId_list.put("Farmer_Id",jsonObject.getString("Farmer_Id"));
					}
					else {
						FarmerId_list.put("Farmer_Id","");
					}
					if(jsonObject.has("FarmerName"))
					{
						FarmerId_list.put("FarmerName",jsonObject.getString("FarmerName"));
					}else {
						FarmerId_list.put("FarmerName","");
					}

					if(jsonObject.has("FatherName"))
					{
						FarmerId_list.put("FatherName",jsonObject.getString("FatherName"));
					}else {
						FarmerId_list.put("FatherName","");
					}
					if(jsonObject.has("MobileNumber"))
					{
						FarmerId_list.put("MobileNumber",jsonObject.getString("MobileNumber"));
					}else {
						FarmerId_list.put("MobileNumber","");
					}
					if(jsonObject.has("Caste"))
					{
						FarmerId_list.put("Social_staus",jsonObject.getString("Caste"));
					}else {
						FarmerId_list.put("Social_staus","");
					}
					if(jsonObject.has("FarmerAddress"))
					{
						FarmerId_list.put("FarmerAddress",jsonObject.getString("FarmerAddress"));
					}else {
						FarmerId_list.put("FarmerAddress","");
					}
					if(jsonObject.has("Survey_No"))
					{
						FarmerId_list.put("Survey_No",jsonObject.getString("Survey_No"));
					}else {
						FarmerId_list.put("Survey_No","");
					}
					if(jsonObject.has("AADHAARNUMBER"))
					{
						FarmerId_list.put("AADHAARNUMBER",jsonObject.getString("AADHAARNUMBER"));
					}else {
						FarmerId_list.put("AADHAARNUMBER","");
					}
					if(jsonObject.has("CropName"))
					{
						FarmerId_list.put("CropName",jsonObject.getString("CropName"));
					}else {
						FarmerId_list.put("CropName","");
					}
					if(jsonObject.has("Area_Proposed"))
					{
						FarmerId_list.put("Area_Proposed",jsonObject.getString("Area_Proposed"));
					}else {
						FarmerId_list.put("Area_Proposed","");
					}
					if(jsonObject.has("FARMERSTATUS"))
					{
						FarmerId_list.put("FARMERSTATUS",jsonObject.getString("FARMERSTATUS"));
					}else {
						FarmerId_list.put("FARMERSTATUS","");
					}
					if(jsonObject.has("CATEGORY"))
					{
						FarmerId_list.put("CATEGORY",jsonObject.getString("CATEGORY"));
					}else {
						FarmerId_list.put("CATEGORY","");
					}
					if(jsonObject.has("RequestId"))
					{
						FarmerId_list.put("RequestId",jsonObject.getString("RequestId"));
					}else {
						FarmerId_list.put("RequestId","");
					}
					if(jsonObject.has("Status_Code"))
					{
						FarmerId_list.put("Status_Code",jsonObject.getString("Status_Code"));
					}else {
						FarmerId_list.put("Status_Code","");
					}
					if(jsonObject.has("MI_Company_Name"))
					{
						FarmerId_list.put("MI_Company_Name",jsonObject.getString("MI_Company_Name"));
					}else {
						FarmerId_list.put("MI_Company_Name","");
					}
					if(jsonObject.has("MI_System_Type"))
					{
						FarmerId_list.put("MI_System_Type",jsonObject.getString("MI_System_Type"));
					}else {
						FarmerId_list.put("MI_System_Type","");
					}
					if(jsonObject.has("Installation_Year"))
					{
						FarmerId_list.put("Installation_Year",jsonObject.getString("Installation_Year"));
					}else {
						FarmerId_list.put("Installation_Year","");
					}
					if(jsonObject.has("Subsidy"))
					{
						FarmerId_list.put("Subsidy",jsonObject.getString("Subsidy"));
					}else {
						FarmerId_list.put("Subsidy","");
					}
					if(jsonObject.has("District_id"))
					{
						FarmerId_list.put("District_id",jsonObject.getString("District_id"));
					}else {
						FarmerId_list.put("District_id","");
					}
					if(jsonObject.has("Mandal_id"))
					{
						FarmerId_list.put("Mandal_id",jsonObject.getString("Mandal_id"));
					}else {
						FarmerId_list.put("Mandal_id","");
					}
					if(jsonObject.has("Panchayat_Code"))
					{
						FarmerId_list.put("Panchayat_Code",jsonObject.getString("Panchayat_Code"));
					}else {
						FarmerId_list.put("Panchayat_Code","");
					}
					if(jsonObject.has("Village_Code"))
					{
						FarmerId_list.put("Village_Code",jsonObject.getString("Village_Code"));
					}else {
						FarmerId_list.put("Village_Code","");
					}
					if(jsonObject.has("Habitation_Id"))
					{
						FarmerId_list.put("Habitation_Id",jsonObject.getString("Habitation_Id"));
					}else {
						FarmerId_list.put("Habitation_Id","");
					}



					if(jsonObject.has("RESULT"))
					{
						FidStatus=jsonObject.getString("RESULT");
					}else {
						FidStatus="";
					}


					data.add(FarmerId_list);
					p++;
				}
			}

			//Log.d("UPLOADIMAGE", result);
			return 23;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}

	public int GPSCoordinatesReport()
	{
		try
		{

			String methodName="GPSCoordinatesReport";
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("DistrictId",Login_Page.Dist_id);
			request.addProperty("MandalId",Login_Page.Mandal_id);
			request.addProperty("PanchayatId",Login_Page.Panchayat_id);
			request.addProperty("VillageId",Login_Page.Viialge_id);


			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();


			JSONArray jsonArray=new JSONArray(result);
			report =new ArrayList<HashMap<String, String>>();
			if(jsonArray.length()!=0)
			{      
				int p=0;
				for(int i=0;i<jsonArray.length();i++)
				{
					report_data=new HashMap<String, String>();
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}
					report_data.put("sno", Integer.toString(p+1));
					if(jsonObject.has("Farmer_Id"))
					{
						report_data.put("Farmer_Id",jsonObject.getString("Farmer_Id"));
					}
					else {
						report_data.put("Farmer_Id","");
					}
					if(jsonObject.has("FarmerName"))
					{
						report_data.put("FarmerName",jsonObject.getString("FarmerName"));
					}else {
						report_data.put("FarmerName","");
					}

					if(jsonObject.has("Survey_No"))
					{
						report_data.put("Survey_No",jsonObject.getString("Survey_No"));
					}else {
						report_data.put("Survey_No","");
					}
					if(jsonObject.has("CropName"))
					{
						report_data.put("CropName",jsonObject.getString("CropName"));
					}else {
						report_data.put("CropName","");
					}
					if(jsonObject.has("MobileNumber"))
					{
						report_data.put("MobileNumber",jsonObject.getString("MobileNumber"));
					}else {
						report_data.put("MobileNumber","");
					}
					if(jsonObject.has("FARMERSTATUS"))
					{
						report_data.put("FARMERSTATUS",jsonObject.getString("FARMERSTATUS"));
					}else {
						report_data.put("FARMERSTATUS","");
					}
					if(jsonObject.has("GPSWATERSOURCE"))
					{
						report_data.put("GPSWATERSOURCE",jsonObject.getString("GPSWATERSOURCE"));
					}else {
						report_data.put("GPSWATERSOURCE","");
					}

					report.add(report_data);
					p++;
				}
			}

			//Log.d("UPLOADIMAGE", result);
			return 24;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}


	public int InsertInspectionDetails() 
	{

		try
		{


			String methodName="InsertInspectionDetails";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			DecimalFormat df = new DecimalFormat("#.##");
			request.addProperty("strUserId",Login_Page.UserId);
			request.addProperty("strfarmerid",MiSurveySystemAct.MIFarmer_ID);
			request.addProperty("strmobile",MiSurveySystemAct.MiMobile);
			request.addProperty("strdischargevalue",MiSurveySystemAct.strdischargevalue);
			request.addProperty("strCROP",MiSurveySystemAct.strCROP);
			request.addProperty("strAREAPROPOSED",MiSurveySystemAct.strAREAPROPOSED);
			request.addProperty("strSTATUSOFMISYSTEM",MiSurveySystemAct.strSTATUSOFMISYSTEM);
			request.addProperty("FarmerFieldPhoto1",MiSurveySystemAct.CapurePhotos.get("photoOne"));
			request.addProperty("FarmerFieldPhoto2",MiSurveySystemAct.CapurePhotos.get("photoTwo"));
			request.addProperty("strHeadControlUnit_GPS_Coordinates",MiSurveySystemAct.Headcontrol_LaLg);
			request.addProperty("strWaterSource_GPS_Coordinates",MiSurveySystemAct.waterSource_LaLg);
			request.addProperty("strTrackingOfTheField_GPS_Coordinates",MiSurveySystemAct.Trackling_LaLg);
			request.addProperty("strFUNCTIONAL",MiSurveySystemAct.strFUNCTIONAL);
			request.addProperty("strNOTEXISTS",MiSurveySystemAct.strNOTEXISTS);
			request.addProperty("strNOTFUNCTIONING",MiSurveySystemAct.strNOTFUNCTIONING);
			//request.addProperty("strInvestigatorDetails",StaffDetailsHm.get(MiSurveySystemAct.strInvestigatorDetails)+"-"+MiSurveySystemAct.miplace);
			//request.addProperty("strDeptOfficialDetails",StaffDetailsHm.get(MiSurveySystemAct.strDeptOfficialDetails)+"-"+MiSurveySystemAct.miplace);
			request.addProperty("strInvestigatorDetails",MiSurveySystemAct.strInvestigatorDetails1+"-"+MiSurveySystemAct.miplace);
			request.addProperty("strDeptOfficialDetails",MiSurveySystemAct.strDeptOfficialDetails1+"-"+MiSurveySystemAct.miplace);
			request.addProperty("strComponentDetails",MiSurveySystemAct.strComponentDetails);
			request.addProperty("strmode","OL");			
			request.addProperty("strvat",df.format(MiSurveySystemAct.vat));
			request.addProperty("strtotalamount",df.format(MiSurveySystemAct.caltot));
			request.addProperty("strsubsidyamount",df.format(MiSurveySystemAct.subsidy));
			request.addProperty("strnonsubsidyamount",df.format(MiSurveySystemAct.nonsubsidy));		
			request.addProperty("strtotalnonsubsidyamount",df.format(MiSurveySystemAct.totalnonsubsidy));
			request.addProperty("strcroptype",MiSurveySystemAct.strCROPTYPE);
			request.addProperty("strcrop2",MiSurveySystemAct.strCROP1);
			request.addProperty("strcroptype2",MiSurveySystemAct.strCROPTYPE1);
			request.addProperty("strextenct",MiSurveySystemAct.strAREAPROPOSED1);
			request.addProperty("strlateralspacing",MiSurveySystemAct.strLateral_space);
			request.addProperty("strlateralspacing2",MiSurveySystemAct.strLateral_space1);
			request.addProperty("strflag","FR");
			request.addProperty("strtranspotationcost",MiSurveySystemAct.strtranspotationcost);
			request.addProperty("strsanctioned_area",MiSurveySystemAct.strsanctioned_area);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();


			JSONArray jsonArray=new JSONArray(result1);
			if(jsonArray.length()!=0)
			{      

				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))

				{
					Error=jsonObject.getString("Error"); 
					return 100;
				}

				if(jsonObject.has("Message"))
				{
					serverResponse=jsonObject.getString("Message").toString();
				}
			}



			return 15;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}

	public int InserGPSCoordinates() 
	{

		try
		{

			String methodName="InserGPSCoordinates";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("FarmerId",Home_Act.Farmer_ID);
			request.addProperty("RequestId",Home_Act.Request_Id);
			request.addProperty("UserId",Login_Page.UserId);
			request.addProperty("FarmerFieldPhoto1",Home_Act.CapurePhotos.get("photoOne"));
			request.addProperty("FarmerFieldPhoto2",Home_Act.CapurePhotos.get("photoTwo"));
			request.addProperty("LandMarkPhoto_FinalInspection","");
			request.addProperty("HeadControlUnit_GPS_Coordinates",Home_Act.Headcontrol_LaLg);
			request.addProperty("WaterSource_GPS_Coordinates",Home_Act.waterSource_LaLg);
			request.addProperty("TrackingOfTheField_GPS_Coordinates",Home_Act.Trackling_LaLg);
			request.addProperty("StatusCode",Home_Act.Status_code);
			request.addProperty("strmode","OL");


			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();


			JSONArray jsonArray=new JSONArray(result1);
			if(jsonArray.length()!=0)
			{      

				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return 100;
				}
				if(jsonObject.has("Message"))
				{
					serverResponse=jsonObject.getString("Message").toString();
				}
			}


			return 15;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}

	}



	public int Check_Version()
	{
		try
		{

			String methodName="CheckAppVersion";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace,methodName);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.


			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION,envelope);	


			String result1 = envelope.getResponse().toString();

			JSONArray jsonArray=new JSONArray(result1);
			if(jsonArray.length()!=0)
			{ 
				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return 100;
				}
				if(jsonObject.has("CurrentVersion"))
				{
					VersionNo=jsonObject.getString("CurrentVersion").toString();
				}
			}
			return 15;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			System.out.println("----"+androidHttpTransport.requestDump);
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}


	}




	public int UploadInserGPSCoordinates()
	{

		ArrayList<HashMap<String,String>> offlineData=new ArrayList<HashMap<String,String>>();
		try 
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("select DISTINCT FarmerId,RequestId,User_ID,FarmerFieldPhoto1,FarmerFieldPhoto2,HeadControlUnit_GPS_Coordinates,WaterSource_GPS_Coordinates,TrackingOfTheField_GPS_Coordinates,Status_Code from APMIP_FARMER_DETAILS where Status_Flag='P' and User_ID='"+Login_Page.UserId+"' and FARMERSTATUS not Like 'MI SURVEY FARMER'");
			if(cursor.getCount()>0)
			{
				if(cursor.moveToFirst())
				{
					do
					{
						HashMap<String, String> uploadDetailsHashMap=new HashMap<String, String>();
						uploadDetailsHashMap=new HashMap<String, String>();
						uploadDetailsHashMap.put("FarmerId", cursor.getString(0));
						uploadDetailsHashMap.put("RequestId",cursor.getString(1));
						uploadDetailsHashMap.put("User_ID", cursor.getString(2));
						uploadDetailsHashMap.put("FarmerFieldPhoto1",cursor.getString(3));
						uploadDetailsHashMap.put("FarmerFieldPhoto2",cursor.getString(4));
						uploadDetailsHashMap.put("HeadControlUnit_GPS_Coordinates",cursor.getString(5));
						uploadDetailsHashMap.put("WaterSource_GPS_Coordinates",cursor.getString(6));
						uploadDetailsHashMap.put("TrackingOfTheField_GPS_Coordinates",cursor.getString(7));
						uploadDetailsHashMap.put("Status_Code",cursor.getString(8));


						offlineData.add(uploadDetailsHashMap);
					}while(cursor.moveToNext());
				}
			}
			cursor.close();
			db.close();
			if(offlineData.size()>0)
			{
				for(int i=0;i<offlineData.size();i++)
				{
					serverUploadcount=0;
					HashMap<String, String> uploadDetailsHashMap=offlineData.get(i);

					String methodName="InserGPSCoordinates";
					Log.e("Method Name", methodName);
					SOAP_ACTION = namespace + methodName;
					request = new SoapObject(namespace, methodName);

					request.addProperty("FarmerId",uploadDetailsHashMap.get("FarmerId"));
					request.addProperty("RequestId",uploadDetailsHashMap.get("RequestId"));
					request.addProperty("UserId",uploadDetailsHashMap.get("User_ID"));
					request.addProperty("FarmerFieldPhoto1",uploadDetailsHashMap.get("FarmerFieldPhoto1"));
					request.addProperty("FarmerFieldPhoto2",uploadDetailsHashMap.get("FarmerFieldPhoto2"));
					request.addProperty("LandMarkPhoto_FinalInspection","");
					request.addProperty("HeadControlUnit_GPS_Coordinates",uploadDetailsHashMap.get("HeadControlUnit_GPS_Coordinates"));
					request.addProperty("WaterSource_GPS_Coordinates",uploadDetailsHashMap.get("WaterSource_GPS_Coordinates"));
					request.addProperty("TrackingOfTheField_GPS_Coordinates",uploadDetailsHashMap.get("TrackingOfTheField_GPS_Coordinates"));
					request.addProperty("StatusCode",uploadDetailsHashMap.get("Status_Code"));
					request.addProperty("strmode","OF");


					envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
					envelope.dotNet=true;
					envelope.setOutputSoapObject(request);
					// Make the soap call.
					androidHttpTransport = new HttpTransportSE(url,120000);
					androidHttpTransport.debug = true;
					androidHttpTransport.call(SOAP_ACTION, envelope);
					String result1 = envelope.getResponse().toString();
					System.out.println("---"+result1);

					JSONArray jsonArray=new JSONArray(result1);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse=jsonObject.getString("Message").toString();
						}
					}

					if(serverResponse.equalsIgnoreCase("success")||serverResponse.equalsIgnoreCase("Exists"))
					{

						db.open();
						db.execSQL("UPDATE APMIP_FARMER_DETAILS SET Status_Flag = 'Y' WHERE Status_Flag='P' and FarmerId='"+uploadDetailsHashMap.get("FarmerId")+"' and User_ID='"+uploadDetailsHashMap.get("User_ID")+"'");
						db.close();
						serverUploadcount++;
					}


				}
			}
			UploadInsertInspectionDetails();
			return 12;
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			e.printStackTrace();
			return 11;
		} catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return 11;
		}catch (Exception e) 
		{
			e.printStackTrace();
			return 11;
		}
	}

	public int UploadInsertInspectionDetails()
	{

		ArrayList<HashMap<String,String>> offlineData=new ArrayList<HashMap<String,String>>();
		try 
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("select DISTINCT User_ID,FarmerId,MobileNumber,Dischargevalue,Survey_CROP,Area_Proposed," +
					"Survey_STATUSOFMISYSTEM,FarmerFieldPhoto1,FarmerFieldPhoto2,HeadControlUnit_GPS_Coordinates," +
					"WaterSource_GPS_Coordinates,TrackingOfTheField_GPS_Coordinates,Survey_FUNCTIONAL,Survey_NOTEXISTS," +
					"Survey_NOTFUNCTIONING,Survey_DeptOfficialDetails,Survey_InvestigatorDetails,Survey_ComponentDetails,totalamount,subsidyamount,nonsubsidyamount,vat,totalnonsubsidyamount,Lateral_space,Lateral_space1,Area_Proposed1,Survey_CROP1,CROP_TYPE,CROP_TYPE1,TRANSPORT_COST,SANCTIONED_EXTENT from APMIP_FARMER_DETAILS where User_ID='"+Login_Page.UserId+"' and FARMERSTATUS='MI SURVEY FARMER' and Status_Flag='P'");
			if(cursor.getCount()>0)
			{
				if(cursor.moveToFirst())
				{
					do
					{
						HashMap<String, String> uploadDetailsHashMap=new HashMap<String, String>();
						uploadDetailsHashMap=new HashMap<String, String>();
						uploadDetailsHashMap.put("User_ID", cursor.getString(0));
						uploadDetailsHashMap.put("FarmerId",cursor.getString(1));
						uploadDetailsHashMap.put("MobileNumber", cursor.getString(2));
						uploadDetailsHashMap.put("Dischargevalue",cursor.getString(3));
						uploadDetailsHashMap.put("Survey_CROP",cursor.getString(4));
						uploadDetailsHashMap.put("Area_Proposed",cursor.getString(5));
						uploadDetailsHashMap.put("Survey_STATUSOFMISYSTEM",cursor.getString(6));
						uploadDetailsHashMap.put("FarmerFieldPhoto1",cursor.getString(7));
						uploadDetailsHashMap.put("FarmerFieldPhoto2",cursor.getString(8));
						uploadDetailsHashMap.put("HeadControlUnit_GPS_Coordinates",cursor.getString(9));
						uploadDetailsHashMap.put("WaterSource_GPS_Coordinates",cursor.getString(10));
						uploadDetailsHashMap.put("TrackingOfTheField_GPS_Coordinates",cursor.getString(11));
						uploadDetailsHashMap.put("Survey_FUNCTIONAL",cursor.getString(12));
						uploadDetailsHashMap.put("Survey_NOTEXISTS",cursor.getString(13));
						uploadDetailsHashMap.put("Survey_NOTFUNCTIONING",cursor.getString(14));
						uploadDetailsHashMap.put("Survey_DeptOfficialDetails",cursor.getString(15));
						uploadDetailsHashMap.put("Survey_InvestigatorDetails",cursor.getString(16));
						uploadDetailsHashMap.put("Survey_ComponentDetails",cursor.getString(17));
						uploadDetailsHashMap.put("totalamount",cursor.getString(18));
						uploadDetailsHashMap.put("subsidyamount",cursor.getString(19));
						uploadDetailsHashMap.put("nonsubsidyamount",cursor.getString(20));
						uploadDetailsHashMap.put("vat",cursor.getString(21));
						uploadDetailsHashMap.put("totalnonsubsidyamount",cursor.getString(22));
						uploadDetailsHashMap.put("strlateralspacing",cursor.getString(23));
						uploadDetailsHashMap.put("strlateralspacing2",cursor.getString(24));
						uploadDetailsHashMap.put("strextenct",cursor.getString(25));
						uploadDetailsHashMap.put("strcrop2",cursor.getString(26));
						uploadDetailsHashMap.put("strcroptype",cursor.getString(27));
						uploadDetailsHashMap.put("strcroptype2",cursor.getString(28));
						uploadDetailsHashMap.put("strtranspotationcost",cursor.getString(29));
						uploadDetailsHashMap.put("strsanctioned_area",cursor.getString(30));
						offlineData.add(uploadDetailsHashMap);
					}while(cursor.moveToNext());
				}
			}
			cursor.close();
			db.close();
			if(offlineData.size()>0)
			{
				for(int i=0;i<offlineData.size();i++)
				{
					serverUploadcount=0;
					HashMap<String, String> uploadDetailsHashMap=offlineData.get(i);

					String methodName="InsertInspectionDetails";
					Log.e("Method Name", methodName);
					SOAP_ACTION = namespace + methodName;
					request = new SoapObject(namespace, methodName);

					request.addProperty("strUserId",uploadDetailsHashMap.get("User_ID"));
					request.addProperty("strfarmerid",uploadDetailsHashMap.get("FarmerId"));
					request.addProperty("strmobile",uploadDetailsHashMap.get("MobileNumber"));
					request.addProperty("strdischargevalue",uploadDetailsHashMap.get("Dischargevalue"));
					request.addProperty("strCROP",uploadDetailsHashMap.get("Survey_CROP"));
					request.addProperty("strAREAPROPOSED",uploadDetailsHashMap.get("Area_Proposed"));
					request.addProperty("strSTATUSOFMISYSTEM",uploadDetailsHashMap.get("Survey_STATUSOFMISYSTEM"));
					request.addProperty("FarmerFieldPhoto1",uploadDetailsHashMap.get("FarmerFieldPhoto1"));
					request.addProperty("FarmerFieldPhoto2",uploadDetailsHashMap.get("FarmerFieldPhoto2"));
					request.addProperty("strHeadControlUnit_GPS_Coordinates",uploadDetailsHashMap.get("HeadControlUnit_GPS_Coordinates"));
					request.addProperty("strWaterSource_GPS_Coordinates",uploadDetailsHashMap.get("WaterSource_GPS_Coordinates"));
					request.addProperty("strTrackingOfTheField_GPS_Coordinates",uploadDetailsHashMap.get("TrackingOfTheField_GPS_Coordinates"));
					request.addProperty("strFUNCTIONAL",uploadDetailsHashMap.get("Survey_FUNCTIONAL"));
					request.addProperty("strNOTEXISTS",uploadDetailsHashMap.get("Survey_NOTEXISTS"));
					request.addProperty("strNOTFUNCTIONING",uploadDetailsHashMap.get("Survey_NOTFUNCTIONING"));
					request.addProperty("strInvestigatorDetails",uploadDetailsHashMap.get("Survey_InvestigatorDetails"));
					request.addProperty("strDeptOfficialDetails",uploadDetailsHashMap.get("Survey_DeptOfficialDetails"));
					request.addProperty("strComponentDetails",uploadDetailsHashMap.get("Survey_ComponentDetails"));
					request.addProperty("strmode","OF");
					request.addProperty("strvat",uploadDetailsHashMap.get("vat"));
					request.addProperty("strtotalamount",uploadDetailsHashMap.get("totalamount"));
					request.addProperty("strsubsidyamount",uploadDetailsHashMap.get("subsidyamount"));
					request.addProperty("strnonsubsidyamount",uploadDetailsHashMap.get("nonsubsidyamount"));		
					request.addProperty("strtotalnonsubsidyamount",uploadDetailsHashMap.get("totalnonsubsidyamount"));
					request.addProperty("strcroptype",uploadDetailsHashMap.get("strcroptype"));
					request.addProperty("strcrop2",uploadDetailsHashMap.get("strcrop2"));
					request.addProperty("strcroptype2",uploadDetailsHashMap.get("strcroptype2"));
					request.addProperty("strextenct",uploadDetailsHashMap.get("strextenct"));
					request.addProperty("strlateralspacing",uploadDetailsHashMap.get("strlateralspacing"));
					request.addProperty("strlateralspacing2",uploadDetailsHashMap.get("strlateralspacing2"));
					request.addProperty("strflag","FR");
					request.addProperty("strtranspotationcost",uploadDetailsHashMap.get("strtranspotationcost"));
					request.addProperty("strsanctioned_area",uploadDetailsHashMap.get("strsanctioned_area"));
					envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
					envelope.dotNet=true;
					envelope.setOutputSoapObject(request);
					// Make the soap call.
					androidHttpTransport = new HttpTransportSE(url,120000);
					androidHttpTransport.debug = true;
					androidHttpTransport.call(SOAP_ACTION, envelope);
					String result1 = envelope.getResponse().toString();


					JSONArray jsonArray=new JSONArray(result1);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse=jsonObject.getString("Message").toString();
						}
					}

					if(serverResponse.equalsIgnoreCase("success")||serverResponse.equalsIgnoreCase("Exists"))
					{
						db.open();
						db.execSQL("UPDATE APMIP_FARMER_DETAILS SET Status_Flag = 'Y' WHERE Status_Flag='P' and FarmerId='"+uploadDetailsHashMap.get("FarmerId")+"' and User_ID='"+uploadDetailsHashMap.get("User_ID")+"'");
						db.close();
						serverUploadcount++;
					}
				}
			}
			return 12;
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			e.printStackTrace();
			return 11;
		} catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return 11;
		}catch (Exception e) 
		{
			e.printStackTrace();
			return 11;
		}
	}

	public int InsertTraingingDetails()
	{

		try
		{
			String methodName="InsertTraingingDetails";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("strdistrictid",Get_FormerDetails.HDist_id);
			request.addProperty("strmandalid",Get_FormerDetails.HMandal_id);
			request.addProperty("strpanchayatid",Get_FormerDetails.HPanchayat_id);
			request.addProperty("strvillageid",Get_FormerDetails.HViialge_id);
			request.addProperty("strCROPnames",Training_Details.strCROPnames);
			request.addProperty("strAGRONOMIC_WATER_MANAGEMENT",Training_Details.strAGRONOMIC_WATER_MANAGEMENT);
			request.addProperty("strAGRONOMIC_NUTRIENT_MANAGEMENT",Training_Details.strAGRONOMIC_NUTRIENT_MANAGEMENT);
			request.addProperty("strAGRONOMIC_PESTDISEASE_MANAGEMENT",Training_Details.strAGRONOMIC_PESTDISEASE_MANAGEMENT);
			request.addProperty("strAGRONOMIC_HARVEST_HANDLING",Training_Details.strAGRONOMIC_HARVEST_HANDLING);
			request.addProperty("strASPECT_FERTIGATION",Training_Details.strASPECT_FERTIGATION);
			request.addProperty("strASPECT_MISYSTEM_MAINTENANCE",Training_Details.strASPECT_MISYSTEM_MAINTENANCE);
			request.addProperty("strASPECT_AFETR_SALESSERVICE",Training_Details.strASPECT_AFETR_SALESSERVICE);
			request.addProperty("strFARMERS_PROBLEMS",Training_Details.strFARMERS_PROBLEMS);
			request.addProperty("strACTION_TAKEN",Training_Details.strACTION_TAKEN);
			request.addProperty("strRESOURCEPERSON_DESIGNATION",Training_Details.person_designation);
			request.addProperty("strRESOURCEPERSON_NAME",Training_Details.person_name);
			request.addProperty("intFARMERSPARTICIPATEDCOUNT",Training_Details.intFARMERSPARTICIPATEDCOUNT);			
			request.addProperty("strCREATEDBY",Login_Page.UserId);
			request.addProperty("strGPSCOORDINATES",Training_Details.gps_latitude+","+Training_Details.gps_longitude);
			request.addProperty("strtrainingdate",Training_Details.strtrainingdate);
			request.addProperty("strPHOTO1",Training_Details.TrainCapurePhotos.get("photoOne"));
			request.addProperty("strPHOTO2",Training_Details.TrainCapurePhotos.get("photoTwo"));
			request.addProperty("strPHOTO3",Training_Details.TrainCapurePhotos.get("photoThree"));
			request.addProperty("strmode","OL");
			request.addProperty("strMISupplierId",Training_Details.strMISupplierId);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			System.out.println("----"+result);
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      

				JSONObject jsonObject=jsonArray.getJSONObject(0);
				if(jsonObject.has("Error"))
				{
					Error=jsonObject.getString("Error"); 
					return 100;
				}
				if(jsonObject.has("Message"))
				{
					serverResponse=jsonObject.getString("Message").toString();
				}
			}

			return 22;
		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}

	public int UploadInsertTraingingDetails() {

		ArrayList<HashMap<String,String>> offlineData=new ArrayList<HashMap<String,String>>();
		try 
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("select  District_id,Mandal_id,Panchayat_id,Village_id,Major_crop,AGRONOMIC_WATER_MANAGEMENT,AGRONOMIC_NUTRIENT_MANAGEMENT,AGRONOMIC_PESTDISEASE_MANAGEMENT,AGRONOMIC_HARVEST_HANDLING,ASPECT_FERTIGATION,ASPECT_MISYSTEM_MAINTENANCE,ASPECT_AFETR_SALESSERVICE,FARMERS_PROBLEMS,ACTION_TAKEN,RESOURCEPERSON_DESIGNATION,RESOURCEPERSON_NAME,FARMERSPARTICIPATEDCOUNT,PHOTO_ONE,PHOTO_TWO,PHOTO_THREE,CREATED_BY,GPSCOORDINATES,TRAINING_DATE,AUTO_ID,MISupplierId from VILLAGE_TRAINING_DETAILS where STATUS_FLAG='P' and CREATED_BY='"+Login_Page.UserId+"'");
			if(cursor.getCount()>0)
			{
				if(cursor.moveToFirst())
				{
					do
					{
						HashMap<String, String> uploadDetailsHashMap=new HashMap<String, String>();
						uploadDetailsHashMap=new HashMap<String, String>();
						uploadDetailsHashMap.put("District_id", cursor.getString(0));
						uploadDetailsHashMap.put("Mandal_id",cursor.getString(1));
						uploadDetailsHashMap.put("Panchayat_id", cursor.getString(2));
						uploadDetailsHashMap.put("Village_id",cursor.getString(3));
						uploadDetailsHashMap.put("Major_crop",cursor.getString(4));
						uploadDetailsHashMap.put("AGRONOMIC_WATER_MANAGEMENT",cursor.getString(5));
						uploadDetailsHashMap.put("AGRONOMIC_NUTRIENT_MANAGEMENT",cursor.getString(6));
						uploadDetailsHashMap.put("AGRONOMIC_PESTDISEASE_MANAGEMENT",cursor.getString(7));
						uploadDetailsHashMap.put("AGRONOMIC_HARVEST_HANDLING",cursor.getString(8));
						uploadDetailsHashMap.put("ASPECT_FERTIGATION",cursor.getString(9));
						uploadDetailsHashMap.put("ASPECT_MISYSTEM_MAINTENANCE",cursor.getString(10));
						uploadDetailsHashMap.put("ASPECT_AFETR_SALESSERVICE",cursor.getString(11));
						uploadDetailsHashMap.put("FARMERS_PROBLEMS",cursor.getString(12));
						uploadDetailsHashMap.put("ACTION_TAKEN",cursor.getString(13));
						uploadDetailsHashMap.put("RESOURCEPERSON_DESIGNATION",cursor.getString(14));
						uploadDetailsHashMap.put("RESOURCEPERSON_NAME",cursor.getString(15));
						uploadDetailsHashMap.put("FARMERSPARTICIPATEDCOUNT",cursor.getString(16));
						uploadDetailsHashMap.put("PHOTO_ONE",cursor.getString(17));
						uploadDetailsHashMap.put("PHOTO_TWO",cursor.getString(18));
						uploadDetailsHashMap.put("PHOTO_THREE",cursor.getString(19));
						uploadDetailsHashMap.put("CREATED_BY",cursor.getString(20));
						uploadDetailsHashMap.put("GPSCOORDINATES",cursor.getString(21));
						uploadDetailsHashMap.put("TRAINING_DATE",cursor.getString(22));
						uploadDetailsHashMap.put("AUTO_ID",cursor.getString(23));
						uploadDetailsHashMap.put("strMISupplierId",cursor.getString(24));
						offlineData.add(uploadDetailsHashMap);
					}while(cursor.moveToNext());
				}
			}
			cursor.close();
			db.close();
			if(offlineData.size()>0)
			{
				for(int i=0;i<offlineData.size();i++)
				{
					serverUploadcount=0;
					HashMap<String, String> uploadDetailsHashMap=offlineData.get(i);

					String methodName="InsertTraingingDetails";
					Log.e("Method Name", methodName);
					SOAP_ACTION = namespace + methodName;
					request = new SoapObject(namespace, methodName);


					request.addProperty("strdistrictid",uploadDetailsHashMap.get("District_id"));
					request.addProperty("strmandalid",uploadDetailsHashMap.get("Mandal_id"));
					request.addProperty("strpanchayatid",uploadDetailsHashMap.get("Panchayat_id"));
					request.addProperty("strvillageid",uploadDetailsHashMap.get("Village_id"));
					request.addProperty("strCROPnames",uploadDetailsHashMap.get("Major_crop"));
					request.addProperty("strAGRONOMIC_WATER_MANAGEMENT",uploadDetailsHashMap.get("AGRONOMIC_WATER_MANAGEMENT"));
					request.addProperty("strAGRONOMIC_NUTRIENT_MANAGEMENT",uploadDetailsHashMap.get("AGRONOMIC_NUTRIENT_MANAGEMENT"));
					request.addProperty("strAGRONOMIC_PESTDISEASE_MANAGEMENT",uploadDetailsHashMap.get("AGRONOMIC_PESTDISEASE_MANAGEMENT"));
					request.addProperty("strAGRONOMIC_HARVEST_HANDLING",uploadDetailsHashMap.get("AGRONOMIC_HARVEST_HANDLING"));
					request.addProperty("strASPECT_FERTIGATION",uploadDetailsHashMap.get("ASPECT_FERTIGATION"));
					request.addProperty("strASPECT_MISYSTEM_MAINTENANCE",uploadDetailsHashMap.get("ASPECT_MISYSTEM_MAINTENANCE"));
					request.addProperty("strASPECT_AFETR_SALESSERVICE",uploadDetailsHashMap.get("ASPECT_AFETR_SALESSERVICE"));
					request.addProperty("strFARMERS_PROBLEMS",uploadDetailsHashMap.get("FARMERS_PROBLEMS"));
					request.addProperty("strACTION_TAKEN",uploadDetailsHashMap.get("ACTION_TAKEN"));
					request.addProperty("strRESOURCEPERSON_DESIGNATION",uploadDetailsHashMap.get("RESOURCEPERSON_DESIGNATION"));
					request.addProperty("strRESOURCEPERSON_NAME",uploadDetailsHashMap.get("RESOURCEPERSON_NAME"));
					request.addProperty("intFARMERSPARTICIPATEDCOUNT",Integer.valueOf(uploadDetailsHashMap.get("FARMERSPARTICIPATEDCOUNT")));					
					request.addProperty("strCREATEDBY",Login_Page.UserId);
					request.addProperty("strGPSCOORDINATES",uploadDetailsHashMap.get("GPSCOORDINATES"));
					request.addProperty("strtrainingdate",uploadDetailsHashMap.get("TRAINING_DATE"));
					request.addProperty("strPHOTO1",uploadDetailsHashMap.get("PHOTO_ONE"));
					request.addProperty("strPHOTO2",uploadDetailsHashMap.get("PHOTO_TWO"));
					request.addProperty("strPHOTO3",uploadDetailsHashMap.get("PHOTO_THREE"));
					request.addProperty("strmode","OF");
					request.addProperty("strMISupplierId",uploadDetailsHashMap.get("strMISupplierId"));
					envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
					envelope.dotNet=true;
					envelope.setOutputSoapObject(request);
					// Make the soap call.
					androidHttpTransport = new HttpTransportSE(url,120000);
					androidHttpTransport.debug = true;
					androidHttpTransport.call(SOAP_ACTION, envelope);
					String result = envelope.getResponse().toString();
					JSONArray jsonArray=new JSONArray(result);
					if(jsonArray.length()!=0)
					{      

						JSONObject jsonObject=jsonArray.getJSONObject(0);
						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("Message"))
						{
							serverResponse=jsonObject.getString("Message").toString();
						}
					}			

					if(serverResponse.equalsIgnoreCase("success")||serverResponse.equalsIgnoreCase("Exists"))
					{
						db.open();
						db.execSQL("UPDATE VILLAGE_TRAINING_DETAILS SET STATUS_FLAG ='Y' WHERE STATUS_FLAG='P' and AUTO_ID='"+uploadDetailsHashMap.get("AUTO_ID")+"'");
						db.close();
						serverUploadcount++;
					}
				}
			}
			return 12;
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			e.printStackTrace();
			return 11;
		} catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return 11;
		}catch (Exception e) 
		{
			e.printStackTrace();
			return 11;
		}


	}

	public int GETGEOGRAPHICDETAILS() {

		try
		{
			String methodName="GETGEOGRAPHICDETAILS";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);

			request.addProperty("strflag",Get_FormerDetails.Dflag);

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
			System.out.println("----"+result);
			JSONArray jsonArray=new JSONArray(result);
			if(Get_FormerDetails.Dflag=="V")
			{			
				villagedata=new ArrayList<ArrayList<String>>();
				if(jsonArray.length()!=0)
				{      
					for(int i=0;i<jsonArray.length();i++)
					{
						ArrayList<String> temp=new ArrayList<String>();
						JSONObject jsonObject=jsonArray.getJSONObject(i);


						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("District_id"))
						{
							temp.add(jsonObject.getString("District_id").toString());
						}
						if(jsonObject.has("Mandal_id"))
						{
							temp.add(jsonObject.getString("Mandal_id").toString());
						}
						if(jsonObject.has("Panchayat_ID"))
						{
							temp.add(jsonObject.getString("Panchayat_ID").toString());
						}
						if(jsonObject.has("Village_ID"))
						{
							temp.add(jsonObject.getString("Village_ID").toString());
						}
						if(jsonObject.has("Village_Name"))
						{
							temp.add(jsonObject.getString("Village_Name").toString());
						}

						villagedata.add(temp);
					}
				}
			}
			if(Get_FormerDetails.Dflag=="P")
			{			
				panchayatdata=new ArrayList<ArrayList<String>>();
				if(jsonArray.length()!=0)
				{      
					for(int i=0;i<jsonArray.length();i++)
					{
						ArrayList<String> temp=new ArrayList<String>();
						JSONObject jsonObject=jsonArray.getJSONObject(i);


						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("District_id"))
						{
							temp.add(jsonObject.getString("District_id").toString());
						}
						if(jsonObject.has("Mandal_id"))
						{
							temp.add(jsonObject.getString("Mandal_id").toString());
						}
						if(jsonObject.has("Panchayat_ID"))
						{
							temp.add(jsonObject.getString("Panchayat_ID").toString());
						}
						if(jsonObject.has("Panchayat_Name"))
						{
							temp.add(jsonObject.getString("Panchayat_Name").toString());
						}
						panchayatdata.add(temp);
					}
				}
			}
			if(Get_FormerDetails.Dflag=="M")
			{			
				mandaldata=new ArrayList<ArrayList<String>>();
				if(jsonArray.length()!=0)
				{      
					for(int i=0;i<jsonArray.length();i++)
					{
						ArrayList<String> temp=new ArrayList<String>();
						JSONObject jsonObject=jsonArray.getJSONObject(i);


						if(jsonObject.has("Error"))
						{
							Error=jsonObject.getString("Error"); 
							return 100;
						}
						if(jsonObject.has("District_id"))
						{
							temp.add(jsonObject.getString("District_id").toString());
						}
						if(jsonObject.has("Mandal_id"))
						{
							temp.add(jsonObject.getString("Mandal_id").toString());
						}
						if(jsonObject.has("Mandal_Name"))
						{
							temp.add(jsonObject.getString("Mandal_Name").toString());
						}
						mandaldata.add(temp);
					}
				}
			}
			if(Get_FormerDetails.Dflag=="M")
			{
				db.open();
				for(int i=0;i<mandaldata.size();i++)
				{
					ArrayList<String> temp=mandaldata.get(i);
					ContentValues cv=new ContentValues();
					cv.put("DISTRICT_ID", temp.get(0).toString());
					cv.put("MANDAL_ID", temp.get(1).toString());
					cv.put("MANDAL_NAME", temp.get(2).toString());
					try
					{

						db.insertTableDate("MANDAL_MASTER",cv);
					}
					catch(Exception e)
					{

					}

				}
				return 22;
			}
			if(Get_FormerDetails.Dflag=="P")
			{
				db.open();
				for(int i=0;i<panchayatdata.size();i++)
				{
					ArrayList<String> temp=panchayatdata.get(i);
					ContentValues cv=new ContentValues();
					cv.put("DISTRICT_ID", temp.get(0).toString());
					cv.put("MANDAL_ID", temp.get(1).toString());
					cv.put("PANCHAYAT_ID", temp.get(2).toString());
					cv.put("PANCHAYAT_NAME", temp.get(3).toString());
					try
					{

						long j=db.insertTableDate("PANCHAYAT_MASTER",cv);
						System.out.println("--"+j);

					}
					catch(Exception e)
					{

					}

				}
				db.close();
			}
			if(Get_FormerDetails.Dflag=="V")
			{
				db.open();
				for(int i=0;i<villagedata.size();i++)
				{
					ArrayList<String> temp=villagedata.get(i);
					ContentValues cv=new ContentValues();
					cv.put("DISTRICT_ID", temp.get(0).toString());
					cv.put("MANDAL_ID", temp.get(1).toString());
					cv.put("PANCHAYAT_ID", temp.get(2).toString());
					cv.put("VILLAGE_ID", temp.get(3).toString());
					cv.put("VILLAGE_NAME", temp.get(4).toString());
					try
					{

						db.insertTableDate("VILLAGE_MASTER",cv);
					}
					catch(Exception e)
					{

					}

				}
				db.close();
			}

			return 22;

		}
		catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}

	public int GetMICompaniesList() {

		try
		{

			String methodName="GetMICompaniesList";

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();
System.out.println("--"+SOAP_ACTION);
			JSONArray jsonArray=new JSONArray(result);
			if(jsonArray.length()!=0)
			{      
				db.open();
				db.execSQL("delete from MI_Companies_List");
				db.close();
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					if(jsonObject.has("Error"))
					{
						Error=jsonObject.getString("Error"); 
						return 100;
					}

					ContentValues contentValues=new ContentValues();
					if(jsonObject.has("SUPPLIER_ID"))
					{
						contentValues.put("SUPPLIER_ID",jsonObject.getString("SUPPLIER_ID").trim());
					}
					if(jsonObject.has("SUPPLIER_NAME"))
					{
						contentValues.put("SUPPLIER_NAME",jsonObject.getString("SUPPLIER_NAME").trim());
					}					
					if(jsonObject.has("DISTRICT_ID"))
					{
						contentValues.put("DISTRICT_ID",jsonObject.getString("DISTRICT_ID").trim());
					}
					
					if(contentValues!=null)
					{
						db.open();				

						db.insertTableDate("MI_Companies_List",contentValues);
						
					

						db.close();



					}
				}

			}

			

			return 32;

		}catch (SocketTimeoutException e)
		{
			Error="TimeOut, Please Try Again!!";
			e.printStackTrace();
			return 10;
		} catch (IOException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		} 
		catch (XmlPullParserException e) 
		{
			Error="Please Try Again!!";
			e.printStackTrace();
			return 11;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return 1;
		}
	}



}