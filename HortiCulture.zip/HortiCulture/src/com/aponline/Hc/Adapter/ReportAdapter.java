package com.aponline.Hc.Adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.aponline.horticulture.R;

public class ReportAdapter extends BaseAdapter
{
	ArrayList<HashMap<String,String>> localArrayList=new ArrayList<HashMap<String,String>>();
	Context mContext;
	private LayoutInflater mInflater;
	private Holder mHolder;

	public ReportAdapter(Context baseContext,ArrayList<HashMap<String,String>> data)
	{
		this.mContext=baseContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(baseContext);
	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position)
	{
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(convertView == null)
		{
			convertView=this.mInflater.inflate(R.layout.loginpage_report_list, null);
//			convertView = this.mInflater.inflate(R.layout.sell, null);
			this.mHolder= new Holder();
			this.mHolder.rsno=(TextView) convertView.findViewById(R.id.rsno);
			this.mHolder.rfid=(TextView) convertView.findViewById(R.id.rfid);
			this.mHolder.rfname=(TextView) convertView.findViewById(R.id.rfname);
			this.mHolder.rsurvey=(TextView) convertView.findViewById(R.id.rsurvey);
			this.mHolder.rcrop=(TextView) convertView.findViewById(R.id.rcrop);
			this.mHolder.rmobile=(TextView) convertView.findViewById(R.id.rmobile);
			this.mHolder.rstatus=(TextView) convertView.findViewById(R.id.rstatus);
			this.mHolder.gps=(TextView) convertView.findViewById(R.id.rgps);	
			convertView.setTag(mHolder);
		}
		else
			this.mHolder=(Holder)convertView.getTag();

		HashMap<String, String> data=this.localArrayList.get(position);
		this.mHolder.rsno.setText(data.get("sno"));
		this.mHolder.rfid.setText(data.get("Farmer_Id"));
		this.mHolder.rfname.setText(data.get("FarmerName"));
		this.mHolder.rsurvey.setText(data.get("Survey_No"));
		this.mHolder.rcrop.setText(data.get("CropName"));
		this.mHolder.rmobile.setText(data.get("MobileNumber"));
		this.mHolder.rstatus.setText(data.get("FARMERSTATUS"));
		this.mHolder.gps.setText(data.get("GPSWATERSOURCE"));	

		return convertView;

	}
	public class Holder
	{
		TextView rsno;
		TextView rfid;
		TextView rfname;
		TextView rsurvey;
		TextView rcrop;
		TextView rmobile;
		TextView rstatus;
		TextView gps;
		}
}