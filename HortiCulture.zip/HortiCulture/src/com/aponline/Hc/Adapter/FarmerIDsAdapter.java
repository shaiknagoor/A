package com.aponline.Hc.Adapter;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.horticulture.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
public class FarmerIDsAdapter extends BaseAdapter
{
	ArrayList<HashMap<String,String>> localArrayList=new ArrayList<HashMap<String,String>>();
	Context mContext;
	private LayoutInflater mInflater;
	private Holder mHolder;

	public FarmerIDsAdapter(Context baseContext,ArrayList<HashMap<String,String>> data)
	{
		this.mContext=baseContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(baseContext);
	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position)
	{
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(convertView == null)
		{
			convertView=this.mInflater.inflate(R.layout.farmer_id_list, null);
//			convertView = this.mInflater.inflate(R.layout.sell, null);
			this.mHolder= new Holder();
			this.mHolder.fsno=(TextView) convertView.findViewById(R.id.fsno);
			this.mHolder.fid=(TextView) convertView.findViewById(R.id.fId);
			this.mHolder.fname=(TextView) convertView.findViewById(R.id.fname);
			this.mHolder.fsurvey=(TextView) convertView.findViewById(R.id.fsurvey);
			this.mHolder.fcrop=(TextView) convertView.findViewById(R.id.fcrop);
			this.mHolder.fmobile=(TextView) convertView.findViewById(R.id.fmobile);
			//this.mHolder.fstatus=(TextView) convertView.findViewById(R.id.fstatus);
			this.mHolder.faddress=(TextView) convertView.findViewById(R.id.faddress);
			this.mHolder.faadhaar=(TextView) convertView.findViewById(R.id.fadhar);
			this.mHolder.farea=(TextView) convertView.findViewById(R.id.farea);
			this.mHolder.fsocial=(TextView) convertView.findViewById(R.id.fsocial);
			this.mHolder.fcategory=(TextView) convertView.findViewById(R.id.fcategory);
			
			
			
			convertView.setTag(mHolder);
		}
		else
			this.mHolder=(Holder)convertView.getTag();

		HashMap<String, String> data=this.localArrayList.get(position);
		this.mHolder.fsno.setText(data.get("sno"));
		this.mHolder.fid.setText(data.get("Farmer_Id"));
		this.mHolder.fname.setText(data.get("FarmerName"));
		this.mHolder.fsurvey.setText(data.get("Survey_No"));
		this.mHolder.fcrop.setText(data.get("CropName"));
		this.mHolder.fmobile.setText(data.get("MobileNumber"));
		//this.mHolder.fstatus.setText(data.get("FARMERSTATUS"));
		this.mHolder.faddress.setText(data.get("FarmerAddress"));
		this.mHolder.faadhaar.setText(data.get("AADHAARNUMBER"));
		this.mHolder.farea.setText(data.get("Area_Proposed"));
		this.mHolder.fsocial.setText(data.get("Social_staus"));
		this.mHolder.fcategory.setText(data.get("CATEGORY"));
		
		
		
		

		return convertView;

	}
	public class Holder
	{
		TextView fsno;
		TextView fid;
		TextView fname;
		TextView fsurvey;
		TextView fcrop;
		TextView fmobile;
		TextView fstatus;
		TextView faddress;
		TextView faadhaar;
		TextView farea;
		TextView fsocial;
		TextView fcategory;
		
		


	}
}
