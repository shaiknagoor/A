package com.aponline.horticulture;


import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.kobjects.base64.Base64;

import com.aponline.Hc.database.DBAdapter;
import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;

import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Training_Details  extends AppCompatActivity
{
	public static String person_designation="",strCROPnames="",strAGRONOMIC_WATER_MANAGEMENT="",strAGRONOMIC_NUTRIENT_MANAGEMENT="",strAGRONOMIC_PESTDISEASE_MANAGEMENT="",strAGRONOMIC_HARVEST_HANDLING="",strASPECT_FERTIGATION=""
			,strASPECT_MISYSTEM_MAINTENANCE="",strASPECT_AFETR_SALESSERVICE="",strFARMERS_PROBLEMS="",strACTION_TAKEN="",strtrainingdate="",gps_latitude="",gps_longitude="",strMISupplierId="";
	public static int intFARMERSPARTICIPATEDCOUNT;
	public static String person_name="";
	CheckBox res_Per1_ck,res_Per2_ck,res_Per3_ck,res_Per4_ck,res_Per5_ck,res_Per6_ck;
	CheckBox argo_ck1,argo_ck2,argo_ck3,argo_ck4,aspect_ck1,aspect_ck2,aspect_ck3;
	EditText res_Per1_et,res_Per2_et,res_Per3_et,res_Per4_et,res_Per5_et,res_Per6_et;
	Context context;
	DBAdapter db;
	GPSTracker gps;
	String pendingCount;
	LocationManager locationManager;
	Bitmap photo;
	private int mYear;
	private int mMonth;
	private int mDay;
	TextView pendingCountEt;
	private static final int CAMERA_REQUEST = 1888; 
	public static String TrainHDist_id,TrainHMandal_id,TrainHPanchayat_id,TrainHViialge_id;
	String photoNo;
	ImageView photo1IV,photo2IV,photo3IV;
	//Spinner TrainmandalSp,TrainpanchayatSp,TrainvillageSp,TraindistrictSp,majorcrop;
	Spinner majorcrop,mi_company_name_sp;
	CheckConnection conn_obj;
	LinearLayout mi_company_ll;
	ProgressDialog progressDialog;
	Handler mHandler;
	ActionBar ab;
	ArrayAdapter<String> micompanyadpater;
	Button add_mi_company;

	public static HashMap<String, String> TrainCapurePhotos;
	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{
					Intent intent = getIntent();
					finish();
					startActivity(intent);
				}
				if(paramMessage.what==22)
				{
					if(WebserviceCall.serverResponse.equalsIgnoreCase("Success")||WebserviceCall.serverResponse.equalsIgnoreCase("Exists"))
					{
						AlertDialog(context, "Successfully Submitted", "Submitted");	
					}
					else if(WebserviceCall.serverResponse.equalsIgnoreCase("Failed"))
					{
						Toast toast = null;
						toast=Toast.makeText(Training_Details.this, "Please Try Agian",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();

					}
				}
				if(paramMessage.what==12)
				{					
					refreshPendingCount();

				}
				if(paramMessage.what==23)
				{


				}
				if(paramMessage.what==1)
				{


				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					
					Toast.makeText(Training_Details.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				
				}
				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Training_Details.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Training_Details.this,"Timeout",Toast.LENGTH_LONG).show();					
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}
	protected void onCreate(Bundle savedInstanceState)
	{
		try
		{
			super.onCreate(savedInstanceState);
			context=this;
			db=new DBAdapter(this);
			setContentView(R.layout.training_details);
			getWindow().setSoftInputMode(
					WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
					);
			TrainCapurePhotos=new HashMap<String,String>();
			final Calendar c = Calendar.getInstance();
			mYear = c.get(Calendar.YEAR);
			mMonth = c.get(Calendar.MONTH);
			mDay = c.get(Calendar.DAY_OF_MONTH);
			gps=new GPSTracker(Training_Details.this);
			pendingCountEt=(TextView)findViewById(R.id.trainpendingUploadCountEt);
		
			refreshPendingCount();

			if(Integer.parseInt(pendingCount) > 0 && CheckConnection.isNetworkAvailable(Training_Details.this))
			{
				Loaddata("UploadInsertTraingingDetails");
			}


			this.ab=getSupportActionBar();
			ab.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.menu_bg));
			ab.setTitle("APMIP");
			ab.setHomeButtonEnabled(true);
			ab.setDisplayHomeAsUpEnabled(true);
			pendingCountEt.startAnimation((Animation)AnimationUtils.loadAnimation(Training_Details.this,R.anim.text_translate));

			locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			{
				buildAlertMessageNoGps();
			}
			mi_company_name_sp=(Spinner)findViewById(R.id.mi_company_name_sp);
			add_mi_company=(Button)findViewById(R.id.add_mi_company);
			majorcrop=(Spinner)findViewById(R.id.train_major_cropsp);
			mi_company_ll=(LinearLayout)findViewById(R.id.mi_company_ll);
			res_Per1_ck=(CheckBox)findViewById(R.id.res_Per1_ck);
			res_Per2_ck=(CheckBox)findViewById(R.id.res_Per2_ck);
			res_Per3_ck=(CheckBox)findViewById(R.id.res_Per3_ck);
			res_Per4_ck=(CheckBox)findViewById(R.id.res_Per4_ck);
			res_Per5_ck=(CheckBox)findViewById(R.id.res_Per5_ck);
			res_Per6_ck=(CheckBox)findViewById(R.id.res_Per6_ck);
			argo_ck1=(CheckBox)findViewById(R.id.argo_ck1);
			argo_ck2=(CheckBox)findViewById(R.id.argo_ck2);
			argo_ck3=(CheckBox)findViewById(R.id.argo_ck3);
			argo_ck4=(CheckBox)findViewById(R.id.argo_ck4);
			aspect_ck1=(CheckBox)findViewById(R.id.aspect_ck1);
			aspect_ck2=(CheckBox)findViewById(R.id.aspect_ck2);
			aspect_ck3=(CheckBox)findViewById(R.id.aspect_ck3);
			((EditText)findViewById(R.id.argo_et1)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.argo_et1)));
			((EditText)findViewById(R.id.argo_et2)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.argo_et2)));
			((EditText)findViewById(R.id.argo_et3)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.argo_et3)));
			((EditText)findViewById(R.id.argo_et4)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.argo_et4)));
			((EditText)findViewById(R.id.aspect_et1)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.aspect_et1)));
			((EditText)findViewById(R.id.aspect_et2)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.aspect_et2)));
			((EditText)findViewById(R.id.aspect_et3)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.aspect_et3)));
			((EditText)findViewById(R.id.train_problems)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.train_problems)));
			((EditText)findViewById(R.id.train_actiontaken)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.train_actiontaken)));
			((EditText)findViewById(R.id.train_major_crop_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.train_major_crop_et)));
			((EditText)findViewById(R.id.res_Per1_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.res_Per1_et)));
			((EditText)findViewById(R.id.res_Per2_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.res_Per2_et)));
			((EditText)findViewById(R.id.res_Per3_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.res_Per3_et)));
			((EditText)findViewById(R.id.res_Per4_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.res_Per4_et)));
			((EditText)findViewById(R.id.res_Per5_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.res_Per5_et)));
			((EditText)findViewById(R.id.res_Per6_et)).addTextChangedListener(new CustomTextWatcher((EditText)findViewById(R.id.res_Per6_et)));
			add_mi_company.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					if((((EditText)findViewById(R.id.res_Per6_et)).getText().toString()).equalsIgnoreCase(""))
					{
						((EditText)findViewById(R.id.res_Per6_et)).setError("Enter Name");
						return;
					}
					if(mi_company_name_sp.getSelectedItemPosition()==0)
					{
						mi_company_name_sp.requestFocusFromTouch();
						return;
					}
				
					final TableLayout tl = (TableLayout)findViewById(R.id.table_data_mi_company);
					LayoutInflater inflater = getLayoutInflater();
					final TableRow tr = (TableRow)inflater.inflate(R.layout.row, tl, false);
					TextView tvValue1 = (TextView)tr.findViewById(R.id.column1tv);
					TextView tvValue2 = (TextView)tr.findViewById(R.id.column2tv);
					TextView tvValue3 = (TextView)tr.findViewById(R.id.column3tv);
					Button ck=(Button)tr.findViewById(R.id.check);
					tvValue1.setText(mi_company_name_sp.getSelectedItem().toString());
					tvValue3.setText(((EditText)findViewById(R.id.res_Per6_et)).getText().toString().trim());
					db.open();
					String a=	db.getSingleValue("Select SUPPLIER_ID from MI_Companies_List where SUPPLIER_NAME='"+mi_company_name_sp.getSelectedItem().toString()+"' ");
					tvValue2.setText(a);

					ck.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {

							View row = (View) v.getParent();

							ViewGroup container = ((ViewGroup)row.getParent());
							View view = ((ViewGroup) row).getChildAt(0);
							micompanyadpater.add(((TextView)view).getText().toString());
							micompanyadpater.notifyDataSetChanged();
							micompanyadpater.sort(new Comparator<String>() {
								@Override
								public int compare(String lhs, String rhs) {
									return lhs.compareTo(rhs);
								}
							});
							container.removeView(row);

							container.invalidate();
							if(tl.getChildCount()==0)
							{


							}
						}
					});
					tl.addView(tr);
					micompanyadpater.remove((String)mi_company_name_sp.getSelectedItem());
					micompanyadpater.notifyDataSetChanged();

					mi_company_name_sp.setSelection(0);
					((EditText)findViewById(R.id.res_Per6_et)).setText("");
				}
			});
			argo_ck1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.argo_et1)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.argo_et1)).setVisibility(8);
						((EditText)findViewById(R.id.argo_et1)).setText("");
					}

				}
			});
			argo_ck2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.argo_et2)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.argo_et2)).setVisibility(8);
						((EditText)findViewById(R.id.argo_et2)).setText("");
					}

				}
			});
			argo_ck3.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.argo_et3)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.argo_et3)).setVisibility(8);
						((EditText)findViewById(R.id.argo_et3)).setText("");
					}

				}
			});
			argo_ck4.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.argo_et4)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.argo_et4)).setVisibility(8);
						((EditText)findViewById(R.id.argo_et4)).setText("");
					}

				}
			});
			aspect_ck1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.aspect_et1)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.aspect_et1)).setVisibility(8);
						((EditText)findViewById(R.id.aspect_et1)).setText("");
					}

				}
			});
			aspect_ck2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.aspect_et2)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.aspect_et2)).setVisibility(8);
						((EditText)findViewById(R.id.aspect_et2)).setText("");
					}

				}
			});
			aspect_ck3.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.aspect_et3)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.aspect_et3)).setVisibility(8);
						((EditText)findViewById(R.id.aspect_et3)).setText("");
					}

				}
			});
			res_Per1_ck.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.res_Per1_et)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.res_Per1_et)).setVisibility(8);
						((EditText)findViewById(R.id.res_Per1_et)).setText("");
					}

				}
			});
			res_Per2_ck.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.res_Per2_et)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.res_Per2_et)).setVisibility(8);
						((EditText)findViewById(R.id.res_Per2_et)).setText("");
					}

				}
			});
			res_Per3_ck.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.res_Per3_et)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.res_Per3_et)).setVisibility(8);
						((EditText)findViewById(R.id.res_Per3_et)).setText("");
					}

				}
			});
			res_Per4_ck.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.res_Per4_et)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.res_Per4_et)).setVisibility(8);
						((EditText)findViewById(R.id.res_Per4_et)).setText("");
					}

				}
			});
			res_Per5_ck.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.res_Per5_et)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.res_Per5_et)).setVisibility(8);
					}

				}
			});
			res_Per6_ck.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked)
					{
						((EditText)findViewById(R.id.res_Per6_et)).setVisibility(0);
						mi_company_ll.setVisibility(0);
						((TableLayout)findViewById(R.id.table_data_mi_company)).setVisibility(0);
					}
					else
					{
						((EditText)findViewById(R.id.res_Per6_et)).setVisibility(8);
						mi_company_ll.setVisibility(8);
						((TableLayout)findViewById(R.id.table_data_mi_company)).setVisibility(8);
						((TableLayout)findViewById(R.id.table_data_mi_company)).removeAllViews();
					}

				}
			});

			majorcrop.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> parent, View view,
						int position, long id) {
					int i=(int)id;
					if(i!=0)
					{
						if(majorcrop.getSelectedItem().toString().equalsIgnoreCase("Others"))
						{
							((EditText)findViewById(R.id.train_major_crop_et)).setVisibility(0);
						}
						else
						{
							((EditText)findViewById(R.id.train_major_crop_et)).setVisibility(8);
							((EditText)findViewById(R.id.train_major_crop_et)).setText("");
						}
					}
					else
					{
						((EditText)findViewById(R.id.train_major_crop_et)).setVisibility(8);
						((EditText)findViewById(R.id.train_major_crop_et)).setText("");
					}

				}

				@Override
				public void onNothingSelected(AdapterView<?> parent) {


				}
			});

			db.open();
			int i=db.getRowCount("Select Count(*) from MI_Companies_List");
			if(i==0)
			{
				new AlertDialog.Builder(this)
				.setIcon(R.drawable.info_icon)
				.setTitle("Mi Company List")
				.setMessage("Download MI Company List Before Doing Survey")
				.setPositiveButton("Download", new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick(DialogInterface dialog, int which) {

						if(CheckConnection.isNetworkAvailable(Training_Details.this))
						{
							Loaddata("GetMICompaniesList");
						}
						else
						{
							Toast toast = null;
							toast=Toast.makeText(Training_Details.this, "Check Internet Connection",Toast.LENGTH_SHORT);
							View view = toast.getView();
							toast.setGravity(Gravity.CENTER, 0, 0);
							view.setBackgroundResource(R.color.red);
							toast.show();
						}
					}

				})

				.show()
				.setCancelable(false);
			}
			else
			{
				db.open();
				List<String> mi_component_list=new ArrayList<String>();
				mi_component_list=db.getSpinnerData("select SUPPLIER_NAME  from MI_Companies_List where DISTRICT_ID='"+Get_FormerDetails.HDist_id+"' ");
				db.close();

				micompanyadpater = new ArrayAdapter<String>(Training_Details.this,android.R.layout.simple_spinner_item,mi_component_list);
				micompanyadpater.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				mi_company_name_sp.setAdapter(micompanyadpater);	
				db.close();
			}
		}
		catch(Exception e)
		{

		}
	}

	private void takePhoto()
	{
		try
		{		
			Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(cameraIntent,CAMERA_REQUEST);
		}catch(Exception e)
		{

		}
	}

	public void TrainCommonAction(View v)
	{
		try
		{
			switch (v.getId()) 
			{
			case R.id.TrainMiphoto1IV:
				photoNo="One";
				takePhoto();			
				break;

			case R.id.TrainMiphoto2IV:
				photoNo="Two";
				takePhoto();			
				break;

			case R.id.TrainMiphoto3IV:
				photoNo="Three";
				takePhoto();		
				break;

			case R.id.train_date:
				dateDialog();
				break;
			}
		}
		catch(Exception e)
		{

		}
	}
	private void buildAlertMessageNoGps()
	{

		AlertDialog(context, "Your GPS seems to be disabled,Please enable it?","GPS Disable");

	}
	public void FinalTrainingSubmit(View v)
	{
		try
		{
			if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			{
				buildAlertMessageNoGps();
			}
			
			if(((TextView)findViewById(R.id.train_date)).getText().toString().equalsIgnoreCase(""))
			{
				((TextView)findViewById(R.id.train_date)).setError("Select Date");
				((TextView)findViewById(R.id.train_date)).requestFocusFromTouch();
				return;
			}
			else
			{
				Calendar c = Calendar.getInstance();


				SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
				String formattedDate = df.format(c.getTime());
				strtrainingdate=((TextView)findViewById(R.id.train_date)).getText().toString()+" "+formattedDate;
			}		

			if(((Spinner)findViewById(R.id.train_major_cropsp)).getSelectedItemPosition()==0)
			{
				((Spinner)findViewById(R.id.train_major_cropsp)).requestFocusFromTouch();
				return;
			}
			else
			{
				if(((Spinner)findViewById(R.id.train_major_cropsp)).getSelectedItem().toString().equalsIgnoreCase("Others"))
				{
					if(((EditText)findViewById(R.id.train_major_crop_et)).getText().toString().equalsIgnoreCase(""))

					{
						((EditText)findViewById(R.id.train_major_crop_et)).setError("Enter Crop");
						((EditText)findViewById(R.id.train_major_crop_et)).requestFocus();
						return;
					}
					else
					{
						strCROPnames=((EditText)findViewById(R.id.train_major_crop_et)).getText().toString();
					}
				}
				else
				{
					strCROPnames=((Spinner)findViewById(R.id.train_major_cropsp)).getSelectedItem().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.argo_ck1)).isChecked()||((CheckBox)findViewById(R.id.argo_ck2)).isChecked()||
					((CheckBox)findViewById(R.id.argo_ck3)).isChecked()||((CheckBox)findViewById(R.id.argo_ck4)).isChecked()||
					((CheckBox)findViewById(R.id.aspect_ck1)).isChecked()||((CheckBox)findViewById(R.id.aspect_ck3)).isChecked()||((CheckBox)findViewById(R.id.aspect_ck2)).isChecked())
			{

			}
			else
			{
				Toast toast = null;
				toast=Toast.makeText(Training_Details.this, "Atleast Select One Option In Topics Covered",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();
				return;
			}
			if(((CheckBox)findViewById(R.id.argo_ck1)).isChecked())
			{
				if(((EditText)findViewById(R.id.argo_et1)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.argo_et1)).setError("Enter Text");
					((EditText)findViewById(R.id.argo_et1)).requestFocus();
					return;
				}
				else
				{

					strAGRONOMIC_WATER_MANAGEMENT=((EditText)findViewById(R.id.argo_et1)).getText().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.argo_ck2)).isChecked())
			{
				if(((EditText)findViewById(R.id.argo_et2)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.argo_et2)).setError("Enter Text");
					((EditText)findViewById(R.id.argo_et2)).requestFocus();
					return;
				}
				else
				{

					strAGRONOMIC_NUTRIENT_MANAGEMENT=((EditText)findViewById(R.id.argo_et2)).getText().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.argo_ck3)).isChecked())
			{
				if(((EditText)findViewById(R.id.argo_et3)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.argo_et3)).setError("Enter Text");
					((EditText)findViewById(R.id.argo_et3)).requestFocus();
					return;
				}
				else
				{				
					strAGRONOMIC_PESTDISEASE_MANAGEMENT=((EditText)findViewById(R.id.argo_et3)).getText().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.argo_ck4)).isChecked())
			{
				if(((EditText)findViewById(R.id.argo_et4)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.argo_et4)).setError("Enter Text");
					((EditText)findViewById(R.id.argo_et4)).requestFocus();
					return;
				}
				else
				{				
					strAGRONOMIC_HARVEST_HANDLING=((EditText)findViewById(R.id.argo_et4)).getText().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.aspect_ck1)).isChecked())
			{
				if(((EditText)findViewById(R.id.aspect_et1)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.aspect_et1)).setError("Enter Text");
					((EditText)findViewById(R.id.aspect_et1)).requestFocus();
					return;
				}
				else
				{				
					strASPECT_FERTIGATION=((EditText)findViewById(R.id.aspect_et1)).getText().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.aspect_ck2)).isChecked())
			{
				if(((EditText)findViewById(R.id.aspect_et2)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.aspect_et2)).setError("Enter Text");
					((EditText)findViewById(R.id.aspect_et2)).requestFocus();
					return;
				}
				else
				{				
					strASPECT_MISYSTEM_MAINTENANCE=((EditText)findViewById(R.id.aspect_et2)).getText().toString();
				}
			}
			if(((CheckBox)findViewById(R.id.aspect_ck3)).isChecked())
			{
				if(((EditText)findViewById(R.id.aspect_et3)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.aspect_et3)).setError("Enter Text");
					((EditText)findViewById(R.id.aspect_et3)).requestFocus();
					return;
				}
				else
				{				
					strASPECT_AFETR_SALESSERVICE=((EditText)findViewById(R.id.aspect_et3)).getText().toString();
				}
			}
			if(((EditText)findViewById(R.id.train_problems)).getText().toString().equalsIgnoreCase(""))

			{
				((EditText)findViewById(R.id.train_problems)).setError("Enter Problems");
				((EditText)findViewById(R.id.train_problems)).requestFocus();
				return;
			}
			else
			{
				strFARMERS_PROBLEMS=((EditText)findViewById(R.id.train_problems)).getText().toString();
			}
			if(((EditText)findViewById(R.id.train_actiontaken)).getText().toString().equalsIgnoreCase(""))

			{
				((EditText)findViewById(R.id.train_actiontaken)).setError("Enter Action Taken");
				((EditText)findViewById(R.id.train_actiontaken)).requestFocus();
				return;
			}
			else
			{
				strACTION_TAKEN=((EditText)findViewById(R.id.train_actiontaken)).getText().toString();
			}
			if(((CheckBox)findViewById(R.id.res_Per1_ck)).isChecked()||((CheckBox)findViewById(R.id.res_Per2_ck)).isChecked()||((CheckBox)findViewById(R.id.res_Per3_ck)).isChecked()
					||((CheckBox)findViewById(R.id.res_Per4_ck)).isChecked()||((CheckBox)findViewById(R.id.res_Per5_ck)).isChecked()||((CheckBox)findViewById(R.id.res_Per6_ck)).isChecked()
					)
			{

			}
			else
			{
				Toast toast = null;
				toast=Toast.makeText(Training_Details.this, "Atleast Select One Option In Resource Person Participated",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();
				return;
			}
			person_designation="";
			person_name="";
			ArrayList<String> per_desg=new ArrayList<String>();
			ArrayList<String> per_name=new ArrayList<String>();
			if(((CheckBox)findViewById(R.id.res_Per1_ck)).isChecked())
			{
				if(((EditText)findViewById(R.id.res_Per1_et)).getText().toString().equalsIgnoreCase(""))
				{
					((EditText)findViewById(R.id.res_Per1_et)).setError("Enter Name");
					((EditText)findViewById(R.id.res_Per1_et)).requestFocus();
					return;
				}
				else
				{
					per_desg.add(((CheckBox)findViewById(R.id.res_Per1_ck)).getText().toString());
					per_name.add(((EditText)findViewById(R.id.res_Per1_et)).getText().toString());
				}
			}
			if(((CheckBox)findViewById(R.id.res_Per2_ck)).isChecked())
			{
				if(((EditText)findViewById(R.id.res_Per2_et)).getText().toString().equalsIgnoreCase(""))

				{
					((EditText)findViewById(R.id.res_Per2_et)).setError("Enter Name");
					((EditText)findViewById(R.id.res_Per2_et)).requestFocus();
					return;
				}
				else
				{
					per_desg.add(((CheckBox)findViewById(R.id.res_Per2_ck)).getText().toString());
					per_name.add(((EditText)findViewById(R.id.res_Per2_et)).getText().toString());
				}
			}
			if(((CheckBox)findViewById(R.id.res_Per3_ck)).isChecked())
			{
				if(((EditText)findViewById(R.id.res_Per3_et)).getText().toString().equalsIgnoreCase(""))

				{
					((EditText)findViewById(R.id.res_Per3_et)).setError("Enter Name");
					((EditText)findViewById(R.id.res_Per3_et)).requestFocus();
					return;
				}
				else
				{
					per_desg.add(((CheckBox)findViewById(R.id.res_Per3_ck)).getText().toString());
					per_name.add(((EditText)findViewById(R.id.res_Per3_et)).getText().toString());
				}
			}
			if(((CheckBox)findViewById(R.id.res_Per4_ck)).isChecked())
			{
				if(((EditText)findViewById(R.id.res_Per4_et)).getText().toString().equalsIgnoreCase(""))

				{
					((EditText)findViewById(R.id.res_Per4_et)).setError("Enter Name");
					((EditText)findViewById(R.id.res_Per4_et)).requestFocus();
					return;
				}
				else
				{
					per_desg.add(((CheckBox)findViewById(R.id.res_Per4_ck)).getText().toString());
					per_name.add(((EditText)findViewById(R.id.res_Per4_et)).getText().toString());
				}
			}
			if(((CheckBox)findViewById(R.id.res_Per5_ck)).isChecked())
			{
				if(((EditText)findViewById(R.id.res_Per5_et)).getText().toString().equalsIgnoreCase(""))

				{
					((EditText)findViewById(R.id.res_Per5_et)).setError("Enter Name");
					((EditText)findViewById(R.id.res_Per5_et)).requestFocus();
					return;
				}
				else
				{
					per_desg.add(((CheckBox)findViewById(R.id.res_Per5_ck)).getText().toString());
					per_name.add(((EditText)findViewById(R.id.res_Per5_et)).getText().toString());
				}
			}
			TableLayout layout = (TableLayout)findViewById(R.id.table_data_mi_company);
			if(((CheckBox)findViewById(R.id.res_Per6_ck)).isChecked())
			{
				if(layout.getChildCount()==0)
				{
					mi_company_name_sp.requestFocusFromTouch();
					Toast toast = null;
					toast=Toast.makeText(Training_Details.this, "Please Select MI Company Name",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
					return;
				}
			}
	//			else
//				{
	//				per_desg.add(((CheckBox)findViewById(R.id.res_Per6_ck)).getText().toString());
//					per_name.add(((EditText)findViewById(R.id.res_Per6_et)).getText().toString());
//				}
//			}
		
//			if(((CheckBox)findViewById(R.id.res_Per6_ck)).isChecked())
//			{
//				if(layout.getChildCount()==0)
//				{
//					mi_company_name_sp.requestFocusFromTouch();
//					Toast toast = null;
//					toast=Toast.makeText(Training_Details.this, "Please Select MI Company Name",Toast.LENGTH_SHORT);
//					View view = toast.getView();
//					toast.setGravity(Gravity.CENTER, 0, 0);
//					view.setBackgroundResource(R.color.red);
//					toast.show();
//					return;
//				}
//
//			}
			if(((EditText)findViewById(R.id.train_no_of_farmers)).getText().toString().equalsIgnoreCase(""))

			{
				((EditText)findViewById(R.id.train_no_of_farmers)).setError("Enter No of Farmers");
				((EditText)findViewById(R.id.train_no_of_farmers)).requestFocus();
				return;
			}
			else
			{
				try
				{
					String temp=	((EditText)findViewById(R.id.train_no_of_farmers)).getText().toString();

					intFARMERSPARTICIPATEDCOUNT=Integer.parseInt(temp);
				}
				catch(Exception e)
				{

				}
			}
			if(TrainCapurePhotos.size()<3)
			{
				AlertDialog(context, "Please Capture Photo","Take Photo");
				return;
			}

			for(int i=0;i<per_desg.size();i++)
			{
				if(i==0)
				{
					person_name=per_name.get(i);
					person_designation=per_desg.get(i);
				}
				else
				{
					person_name=person_name+","+per_name.get(i);
					person_designation=person_designation+","+per_desg.get(i);
				}
			}

			for (int i = 0; i < layout.getChildCount(); i++) {
				View child = layout.getChildAt(i);

				if (child instanceof TableRow) {
					TableRow row = (TableRow) child;
					View view = row.getChildAt(1);
View view1=row.getChildAt(2);
					if(i==0)
					{
						strMISupplierId=((TextView)view).getText().toString()+"|"+((TextView)view1).getText().toString();
					}
					else
					{
						strMISupplierId=strMISupplierId+","+((TextView)view).getText().toString()+"|"+((TextView)view1).getText().toString();
					}



				}
			}
			if(CheckConnection.isNetworkAvailable(Training_Details.this))
			{
				Loaddata("InsertTraingingDetails");
			}
			else
			{
				db.open();
				ContentValues cv=new ContentValues();

				cv.put("District_id",Get_FormerDetails.HDist_id);cv.put("Mandal_id",Get_FormerDetails.HMandal_id);cv.put("Panchayat_id",Get_FormerDetails.HPanchayat_id);
				cv.put("Village_id",Get_FormerDetails.HViialge_id);
				cv.put("Major_crop",strCROPnames);cv.put("AGRONOMIC_WATER_MANAGEMENT",strAGRONOMIC_WATER_MANAGEMENT);
				cv.put("AGRONOMIC_NUTRIENT_MANAGEMENT",strAGRONOMIC_NUTRIENT_MANAGEMENT);
				cv.put("AGRONOMIC_PESTDISEASE_MANAGEMENT",strAGRONOMIC_PESTDISEASE_MANAGEMENT);cv.put("AGRONOMIC_HARVEST_HANDLING",strAGRONOMIC_HARVEST_HANDLING);
				cv.put("ASPECT_FERTIGATION",strASPECT_FERTIGATION);cv.put("ASPECT_MISYSTEM_MAINTENANCE",strASPECT_MISYSTEM_MAINTENANCE);
				cv.put("ASPECT_AFETR_SALESSERVICE",strASPECT_AFETR_SALESSERVICE);
				cv.put("FARMERS_PROBLEMS",strFARMERS_PROBLEMS);cv.put("ACTION_TAKEN",strACTION_TAKEN);cv.put("RESOURCEPERSON_DESIGNATION",person_designation);cv.put("RESOURCEPERSON_NAME",person_name);
				cv.put("FARMERSPARTICIPATEDCOUNT",Integer.toString(intFARMERSPARTICIPATEDCOUNT));
				cv.put("PHOTO_ONE",TrainCapurePhotos.get("photoOne"));cv.put("PHOTO_TWO",TrainCapurePhotos.get("photoTwo"));
				cv.put("PHOTO_THREE",TrainCapurePhotos.get("photoThree"));cv.put("CREATED_BY",Login_Page.UserId);
				cv.put("GPSCOORDINATES",gps_latitude+","+gps_longitude);cv.put("STATUS_FLAG","P");cv.put("TRAINING_DATE",strtrainingdate);
				cv.put("MISupplierId",strMISupplierId);
				long i=db.insertTableDate("VILLAGE_TRAINING_DETAILS", cv);
				if(i>0)
				{
					AlertDialog(context, "Successfully Submitted","Submitted");
					return;
				}
			}
		}
		catch(Exception e)
		{

		}

	}
	private void launchGPSOptions() 
	{


		Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		startActivity(intent);

	} 
	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		//dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);	  
		//Animation shake = AnimationUtils.loadAnimation(context, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		//yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{


				if(DialogType.equalsIgnoreCase("GPS Disable"))
				{
					launchGPSOptions();
					dialog.cancel();
				}
				if(DialogType.equalsIgnoreCase("Submitted"))
				{
					startActivity(new Intent(Training_Details.this, Get_FormerDetails.class));
					finish();
				}			

				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}
	public void dateDialog()
	{
		DatePickerDialog dpd=new DatePickerDialog(Training_Details.this, new DatePickerDialog.OnDateSetListener() 
		{
			@Override
			public void onDateSet(DatePicker view, int year,int month,int date) 
			{
				String month1=Integer.toString(month+1);
				String date1=Integer.toString(date);
				if(month1.length()==1)
					month1="0"+Integer.toString(month+1);
				if(date1.length()==1)
					date1="0"+Integer.toString(date);
				String dateSelected=date1+"/"+month1+"/"+Integer.toString(year);
				//String dateSelected=Integer.toString(year)+"-"+month1+"-"+date1 ;
				((TextView)findViewById(R.id.train_date)).setText(dateSelected);
				((TextView)findViewById(R.id.train_date)).setError(null);
			}
		}, mYear, mMonth, mDay);
		dpd.show();	
		dpd.getDatePicker().setMaxDate(System.currentTimeMillis());
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
		try {


			if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) 
			{  

				if(photoNo.equalsIgnoreCase("One"))
				{
					ByteArrayOutputStream out1 = new ByteArrayOutputStream();
					photo = (Bitmap) data.getExtras().get("data"); 
					((ImageView)findViewById(R.id.TrainMiphoto1IV)).setImageBitmap(photo);
					photo.compress(Bitmap.CompressFormat.PNG, 100, out1);
					byte[] ba1 = out1.toByteArray();
					TrainCapurePhotos.put("photoOne",Base64.encode(ba1));

				}else if(photoNo.equalsIgnoreCase("Two"))
				{
					ByteArrayOutputStream out2 = new ByteArrayOutputStream();
					photo = (Bitmap) data.getExtras().get("data"); 
					((ImageView)findViewById(R.id.TrainMiphoto2IV)).setImageBitmap(photo);
					photo.compress(Bitmap.CompressFormat.PNG, 100, out2);
					byte[] ba2 = out2.toByteArray();
					TrainCapurePhotos.put("photoTwo",Base64.encode(ba2));

				}
				else if(photoNo.equalsIgnoreCase("Three"))
				{
					ByteArrayOutputStream out2 = new ByteArrayOutputStream();
					photo = (Bitmap) data.getExtras().get("data"); 
					((ImageView)findViewById(R.id.TrainMiphoto3IV)).setImageBitmap(photo);
					photo.compress(Bitmap.CompressFormat.PNG, 100, out2);
					byte[] ba2 = out2.toByteArray();
					TrainCapurePhotos.put("photoThree",Base64.encode(ba2));
					gps=new GPSTracker(Training_Details.this);
					//locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

					gps_latitude=String.valueOf(gps.getLatitude());
					gps_longitude=String.valueOf(gps.getLongitude());
					
				}

			}
		} catch (Exception e)
		{

		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.train_ab, menu);



		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int id = item.getItemId();

		if (id == R.id.logout) 
		{
			LogoutAlert("Are you sure you want to Logout","logout");

		}
		if (id == R.id.mi_company_download) 
		{
			boolean a=	CheckConnection.isNetworkAvailable(Training_Details.this);
			if(a==false)
			{
				Toast toast = null;
				toast=Toast.makeText(Training_Details.this, "Check Internet Connection",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();
			}
			else
			{
				Loaddata("GetMICompaniesList");
			}

		}

		if (id == R.id.trainUpload_OffLine_Data) 
		{
			if(Integer.parseInt(pendingCount) > 0 && CheckConnection.isNetworkAvailable(Training_Details.this))
			{
				Loaddata("UploadInsertTraingingDetails");
			}
			else
			{
				if(Integer.parseInt(pendingCount)==0)
				{
					Toast toast = null;
					toast=Toast.makeText(Training_Details.this, "No Data To Upload",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				else
				{
					boolean a=	CheckConnection.isNetworkAvailable(Training_Details.this);
					if(a==false)
					{
						Toast toast = null;
						toast=Toast.makeText(Training_Details.this, "Check Internet Connection",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
				}

			}
		}
		return super.onOptionsItemSelected(item);
	}
	public void LogoutAlert(String msg1,final String diatype)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Horticulture");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) {

				if(diatype.equalsIgnoreCase("logout")){
					Intent i=new Intent(Training_Details.this,Login_Page.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				dialog.cancel();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	public void refreshPendingCount()
	{
		try
		{
			db.open();
			pendingCount=db.getSingleValue("select DISTINCT Count(AUTO_ID) from VILLAGE_TRAINING_DETAILS where STATUS_FLAG='P'  and CREATED_BY='"+Login_Page.UserId+"'");
			pendingCountEt.setText("Pending Upload To Online     Count :"+pendingCount);
			db.close();
		}
		catch(Exception e)
		{

		}
	}
	public void onBackPressed()
	{
		startActivity(new Intent(Training_Details.this,Get_FormerDetails.class));
		finish();
	}
}
