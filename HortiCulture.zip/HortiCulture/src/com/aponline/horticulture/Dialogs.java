package com.aponline.horticulture;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Dialogs 
{
	public static void AlertDialogs(Context context, String title, String msg)
	{
		AlertDialog.Builder adb = new AlertDialog.Builder(context);
		adb.setTitle(title);
		adb.setMessage(msg);			
		adb.setPositiveButton("Ok", 
				new DialogInterface.OnClickListener()
		{				
			public void onClick(DialogInterface dialog, int which) 
			{	
				return;
			}
		});
		adb.show();
	}
	public static void AlertDialog(Context context,String msg)
	{
		final Dialog dialog = new Dialog(context);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		//dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);	  
		//Animation shake = AnimationUtils.loadAnimation(context, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		//yes.startAnimation(shake);
		
		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				new Thread(new Runnable() 
				{
					@Override
					public void run()
					{
						try {
							Thread.sleep(500);
							dialog.dismiss();
							//context.this.finish();
						} catch (InterruptedException e) {

							e.printStackTrace();
						}

					}
				}).start();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}
}
