package com.aponline.horticulture;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.aponline.Hc.Adapter.FarmerIDsAdapter;
import com.aponline.Hc.database.DBAdapter;
import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

@SuppressLint("NewApi")
public class Get_FormerDetails extends AppCompatActivity
{
	Spinner HmandalSp,HpanchayatSp,HvillageSp,HhabitationSp,HstatusSp;
	public static String HDist_id,HMandal_id,HPanchayat_id,HViialge_id,HHabitation_id,HFId_status;
	LinearLayout list;
	DBAdapter db;
	ActionBar ab;
	public 	static String Dflag=""; 
	Context context;
	TextView HdistrictSp;
	ListView FdetailsLV;
	HashMap<String, String> FIdStatus_Master;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	FarmerIDsAdapter Fadapter;
	public static int rowid;
	public static String OFStatus;


	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==23)
				{

					((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(0);
					Fadapter=new FarmerIDsAdapter(Get_FormerDetails.this, WebserviceCall.data);
					FdetailsLV.setAdapter(Fadapter);
				}

				//				}else{
				//
				//					Toast toast = null;
				//					toast=Toast.makeText(Login_Page.this, "No Data Found",Toast.LENGTH_SHORT);
				//					View view = toast.getView();
				//					toast.setGravity(Gravity.CENTER, 0, 0);
				//					view.setBackgroundResource(R.color.red);
				//					toast.show();
				//
				//
				//				}


				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast.makeText(Get_FormerDetails.this, "No New Data",Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Get_FormerDetails.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Get_FormerDetails.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Get_FormerDetails.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				if(paramMessage.what==22)
				{
					
					Toast.makeText(Get_FormerDetails.this,"Successfully Inserted",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}


	protected void onCreate(Bundle savedInstanceState) {
		try
		{
			super.onCreate(savedInstanceState);
			context=this;
			db=new DBAdapter(this);
			setContentView(R.layout.get_former_details);

			//db.exportDB();
			ArrayList<String> HstatusList=new ArrayList<String>();
			HstatusList.add("---Select---");
			//HstatusList.add("Preliminary Inspection");
			//HstatusList.add("Final Inspection");
			//HstatusList.add("Random Inspection");

			FIdStatus_Master=new HashMap<String, String>();
			FIdStatus_Master.put("Preliminary Inspection", "PI");
			FIdStatus_Master.put("Final Inspection", "FI");
			FIdStatus_Master.put("Random Inspection", "RI");
			FIdStatus_Master.put("Training Details", "TI");
			FIdStatus_Master.put("Revival of MI System", "MI SURVEY FARMER");



			if(WebserviceCall.Login_Details.get("ROLE_ID").equalsIgnoreCase("MIAPD") || WebserviceCall.Login_Details.get("ROLE_ID").equalsIgnoreCase("MIPD") || WebserviceCall.Login_Details.get("ROLE_ID").equalsIgnoreCase("MIHO"))
			{
				HstatusList.add("Random Inspection");
				//HstatusList.add("Revival of MI System");
				//			HstatusList.add("Farmer MI Survey");
				HstatusList.add("Training Details");
			}
			if(WebserviceCall.Login_Details.get("ROLE_ID").equalsIgnoreCase("MIE") )
			{
				HstatusList.add("Preliminary Inspection");
				HstatusList.add("Final Inspection");
				//HstatusList.add("Revival of MI System");
				HstatusList.add("Training Details");
			}
			if( WebserviceCall.Login_Details.get("ROLE_ID").equalsIgnoreCase("MIAO"))
			{
				HstatusList.add("Preliminary Inspection");
				HstatusList.add("Final Inspection");
				HstatusList.add("Revival of MI System");
				HstatusList.add("Training Details");
			}
			if(WebserviceCall.Login_Details.get("ROLE_ID").equalsIgnoreCase("MIDC") )
			{
				HstatusList.add("Final Inspection");
			//	HstatusList.add("Revival of MI System");
				HstatusList.add("Training Details");
			}


			this.ab=getSupportActionBar();
			ab.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.menu_bg));
			ab.setTitle("APMIP");
			ab.setHomeButtonEnabled(true);
			ab.setDisplayHomeAsUpEnabled(true);


			HdistrictSp=(TextView) findViewById(R.id.HdistrictSP);
			HmandalSp=(Spinner) findViewById(R.id.HmandalSP);
			HpanchayatSp=(Spinner) findViewById(R.id.HpanchayayatSP);
			HvillageSp=(Spinner) findViewById(R.id.HvillageSP);
			HstatusSp=(Spinner) findViewById(R.id.HStatusSP);
			FdetailsLV=(ListView)findViewById(R.id.FdetailsLV);


			int dd=Integer.parseInt(WebserviceCall.Login_Details.get("DistrictId"));
			HDist_id=Integer.toString(dd);

			if(!CheckConnection.isNetworkAvailable(Get_FormerDetails.this))
			{
				db.open();
				Cursor cursor=db.getTableDataCursor("select DISTINCT Staff_Name from InspectionStaffDetails where User_Name='"+Login_Page.UserId+"' order by Staff_Name");
				if (cursor.getCount() > 0) {

					WebserviceCall.StaffDataSP_AL=new ArrayList<String>();

					for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
					{
						WebserviceCall.StaffDataSP_AL.add(cursor.getString(0));

					}
					db.close();
				}
			}

			ArrayAdapter<String> statusAdapter = new ArrayAdapter<String>(Get_FormerDetails.this,android.R.layout.simple_spinner_item,HstatusList);
			statusAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			HstatusSp.setAdapter(statusAdapter);


			FdetailsLV.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) {


					rowid=(int) arg3;
					if(HFId_status.equalsIgnoreCase("MI SURVEY FARMER"))
					{

						if(WebserviceCall.StaffDataSP_AL!=null && !WebserviceCall.StaffDataSP_AL.isEmpty())
						{
							Intent intent = new Intent(Get_FormerDetails.this, MiSurveySystemAct.class);
							intent.putExtra("Srtatus","MI SURVEY FARMER");
							startActivity(intent);
							finish();
						}else {
							Toast toast = null;
							toast=Toast.makeText(Get_FormerDetails.this, "Please Re-Login Online",Toast.LENGTH_SHORT);
							View view = toast.getView();
							toast.setGravity(Gravity.CENTER, 0, 0);
							view.setBackgroundResource(R.color.red);
							toast.show();
						}
					}else
					{
						Intent intent = new Intent(Get_FormerDetails.this, Home_Act.class);
						intent.putExtra("Clicked","Done");
						startActivity(intent);
						//finish();
					}
				}
			});


			db.open();
			String distName=db.getSingleValue("select DISTRICT_NAME from DISTRICT_MASTER  where DISTRICT_ID='"+HDist_id+"'");
			db.close();
			HdistrictSp.setText(distName);
			if(HDist_id.length()==1)
			{
				HDist_id="0"+HDist_id;
			}
			db.open();
			List<String> mandallist=new ArrayList<String>();
			mandallist=db.getSpinnerData("select MANDAL_NAME from MANDAL_MASTER  where DISTRICT_ID='"+HDist_id+"' order by MANDAL_NAME");
			db.close();

			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Get_FormerDetails.this,android.R.layout.simple_spinner_item,mandallist);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			HmandalSp.setAdapter(dataAdapter);


			HstatusSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
				{

					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
					{
						OFStatus=HstatusSp.getSelectedItem().toString();
						HFId_status=FIdStatus_Master.get(HstatusSp.getSelectedItem().toString());
						if(HFId_status.equalsIgnoreCase("TI"))
						{
							Intent intent = new Intent(Get_FormerDetails.this, Training_Details.class);
							startActivity(intent);

						}

						else if(!HFId_status.isEmpty())
						{
							((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(8);
							GetFarmerDbList(HFId_status);
							//GetDbFarmerDetails(HFId_status);
							//						Home_Act.Farmer_ID="";
							//						Loaddata("GetFarmerBasicDetails");	
						}

					}

				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});

			//		HdistrictSp.setOnItemSelectedListener(new OnItemSelectedListener() {
			//
			//			@Override
			//			public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
			//			{
			//				if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
			//				{
			//					db.open();
			//					HDist_id=db.getSingleValue("select DISTRICT_ID from DISTRICT_MASTER  where DISTRICT_NAME='"+HdistrictSp.getSelectedItem().toString()+"'");
			//					db.close();
			//
			//					db.open();
			//					List<String> mandallist=new ArrayList<String>();
			//					mandallist=db.getSpinnerData("select MANDAL_NAME from MANDAL_MASTER  where DISTRICT_ID='"+HDist_id+"' order by MANDAL_NAME");
			//					db.close();
			//
			//					ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Get_FormerDetails.this,android.R.layout.simple_spinner_item,mandallist);
			//					dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			//					HmandalSp.setAdapter(dataAdapter);
			//
			//				}
			//
			//			}
			//
			//			@Override
			//			public void onNothingSelected(AdapterView<?> arg0) {
			//				
			//
			//			}
			//		});

			HmandalSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {

					//	db.open();
					//					if(HDist_id.length()==2)
					//					{
					//						char temp=HDist_id.charAt(0);
					//						if(temp=='0')
					//						{
					//							HDist_id=HDist_id.substring(1, 2);
					//						}
					//					}
					//					if(HDist_id.length()==3)
					//					{
					//						char temp=HDist_id.charAt(0);
					//						if(temp=='0')
					//						{
					//							HDist_id=HDist_id.substring(1, 3);
					//						}
					//					}
					((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(8);
					//reg_mandal=mandalSp.getSelectedItem().toString();
					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
					{


						((LinearLayout)findViewById(R.id.HStatusLL)).setVisibility(8);
						HvillageSp.setAdapter(null);
						HstatusSp.setSelection(0);

						db.open();
						HMandal_id=db.getSingleValue("select MANDAL_ID from MANDAL_MASTER  where DISTRICT_ID='"+HDist_id+"' and MANDAL_NAME='"+HmandalSp.getSelectedItem().toString()+"'");
						db.close();
						System.out.println("-------------mandal-------"+"select MANDAL_ID from MANDAL_MASTER  where DISTRICT_ID='"+HDist_id+"' and MANDAL_NAME='"+HmandalSp.getSelectedItem().toString()+"'");
						db.open();
						List<String> paanchayatList=new ArrayList<String>();
						paanchayatList=db.getSpinnerData("select PANCHAYAT_NAME from PANCHAYAT_MASTER  where DISTRICT_ID='"+HDist_id+"' and MANDAL_ID='"+HMandal_id+"'   order by PANCHAYAT_NAME");
						db.close();

						ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Get_FormerDetails.this,android.R.layout.simple_spinner_item,paanchayatList);
						dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
						HpanchayatSp.setAdapter(dataAdapter);

					}
					else 
					{
						HpanchayatSp.setAdapter(null);
						HvillageSp.setAdapter(null);
						((LinearLayout)findViewById(R.id.HStatusLL)).setVisibility(8);
						((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(8);
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});

			HpanchayatSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {

					db.open();
					((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(8);
					//reg_mandal=mandalSp.getSelectedItem().toString();
					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
					{
						((LinearLayout)findViewById(R.id.HStatusLL)).setVisibility(8);
						HstatusSp.setSelection(0);
						db.open();
						HPanchayat_id=db.getSingleValue("select PANCHAYAT_ID from PANCHAYAT_MASTER  where DISTRICT_ID='"+HDist_id+"' and MANDAL_ID='"+HMandal_id+"' and PANCHAYAT_NAME='"+HpanchayatSp.getSelectedItem().toString()+"'");
						db.close();

						db.open();
						List<String> villagelist=new ArrayList<String>();
						villagelist=db.getSpinnerData("select VILLAGE_NAME from VILLAGE_MASTER  where DISTRICT_ID='"+HDist_id+"' and MANDAL_ID='"+HMandal_id+"' and PANCHAYAT_ID='"+HPanchayat_id+"'  order by VILLAGE_NAME");
						db.close();

						ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Get_FormerDetails.this,android.R.layout.simple_spinner_item,villagelist);
						dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
						HvillageSp.setAdapter(dataAdapter);

					}else {

						HvillageSp.setAdapter(null);
						((LinearLayout)findViewById(R.id.HStatusLL)).setVisibility(8);

					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {

				}
			});

			HvillageSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(8);

					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
					{

						db.open();
						HViialge_id=db.getSingleValue("select VILLAGE_ID from VILLAGE_MASTER  where DISTRICT_ID='"+HDist_id+"' and MANDAL_ID='"+HMandal_id+"' and PANCHAYAT_ID='"+HPanchayat_id+"' and VILLAGE_NAME='"+HvillageSp.getSelectedItem().toString()+"'");
						System.out.println("---"+HViialge_id);
						db.close();

						((LinearLayout)findViewById(R.id.HStatusLL)).setVisibility(0);

					}
					else {

						((LinearLayout)findViewById(R.id.HStatusLL)).setVisibility(8);

					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {

				}
			});
		}
		catch(Exception e)
		{
			Intent i=new Intent(Get_FormerDetails.this,Login_Page.class);
			startActivity(i);
			finish();
		}
	}
	private void GetFarmerDbList(String Staus)
	{
		try
		{
			if(CheckConnection.isNetworkAvailable(Get_FormerDetails.this))
			{
				Home_Act.Farmer_ID="";
				Loaddata("GetFarmerBasicDetails");	
			}
			if(!CheckConnection.isNetworkAvailable(Get_FormerDetails.this)){

				if(HDist_id.length()==1)
				{
					HDist_id="0"+HDist_id;
				}
				//				if(HMandal_id.length()==1)
				//				{
				//					HMandal_id="0"+HMandal_id;
				//				}
				//				if(HPanchayat_id.length()==1)
				//				{
				//					HPanchayat_id="0"+HPanchayat_id;
				//				}
								if(HViialge_id.length()==1)
								{
									HViialge_id="00"+HViialge_id;
								}
								if(HViialge_id.length()==2)
								{
									HViialge_id="0"+HViialge_id;
								}
				GetDbFarmerDetails(Staus);
				if(!WebserviceCall.data.isEmpty()){
					((LinearLayout)findViewById(R.id.FdetailLL)).setVisibility(0);
					Fadapter=new FarmerIDsAdapter(Get_FormerDetails.this,WebserviceCall.data);
					FdetailsLV.setAdapter(Fadapter);
				}else {
					Toast.makeText(Get_FormerDetails.this, "No New Data",Toast.LENGTH_LONG).show();
				}
			}

		}
		catch(Exception e)
		{

		}
	}
	public void GetDbFarmerDetails(String StausCode)
	{
		try
		{

			WebserviceCall.data=new ArrayList<HashMap<String,String>>();
			if(StausCode.equalsIgnoreCase("PI"))
			{
				StausCode="Preliminary Inspection";
			}
			else if(StausCode.equalsIgnoreCase("RI"))
			{
				StausCode="Random Inspection";
			}
			else if(StausCode.equalsIgnoreCase("FI"))
			{
				StausCode="Final Inspection";
			}

			db.open();
			DBAdapter.DATABASE_NAME="APMIP3.db";
			
			Cursor cursor=db.getTableDataCursor("select FarmerId,FarmerName,AADHAARNUMBER,MobileNumber,Social_staus,CATEGORY,CropName," +
					"Area_Proposed,FarmerAddress,FARMERSTATUS,Installation_Year,MI_Company_Name,MI_System_Type,Subsidy,Survey_No from APMIP_FARMER_DETAILS where District_id='"+HDist_id+"' and Status_Flag='N' and Mandal_id=='"+HMandal_id+"' and Panchayat_Code='"+HPanchayat_id+"' and Village_Code='"+HViialge_id+"' and FARMERSTATUS='"+StausCode+"' and  User_ID='"+Login_Page.UserId+"' and Password='"+Login_Page.PWd+"'");
			if (cursor.getCount() > 0) {

				//WebserviceCall.data=new ArrayList<HashMap<String,String>>();
				int p=0;
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
				{
					WebserviceCall.FarmerId_list=new HashMap<String, String>();

					WebserviceCall.FarmerId_list.put("sno", Integer.toString(p+1));
					WebserviceCall.FarmerId_list.put("Farmer_Id",cursor.getString(0));
					WebserviceCall.FarmerId_list.put("FarmerName",cursor.getString(1));
					WebserviceCall.FarmerId_list.put("AADHAARNUMBER",cursor.getString(2));
					WebserviceCall.FarmerId_list.put("MobileNumber",cursor.getString(3));
					WebserviceCall.FarmerId_list.put("Social_staus",cursor.getString(4));
					WebserviceCall.FarmerId_list.put("CATEGORY",cursor.getString(5));
					WebserviceCall.FarmerId_list.put("CropName",cursor.getString(6));
					WebserviceCall.FarmerId_list.put("Area_Proposed",cursor.getString(7));
					WebserviceCall.FarmerId_list.put("FarmerAddress",cursor.getString(8));
					WebserviceCall.FarmerId_list.put("FARMERSTATUS",cursor.getString(9));

					WebserviceCall.FarmerId_list.put("Installation_Year",cursor.getString(10));
					WebserviceCall.FarmerId_list.put("MI_Company_Name",cursor.getString(11));
					WebserviceCall.FarmerId_list.put("MI_System_Type",cursor.getString(12));
					WebserviceCall.FarmerId_list.put("Subsidy",cursor.getString(13));
					WebserviceCall.FarmerId_list.put("Survey_No",cursor.getString(14));


					//				WebserviceCall.FarmerId_list.put("RequestId",cursor.getString(10));
					//				WebserviceCall.FarmerId_list.put("Status_Code",cursor.getString(11));


					WebserviceCall.data.add(WebserviceCall.FarmerId_list);
					p++;

				}

			}

			db.close();


		}
		catch(Exception e)
		{
		}
	}
	private void DownloadOfflineData()
	{

		try{
			progressDialog=new ProgressDialog(Get_FormerDetails.this);

			ArrayList<String> dbData=new ArrayList<String>();

			//			if(WebserviceCall.data==null)
			//			{
			//				//			if(WebserviceCall.data.size()==0)
			//				//			{
			//				db.open();
			//				int i=	db.getRowCount("select Count(User_ID) from APMIP_FARMER_DETAILS where User_ID='"+Login_Page.UserId+"' and Password='"+Login_Page.PWd+"' ");
			//				if(i==0)
			//				{
			//
			//					db.execSQL("Insert into APMIP_FARMER_DETAILS (User_ID,Password,User_ROLE_ID,User_DistrictId)  values('"+Login_Page.UserId+"','"+Login_Page.PWd+"','"+WebserviceCall.Login_Details.get("ROLE_ID")+"','"+WebserviceCall.Login_Details.get("DistrictId")+"')");
			//					Toast toast = null;
			//					toast=Toast.makeText(Get_FormerDetails.this, "Login Details Successfully Downloaded",Toast.LENGTH_LONG);
			//					View view = toast.getView();
			//					toast.setGravity(Gravity.CENTER, 0, 0);
			//					view.setBackgroundResource(R.color.red);
			//					toast.show();
			//				}
			//				else
			//				{
			//					Toast toast = null;
			//					toast=Toast.makeText(Get_FormerDetails.this, "Login Details Already Downloaded",Toast.LENGTH_LONG);
			//					View view = toast.getView();
			//					toast.setGravity(Gravity.CENTER, 0, 0);
			//					view.setBackgroundResource(R.color.red);
			//					toast.show();
			//				}
			//				db.close();	
			//
			//				//	}
			//			}

			if(OFStatus.equalsIgnoreCase("Preliminary Inspection") ||OFStatus.equalsIgnoreCase("Random Inspection")||OFStatus.equalsIgnoreCase("Final Inspection"))
			{
				OFStatus=null;
				if(WebserviceCall.data!=null)
				{
					if(!WebserviceCall.data.isEmpty()  )
					{
						if(progressDialog.isShowing())
							progressDialog.dismiss();
						progressDialog.setMessage("Please Wait.......");
						progressDialog.show();
						if(HDist_id.length()==1)
						{
							HDist_id="0"+HDist_id;
						}
						//						if(HMandal_id.length()==1)
						//						{
						//							HMandal_id="0"+HMandal_id;
						//						}
						//						if(HPanchayat_id.length()==1)
						//						{
						//							HPanchayat_id="0"+HPanchayat_id;
						//						}
												if(HViialge_id.length()==1)
												{
													HViialge_id="00"+HViialge_id;
												}
												if(HViialge_id.length()==2)
												{
													HViialge_id="0"+HViialge_id;
												}



						for(HashMap<String, String> hmap:WebserviceCall.data)
						{


							ContentValues contentValues=new ContentValues();

							contentValues.put("User_ID",Login_Page.UserId);
							contentValues.put("Password",Login_Page.PWd);
							contentValues.put("User_DistrictId",WebserviceCall.Login_Details.get("DistrictId"));
							contentValues.put("User_ROLE_ID",WebserviceCall.Login_Details.get("ROLE_ID"));
							contentValues.put("User_STATUS",WebserviceCall.Login_Details.get("STATUS"));

							contentValues.put("FarmerId",hmap.get("Farmer_Id"));
							contentValues.put("RequestId",hmap.get("RequestId"));
							contentValues.put("AADHAARNUMBER",hmap.get("AADHAARNUMBER"));
							contentValues.put("FarmerName",hmap.get("FarmerName"));
							contentValues.put("FatherName",hmap.get("FatherName"));
							contentValues.put("MobileNumber",hmap.get("MobileNumber"));
							contentValues.put("Caste",hmap.get("Caste"));
							contentValues.put("Social_staus",hmap.get("Social_staus"));
							contentValues.put("FarmerAddress",hmap.get("FarmerAddress"));
							contentValues.put("Survey_No",hmap.get("Survey_No"));
							contentValues.put("CropName",hmap.get("CropName"));
							contentValues.put("Area_Proposed",hmap.get("Area_Proposed"));
							contentValues.put("FARMERSTATUS",hmap.get("FARMERSTATUS"));
							contentValues.put("CATEGORY",hmap.get("CATEGORY"));
							contentValues.put("Status_Code",hmap.get("Status_Code"));
							contentValues.put("MI_Company_Name",hmap.get("MI_Company_Name"));
							contentValues.put("MI_System_Type",hmap.get("MI_System_Type"));
							contentValues.put("Installation_Year",hmap.get("Installation_Year"));
							contentValues.put("Subsidy",hmap.get("Subsidy"));
							contentValues.put("District_id",hmap.get("District_id"));
							contentValues.put("Mandal_id",hmap.get("Mandal_id"));
							contentValues.put("Panchayat_Code",hmap.get("Panchayat_Code"));
							contentValues.put("Village_Code",hmap.get("Village_Code"));
							contentValues.put("Habitation_Id",hmap.get("Habitation_Id"));
							System.out.println("------"+db.DATABASE_NAME);
							if(contentValues!=null)
							{
								if(!dbData.contains(contentValues.get("FarmerId"))){
									db.open();
									
									db.insertTableDate("APMIP_FARMER_DETAILS",contentValues);
									String ff=db.getSingleValue("select Count(FarmerId) from APMIP_FARMER_DETAILS");
									System.out.println("---------------count----"+ff);
									db.close();
									//db.open();
									//db.exportDB();
								}

							}



						}



						new android.os.Handler().postDelayed(
								new Runnable() {
									public void run() {
										progressDialog.setMessage("---Successfully Downloaded.......");
										progressDialog.dismiss();
										Toast toast = null;
										toast=Toast.makeText(Get_FormerDetails.this, "Successfully Downloaded  ",Toast.LENGTH_LONG);
										View view = toast.getView();
										toast.setGravity(Gravity.CENTER, 0, 0);
										view.setBackgroundResource(R.color.red);
										toast.show();
									}
								}, 2000);


						//
					}
					else
					{
						progressDialog.dismiss();
					}
				}
				else
				{
					Toast toast = null;
					toast=Toast.makeText(Get_FormerDetails.this, "No New Data",Toast.LENGTH_LONG);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
			}

			else if( !(WebserviceCall.data==null) && !(WebserviceCall.InspectionStaff_Cv==null))
			{



				if(!WebserviceCall.data.isEmpty() && !WebserviceCall.InspectionStaff_Cv.isEmpty() )
				{
					if(progressDialog.isShowing())
						progressDialog.dismiss();
					progressDialog.setMessage("Please Wait.......");
					progressDialog.show();
					if(HDist_id.length()==1)
					{
						HDist_id="0"+HDist_id;
					}
				
					//					if(HMandal_id.length()==1)
					//					{
					//						HMandal_id="0"+HMandal_id;
					//					}
					//					if(HPanchayat_id.length()==1)
					//					{
					//						HPanchayat_id="0"+HPanchayat_id;
					//					}
										if(HViialge_id.length()==1)
										{
											HViialge_id="00"+HViialge_id;
										}
										if(HViialge_id.length()==2)
										{
											HViialge_id="0"+HViialge_id;
										}


					try
					{
						db.open();
						db.deleteTableData("InspectionStaffDetails", "User_Name='"+Login_Page.UserId+"'");

						Cursor cursor=db.getTableDataCursor("select DISTINCT FarmerId from APMIP_FARMER_DETAILS where FARMERSTATUS='"+HFId_status+"' and District_id='"+HDist_id+"' and Mandal_id='"+HMandal_id+"' and Panchayat_Code='"+HPanchayat_id+"' and Village_Code='"+HViialge_id+"' and User_ID='"+Login_Page.UserId+"'");
						if (cursor.getCount() > 0) {



							for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
							{

								dbData.add(cursor.getString(0));

							}

						}

						db.close();
					}
					catch(Exception e)
					{

					}
					for(HashMap<String, String> hmap:WebserviceCall.data)
					{


						ContentValues contentValues=new ContentValues();

						contentValues.put("User_ID",Login_Page.UserId);
						contentValues.put("Password",Login_Page.PWd);
						contentValues.put("User_DistrictId",WebserviceCall.Login_Details.get("DistrictId"));
						contentValues.put("User_ROLE_ID",WebserviceCall.Login_Details.get("ROLE_ID"));
						contentValues.put("User_STATUS",WebserviceCall.Login_Details.get("STATUS"));

						contentValues.put("FarmerId",hmap.get("Farmer_Id"));
						contentValues.put("RequestId",hmap.get("RequestId"));
						contentValues.put("AADHAARNUMBER",hmap.get("AADHAARNUMBER"));
						contentValues.put("FarmerName",hmap.get("FarmerName"));
						contentValues.put("FatherName",hmap.get("FatherName"));
						contentValues.put("MobileNumber",hmap.get("MobileNumber"));
						contentValues.put("Caste",hmap.get("Caste"));
						contentValues.put("Social_staus",hmap.get("Social_staus"));
						contentValues.put("FarmerAddress",hmap.get("FarmerAddress"));
						contentValues.put("Survey_No",hmap.get("Survey_No"));
						contentValues.put("CropName",hmap.get("CropName"));
						contentValues.put("Area_Proposed",hmap.get("Area_Proposed"));
						contentValues.put("FARMERSTATUS",hmap.get("FARMERSTATUS"));
						contentValues.put("CATEGORY",hmap.get("CATEGORY"));
						contentValues.put("Status_Code",hmap.get("Status_Code"));
						contentValues.put("MI_Company_Name",hmap.get("MI_Company_Name"));
						contentValues.put("MI_System_Type",hmap.get("MI_System_Type"));
						contentValues.put("Installation_Year",hmap.get("Installation_Year"));
						contentValues.put("Subsidy",hmap.get("Subsidy"));
						contentValues.put("District_id",hmap.get("District_id"));
						contentValues.put("Mandal_id",hmap.get("Mandal_id"));
						contentValues.put("Panchayat_Code",hmap.get("Panchayat_Code"));
						contentValues.put("Village_Code",hmap.get("Village_Code"));
						contentValues.put("Habitation_Id",hmap.get("Habitation_Id"));

						if(contentValues!=null)
						{
							if(!dbData.contains(contentValues.get("FarmerId"))){
								db.open();
								db.insertTableDate("APMIP_FARMER_DETAILS",contentValues);
								String ff=db.getSingleValue("select Count(FarmerId) from APMIP_FARMER_DETAILS");
								System.out.println("---------------count----"+ff);
								db.close();
								db.open();
								db.exportDB();
							}

						}



					}

					for(ContentValues cv:WebserviceCall.InspectionStaff_Cv)
					{

						db.open();
						db.insertTableDate("InspectionStaffDetails",cv);
						String ff=db.getSingleValue("select Count(Staff_ID) from InspectionStaffDetails");
						System.out.println("---------------staff cou----"+ff);
						db.close();
						

					}

					new android.os.Handler().postDelayed(
							new Runnable() {
								public void run() {
									progressDialog.setMessage("---Successfully Downloaded.......");
									progressDialog.dismiss();
									Toast toast = null;
									toast=Toast.makeText(Get_FormerDetails.this, "Successfully Downloaded  ",Toast.LENGTH_LONG);
									View view = toast.getView();
									toast.setGravity(Gravity.CENTER, 0, 0);
									view.setBackgroundResource(R.color.red);
									toast.show();
								}
							}, 2000);


					//progressDialog.dismiss();
				}

			}
			else 
			{
				Toast toast = null;
				toast=Toast.makeText(Get_FormerDetails.this, "No New Data/Please Re-Login Online",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();
			}
		}
		catch(Exception e)
		{

		}

	}

	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home_, menu);
		MenuItem item=menu.findItem(R.id.logout);
		item.setVisible(false);
		MenuItem item1=menu.findItem(R.id.UserManual);
		item1.setVisible(false);

		MenuItem item2=menu.findItem(R.id.Upload_OffLine_Data);
		item2.setVisible(false);

		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();

		if(id== R.id.Download_OffLine_Data)
		{
			DownloadOfflineData();
			//DownloadAlert("Are you sure you want to Download UserManual file");
			//new DownloadFile().execute();
		}
		if(id==R.id.VMasterData)
		{
			Dflag="V";
			Loaddata("GETGEOGRAPHICDETAILS");
		}
		if(id==R.id.MMasterData)
		{
			Dflag="M";
			Loaddata("GETGEOGRAPHICDETAILS");
		}
		if(id==R.id.PMasterData)
		{

			Dflag="P";
			Loaddata("GETGEOGRAPHICDETAILS");
		}

		return super.onOptionsItemSelected(item);
	}

	public void onBackPressed()
	{
		startActivity(new Intent(Get_FormerDetails.this,Home_Act1.class));
		finish();
	}
}
