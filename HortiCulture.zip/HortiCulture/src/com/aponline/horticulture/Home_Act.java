package com.aponline.horticulture;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.kobjects.base64.Base64;

import com.aponline.Hc.database.DBAdapter;
import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.WebserviceCall;

import android.R.integer;
import android.support.annotation.DrawableRes;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


@SuppressLint("NewApi")
public class Home_Act extends AppCompatActivity 
{
	DBAdapter db;
	CheckConnection conn_obj;
	ProgressDialog progressDialog;
	Handler mHandler;
	TableLayout addPhoto;
	Button addPhotoBt;
	Context context;
//	RadioGroup selectionRG;
//	RadioButton radioButton1,radioButton2;
	int count=0;
	GPSTracker gps;
	String pendingCount;
	ImageView photo1IV,photo2IV;
	EditText Farmer_id;
	public static HashMap<String, String> CapurePhotos;
	private static final int CAMERA_REQUEST = 1888; 
	Bitmap photo;
	String photoNo;
	boolean doubleBackToExitPressedOnce = true;
	TextView userId,pendingCountEt,Headcontrol_LaLgTv1,Headcontrol_LaLgTv2,Trackling_LaLgTv1,Trackling_LaLgTv2;
	LocationManager locationManager;
	ActionBar ab;
	public static String Farmer_ID,waterSource_LaLg,Headcontrol_LaLg,Trackling_LaLg,Request_Id,Status_code;
	HashMap< String, Bitmap> photodata=new HashMap<String, Bitmap>();

	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==22)
				{
					if((WebserviceCall.Login_Details.get("STATUS")).equalsIgnoreCase("TRUE"))
					{
						startActivity(new Intent(Home_Act.this,Home_Act.class));
					}else{

						Toast toast = null;
						toast=Toast.makeText(Home_Act.this, "Invalid User",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();


					}


				}
				if(paramMessage.what==15)
				{

					if(WebserviceCall.serverResponse.equalsIgnoreCase("success")){
						AlertDialog(context, "Successfully Submitted","Submitted");
						resetALL();
					}else if(WebserviceCall.serverResponse.equalsIgnoreCase("Failed"))
					{
						Toast toast = null;
						toast=Toast.makeText(Home_Act.this, "Please Try Agian",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.BOTTOM, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
				}
				if(paramMessage.what==12)
				{
					//					Intent intent = getIntent();
					//					finish();
					//					startActivity(intent);
					refreshPendingCount();
				}
				if(paramMessage.what==23)
				{

					if(!(WebserviceCall.FidStatus.equalsIgnoreCase("")))
					{
						AlertDialog(context, WebserviceCall.FidStatus, "FidStatus");
					}else if(WebserviceCall.data.get(0).get("FARMERSTATUS").toString().equalsIgnoreCase("MI SURVEY FARMER"))
					{
						Intent intent = new Intent(Home_Act.this, MiSurveySystemAct.class);
						intent.putExtra("Srtatus","MI SURVEY FARMER");
						startActivity(intent);
					}else{
						GeneralFarmerDetails();
						//Farmer_id.setText(WebserviceCall.data.get(0).get("Farmer_Id").toString());
						//Farmer_ID=Farmer_id.getText().toString();




						//						((LinearLayout)findViewById(R.id.mainLL)).setVisibility(0);
						//						Farmer_ID=WebserviceCall.data.get(0).get("Farmer_Id").toString();
						//
						//						((TextView)findViewById(R.id.hfname)).setText(WebserviceCall.data.get(0).get("FarmerName"));
						//						((TextView)findViewById(R.id.hfaadhar)).setText(WebserviceCall.data.get(0).get("AADHAARNUMBER"));
						//						((TextView)findViewById(R.id.hfmobile)).setText(WebserviceCall.data.get(0).get("MobileNumber"));
						//						((TextView)findViewById(R.id.hfsocial)).setText(WebserviceCall.data.get(0).get("Social_staus"));
						//						((TextView)findViewById(R.id.hfcategory)).setText(WebserviceCall.data.get(0).get("CATEGORY"));
						//						((TextView)findViewById(R.id.hfcrop)).setText(WebserviceCall.data.get(0).get("CropName"));
						//						((TextView)findViewById(R.id.hfarea)).setText(WebserviceCall.data.get(0).get("Area_Proposed"));
						//						((TextView)findViewById(R.id.hfaddress)).setText(WebserviceCall.data.get(0).get("FarmerAddress"));
						//						((TextView)findViewById(R.id.hfstatus)).setText(WebserviceCall.data.get(0).get("FARMERSTATUS"));
						//						Request_Id=WebserviceCall.data.get(0).get("RequestId");
						//						Status_code=WebserviceCall.data.get(0).get("Status_Code").toString();
					}
				}



				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(Home_Act.this, "Please Enter Valid Farmer ID",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Home_Act.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Home_Act.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Home_Act.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}

	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
			super.onCreate(savedInstanceState);
			context=this;
			db=new DBAdapter(this);
			setContentView(R.layout.home);
			gps=new GPSTracker(Home_Act.this);
			userId=(TextView) findViewById(R.id.userId);
			pendingCountEt=(TextView) findViewById(R.id.pendingUploadCountEt);
			CapurePhotos=new HashMap<String, String>();
			photo1IV=((ImageView)findViewById(R.id.photo1IV));
			photo2IV=((ImageView)findViewById(R.id.photo2IV));


			//		db.open();
			//		pendingCount=db.getSingleValue("select DISTINCT Count(FarmerId) from APMIP_FARMER_DETAILS where Status_Flag='P' and User_ID='"+Login_Page.UserId+"'");
			//		pendingCountEt.setText("Pending Upload To Online Count : "+pendingCount);
			//		db.close();

			refreshPendingCount();



			if(Integer.parseInt(pendingCount) > 0 && CheckConnection.isNetworkAvailable(Home_Act.this))
			{
				Loaddata("UploadInserGPSCoordinates");
			}


			this.ab=getSupportActionBar();
			ab.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.menu_bg));
			ab.setTitle("APMIP");
				//	ab.setHomeButtonEnabled(true);
				//	ab.setDisplayHomeAsUpEnabled(true);

			try
			{
				userId.setText("Welcome To "+WebserviceCall.Login_Details.get("ROLE_ID"));
			}
			catch(Exception e)
			{

			}

			userId.startAnimation((Animation)AnimationUtils.loadAnimation(Home_Act.this,R.anim.text_translate));
			pendingCountEt.startAnimation((Animation)AnimationUtils.loadAnimation(Home_Act.this,R.anim.text_translate));


			//addPhoto=(TableLayout) findViewById(R.id.testAdd);
			//		addPhotoBt=(Button) findViewById(R.id.addPhotoBt);
			//		photo3IV=((ImageView)findViewById(R.id.photo3IV));
			//		photo4IV=((ImageView)findViewById(R.id.photo4IV));
			//		photo5IV=((ImageView)findViewById(R.id.photo5IV));

			//selectionRG = (RadioGroup)findViewById(R.id.radioGroup1);

			Headcontrol_LaLgTv1=((TextView)findViewById(R.id.headControlTVLa));
			Headcontrol_LaLgTv2=((TextView)findViewById(R.id.headControlTVLg));

			Trackling_LaLgTv1=((TextView)findViewById(R.id.TraclingTVLa));
			Trackling_LaLgTv2=((TextView)findViewById(R.id.TraclingTVLg));

			//radioButton1=(RadioButton) findViewById(R.id.radio0);
			//radioButton2=(RadioButton) findViewById(R.id.radio1);
			Farmer_id=((EditText)findViewById(R.id.Farmet_IdEt));

		//	radioButton1.setChecked(true);
		//	radioButton2.setChecked(false);


			Intent intent = getIntent(); 
			if(!(intent.getStringExtra("Clicked")==null) && intent.getStringExtra("Clicked").toString().equalsIgnoreCase("Done") )
			{
				MiFarmerDetails();
				//			((LinearLayout)findViewById(R.id.mainLL)).setVisibility(0);
				//			((Button)findViewById(R.id.getDetailBt)).setVisibility(8);
				//			((TextView)findViewById(R.id.Farmet_IdEt1)).setVisibility(8);
				//			radioButton1.setChecked(false);
				//			radioButton2.setChecked(true);
				//			Farmer_id.setEnabled(false);
				//			int maxLength =19;    
				//			Farmer_id.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maxLength)});
				//			Farmer_id.setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Farmer_Id"));
				//			Farmer_ID=Farmer_id.getText().toString();
				//			((TextView)findViewById(R.id.hfname)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FarmerName"));
				//			((TextView)findViewById(R.id.hfaadhar)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("AADHAARNUMBER"));
				//			((TextView)findViewById(R.id.hfmobile)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MobileNumber"));
				//			((TextView)findViewById(R.id.hfsocial)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Social_staus"));
				//			((TextView)findViewById(R.id.hfcategory)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("CATEGORY"));
				//			((TextView)findViewById(R.id.hfcrop)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("CropName"));
				//			((TextView)findViewById(R.id.hfarea)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Area_Proposed"));
				//			((TextView)findViewById(R.id.hfaddress)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FarmerAddress"));
				//			((TextView)findViewById(R.id.hfstatus)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FARMERSTATUS"));
				//			Request_Id=WebserviceCall.data.get(Get_FormerDetails.rowid).get("RequestId");
				//			Status_code=WebserviceCall.data.get(Get_FormerDetails.rowid).get("Status_Code");


			}

//			radioButton1.setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View v) {
//
//					Intent refresh = new Intent(Home_Act.this, Home_Act.class);
//					startActivity(refresh);//Start the same Activity
//					finish(); //finish Activity.
//					Farmer_id.setEnabled(true);
//					Farmer_id.setText("");
//
//
//					((Button)findViewById(R.id.getDetailBt)).setVisibility(0);
//					((LinearLayout)findViewById(R.id.FormerIdSearchLL)).setVisibility(0);
//					((LinearLayout)findViewById(R.id.mainLL)).setVisibility(8);
//
//
//
//				}
//			});
//			radioButton2.setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View v) {
//					Farmer_id.setText("");
//					Farmer_ID="";
//					startActivity(new Intent(Home_Act.this, Get_FormerDetails.class));
//
//
//				}
//			});
		}
		catch(Exception e)
		{

		}
	}

	public void resetALL()
	{
		try
		{
			Farmer_id.setText("");
			Farmer_id.setEnabled(true);
			Farmer_ID="";

			Headcontrol_LaLg="";
			Trackling_LaLg="";
			waterSource_LaLg="";

			CapurePhotos.clear();

			//		Get_FormerDetails.HDist_id="";
			//		Get_FormerDetails.HMandal_id="";
			//		Get_FormerDetails.HPanchayat_id="";
			//		Get_FormerDetails.HViialge_id="";
			//		Get_FormerDetails.HFId_status="";

		//	radioButton1.setChecked(true);
		//	radioButton2.setChecked(false);

			((Button)findViewById(R.id.getDetailBt)).setVisibility(0);
			((LinearLayout)findViewById(R.id.mainLL)).setVisibility(8);

			((TextView)findViewById(R.id.headControlTVLa)).setText("");
			((TextView)findViewById(R.id.headControlTVLg)).setText("");

			((TextView)findViewById(R.id.TraclingTVLa)).setText("");
			((TextView)findViewById(R.id.TraclingTVLg)).setText("");
		}
		catch(Exception e)
		{

		}
	}

	//	public void addPhotoFrame(View v)
	//	{
	//
	//		count++;
	//
	//		if(count==1)
	//		{
	//			photo3IV.setVisibility(0);
	//			((Button)findViewById(R.id.removePhotoBt)).setVisibility(0);
	//			addPhotoBt.setVisibility(0);
	//		}else if (count==2) 
	//		{
	//			photo4IV.setVisibility(0);
	//			((Button)findViewById(R.id.removePhotoBt)).setVisibility(0);
	//			addPhotoBt.setVisibility(0);
	//		}else if (count==3)
	//		{
	//			photo5IV.setVisibility(0);
	//			((Button)findViewById(R.id.removePhotoBt)).setVisibility(0);
	//			addPhotoBt.setVisibility(8);
	//		}
	//
	//
	//
	//	}
	//	public void removePhotoFrame(View v)
	//	{
	//				if(count==3)
	//				{
	//					photo5IV.setVisibility(8);
	//					((Button)findViewById(R.id.removePhotoBt)).setVisibility(0);
	//					addPhotoBt.setVisibility(0);
	//		
	//				}else if (count==2) {
	//					photo4IV.setVisibility(8);
	//					((Button)findViewById(R.id.removePhotoBt)).setVisibility(0);
	//					addPhotoBt.setVisibility(0);
	//				}else if (count==1) {
	//					photo3IV.setVisibility(8);
	//					((Button)findViewById(R.id.removePhotoBt)).setVisibility(8);
	//					addPhotoBt.setVisibility(0);
	//				}
	//				count--;
	//		
	//				if(count==0)
	//				{
	//					addPhotoBt.setVisibility(0);
	//				}
	//
	//
	//	}
	//	Button photoButton = (Button) this.findViewById(R.id.button1);
	//    photoButton.setOnClickListener(new View.OnClickListener() {
	//
	//        @Override
	//        public void onClick(View v) {
	//            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); 
	//            startActivityForResult(cameraIntent, CAMERA_REQUEST); 
	//        }
	//    });
	//}
	//
	//protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
	//    if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {  
	//        Bitmap photo = (Bitmap) data.getExtras().get("data"); 
	//        imageView.setImageBitmap(photo);
	//    }  
	//} 

	private void photos()
	{
		//		if(count==1)
		//		{
		//			photo3IV.setVisibility(0);
		//		}else if (count==2) {
		//			photo4IV.setVisibility(0);
		//		}else if (count==3) {
		//			photo5IV.setVisibility(0);
		//		}
		//		LinearLayout linearLayout1 = (LinearLayout) findViewById(R.id.linearLayout1);
		//
		//		final ImageButton image = new ImageButton(Home_Act.this);
		//
		//		image.setBackgroundResource(R.drawable.camera_icon);
		//		linearLayout1.addView(image);
		//
		//		image.setOnClickListener(new OnClickListener() {
		//
		//			@Override
		//			public void onClick(View v) {
		//				takePhoto();
		//				image.setImageBitmap(photo);
		//			}
		//		});
	}
	public void FinalSubmit(View v)
	{
		try
		{
			//((TextView)findViewById(R.id.waterSourceTVLa)).setText("");
			//((TextView)findViewById(R.id.waterSourceTVLg)).setText("");
			//((Button)findViewById(R.id.WaterSourceGpsBt)).setEnabled(true);
			System.out.println("----------gg--"+Headcontrol_LaLgTv1.getText().toString());


			if(CapurePhotos.size()<2)
			{
				AlertDialog(context, "Please Capture Photo","Take Photo");
			}else if (waterSource_LaLg.equalsIgnoreCase("0.0,0.0") || waterSource_LaLg.equalsIgnoreCase("") || waterSource_LaLg.equalsIgnoreCase("null")) {
				AlertDialog(context, "Please ReCapture WaterSource Photo","Take Photo");
			}
			else if ((Headcontrol_LaLgTv1.getText().toString()).equalsIgnoreCase("La-0.0") || (Headcontrol_LaLgTv1.getText().toString()).equalsIgnoreCase("null") || (Headcontrol_LaLgTv1.getText().toString()).equalsIgnoreCase("")) 
			{
				AlertDialog(context, "Get Head Control Unit GPS","Gps Coordinates");
			}else if ((Trackling_LaLgTv1.getText().toString()).equalsIgnoreCase("null") || (Trackling_LaLgTv1.getText().toString()).equalsIgnoreCase("La-0.0") || (Trackling_LaLgTv1.getText().toString()).equalsIgnoreCase("")) 
			{
				AlertDialog(context, "Get Tracking of Field GPS","Gps Coordinates");
			}else {

				LogoutAlert("do you want confirm this Details?","proceed");
				//Loaddata("InserGPSCoordinates");
			}
		}
		catch(Exception e)
		{

		}
	}
	public void photo1(View v)
	{
		try
		{
			photoNo="one";
			locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			{
				buildAlertMessageNoGps();
			}  else {
				takePhoto();
			}

		}
		catch(Exception e)
		{

		}
	}
	public void photo2(View v)
	{
		try
		{
			photoNo="two";
			takePhoto();
		}
		catch(Exception e)
		{

		}
	}
	//	public void photo3(View v)
	//	{
	//		photoNo="three";
	//		takePhoto();
	//
	//	}
	//	public void photo4(View v)
	//	{
	//		photoNo="four";
	//		takePhoto();
	//
	//	}public void photo5(View v)
	//	{
	//		photoNo="five";
	//		takePhoto();
	//
	//	}
	private void takePhoto()
	{
		try
		{
			Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(cameraIntent,CAMERA_REQUEST);
		}
		catch(Exception e)
		{

		}
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{  
		try
		{
			if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) 
			{  

				if(photoNo.equalsIgnoreCase("one"))
				{
					ByteArrayOutputStream out1 = new ByteArrayOutputStream();
					photo = (Bitmap) data.getExtras().get("data"); 
					photo1IV.setImageBitmap(photo);
					photo.compress(Bitmap.CompressFormat.PNG, 100, out1);
					//saveToInternalSorage(photo);
					byte[] ba1 = out1.toByteArray();
					CapurePhotos.put("photoOne",Base64.encode(ba1));

					//					gps=new GPSTracker(Home_Act.this);
					//					if(GPSTracker.acc1!=0.0)
					//					{
					//						Toast toast = null;
					//						toast=Toast.makeText(Home_Act.this,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 4)",Toast.LENGTH_SHORT);
					//						View view = toast.getView();
					//						toast.setGravity(Gravity.CENTER, 0, 0);
					//						view.setBackgroundResource(R.color.blue);
					//						toast.show();
					//					//Toast.makeText(context,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 3)",2000).show();
					//					}


				}else if(photoNo.equalsIgnoreCase("two"))
				{
					ByteArrayOutputStream out2 = new ByteArrayOutputStream();
					photo = (Bitmap) data.getExtras().get("data"); 
					photo2IV.setImageBitmap(photo);
					photo.compress(Bitmap.CompressFormat.PNG, 100, out2);
					byte[] ba2 = out2.toByteArray();
					CapurePhotos.put("photoTwo",Base64.encode(ba2));


				}

			}
		}
		catch(Exception e)
		{

		}
	}

	//	private String saveToInternalSorage(Bitmap bitmapImage){
	//		ContextWrapper cw = new ContextWrapper(getApplicationContext());
	//		// path to /data/data/yourapp/app_data/imageDir
	//		File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
	//		// Create imageDir
	//
	//		File mypath=new File(Environment.getExternalStorageDirectory(),"profile.jpg");
	//
	//		FileOutputStream fos = null;
	//		try {           
	//
	//			fos = new FileOutputStream(mypath);
	//			System.out.println("------------"+mypath);
	//
	//			// Use the compress method on the BitMap object to write image to the OutputStream
	//			bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
	//			fos.close();
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//		}
	//		return directory.getAbsolutePath();
	//	}

	public void GeneralFarmerDetails()
	{
		try
		{
			((LinearLayout)findViewById(R.id.mainLL)).setVisibility(0);
			Farmer_ID=WebserviceCall.data.get(0).get("Farmer_Id").toString();

			((TextView)findViewById(R.id.hfname)).setText(WebserviceCall.data.get(0).get("FarmerName"));
			((TextView)findViewById(R.id.hfaadhar)).setText(WebserviceCall.data.get(0).get("AADHAARNUMBER"));
			((TextView)findViewById(R.id.hfmobile)).setText(WebserviceCall.data.get(0).get("MobileNumber"));
			((TextView)findViewById(R.id.hfsocial)).setText(WebserviceCall.data.get(0).get("Social_staus"));
			((TextView)findViewById(R.id.hfcategory)).setText(WebserviceCall.data.get(0).get("CATEGORY"));
			((TextView)findViewById(R.id.hfcrop)).setText(WebserviceCall.data.get(0).get("CropName"));
			((TextView)findViewById(R.id.hfarea)).setText(WebserviceCall.data.get(0).get("Area_Proposed"));
			((TextView)findViewById(R.id.hfaddress)).setText(WebserviceCall.data.get(0).get("FarmerAddress"));
			((TextView)findViewById(R.id.hfstatus)).setText(WebserviceCall.data.get(0).get("FARMERSTATUS"));
			Request_Id=WebserviceCall.data.get(0).get("RequestId");
			Status_code=WebserviceCall.data.get(0).get("Status_Code").toString();
		}
		catch(Exception e)
		{

		}
	}
	public void MiFarmerDetails()
	{
		try
		{
			((LinearLayout)findViewById(R.id.mainLL)).setVisibility(0);
			((Button)findViewById(R.id.getDetailBt)).setVisibility(8);
			((TextView)findViewById(R.id.Farmet_IdEt1)).setVisibility(8);
		//	radioButton1.setChecked(false);
		//	radioButton2.setChecked(true);
			Farmer_id.setEnabled(false);
			int maxLength =19;    
			Farmer_id.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maxLength)});
			Farmer_id.setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Farmer_Id"));
			Farmer_ID=Farmer_id.getText().toString();
			((TextView)findViewById(R.id.hfname)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FarmerName"));
			((TextView)findViewById(R.id.hfaadhar)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("AADHAARNUMBER"));
			((TextView)findViewById(R.id.hfmobile)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MobileNumber"));
			((TextView)findViewById(R.id.hfsocial)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Social_staus"));
			((TextView)findViewById(R.id.hfcategory)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("CATEGORY"));
			((TextView)findViewById(R.id.hfcrop)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("CropName"));
			((TextView)findViewById(R.id.hfarea)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Area_Proposed"));
			((TextView)findViewById(R.id.hfaddress)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FarmerAddress"));
			((TextView)findViewById(R.id.hfstatus)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FARMERSTATUS"));
			Request_Id=WebserviceCall.data.get(Get_FormerDetails.rowid).get("RequestId");
			Status_code=WebserviceCall.data.get(Get_FormerDetails.rowid).get("Status_Code");
		}
		catch(Exception e)
		{

		}
	}

	public void getDetails(View v)
	{
		try
		{
			photo1IV.setImageBitmap(null);
			photo2IV.setImageBitmap(null);
			photo1IV.setImageDrawable(getResources().getDrawable(R.drawable.camera_icon));
			photo2IV.setImageDrawable(getResources().getDrawable(R.drawable.camera_icon));
			Headcontrol_LaLg="";
			Trackling_LaLg="";


			((LinearLayout)findViewById(R.id.mainLL)).setVisibility(8);

			((Button)findViewById(R.id.headControlGpsBt)).setEnabled(true);
			((Button)findViewById(R.id.TraclingGpsBt)).setEnabled(true);
			Farmer_ID="HP"+Farmer_id.getText().toString();
			if(Farmer_id.getText().toString().isEmpty())
			{
				((EditText)findViewById(R.id.Farmet_IdEt)).requestFocus();
				((EditText)findViewById(R.id.Farmet_IdEt)).setError("Enter Farmer ID");
			}else {
				if(CheckConnection.isNetworkAvailable(Home_Act.this))
				{
					Loaddata("GetFarmerBasicDetails");
				}else {

					GetDbFarmerDetails();

					if(WebserviceCall.data!=null && WebserviceCall.data.size()>0)
					{
						if(WebserviceCall.data.get(0).get("FARMERSTATUS").toString().equalsIgnoreCase("MI SURVEY FARMER"))
						{
							Intent intent = new Intent(Home_Act.this, MiSurveySystemAct.class);
							intent.putExtra("Srtatus","MI SURVEY FARMER");
							startActivity(intent);
						}else{
							GeneralFarmerDetails();
						}
					}
					else
					{

						Toast toast = null;
						toast=Toast.makeText(Home_Act.this, "Please Enter Valid Farmer ID",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
				}

			}

		}
		catch(Exception e)
		{

		}

	}

	public void GetDbFarmerDetails()
	{
		try
		{
			db.open();
			Cursor cursor=db.getTableDataCursor("select FarmerId,FarmerName,AADHAARNUMBER,MobileNumber,Social_staus,CATEGORY,CropName," +
					"Area_Proposed,FarmerAddress,FARMERSTATUS,Installation_Year,MI_Company_Name,MI_System_Type,Subsidy,RequestId,Status_Code from APMIP_FARMER_DETAILS where FarmerId='"+Farmer_ID+"' and  User_ID='"+Login_Page.UserId+"' and Password='"+Login_Page.PWd+"' and Status_Flag='N' ");
			if (cursor.getCount() > 0) {

				WebserviceCall.data=new ArrayList<HashMap<String,String>>();
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

					WebserviceCall.FarmerId_list=new HashMap<String, String>();
					WebserviceCall.FarmerId_list.put("Farmer_Id",cursor.getString(0));
					WebserviceCall.FarmerId_list.put("FarmerName",cursor.getString(1));
					WebserviceCall.FarmerId_list.put("AADHAARNUMBER",cursor.getString(2));
					WebserviceCall.FarmerId_list.put("MobileNumber",cursor.getString(3));
					WebserviceCall.FarmerId_list.put("Social_staus",cursor.getString(4));
					WebserviceCall.FarmerId_list.put("CATEGORY",cursor.getString(5));
					WebserviceCall.FarmerId_list.put("CropName",cursor.getString(6));
					WebserviceCall.FarmerId_list.put("Area_Proposed",cursor.getString(7));
					WebserviceCall.FarmerId_list.put("FarmerAddress",cursor.getString(8));
					WebserviceCall.FarmerId_list.put("FARMERSTATUS",cursor.getString(9));
					WebserviceCall.FarmerId_list.put("Installation_Year",cursor.getString(10));
					WebserviceCall.FarmerId_list.put("MI_Company_Name",cursor.getString(11));
					WebserviceCall.FarmerId_list.put("MI_System_Type",cursor.getString(10));
					WebserviceCall.FarmerId_list.put("Subsidy",cursor.getString(11));
					WebserviceCall.FarmerId_list.put("RequestId",cursor.getString(12));
					WebserviceCall.FarmerId_list.put("Status_Code",cursor.getString(13));


					WebserviceCall.data.add(WebserviceCall.FarmerId_list);

				}

			}
			else
			{
				WebserviceCall.data=null;
			}

			db.close();
		}
		catch(Exception e)
		{

		}
	}
	public void headControlGps(View v)
	{ 
		try
		{
			gps=new GPSTracker(Home_Act.this);
			((LinearLayout)findViewById(R.id.hla)).setVisibility(0);
			if(GPSTracker.acc1!=0.0)
			{
				Toast toast = null;
				toast=Toast.makeText(Home_Act.this,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 4)",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.blue);
				toast.show();
				//Toast.makeText(context,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 3)",2000).show();
			}
			locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			{
				buildAlertMessageNoGps();
			}  else {
				((TextView)findViewById(R.id.headControlTVLa)).setText("La-"+String.valueOf(gps.getLatitude()));
				((TextView)findViewById(R.id.headControlTVLg)).setText("Lg-"+String.valueOf(gps.getLongitude()));

				Headcontrol_LaLg=String.valueOf(gps.getLatitude())+","+String.valueOf(gps.getLongitude());
			}
		}
		catch(Exception e)
		{

		}
	}
	public void WaterSourceGps(View v)
	{
		try
		{
			gps=new GPSTracker(Home_Act.this);
			((LinearLayout)findViewById(R.id.wla)).setVisibility(0);
			if(GPSTracker.acc1!=0.0)
			{
				Toast toast = null;
				toast=Toast.makeText(Home_Act.this,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 4)",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.blue);
				toast.show();
				//Toast.makeText(context,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 3)",2000).show();
			}

			locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			{
				buildAlertMessageNoGps();
			}  else {
				((TextView)findViewById(R.id.waterSourceTVLa)).setText("La-"+String.valueOf(gps.getLatitude()));
				((TextView)findViewById(R.id.waterSourceTVLg)).setText("Lg-"+String.valueOf(gps.getLongitude()));

				waterSource_LaLg=String.valueOf(gps.getLatitude())+","+String.valueOf(gps.getLongitude());
			}
		}
		catch(Exception e)
		{

		}
	}
	public void traclingGps(View v)
	{ 
		try
		{
			gps=new GPSTracker(Home_Act.this);
			((LinearLayout)findViewById(R.id.tla)).setVisibility(0);
			if(GPSTracker.acc1!=0.0)
			{
				Toast toast = null;
				toast=Toast.makeText(Home_Act.this,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 4)",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.blue);
				toast.show();
				//Toast.makeText(context,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 3)",2000).show();
			}

			locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			{
				buildAlertMessageNoGps();
			}  else {
				((TextView)findViewById(R.id.TraclingTVLa)).setText("La-"+String.valueOf(gps.getLatitude()));
				((TextView)findViewById(R.id.TraclingTVLg)).setText("Lg-"+String.valueOf(gps.getLongitude()));

				Trackling_LaLg=String.valueOf(gps.getLatitude())+","+String.valueOf(gps.getLongitude());
			}
		}
		catch(Exception e)
		{

		}

	}

	public void AlertDialog(String Message)
	{
		new android.app.AlertDialog.Builder(this)
		.setTitle("Horticulture")
		.setMessage(Message)
		.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which)
			{ 
				Farmer_id.setText("");
				((LinearLayout)findViewById(R.id.mainLL)).setVisibility(8);
			}
		})

		.setIcon(android.R.drawable.ic_dialog_alert).show();
	}



	//	private void addOffenceRemarks1()
	//	{
	//
	//
	//		//int rowid=100+OffenceReTableMap.size();
	//		//OffenceReTableMap.put(Integer.toString(cb.getId()), Integer.toString(rowid));
	//		TableRow Rw=new TableRow(this);
	//		//Rw.setId(rowid);
	//		TableLayout.LayoutParams layoutParams1=new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
	//		layoutParams1.setMargins(2, 1, 2, 1);
	//		Rw.setLayoutParams(layoutParams1);
	//
	//
	//		TableRow.LayoutParams column1=new TableRow.LayoutParams(0,LayoutParams.FILL_PARENT);
	//		column1.leftMargin=10;
	//		final ImageButton tv=new ImageButton(this);
	//		//tv.setText(cb.getText().toString());
	//
	//		tv.setBackgroundResource(R.drawable.camera_icon);
	//		//tv.setTypeface(null, Typeface.BOLD);
	//		//tv.setLayoutParams(column1);
	//		Rw.addView(tv);
	//
	//
	//		//		TableRow.LayoutParams column2=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
	//		//		column2.leftMargin=2;
	//		//		column2.weight=70;
	//		//		final EditText VehicleNumberEt=new EditText(this);
	//		//		VehicleNumberEt.setBackgroundResource(R.drawable.rounded_corner_et);
	//		//		VehicleNumberEt.setTextColor(Color.BLACK);
	//		//		VehicleNumberEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
	//		//		VehicleNumberEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
	//		//		VehicleNumberEt.setLayoutParams(column2);
	//		//		Rw.addView(VehicleNumberEt);
	//		//
	//		//		TableRow.LayoutParams column3=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
	//		//		column3.leftMargin=2;
	//		//		column3.weight=40;
	//		//		final EditText OwnerNameEt=new EditText(this);
	//		//		OwnerNameEt.setBackgroundResource(R.drawable.rounded_corner_et);
	//		//		OwnerNameEt.setTextColor(Color.BLACK); 
	//		//
	//		//		//OwnerNameEt.setFilters(new InputFilter[]{ new InputFilterMinMax(min, max)});
	//		//		OwnerNameEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
	//		//		OwnerNameEt.setInputType(InputType.TYPE_CLASS_NUMBER);
	//		//		OwnerNameEt.setLayoutParams(column3);
	//		//		Rw.addView(OwnerNameEt);
	//		//
	//		//		TableRow.LayoutParams column4=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
	//		//		column4.leftMargin=2;
	//		//		column4.weight=20;
	//		//		final Button addBtn=new Button(this);
	//		//		addBtn.setText("Add");
	//		//		addBtn.setLayoutParams(column4);
	//		//		Rw.addView(addBtn);
	//
	//
	//	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home_, menu);
		MenuItem item=menu.findItem(R.id.UserManual);
		item.setVisible(false);

		MenuItem item1=menu.findItem(R.id.Download_OffLine_Data);
		item1.setVisible(false);
		
		MenuItem item2=menu.findItem(R.id.main);
		item2.setVisible(false);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int id = item.getItemId();
		//				if (id == R.id.Upload_OffLine_Data) 
		//				{
		//					
		//					return true;
		//				}
		//		if (id == R.id.getData) 
		//		{
		//			startActivity(new Intent(Home_Act.this, Get_FormerDetails.class));
		//			return true;
		//		}
		if (id == R.id.logout) 
		{
			LogoutAlert("Are you sure you want to Logout","logout");

		}
//		if(id==android.R.id.home)
//		{
//			   super.onBackPressed();
//		        return true;
//		}
		if (id == R.id.Upload_OffLine_Data) 
		{
			if(Integer.parseInt(pendingCount) > 0 && CheckConnection.isNetworkAvailable(Home_Act.this))
			{
				Loaddata("UploadInserGPSCoordinates");
			}
			else
			{
				if(Integer.parseInt(pendingCount)==0)
				{
					Toast toast = null;
					toast=Toast.makeText(Home_Act.this, "No Data To Upload",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				else
				{
					boolean a=	CheckConnection.isNetworkAvailable(Home_Act.this);
					if(a==false)
					{
						Toast toast = null;
						toast=Toast.makeText(Home_Act.this, "Check Internet Connection",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
				}

			}
		}
		return super.onOptionsItemSelected(item);
	}

	private void buildAlertMessageNoGps()
	{

		AlertDialog(context, "Your GPS seems to be disabled,Please enable it?","GPS Disable");

		//		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		//		builder.setMessage("Your GPS seems to be disabled,Please enable it?");
		//		builder.setTitle("Information!!");
		//		builder.setCancelable(false);
		//		builder.setPositiveButton("Ok",new DialogInterface.OnClickListener()
		//		{
		//			public void onClick(final DialogInterface dialog,final int id)
		//			{
		//				launchGPSOptions();
		//			}
		//		});
		//		builder.show();
	}
	public void CheckNetworkStaus()
	{
		try
		{
			if(CheckConnection.isNetworkAvailable(Home_Act.this))
			{
				Loaddata("InserGPSCoordinates");
			}else {
				ContentValues cv=new ContentValues();
				cv.put("RequestId",Request_Id );cv.put("FarmerFieldPhoto1",CapurePhotos.get("photoOne") );cv.put("FarmerFieldPhoto2",CapurePhotos.get("photoTwo") );
				cv.put("WaterSource_GPS_Coordinates",waterSource_LaLg );cv.put("HeadControlUnit_GPS_Coordinates",Headcontrol_LaLg );
				cv.put("TrackingOfTheField_GPS_Coordinates",Trackling_LaLg );cv.put("Status_Flag","P" );

				db.open();
				boolean staus=db.updateTableData("APMIP_FARMER_DETAILS", cv, "Status_Flag='N' and FarmerId='"+Farmer_ID+"' and User_ID='"+Login_Page.UserId+"'");
				db.close();
				if(staus==true)
				{
					AlertDialog(context, "Successfully Submitted","Submitted");
					resetALL();
					refreshPendingCount();
				}
				else
				{
					Toast toast = null;
					toast=Toast.makeText(Home_Act.this, "Please Download Offline Data",Toast.LENGTH_LONG);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}

			}
		}
		catch(Exception e)
		{

		}
	}

	public void LogoutAlert(String msg1,final String diatype)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Horticulture");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) {

				if(diatype.equalsIgnoreCase("logout")){
					Intent i=new Intent(Home_Act.this,Login_Page.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					//finish();
				}else if(diatype.equalsIgnoreCase("proceed"))
				{
					CheckNetworkStaus();
					//Loaddata("InserGPSCoordinates");
				}
				dialog.cancel();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	private void launchGPSOptions() 
	{
		try
		{

			Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
			startActivity(intent);
		}
		catch(Exception e)
		{

		}
		//		final ComponentName toLaunch = new ComponentName(
		//				"com.android.settings", "com.android.settings.SecuritySettings");
		//		final Intent intent = new Intent(
		//				Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		//		intent.addCategory(Intent.CATEGORY_LAUNCHER);
		//		intent.setComponent(toLaunch);
		//		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

	} 

	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		//dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);	  
		//Animation shake = AnimationUtils.loadAnimation(context, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		//yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				if(DialogType.equalsIgnoreCase("GPS Disable"))
				{
					launchGPSOptions();
					dialog.cancel();
				}else if (DialogType.equalsIgnoreCase("FidStatus") || DialogType.equalsIgnoreCase("Take Photo") || DialogType.equalsIgnoreCase("Gps Coordinates") ||DialogType.equalsIgnoreCase("Submitted") ) {
					WebserviceCall.FidStatus="";
					dialog.dismiss();
				}
				//				else if (DialogType.equalsIgnoreCase("Gps Coordinates")) {
				//					dialog.dismiss();
				//				}else if(DialogType.equalsIgnoreCase("Submitted")){
				//					dialog.dismiss();
				//				}


				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}
	public void refreshPendingCount()
	{
		try
		{
			db.open();
			pendingCount=db.getSingleValue("select DISTINCT Count(FarmerId) from APMIP_FARMER_DETAILS where Status_Flag='P' and User_ID='"+Login_Page.UserId+"'");
			pendingCountEt.setText("Pending Upload To Online Count : "+pendingCount);
			db.close();
		}
		catch(Exception e)
		{

		}
	}
	public void onBackPressed()
	{
		 super.onBackPressed();
	        return ;	
		
	}

	

	
	   
}