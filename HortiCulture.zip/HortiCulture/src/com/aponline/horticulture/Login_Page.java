package com.aponline.horticulture;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import com.aponline.Hc.Adapter.ReportAdapter;
import com.aponline.Hc.Adapter.ReportAdapteroffline;
import com.aponline.Hc.database.DBAdapter;
import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.WebserviceCall;





import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

@SuppressLint("NewApi")
public class Login_Page extends AppCompatActivity
{
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	DBAdapter db;
	Context context;
	RelativeLayout loginRl,reportRl;
	LinearLayout sellingrlist1;
	ListView HcReportLV;
	ReportAdapter reportAdapter;
	ReportAdapteroffline reportAdapter1;
	private ProgressDialog pDialog;
	public static final int progress_bar_type = 0; 
	Spinner districtSp,mandalSp,panchayatSp,villageSp,habitationSp;
	public static String Dist_id,Mandal_id,Panchayat_id,Viialge_id,Habitation_id,UserId,PWd;
	ActionBar ab;
	Button login_submit;
	TextView versiontv;
	List<String> mandallist,villagelist,paanchayatList;
	private static String file_url = "http://125.17.121.170/Horticulture1/Usermanual.aspx";
	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;


	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case progress_bar_type:
			pDialog = new ProgressDialog(this);
			pDialog.setMessage("Downloading. Please wait...");
			pDialog.setIndeterminate(false);
			pDialog.setMax(100);
			pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			pDialog.setCancelable(true);
			pDialog.show();
			return pDialog;
		default:
			return null;
		}

	}
	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(Login_Page.this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();

				if(paramMessage.what==24)
				{
					((LinearLayout)findViewById(R.id.reportlist)).setVisibility(0);
					reportAdapter=new ReportAdapter(Login_Page.this, WebserviceCall.report);
					HcReportLV.setAdapter(reportAdapter);
				}

				if(paramMessage.what==22)
				{
					if((WebserviceCall.Login_Details.get("STATUS")).equalsIgnoreCase("TRUE"))
					{
						try
						{
							db.open();
							int i=	db.getRowCount("select Count(User_ID) from APMIP_FARMER_DETAILS where User_ID='"+Login_Page.UserId+"' and Password='"+Login_Page.PWd+"' ");
							if(i==0)
							{
								db.execSQL("Insert into APMIP_FARMER_DETAILS (User_ID,Password,User_ROLE_ID,User_DistrictId)  values('"+Login_Page.UserId+"','"+Login_Page.PWd+"','"+WebserviceCall.Login_Details.get("ROLE_ID")+"','"+WebserviceCall.Login_Details.get("DistrictId")+"')");
								db.exportDB();
							}
							db.close();

							Loaddata("GetMICompaniesList");
						}
						catch(Exception e)
						{

						}
						startActivity(new Intent(Login_Page.this,Home_Act1.class));

					}else {
						Toast toast = null;
						toast=Toast.makeText(Login_Page.this, "Invalid user / Password",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.BOTTOM, 0, 200);
						view.setBackgroundResource(R.color.red);
						toast.show();

					}

				}

				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast.makeText(Login_Page.this, "No New Data",Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Login_Page.this,"Please Try Again",Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Login_Page.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Login_Page.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_page);


		this.ab=getSupportActionBar();
		ab.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.menu_bg));
		ab.setTitle("APMIP");
		View mActionBarView = getLayoutInflater().inflate(R.layout.icon, null);
		ab.setCustomView(mActionBarView);
		ab.setDisplayOptions(ab.DISPLAY_SHOW_CUSTOM);
		//ab.setHomeButtonEnabled(true);
		//ab.setDisplayHomeAsUpEnabled(true);
		login_submit=(Button)findViewById(R.id.login_page_btn);
		versiontv=(TextView)findViewById(R.id.versiontv);
		
		context=this;
		DBAdapter.DATABASE_NAME="APMIP3.db";
		db=new DBAdapter(this);

		if (Build.VERSION.SDK_INT >= 23)
		{
			requestPermissions();
		}
		else
		{
		try 
		{
			db.createDataBase();
			db.open();
			db.createNewTable();

			db.close();
			

		} 
		catch (IOException e) 		{
			e.printStackTrace();
			//db.close();
		}
		//	db.close();


		PackageManager localPackageManager = getApplicationContext().getPackageManager();
		try {
			versiontv.setText("Version "+localPackageManager.getPackageInfo(getApplicationContext().getPackageName(), 128).versionName+"  ");
		} catch (NameNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		loginRl=(RelativeLayout) findViewById(R.id.loginRl);
		reportRl=(RelativeLayout) findViewById(R.id.reportRL);
		districtSp=(Spinner) findViewById(R.id.districtSP);
		mandalSp=(Spinner) findViewById(R.id.mandalSP);
		panchayatSp=(Spinner) findViewById(R.id.panchayayatSP);
		villageSp=(Spinner) findViewById(R.id.villageSP);

		HcReportLV=(ListView) findViewById(R.id.HcReport);

		((LinearLayout)findViewById(R.id.loginBlockLL)).setVisibility(0);

		loginRl.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {


				((EditText)findViewById(R.id.userid_et)).setText("");
				((EditText)findViewById(R.id.password_et)).setText("");
				((EditText)findViewById(R.id.userid_et)).setError(null);
				((EditText)findViewById(R.id.password_et)).setError(null);

				((LinearLayout)findViewById(R.id.loginLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.reportLL)).setVisibility(4);

				((LinearLayout)findViewById(R.id.loginBlockLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.main2)).setVisibility(8);


			}
		});

		reportRl.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {


				((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);

				mandallist=new ArrayList<String>();
				paanchayatList=new ArrayList<String>();
				villagelist=new ArrayList<String>();

				db.open();
				List<String> distlist=new ArrayList<String>();
				distlist=db.getSpinnerData("select DISTRICT_NAME from DISTRICT_MASTER  order by DISTRICT_NAME");
				db.close();

				ArrayAdapter<String> distAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,distlist);
				distAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				districtSp.setAdapter(distAdapter);

				((LinearLayout)findViewById(R.id.loginLL)).setVisibility(4);
				((LinearLayout)findViewById(R.id.reportLL)).setVisibility(0);

				((LinearLayout)findViewById(R.id.loginBlockLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.main2)).setVisibility(0);

				mandalSp.setAdapter(null);
				panchayatSp.setAdapter(null);
				villageSp.setAdapter(null);
				//sellingrlist1.setVisibility(8);

			}
		});



		HcReportLV.setOnItemClickListener(new OnItemClickListener() 
		{
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				TextView gpsTv=(TextView)arg1.findViewById(R.id.rgps);
				String GpsCo=gpsTv.getText().toString();

				//				GpsCo="geo:0,0?q="+"+GpsCo+"+"(label)";
				//				
				//				geo:0,0?q="+"+GpsCo+"+"(label)
				//				System.out.println("---------gg--"+GpsCo);

				Uri gmmIntentUri = Uri.parse("geo:0,0?q="+GpsCo+"(label)");
				Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
				mapIntent.setPackage("com.google.android.apps.maps");
				startActivity(mapIntent);



			}
		});

		//		HcReportLV.setOnClickListener(new OnClickListener() {
		//
		//			@Override
		//			public void onClick(View v) {
		//				Uri gmmIntentUri = Uri.parse("geo:0,0?q=17.4587791,78.3679943(label)");
		//				Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
		//				mapIntent.setPackage("com.google.android.apps.maps");
		//				startActivity(mapIntent);
		//
		//			}
		//		});



		districtSp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
			{

				((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
				if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
				{
					panchayatSp.setAdapter(null);
					villageSp.setAdapter(null);

					db.open();
					Dist_id=db.getSingleValue("select DISTRICT_ID from DISTRICT_MASTER  where DISTRICT_NAME='"+districtSp.getSelectedItem().toString()+"'");
					db.close();
					if(Dist_id.length()==1)
					{
						//						char temp=Dist_id.charAt(0);
						//						if(temp=='0')
						//						{
						//							HDist_id=HDist_id.substring(1, 2);
						//						}
						Dist_id="0"+Dist_id;
					}
					db.open();
					//List<String> mandallist=new ArrayList<String>();
					mandallist=db.getSpinnerData("select MANDAL_NAME from MANDAL_MASTER  where DISTRICT_ID='"+Dist_id+"' order by MANDAL_NAME");
					db.close();

					ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,mandallist);
					dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
					mandalSp.setAdapter(dataAdapter);

				}else {
					mandalSp.setAdapter(null);
					panchayatSp.setAdapter(null);
					villageSp.setAdapter(null);
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {


			}
		});

		mandalSp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3)
			{

				db.open();
				((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
				//reg_mandal=mandalSp.getSelectedItem().toString();
				if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
				{

					villageSp.setAdapter(null);
					//					if(Dist_id.length()==2)
					//					{
					//						Dist_id=Dist_id.substring(1,2);
					//					}

					db.open();
					Mandal_id=db.getSingleValue("select MANDAL_ID from MANDAL_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_NAME='"+mandalSp.getSelectedItem().toString()+"'");
					db.close();

					db.open();
					//List<String> paanchayatList=new ArrayList<String>();
					paanchayatList=db.getSpinnerData("select PANCHAYAT_NAME from PANCHAYAT_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"'   order by PANCHAYAT_NAME");
					db.close();

					ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,paanchayatList);
					dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
					panchayatSp.setAdapter(dataAdapter);

				}else {

					panchayatSp.setAdapter(null);
					villageSp.setAdapter(null);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {


			}
		});

		panchayatSp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {

				db.open();

				//reg_mandal=mandalSp.getSelectedItem().toString();
				((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
				if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
				{
					//					if(Dist_id.length()==2)
					//					{
					//						Dist_id=Dist_id.substring(1,2);
					//					}
					db.open();
					Panchayat_id=db.getSingleValue("select PANCHAYAT_ID from PANCHAYAT_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"' and PANCHAYAT_NAME='"+panchayatSp.getSelectedItem().toString()+"'");
					db.close();

					db.open();
					//List<String> villagelist=new ArrayList<String>();
					villagelist=db.getSpinnerData("select VILLAGE_NAME from VILLAGE_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"' and PANCHAYAT_ID='"+Panchayat_id+"'  order by VILLAGE_NAME");
					db.close();

					ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,villagelist);
					dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
					villageSp.setAdapter(dataAdapter);

				}else {

					villageSp.setAdapter(null);

				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {


			}
		});

		villageSp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
				if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
				{
					//					if(Dist_id.length()==2)
					//					{
					//						Dist_id=Dist_id.substring(1,2);
					//					}
					db.open();
					Viialge_id=db.getSingleValue("select VILLAGE_ID from VILLAGE_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"' and PANCHAYAT_ID='"+Panchayat_id+"' and VILLAGE_NAME='"+villageSp.getSelectedItem().toString()+"'");
					db.close();
					if(CheckConnection.isNetworkAvailable(Login_Page.this))
					{
						((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
						Loaddata("GPSCoordinatesReport");
					}
					else
					{
						oflineReport();
					}


				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});
		login_submit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				try
				{
					UserId=((EditText)findViewById(R.id.userid_et)).getText().toString();
					PWd=((EditText)findViewById(R.id.password_et)).getText().toString();

					if(UserId.isEmpty())
					{
						((EditText)findViewById(R.id.userid_et)).requestFocus();
						((EditText)findViewById(R.id.userid_et)).setError("Enter UserName");

						return;
					}else if (PWd.isEmpty()) 
					{
						((EditText)findViewById(R.id.password_et)).requestFocus();
						((EditText)findViewById(R.id.password_et)).setError("Enter Password");

						return;
					}else {

						if(CheckConnection.isNetworkAvailable(Login_Page.this))
						{
							Loaddata("CheckUserAuthentication");
						}else {

							db.open();
							Cursor cursor=db.getTableDataCursor("select DISTINCT User_ID,User_DistrictId,User_ROLE_ID from APMIP_FARMER_DETAILS where User_ID='"+UserId+"' and Password='"+PWd+"'");
							if (cursor.getCount() > 0) {
								WebserviceCall.Login_Details=new HashMap<String, String>();
								for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

									WebserviceCall.Login_Details.put("User_ID", cursor.getString(0).trim());
									WebserviceCall.Login_Details.put("DistrictId", cursor.getString(1));
									WebserviceCall.Login_Details.put("ROLE_ID", cursor.getString(2));
								}
								startActivity(new Intent(Login_Page.this,Home_Act1.class));
							}
							else {
								Toast toast = null;
								toast=Toast.makeText(Login_Page.this, "Invalid user / Password",Toast.LENGTH_SHORT);
								View view = toast.getView();
								toast.setGravity(Gravity.BOTTOM, 0, 200);
								view.setBackgroundResource(R.color.red);
								toast.show();
							}

							db.close();

							//				if(WebserviceCall.Login_Details.get("User_ID").equalsIgnoreCase(UserId))
							//				{
							//					startActivity(new Intent(Login_Page.this,Home_Act.class));
							//				}else {
							//					Toast toast = null;
							//					toast=Toast.makeText(Login_Page.this, "Invalid user / Password",Toast.LENGTH_SHORT);
							//					View view = toast.getView();
							//					toast.setGravity(Gravity.BOTTOM, 0, 200);
							//					view.setBackgroundResource(R.color.red);
							//					toast.show();
							//				}
						}

					}
				}
				catch(Exception e)
				{

				}
				
			}
		});
		
		}
	}



	public void DownloadAlert(String msg1)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(Login_Page.this);
		builder1.setCancelable(false);
		builder1.setTitle("Horticulture");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) {

				new DownloadFile().execute();
				dialog.cancel();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	public void login(View v)
	{
		try
		{
			UserId=((EditText)findViewById(R.id.userid_et)).getText().toString();
			PWd=((EditText)findViewById(R.id.password_et)).getText().toString();

			if(UserId.isEmpty())
			{
				((EditText)findViewById(R.id.userid_et)).requestFocus();
				((EditText)findViewById(R.id.userid_et)).setError("Enter UserName");

				return;
			}else if (PWd.isEmpty()) 
			{
				((EditText)findViewById(R.id.password_et)).requestFocus();
				((EditText)findViewById(R.id.password_et)).setError("Enter Password");

				return;
			}else {

				if(CheckConnection.isNetworkAvailable(Login_Page.this))
				{
					Loaddata("CheckUserAuthentication");
				}else {

					db.open();
					Cursor cursor=db.getTableDataCursor("select DISTINCT User_ID,User_DistrictId,User_ROLE_ID from APMIP_FARMER_DETAILS where User_ID='"+UserId+"' and Password='"+PWd+"'");
					if (cursor.getCount() > 0) {
						WebserviceCall.Login_Details=new HashMap<String, String>();
						for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

							WebserviceCall.Login_Details.put("User_ID", cursor.getString(0).trim());
							WebserviceCall.Login_Details.put("DistrictId", cursor.getString(1));
							WebserviceCall.Login_Details.put("ROLE_ID", cursor.getString(2));
						}
						startActivity(new Intent(Login_Page.this,Home_Act1.class));
					}
					else {
						Toast toast = null;
						toast=Toast.makeText(Login_Page.this, "Invalid user / Password",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.BOTTOM, 0, 200);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}

					db.close();

				
				}

			}
		}
		catch(Exception e)
		{

		}
		//startActivity(new Intent(Login_Page.this,Home_Act.class));
	}

	



	class DownloadFile extends AsyncTask<String,Integer,Void>{  
		NotificationManager mNotifyManager;
		NotificationCompat.Builder mBuilder;   		
		protected void onPreExecute(){
			super.onPreExecute(); 
			String storeDir=Environment.getExternalStorageDirectory().toString();
			String	pathl=storeDir+"/"+"APMIP.pdf";
			mNotifyManager =(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
			mBuilder = new NotificationCompat.Builder(context);
			Intent intent = new Intent();
			intent.setAction(android.content.Intent.ACTION_VIEW);
			File file = new File(pathl);  
			intent.setDataAndType(Uri.fromFile(file), "application/pdf");
			PendingIntent pIntent = PendingIntent.getActivity(getApplicationContext(), 0,intent, 0);
			mBuilder.setContentTitle("File Download")
			.setContentText("Download in progress")
			.setSmallIcon(R.drawable.hc_icon_notification)
			.setContentIntent(pIntent);
			Toast.makeText(context, "Downloading the file... The download progress is on notification bar.", Toast.LENGTH_LONG).show();

		}

		protected Void doInBackground(String...params){  
			URL url;
			int count;

			String storeDir=Environment.getExternalStorageDirectory().toString();
			try {
				url = new URL(file_url);					
				String pathl="";
				try {
					
					File f=new File(storeDir);
					if(f.exists()){
						HttpURLConnection con=(HttpURLConnection)url.openConnection();
						InputStream is=con.getInputStream();
						String pathr=url.getPath();
						//String filename=pathr.substring(pathr.lastIndexOf('/')+1);
						pathl=storeDir+"/"+"APMIP.pdf";
						FileOutputStream fos=new FileOutputStream(pathl);    			   
						int lenghtOfFile = con.getContentLength();
						byte data[] = new byte[1024];	   			 
						long total = 0;	
						while ((count = is.read(data)) != -1) {
							total += count;
							// publishing the progress
							publishProgress((int)((total*100)/lenghtOfFile));   
							// writing data to output file
							fos.write(data, 0, count);
						}

						is.close();
						fos.flush();
						fos.close();
					}
					else{
						Log.e("Error","Not found: "+storeDir);

					}

				} catch (Exception e) {
					e.printStackTrace();

				}			

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;

		}     
		//9502162616
		protected void onProgressUpdate(Integer... progress) {

			mBuilder.setProgress(100, progress[0], false);
			// Displays the progress bar on notification
			mNotifyManager.notify(0, mBuilder.build());
		}

		protected void onPostExecute(Void result){
			mBuilder.setContentText("Download complete");
			// Removes the progress bar
			mBuilder.setProgress(0,0,false);
			mNotifyManager.notify(0, mBuilder.build());

		}     

	}


	

	public void oflineReport()
	{
		try
		{
			db.open();
			if(Dist_id.length()==1)
			{
				Dist_id="0"+Dist_id;
			}
			//		if(Mandal_id.length()==1)
			//		{
			//			Mandal_id="0"+Mandal_id;
			//		}
			//		if(Panchayat_id.length()==1)
			//		{
			//			Panchayat_id="0"+Panchayat_id;
			//		}
			if(Viialge_id.length()==1)
			{
				Viialge_id="00"+Viialge_id;
			}
			if(Viialge_id.length()==2)
			{
				Viialge_id="0"+Viialge_id;
			}
			Cursor cursor=db.getTableDataCursor("select Distinct FarmerId,FarmerName,Survey_No,CropName,MobileNumber,FARMERSTATUS,WaterSource_GPS_Coordinates from  APMIP_FARMER_DETAILS  where  District_id='"+Dist_id+"' and Mandal_id='"+Mandal_id+"' and Panchayat_Code='"+Panchayat_id+"' and Village_Code='"+Viialge_id+"' and Status_Flag='Y'");

			if (cursor.getCount() > 0) 
			{
				WebserviceCall.report=new  ArrayList<HashMap<String, String>>();

				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
					HashMap<String,String> local=new HashMap<String,String>();

					local.put("Farmer_Id",cursor.getString(0));
					local.put("FarmerName",cursor.getString(1));
					local.put("Survey_No",cursor.getString(2));
					local.put("CropName",cursor.getString(3));
					local.put("MobileNumber",cursor.getString(4));
					local.put("FARMERSTATUS",cursor.getString(5));
					local.put("GPSWATERSOURCE",cursor.getString(6));
					WebserviceCall.report.add(local);
				}
				((LinearLayout)findViewById(R.id.reportlist)).setVisibility(0);
				reportAdapter1=new ReportAdapteroffline(Login_Page.this, WebserviceCall.report);
				HcReportLV.setAdapter(reportAdapter1);
			}
			else
			{
				Toast.makeText(Login_Page.this, "No New Data",Toast.LENGTH_LONG).show();
			}
			db.close();
		}
		catch(Exception e)
		{
			db.close();
			Toast.makeText(Login_Page.this, "No New Data",Toast.LENGTH_LONG).show();
		}
	}
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_manual, menu);
		//		MenuItem item=menu.findItem(R.id.logout);
		//		item.setVisible(false);
		//
		//		MenuItem item1=menu.findItem(R.id.Download_OffLine_Data);
		//		item1.setVisible(false);
		//		MenuItem item2=menu.findItem(R.id.Upload_OffLine_Data);
		//		item2.setVisible(false);		
		//		MenuItem item3=menu.findItem(R.id.u);
		//		item3.setVisible(false);



		//		MenuItem item4=menu.findItem(R.id.VMasterData);
		//		item4.setVisible(false);
		//		MenuItem item5=menu.findItem(R.id.MMasterData);
		//		item5.setVisible(false);
		//		MenuItem item6=menu.findItem(R.id.PMasterData);
		//		item6.setVisible(false);
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();

		if(id== R.id.UserManual1)
		{
			if(CheckConnection.isNetworkAvailable(context))
			{
				DownloadAlert("Are you sure you want to Download UserManual file");
			}
			else
			{
				Toast toast = null;
				toast=Toast.makeText(Login_Page.this, "Check Internet Connection",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 200);
				view.setBackgroundResource(R.color.red);
				toast.show();
			}
			
		}

		return super.onOptionsItemSelected(item);
	}
	
	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("Write enternal Contacts");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("camera");

		if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
			permissionsNeeded.add("Access Fine Location");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
			permissionsNeeded.add("Access Coarse Location");


		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				// Need Rationale
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				try
				{

					ActivityCompat.requestPermissions(Login_Page.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
					return;

				} catch (Resources.NotFoundException e) {
					e.printStackTrace();
				}

				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}
		
	}


	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}
		return true;
	}

	@Override
	public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){

		switch (permsRequestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			// Initial
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.GET_ACCOUNTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);

			// Fill with results
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			// Check for ACCESS_FINE_LOCATION
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
			{
				try 
				{
					db.createDataBase();
					db.open();
					db.createNewTable();

					db.close();
					

				} 
				catch (IOException e) 		{
					e.printStackTrace();
					//db.close();
				}
				//	db.close();
				PackageManager localPackageManager = getApplicationContext().getPackageManager();
try {
	versiontv.setText("Version "+localPackageManager.getPackageInfo(getApplicationContext().getPackageName(), 128).versionName+"  ");
} catch (NameNotFoundException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}

				loginRl=(RelativeLayout) findViewById(R.id.loginRl);
				reportRl=(RelativeLayout) findViewById(R.id.reportRL);
				districtSp=(Spinner) findViewById(R.id.districtSP);
				mandalSp=(Spinner) findViewById(R.id.mandalSP);
				panchayatSp=(Spinner) findViewById(R.id.panchayayatSP);
				villageSp=(Spinner) findViewById(R.id.villageSP);

				HcReportLV=(ListView) findViewById(R.id.HcReport);

				((LinearLayout)findViewById(R.id.loginBlockLL)).setVisibility(0);

				loginRl.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {


						((EditText)findViewById(R.id.userid_et)).setText("");
						((EditText)findViewById(R.id.password_et)).setText("");
						((EditText)findViewById(R.id.userid_et)).setError(null);
						((EditText)findViewById(R.id.password_et)).setError(null);

						((LinearLayout)findViewById(R.id.loginLL)).setVisibility(0);
						((LinearLayout)findViewById(R.id.reportLL)).setVisibility(4);

						((LinearLayout)findViewById(R.id.loginBlockLL)).setVisibility(0);
						((LinearLayout)findViewById(R.id.main2)).setVisibility(8);


					}
				});

				reportRl.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {


						((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);

						mandallist=new ArrayList<String>();
						paanchayatList=new ArrayList<String>();
						villagelist=new ArrayList<String>();

						db.open();
						List<String> distlist=new ArrayList<String>();
						distlist=db.getSpinnerData("select DISTRICT_NAME from DISTRICT_MASTER  order by DISTRICT_NAME");
						db.close();

						ArrayAdapter<String> distAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,distlist);
						distAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
						districtSp.setAdapter(distAdapter);

						((LinearLayout)findViewById(R.id.loginLL)).setVisibility(4);
						((LinearLayout)findViewById(R.id.reportLL)).setVisibility(0);

						((LinearLayout)findViewById(R.id.loginBlockLL)).setVisibility(8);
						((LinearLayout)findViewById(R.id.main2)).setVisibility(0);

						mandalSp.setAdapter(null);
						panchayatSp.setAdapter(null);
						villageSp.setAdapter(null);
						//sellingrlist1.setVisibility(8);

					}
				});



				HcReportLV.setOnItemClickListener(new OnItemClickListener() 
				{
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
							long arg3) {
						TextView gpsTv=(TextView)arg1.findViewById(R.id.rgps);
						String GpsCo=gpsTv.getText().toString();

						//				GpsCo="geo:0,0?q="+"+GpsCo+"+"(label)";
						//				
						//				geo:0,0?q="+"+GpsCo+"+"(label)
						//				System.out.println("---------gg--"+GpsCo);

						Uri gmmIntentUri = Uri.parse("geo:0,0?q="+GpsCo+"(label)");
						Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
						mapIntent.setPackage("com.google.android.apps.maps");
						startActivity(mapIntent);



					}
				});

				//		HcReportLV.setOnClickListener(new OnClickListener() {
				//
				//			@Override
				//			public void onClick(View v) {
				//				Uri gmmIntentUri = Uri.parse("geo:0,0?q=17.4587791,78.3679943(label)");
				//				Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
				//				mapIntent.setPackage("com.google.android.apps.maps");
				//				startActivity(mapIntent);
				//
				//			}
				//		});



				districtSp.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
					{

						((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
						if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
						{
							panchayatSp.setAdapter(null);
							villageSp.setAdapter(null);

							db.open();
							Dist_id=db.getSingleValue("select DISTRICT_ID from DISTRICT_MASTER  where DISTRICT_NAME='"+districtSp.getSelectedItem().toString()+"'");
							db.close();
							if(Dist_id.length()==1)
							{
								//						char temp=Dist_id.charAt(0);
								//						if(temp=='0')
								//						{
								//							HDist_id=HDist_id.substring(1, 2);
								//						}
								Dist_id="0"+Dist_id;
							}
							db.open();
							//List<String> mandallist=new ArrayList<String>();
							mandallist=db.getSpinnerData("select MANDAL_NAME from MANDAL_MASTER  where DISTRICT_ID='"+Dist_id+"' order by MANDAL_NAME");
							db.close();

							ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,mandallist);
							dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
							mandalSp.setAdapter(dataAdapter);

						}else {
							mandalSp.setAdapter(null);
							panchayatSp.setAdapter(null);
							villageSp.setAdapter(null);
						}

					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {


					}
				});

				mandalSp.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3)
					{

						db.open();
						((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
						//reg_mandal=mandalSp.getSelectedItem().toString();
						if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
						{

							villageSp.setAdapter(null);
							//					if(Dist_id.length()==2)
							//					{
							//						Dist_id=Dist_id.substring(1,2);
							//					}

							db.open();
							Mandal_id=db.getSingleValue("select MANDAL_ID from MANDAL_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_NAME='"+mandalSp.getSelectedItem().toString()+"'");
							db.close();

							db.open();
							//List<String> paanchayatList=new ArrayList<String>();
							paanchayatList=db.getSpinnerData("select PANCHAYAT_NAME from PANCHAYAT_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"'   order by PANCHAYAT_NAME");
							db.close();

							ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,paanchayatList);
							dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
							panchayatSp.setAdapter(dataAdapter);

						}else {

							panchayatSp.setAdapter(null);
							villageSp.setAdapter(null);
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {


					}
				});

				panchayatSp.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						db.open();

						//reg_mandal=mandalSp.getSelectedItem().toString();
						((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
						if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
						{
							//					if(Dist_id.length()==2)
							//					{
							//						Dist_id=Dist_id.substring(1,2);
							//					}
							db.open();
							Panchayat_id=db.getSingleValue("select PANCHAYAT_ID from PANCHAYAT_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"' and PANCHAYAT_NAME='"+panchayatSp.getSelectedItem().toString()+"'");
							db.close();

							db.open();
							//List<String> villagelist=new ArrayList<String>();
							villagelist=db.getSpinnerData("select VILLAGE_NAME from VILLAGE_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"' and PANCHAYAT_ID='"+Panchayat_id+"'  order by VILLAGE_NAME");
							db.close();

							ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Login_Page.this,android.R.layout.simple_spinner_item,villagelist);
							dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
							villageSp.setAdapter(dataAdapter);

						}else {

							villageSp.setAdapter(null);

						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {


					}
				});

				villageSp.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
						if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
						{
							//					if(Dist_id.length()==2)
							//					{
							//						Dist_id=Dist_id.substring(1,2);
							//					}
							db.open();
							Viialge_id=db.getSingleValue("select VILLAGE_ID from VILLAGE_MASTER  where DISTRICT_ID='"+Dist_id+"' and MANDAL_ID='"+Mandal_id+"' and PANCHAYAT_ID='"+Panchayat_id+"' and VILLAGE_NAME='"+villageSp.getSelectedItem().toString()+"'");
							db.close();
							if(CheckConnection.isNetworkAvailable(Login_Page.this))
							{
								((LinearLayout)findViewById(R.id.reportlist)).setVisibility(8);
								Loaddata("GPSCoordinatesReport");
							}
							else
							{
								oflineReport();
							}


						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {

					}
				});
				login_submit.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						try
						{
							UserId=((EditText)findViewById(R.id.userid_et)).getText().toString();
							PWd=((EditText)findViewById(R.id.password_et)).getText().toString();

							if(UserId.isEmpty())
							{
								((EditText)findViewById(R.id.userid_et)).requestFocus();
								((EditText)findViewById(R.id.userid_et)).setError("Enter UserName");

								return;
							}else if (PWd.isEmpty()) 
							{
								((EditText)findViewById(R.id.password_et)).requestFocus();
								((EditText)findViewById(R.id.password_et)).setError("Enter Password");

								return;
							}else {

								if(CheckConnection.isNetworkAvailable(Login_Page.this))
								{
									Loaddata("CheckUserAuthentication");
								}else {

									db.open();
									Cursor cursor=db.getTableDataCursor("select DISTINCT User_ID,User_DistrictId,User_ROLE_ID from APMIP_FARMER_DETAILS where User_ID='"+UserId+"' and Password='"+PWd+"'");
									if (cursor.getCount() > 0) {
										WebserviceCall.Login_Details=new HashMap<String, String>();
										for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

											WebserviceCall.Login_Details.put("User_ID", cursor.getString(0).trim());
											WebserviceCall.Login_Details.put("DistrictId", cursor.getString(1));
											WebserviceCall.Login_Details.put("ROLE_ID", cursor.getString(2));
										}
										startActivity(new Intent(Login_Page.this,Home_Act1.class));
									}
									else {
										Toast toast = null;
										toast=Toast.makeText(Login_Page.this, "Invalid user / Password",Toast.LENGTH_SHORT);
										View view = toast.getView();
										toast.setGravity(Gravity.BOTTOM, 0, 200);
										view.setBackgroundResource(R.color.red);
										toast.show();
									}

									db.close();

								
								}

							}
						}
						catch(Exception e)
						{

						}
						
					}
				});
				
			}
			else
			{
				// Permission Denied
				Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
				.show();
			}
		}
		break;
		default:
			super.onRequestPermissionsResult(permsRequestCode, permissions, grantResults);
		}
	}
	
	@Override
	public void onBackPressed() 
	{
		finishAffinity();
	}

}
