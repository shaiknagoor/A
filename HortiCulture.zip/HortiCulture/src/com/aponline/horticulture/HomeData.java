package com.aponline.horticulture;



import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

public class HomeData 
{

	public static String DeviceID;
	public static int sApiLevel = 0;
	public static String sAppVersion;
	public static Boolean sCheckMeEnable;
	public static String sCountry;
	public static String sCountrySortName;
	public static String sDeviceId;
	public static String sModel;
	public static String sOSVersion;
	public static String current_date;
	
//	public static String smUpgrade_Content;
//	public static int smUpgrade_count;
//	public static boolean smUpgrade_displayflag;
//	public static String smUpgrade_header;
//	public static String smAppSettingVersion;
//	HashMap<String, Bitmap> photoHashMap=new HashMap<String, Bitmap>();
//	public static ArrayList<Bitmap> photoBitmapsList;

//	public static String distId="07";
//	public static String mandId;
//	public static String villageId;
//	public static String unitId;
public static String MI_Companies_List="CREATE TABLE IF NOT EXISTS MI_Companies_List("
		+ "SUPPLIER_ID TEXT,"
		+ "SUPPLIER_NAME TEXT," 
		+ "DISTRICT_ID TEXT);";

	public static String APMIP_FARMER_DETAILS="CREATE TABLE IF NOT EXISTS APMIP_FARMER_DETAILS("
			+"AUTO_ID integer primary key autoincrement,"
			+"User_ID TEXT," 
			+"Password TEXT," 
			+"User_DistrictId TEXT," 
			+"User_ROLE_ID TEXT,"
			+"User_STATUS TEXT," 
			+"FarmerId TEXT," 
			+"RequestId TEXT," 
			+"AADHAARNUMBER TEXT," 
			+"FarmerName TEXT," 
			+"FatherName TEXT," 
			+"MobileNumber TEXT,"
			+"Caste TEXT," 
			+"Social_staus TEXT,"
			+"FarmerAddress TEXT,"
			+"Survey_No TEXT,"
			+"CropName TEXT," 
			+"Area_Proposed TEXT," 
			+"FARMERSTATUS TEXT,"
			+"CATEGORY TEXT," 
			+"Status_Code TEXT,"
			+"MI_Company_Name TEXT,"
			+"MI_System_Type TEXT,"
			+"Installation_Year TEXT," 
			+"Subsidy TEXT," 
			+"District_id TEXT," 
			+"Mandal_id TEXT," 
			+"Panchayat_Code TEXT," 
			+"Village_Code TEXT," 
			+"Habitation_Id TEXT," 
			
			+"FarmerFieldPhoto1 TEXT," 
			+"FarmerFieldPhoto2 TEXT,"
			+"WaterSource_GPS_Coordinates TEXT," 
			+"HeadControlUnit_GPS_Coordinates TEXT,"
			+"TrackingOfTheField_GPS_Coordinates TEXT,"
			+"Dischargevalue TEXT,"
			+"Survey_CROP TEXT," 
			+"Survey_AREAPROPOSED TEXT," 
			+"Survey_STATUSOFMISYSTEM TEXT," 
			+"Survey_FUNCTIONAL TEXT," 
			+"Survey_NOTEXISTS TEXT," 
			+"Survey_NOTFUNCTIONING TEXT," 
			+"Survey_InvestigatorDetails TEXT," 
			+"Survey_DeptOfficialDetails TEXT," 
			+"Survey_ComponentDetails TEXT," 

			+"Status_Flag TEXT default 'N',"
			+"CREATED_DATE default current_timestamp);";

	public static String InspectionStaffDetails="CREATE TABLE IF NOT EXISTS InspectionStaffDetails("
			+ "Staff_Name TEXT,"
			+ "Staff_ID TEXT," 
			+ "User_Name TEXT);";

	public static String COUNTRY_MASTER="CREATE TABLE COUNTRY_MASTER("
			+ "COUNTRY_ID VARCHAR(5),"
			+ "COUNTRY_NAME TEXT);";

	public static String STATE_MASTER="CREATE TABLE STATE_MASTER("
			+ "COUNTRY_ID VARCHAR(5),"
			+ "STATE_ID VARCHAR(5),"
			+ "STATE_NAME TEXT);";
	
	public static String DISTRICT_MASTER="CREATE TABLE DISTRICT_MASTER("
			+ "STATE_ID VARCHAR(5),"
			+ "DISTRICT_ID VARCHAR(5),"
			+ "CDMA_DISTRICT_ID VARCHAR(5),"
			+ "DISTRICT_NAME TEXT,"
			+ "REGION_CODE VARCHAR(5));";
	
	public static String MANDAL_MASTER="CREATE TABLE MANDAL_MASTER("
			+ "STATE_ID VARCHAR(5),"
			+ "DISTRICT_ID VARCHAR(5),"
			+ "MANDAL_ID VARCHAR(5),"
			+ "MANDAL_NAME TEXT);";

	public static String VILLAGEL_MASTER="CREATE TABLE VILLAGEL_MASTER("
			+ "STATE_ID VARCHAR(5),"
			+ "DISTRICT_ID VARCHAR(5),"
			+ "MANDAL_ID VARCHAR(5),"
			+ "VILLAGE_ID VARCHAR(5),"
			+ "VILLAGE_NAME TEXT);";
	
	
			

	public static String VILLAGE_TRAINING_DETAILS="CREATE TABLE IF NOT EXISTS VILLAGE_TRAINING_DETAILS("
			+"AUTO_ID integer primary key autoincrement,"
			+"District_id TEXT," 
			+"Mandal_id TEXT," 
			+"Panchayat_id TEXT," 
			+"Village_id TEXT,"
			+"Major_crop TEXT,"
			+"AGRONOMIC_WATER_MANAGEMENT TEXT,"
			+"AGRONOMIC_NUTRIENT_MANAGEMENT TEXT,"
			+"AGRONOMIC_PESTDISEASE_MANAGEMENT TEXT,"
			+"AGRONOMIC_HARVEST_HANDLING TEXT,"
			+"ASPECT_FERTIGATION TEXT,"
			+"ASPECT_MISYSTEM_MAINTENANCE TEXT,"
			+"ASPECT_AFETR_SALESSERVICE TEXT,"
			+"FARMERS_PROBLEMS TEXT,"
			+"ACTION_TAKEN TEXT,"
			+"RESOURCEPERSON_DESIGNATION TEXT,"
			+"RESOURCEPERSON_NAME TEXT,"
			+"FARMERSPARTICIPATEDCOUNT TEXT,"
			+"PHOTO_ONE TEXT,"
			+"PHOTO_TWO TEXT,"
			+"PHOTO_THREE TEXT,"
			+"CREATED_BY TEXT,"
			+"GPSCOORDINATES TEXT,"
			+"STATUS_FLAG TEXT default 'N',"
			+"TRAINING_DATE TEXT);";	
		
	
	
	


	

	


	public static void readDeviceDetails(Context paramContext)
	{
		String str1 = ((TelephonyManager)paramContext.getApplicationContext().getSystemService("phone")).getDeviceId();
		if (str1 == null)
			str1 = Settings.Secure.getString(paramContext.getApplicationContext().getContentResolver(), "android_id");
		if (str1 == null)
			str1 = "NODeviceID";
		String str2 = Build.VERSION.RELEASE;
		String str3 = Build.MODEL;
		int i = Integer.parseInt(Build.VERSION.SDK);
		SharedPreferences localSharedPreferences = paramContext.getApplicationContext().getSharedPreferences("user_settings", 0);
		String str4 = localSharedPreferences.getString("UserLocation", "");
		String str5 = localSharedPreferences.getString("UserLocationSortName", "");
		//	    if ((str4.equalsIgnoreCase("")) && (smLocationUrl != null) && (smLocationUrl.length() > 0))
		//	      getCountry_LocationUrl(paramContext, smLocationUrl);
		PackageManager localPackageManager = paramContext.getApplicationContext().getPackageManager();
		String str6 = "";
		try
		{
			str6 = localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 128).versionName;
			sApiLevel = i;
			Log.d("API LEVEL", Integer.toString(sApiLevel));
			sAppVersion = str6;
			Log.d("APP VERSION",sAppVersion);
			sDeviceId = str1;
			Log.d("Device ID",sDeviceId);
			sOSVersion = str2;
			Log.d("OS Version",sOSVersion);
			sModel = str3;
			Log.d("MODEL",sModel);
			sCountry = str4;
			Log.d("COUNTRY",sCountry);
			sCountrySortName = str5;
			Log.d("COUNTRY SORT", sCountrySortName);
			return;
		}
		catch (Exception localException)
		{
			while (true)
				localException.printStackTrace();
		}
	}
}
