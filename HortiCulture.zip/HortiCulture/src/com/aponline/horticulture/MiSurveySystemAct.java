package com.aponline.horticulture;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.kobjects.base64.Base64;

import com.aponline.Hc.database.DBAdapter;
import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.WebserviceCall;
import com.aponline.horticulture.R.color;









import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ResourceAsColor")
public class MiSurveySystemAct extends AppCompatActivity
{
	CheckConnection conn_obj;
	ProgressDialog progressDialog;
	Handler mHandler;
	Context context;
	DBAdapter db;
	ActionBar ab;
	GPSTracker gps;
	private static final int CAMERA_REQUEST = 1888; 
	Bitmap photo;
	String photoNo,InvestgatorName,DeptStaffName;
	ImageView photo1IV,photo2IV;
	EditText Farmer_id,MiMobileEt,InvestigatorSp1,DeptSp1,miextentEt,sancmiextentEt;
	TableLayout test;
	ArrayList<ArrayList<View>> ComponentDetails_Al,Al;
	Spinner miCropTypeSp,miCropNameSp,miCropTypeSp1,miCropNameSp1;
	//InvestigatorSp,DeptSp,
	TextView MiHeadcontrol_La,MiTrackling_La,MiWaterSource_La,MiHeadcontrol_Lg,MiTrackling_Lg,MiWaterSource_Lg;
	String CoName,CoSize,cropType,cropType1;
	LocationManager locationManager;
	int row;
	InputFilter filter;
	boolean keyDel= false;
	Button CalculateSubsidy,addmorecropBtn;

	public static String MIFarmer_ID,MIRequest_Id,MIStatus_code,waterSource_LaLg,Headcontrol_LaLg,Trackling_LaLg,strComponentDetails="",MiMobile,strdischargevalue,strCROP,strCROP1
			,strAREAPROPOSED,strSTATUSOFMISYSTEM,strFUNCTIONAL,strNOTEXISTS,strNOTFUNCTIONING,strInvestigatorDetails,strDeptOfficialDetails,miplace,strCROPTYPE,strCROPTYPE1,strAREAPROPOSED1,strLateral_space,strLateral_space1,strInvestigatorDetails1,strDeptOfficialDetails1,strtranspotationcost,strsanctioned_area;
	public static HashMap<String, String> CapurePhotos;
	ArrayList<View> dynamic_Al=new ArrayList<View>();
	public static float subsidy ;
	public 	static float nonsubsidy;
	public static float vat;
	public static float totalnonsubsidy;
	public  static float  caltot = 0;
	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==22)
				{
					if((WebserviceCall.Login_Details.get("STATUS")).equalsIgnoreCase("TRUE"))
					{
						//startActivity(new Intent(Home_Act.this,Home_Act.class));
					}
					else
					{

						Toast toast = null;
						toast=Toast.makeText(MiSurveySystemAct.this, "Invalid User",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();


					}


				}
				if(paramMessage.what==15)
				{

					if(WebserviceCall.serverResponse.equalsIgnoreCase("success")){
						AlertDialog(context, "Successfully Submitted","Submitted");
						//resetALL();
					}else if(WebserviceCall.serverResponse.equalsIgnoreCase("Failed"))
					{
						Toast toast = null;
						toast=Toast.makeText(MiSurveySystemAct.this, "Please Try Agian",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();

						//startActivity(new Intent(MiSurveySystemAct.this, Get_FormerDetails.class));
					}
				}
				if(paramMessage.what==23)
				{

					if(!(WebserviceCall.FidStatus.equalsIgnoreCase("")))
					{
						AlertDialog(context, WebserviceCall.FidStatus, "FidStatus");
					}else {
						//Farmer_id.setText(WebserviceCall.data.get(0).get("Farmer_Id").toString());
						//Farmer_ID=Farmer_id.getText().toString();

					}
				}



				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");

					Toast toast = null;
					toast=Toast.makeText(MiSurveySystemAct.this, "Please Try Agian",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.BOTTOM, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();

					startActivity(new Intent(MiSurveySystemAct.this, Get_FormerDetails.class));
					//Toast.makeText(MiSurveySystemAct.this,"Please Try Agian",Toast.LENGTH_LONG).show();


				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(MiSurveySystemAct.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(MiSurveySystemAct.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(MiSurveySystemAct.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}
	protected void onCreate(Bundle savedInstanceState) {
		try
		{

			super.onCreate(savedInstanceState);
			context=this;

			db=new DBAdapter(this);
			setContentView(R.layout.other_farmerids_details);
			gps=new GPSTracker(MiSurveySystemAct.this);
			HashMap< String, Bitmap> photodata=new HashMap<String, Bitmap>();
			CapurePhotos=new HashMap<String, String>();
			test=((TableLayout)findViewById(R.id.NotEnteredBlockLL));
			SharedPreferences prefs = getSharedPreferences("MY_PREFS_NAME",MODE_PRIVATE); 
			String name = prefs.getString("Miaoname","");
			((EditText)findViewById(R.id.InvestigatorSp1)).setText(name);
			String name1 = prefs.getString("Deptname","");
			((EditText)findViewById(R.id.DeptofficialSp1)).setText(name1);

			this.ab=getSupportActionBar();
			ab.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.menu_bg));
			ab.setTitle("APMIP");
			ab.setHomeButtonEnabled(true);
			ab.setDisplayHomeAsUpEnabled(true);

			((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);

			MiWaterSource_La=((TextView)findViewById(R.id.MiwaterSourceGpsTvLa));
			MiHeadcontrol_La=((TextView)findViewById(R.id.MiheadControlGpsTvLa));
			MiTrackling_La=((TextView)findViewById(R.id.MiTraclingGpsTVLa));

			MiWaterSource_Lg=((TextView)findViewById(R.id.MiwaterSourceGpsTVLg));
			MiHeadcontrol_Lg=((TextView)findViewById(R.id.MiheadControlGpsTVLg));
			MiTrackling_Lg=((TextView)findViewById(R.id.MiTraclingGpsTVLg));

			//InvestigatorSp=((Spinner)findViewById(R.id.InvestigatorSp));
			//	DeptSp=((Spinner)findViewById(R.id.DeptofficialSp));
			miCropTypeSp=((Spinner)findViewById(R.id.miCropTypeSp));
			miCropNameSp=((Spinner)findViewById(R.id.miCropNameSp));
			miCropTypeSp1=((Spinner)findViewById(R.id.miCropTypeSp1));
			miCropNameSp1=((Spinner)findViewById(R.id.miCropNameSp1));
			CalculateSubsidy=(Button)findViewById(R.id.CalculateSubsidy);
			miextentEt=(EditText)findViewById(R.id.miextentEt);
			sancmiextentEt=(EditText)findViewById(R.id.misancextentEt);
			MiMobileEt=((EditText) findViewById(R.id.MiMobileEt));
			addmorecropBtn=(Button)findViewById(R.id.addmorecropBtn);
			filter = new InputFilter() {
				final int maxDigitsBeforeDecimalPoint=4;
				final int maxDigitsAfterDecimalPoint=2;

				@Override
				public CharSequence filter(CharSequence source, int start, int end,
						Spanned dest, int dstart, int dend) {
					StringBuilder builder = new StringBuilder(dest);
					builder.replace(dstart, dend, source
							.subSequence(start, end).toString());
					if (!builder.toString().matches(
							"(([0-9]{1})([0-9]{0,"+(maxDigitsBeforeDecimalPoint-1)+"})?)?(\\.[0-9]{0,"+maxDigitsAfterDecimalPoint+"})?"

							)) {
						if(source.length()==0)
							return dest.subSequence(dstart, dend);
						return "";
					}

					return null;
				}
			};
			miextentEt.setFilters(new InputFilter[]{filter});
			sancmiextentEt.setFilters(new InputFilter[]{filter});
			sancmiextentEt.addTextChangedListener(new TextWatcher() 
			{

				@Override
				public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) 
				{
					// TODO Auto-generated method stub

				}

				@Override
				public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
						int arg3) 
				{
					// TODO Auto-generated method stub

				}

				@Override
				public void afterTextChanged(Editable arg0) 
				{

					try
					{
						String temp=((EditText) findViewById(R.id.misancextentEt)).getText().toString();
						double temp1=Double.parseDouble(temp)*500;
						((TextView)findViewById(R.id.mi_transport_cost)).setText(Double.toString(temp1));
					}
					catch(Exception e)
					{

					}
				}
			});
			//			miextentEt.addTextChangedListener(new TextWatcher() 
			//			{
			//
			//				@Override
			//				public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) 
			//				{
			//					// TODO Auto-generated method stub
			//
			//				}
			//
			//				@Override
			//				public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
			//						int arg3) 
			//				{
			//					// TODO Auto-generated method stub
			//
			//				}
			//
			//				@Override
			//				public void afterTextChanged(Editable arg0) 
			//				{
			//
			//					try
			//					{
			//						String temp=((EditText) findViewById(R.id.miextentEt)).getText().toString();
			//						double temp1=Double.parseDouble(temp)*500;
			//						((TextView)findViewById(R.id.mi_transport_cost)).setText(Double.toString(temp1));
			//					}
			//					catch(Exception e)
			//					{
			//
			//					}
			//				}
			//			});
			addmorecropBtn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) 
				{
					if(((LinearLayout)findViewById(R.id.addmorecropll)).isShown())
					{
						((LinearLayout)findViewById(R.id.addmorecropll)).setVisibility(8);
						addmorecropBtn.setText("Add More Crop");
						miCropTypeSp1.setSelection(0);
						miCropNameSp1.setSelection(0);
						((EditText)findViewById(R.id.miextentEt1)).setText("");
						((EditText)findViewById(R.id.milateralEt1)).setText("");
					}
					else
					{
						((LinearLayout)findViewById(R.id.addmorecropll)).setVisibility(0);
						addmorecropBtn.setText("Remove Crop");
					}

				}
			});

			CalculateSubsidy.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {


					float totalamounts=0;
					if(ComponentDetails_Al.size()>0)
					{

						for (int i = 0; i < ComponentDetails_Al.size(); i++) {

							ArrayList<View> localArrayListb = new ArrayList<View>();
							localArrayListb.addAll(ComponentDetails_Al.get(i));

							for (int j = 0; j < localArrayListb.size(); j++) {

								if (j == 0 || j==1)
								{
									Spinner tv1 = (Spinner) localArrayListb.get(j);
									if(tv1.getSelectedItem().toString().equalsIgnoreCase("---Select---"))
									{
										//System.out.println("-----------aa-");
										if(j==0)
										{
											AlertDialog(context, "Select Component Name", "hh");
											return;
										}
										else
										{
											AlertDialog(context, "Select Component Size", "hh");
											return;
										} 
									}

								} else {
									EditText tv = (EditText) localArrayListb.get(j);
									if(j==3 && tv.getText().toString().equals(""))
									{
										AlertDialog(context, "Enter Component Quantity ", "hh");
										return;
									}

								}


							}

							totalamounts=totalamounts+Float.parseFloat(((TextView)localArrayListb.get(4)).getText().toString());
							caltot=totalamounts;
						}
						
						if(((EditText) findViewById(R.id.misancextentEt)).getText().toString().equalsIgnoreCase("")) 
						{
							((EditText) findViewById(R.id.misancextentEt)).setError("Enter Extent");
							((EditText) findViewById(R.id.misancextentEt)).requestFocus();
							return;
						}
						caltot=caltot+Float.parseFloat(((TextView)findViewById(R.id.mi_transport_cost)).getText().toString());

						subsidy =  (50.0f/100.0f)*caltot ;
						nonsubsidy=(50.0f/100.0f)*caltot ;
						vat=(5f/100.0f)*caltot;
						totalnonsubsidy= vat+nonsubsidy;
						((TextView)findViewById(R.id.totaltv)).setText(Float.toString(caltot));
						((TextView)findViewById(R.id.subsidytv)).setText(Float.toString(subsidy));
						((TextView)findViewById(R.id.nonsubsidytv)).setText(Float.toString(nonsubsidy));
						((TextView)findViewById(R.id.vattv)).setText(Float.toString(vat));					
						((TextView)findViewById(R.id.totalnonsubtv)).setText(Float.toString(totalnonsubsidy));


					}
					else
					{
						AlertDialog(context,"Please Select Atleast One Component","hh");
						return;
					}
				}
			});

			((EditText) findViewById(R.id.miplaceEt)).setOnFocusChangeListener(new OnFocusChangeListener() {

				@Override
				public void onFocusChange(View v, boolean hasFocus) {
					if(hasFocus){
						((EditText) findViewById(R.id.miplaceEt)).setError(null);	
					}

				}
			});

			MiMobileEt.addTextChangedListener(new TextWatcher() {

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {

					String str = s.toString();
					if(str.length() > 0 && str.startsWith("0")){
						MiMobileEt.setText("");
					}
				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count,
						int after) {


				}

				@Override
				public void afterTextChanged(Editable s) {


				}
			});



			db.open();
			List<String> miCropTypelist=new ArrayList<String>();
			miCropTypelist=db.getSpinnerData("select DISTINCT Crop_Type_Description from Crop_Master order by Crop_Type_Description");
			db.close();

			ArrayAdapter<String> miCropTypeSpAdapter = new ArrayAdapter<String>(MiSurveySystemAct.this,android.R.layout.simple_spinner_item,miCropTypelist);
			miCropTypeSpAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			miCropTypeSp.setAdapter(miCropTypeSpAdapter);

			miCropTypeSp1.setAdapter(miCropTypeSpAdapter);

			//			if(!CheckConnection.isNetworkAvailable(MiSurveySystemAct.this))
			//			{
			//				db.open();
			//				Cursor cursor=db.getTableDataCursor("select DISTINCT Staff_Name from InspectionStaffDetails where User_Name='"+Login_Page.UserId+"' order by Staff_Name");
			//				if (cursor.getCount() > 0) {
			//
			//					WebserviceCall.StaffDataSP_AL=new ArrayList<String>();
			//					WebserviceCall.StaffDataSP_AL.add("---Select---");
			//					for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
			//					{
			//
			//						WebserviceCall.StaffDataSP_AL.add(cursor.getString(0));
			//
			//					}
			//					db.close();
			//				}
			//			}
			//			ArrayAdapter<String> InvestigatorSpapter = new ArrayAdapter<String>(MiSurveySystemAct.this,android.R.layout.simple_spinner_item,WebserviceCall.StaffDataSP_AL);
			//			InvestigatorSpapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			//			InvestigatorSp.setAdapter(InvestigatorSpapter);
			//
			//			ArrayAdapter<String> DeptSpAdapter = new ArrayAdapter<String>(MiSurveySystemAct.this,android.R.layout.simple_spinner_item,WebserviceCall.StaffDataSP_AL);
			//			DeptSpAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			//			DeptSp.setAdapter(DeptSpAdapter);


			((LinearLayout)findViewById(R.id.mi_NotExistLL)).setVisibility(0);
			miCropTypeSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
				{

					if(!((TextView)arg1).getText().toString().equalsIgnoreCase("---Select---"))
					{
						cropType=miCropTypeSp.getSelectedItem().toString();
						db.open();
						List<String> CropNamelist=new ArrayList<String>();
						List<String> DCropNamelist=new ArrayList<String>();
						CropNamelist=db.getSpinnerDatacrop("select DISTINCT Crop_Code from Crop_Master where Crop_Type_Description='"+miCropTypeSp.getSelectedItem().toString()+"'");
						db.close();
						db.open();
						DCropNamelist.add("--Select--");
						for(int i=0;i<CropNamelist.size();i++)
						{
							DCropNamelist.add(db.getSingleValue("select distinct Crop_Description from Crop_Master where Crop_Code='"+CropNamelist.get(i)+"'"));

						}

						ArrayAdapter<String> miCropNameSpAdapter = new ArrayAdapter<String>(MiSurveySystemAct.this,android.R.layout.simple_spinner_item,DCropNamelist);
						miCropNameSpAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
						miCropNameSp.setAdapter(miCropNameSpAdapter);
						strCROPTYPE=db.getSingleValue("select  DISTINCT Crop_Type_Code from Crop_Master where Crop_Type_Description='"+cropType+"'");
						db.close();
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});

			miCropNameSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
				{
					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
					{

						String Name=miCropNameSp.getSelectedItem().toString();
						db.open();
						strCROP=db.getSingleValue("select  DISTINCT Crop_Code from Crop_Master where Crop_Type_Description='"+cropType+"' and Crop_Description='"+Name+"'");
						db.close();
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});
			miCropTypeSp1.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
				{

					if(!((TextView)arg1).getText().toString().equalsIgnoreCase("---Select---"))
					{
						cropType1=miCropTypeSp1.getSelectedItem().toString();
						db.open();
						List<String> CropNamelist=new ArrayList<String>();
						List<String> DCropNamelist=new ArrayList<String>();
						CropNamelist=db.getSpinnerDatacrop("select DISTINCT Crop_Code from Crop_Master where Crop_Type_Description='"+miCropTypeSp1.getSelectedItem().toString()+"'");
						db.close();
						db.open();
						DCropNamelist.add("--Select--");
						for(int i=0;i<CropNamelist.size();i++)
						{
							DCropNamelist.add(db.getSingleValue("select distinct Crop_Description from Crop_Master where Crop_Code='"+CropNamelist.get(i)+"'"));

						}

						ArrayAdapter<String> miCropNameSpAdapter = new ArrayAdapter<String>(MiSurveySystemAct.this,android.R.layout.simple_spinner_item,DCropNamelist);
						miCropNameSpAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
						miCropNameSp1.setAdapter(miCropNameSpAdapter);
						strCROPTYPE1=db.getSingleValue("select  DISTINCT Crop_Type_Code from Crop_Master where Crop_Type_Description='"+cropType1+"'");
						db.close();
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});

			miCropNameSp1.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
				{
					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
					{

						String Name=miCropNameSp1.getSelectedItem().toString();
						db.open();
						strCROP1=db.getSingleValue("select  DISTINCT Crop_Code from Crop_Master where Crop_Type_Description='"+cropType1+"' and Crop_Description='"+Name+"'");
						db.close();
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});



			//			InvestigatorSp.setOnItemSelectedListener(new OnItemSelectedListener() {
			//
			//				@Override
			//				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
			//				{
			//					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
			//					{
			//						strInvestigatorDetails=InvestigatorSp.getSelectedItem().toString();
			//
			//					}
			//				}
			//
			//				@Override
			//				public void onNothingSelected(AdapterView<?> arg0) {
			//
			//
			//				}
			//			});
			//
			//
			//			DeptSp.setOnItemSelectedListener(new OnItemSelectedListener() {
			//
			//				@Override
			//				public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3) 
			//				{
			//
			//
			//					if(!(((TextView)arg1).getText().toString()).equalsIgnoreCase("---Select---"))
			//					{
			//						strDeptOfficialDetails=DeptSp.getSelectedItem().toString();
			//
			//
			//					}
			//				}
			//				@Override
			//				public void onNothingSelected(AdapterView<?> arg0) {
			//
			//
			//				}
			//			});


			Intent intent = getIntent(); 
			if(!(intent.getStringExtra("Srtatus")==null) && intent.getStringExtra("Srtatus").toString().equalsIgnoreCase("MI SURVEY FARMER") )
			{
				MIFarmer_ID=WebserviceCall.data.get(Get_FormerDetails.rowid).get("Farmer_Id");
				((TextView)findViewById(R.id.mifID)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Farmer_Id"));
				((TextView)findViewById(R.id.mifname)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FarmerName"));
				((TextView)findViewById(R.id.mifaadhar)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("AADHAARNUMBER"));
				//((TextView)findViewById(R.id.mifmobile)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MobileNumber"));
				((TextView)findViewById(R.id.mifsocial)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Social_staus"));
				((TextView)findViewById(R.id.mifcategory)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("CATEGORY"));
				((TextView)findViewById(R.id.mifcrop)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("CropName"));
				((TextView)findViewById(R.id.mifarea)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Area_Proposed"));
				((TextView)findViewById(R.id.mifaddress)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FarmerAddress"));
				((TextView)findViewById(R.id.mifstatus)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("FARMERSTATUS"));
				if(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MobileNumber")!="" &&  WebserviceCall.data.get(Get_FormerDetails.rowid).get("MobileNumber")!="null")
				{
					((EditText)findViewById(R.id.MiMobileEt)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MobileNumber"));
				}

				((TextView)findViewById(R.id.Year_installation)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Installation_Year"));
				((TextView)findViewById(R.id.MIcompany)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MI_Company_Name"));
				((TextView)findViewById(R.id.system_supplied)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("MI_System_Type"));
				((TextView)findViewById(R.id.subsidy)).setText(WebserviceCall.data.get(Get_FormerDetails.rowid).get("Subsidy"));

				MIRequest_Id=WebserviceCall.data.get(Get_FormerDetails.rowid).get("RequestId");
				MIStatus_code=WebserviceCall.data.get(Get_FormerDetails.rowid).get("Status_Code");
			}

			db=new DBAdapter(this);

			try 
			{
				db.createDataBase();
				//db.createNewTable();

				db.close();

			} 
			catch (IOException e) 
			{
				e.printStackTrace();
				db.close();
			}
			db.close();


			ComponentDetails_Al=new ArrayList<ArrayList<View>>();
			Al=new ArrayList<ArrayList<View>>();

			dynamic();

			//		TableRow Rw=new TableRow(this);
			//		TableLayout.LayoutParams layoutParams1=new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
			//		layoutParams1.setMargins(2, 1, 2, 1);
			//		Rw.setLayoutParams(layoutParams1);
			//		test.addView(Rw);
			//
			//		TableRow.LayoutParams column1=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			//		column1.leftMargin=2;
			//		column1.weight=50;
			//
			//
			//		Spinner spinner = new Spinner(this);
			//
			//		ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(MiSurveySystemAct.this,android.R.layout.simple_spinner_item, spinnerArray);
			//		spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
			//		spinner.setAdapter(spinnerArrayAdapter);
			//		Rw.addView(spinner);
			//
			//		TelephonyManager mTelephonyMgr = (TelephonyManager)
			//
			//				getSystemService(Context.TELEPHONY_SERVICE);
			//
			//		String imei = mTelephonyMgr.getDeviceId();
			//		System.out.println("---------------imei-------"+imei);

			//select DISTINCT Component_Name from MI_Components_Prices order by Component_Name
		}
		catch(Exception e)
		{

		}
	}



	public void dynamic()
	{

		try
		{
			db.open();
			List<String> spinnerArray=new ArrayList<String>();
			spinnerArray=db.getSpinnerData("select DISTINCT Component_Name from MI_Components_Prices order by Component_Name");
			db.close();

			TableRow Rw=new TableRow(MiSurveySystemAct.this);
			TableLayout.LayoutParams layoutParams1=new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
			layoutParams1.setMargins(2, 1, 2, 1);
			Rw.setLayoutParams(layoutParams1);
			test.addView(Rw);

			TableRow.LayoutParams column1=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			column1.leftMargin=2;
			column1.weight=100;
			//column1.width=110;
			final Spinner ComponentSp = new Spinner(this);
			ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerArray); //selected item will look like a spinner set from XML
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);

			//ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, spinnerArray);
			ComponentSp.setAdapter(spinnerArrayAdapter);
			ComponentSp.setLayoutParams(column1);
			Rw.addView(ComponentSp);


			TableRow.LayoutParams column2=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			column2.leftMargin=2;
			column2.weight=100;
			//column2.width=110;
			final Spinner componentSizeSp = new Spinner(this);
			//ArrayAdapter<String> spinnerArrayAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, spinnerArray);
			//componentSizeSp.setAdapter(spinnerArrayAdapter1);
			componentSizeSp.setLayoutParams(column2);
			Rw.addView(componentSizeSp);

			TableRow.LayoutParams column3=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			column3.leftMargin=2;
			column3.weight=70;
			//column3.width=110;
			final EditText componentRateEt=new EditText(this);
			componentRateEt.setBackgroundResource(R.drawable.rectangular_et);
			componentRateEt.setTextColor(Color.BLACK);
			componentRateEt.setEnabled(false);
			componentRateEt.setHint("Price");
			componentRateEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
			componentRateEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
			componentRateEt.setLayoutParams(column3);
			Rw.addView(componentRateEt);

			TableRow.LayoutParams column4=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			column4.leftMargin=2;
			column4.weight=70;
			//column4.width=110;
			final EditText ComponentQtyEt=new EditText(this);
			ComponentQtyEt.setBackgroundResource(R.drawable.rectangular_et);
			ComponentQtyEt.setTextColor(Color.BLACK);
			ComponentQtyEt.setHint("Quantity");

			ComponentQtyEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
			ComponentQtyEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
			ComponentQtyEt.setLayoutParams(column4);
			Rw.addView(ComponentQtyEt);

			TableRow.LayoutParams column5=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			column5.leftMargin=2;
			column5.weight=70;
			//column5.width=110;
			final EditText ComponentTotalEt=new EditText(this);
			ComponentTotalEt.setBackgroundResource(R.drawable.rectangular_et);
			ComponentTotalEt.setTextColor(Color.BLACK);
			ComponentTotalEt.setHint("Total");
			ComponentTotalEt.setEnabled(false);
			ComponentTotalEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
			ComponentTotalEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
			ComponentTotalEt.setLayoutParams(column5);
			Rw.addView(ComponentTotalEt);

			TableRow.LayoutParams column6=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			column6.leftMargin=2;
			column6.weight=100;
			//column6.width=110;
			final EditText ComponentRemarksEt=new EditText(this);
			ComponentRemarksEt.setBackgroundResource(R.drawable.rectangular_et);
			ComponentRemarksEt.setTextColor(Color.BLACK);
			ComponentRemarksEt.setHint("Remarks");
			ComponentRemarksEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_TEXT);
			ComponentRemarksEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
			ComponentRemarksEt.setLayoutParams(column6);
			Rw.addView(ComponentRemarksEt);

			//		TableRow.LayoutParams column7=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			//		column7.leftMargin=2;
			//		column7.weight=70;
			//		final EditText ComponentSpEt=new EditText(this);
			//		ComponentSpEt.setBackgroundResource(R.drawable.rectangular_et);
			//		ComponentSpEt.setTextColor(Color.BLACK);
			//		ComponentSpEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
			//		ComponentSpEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
			//		ComponentSpEt.setLayoutParams(column7);
			//		ComponentSpEt.setVisibility(8);
			//		Rw.addView(ComponentSpEt);
			//
			//		TableRow.LayoutParams column8=new TableRow.LayoutParams(0,LayoutParams.WRAP_CONTENT);
			//		column8.leftMargin=2;
			//		column8.weight=70;
			//		final EditText ComponentSpsizeEt=new EditText(this);
			//		ComponentSpsizeEt.setBackgroundResource(R.drawable.rectangular_et);
			//		ComponentSpsizeEt.setTextColor(Color.BLACK);
			//		ComponentSpsizeEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
			//		ComponentSpsizeEt.setImeOptions(EditorInfo.IME_ACTION_DONE);
			//		ComponentSpsizeEt.setLayoutParams(column8);
			//		ComponentSpsizeEt.setVisibility(8);
			//		Rw.addView(ComponentSpsizeEt);


			ComponentQtyEt.setOnKeyListener(new OnKeyListener() {

				@Override
				public boolean onKey(View arg0, int arg1, KeyEvent arg2) {
					//				String r=componentRateEt.getText().toString();
					//				String q=ComponentQtyEt.getText().toString();
					//				if(!r.isEmpty() && !q.isEmpty()){
					//					Float f = Float.parseFloat(r) * Float.parseFloat(q);
					//					ComponentTotalEt.setText(Float.toString(f));
					//}
					if(arg1 == KeyEvent.KEYCODE_DEL){  
						keyDel=true;
					}
					else
					{
						keyDel=false;
					}
					return false;
				}

			});

			ComponentQtyEt.addTextChangedListener(new TextWatcher() {

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {


					ComponentTotalEt.setText("");

				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count,
						int after)
				{


				}

				@Override
				public void afterTextChanged(Editable s) {
					if (!keyDel) 
					{
						String r=componentRateEt.getText().toString();
						String q=ComponentQtyEt.getText().toString();
						if(!r.isEmpty() && !q.isEmpty()){
							Float f = Float.parseFloat(r) * Float.parseFloat(q);
							ComponentTotalEt.setText(Float.toString(f));
						}
					}
					else
					{
						String r=componentRateEt.getText().toString();
						String q=ComponentQtyEt.getText().toString();
						if(!r.isEmpty() && !q.isEmpty()){
							Float f = Float.parseFloat(r) * Float.parseFloat(q);
							ComponentTotalEt.setText(Float.toString(f));
						}
						// ComponentTotalEt.setText("");
					}

				}
			});


			ComponentSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {


					int i=(int) arg3;

					if(i!=0)
					{

						ComponentQtyEt.setText("");
						ComponentTotalEt.setText("");
						componentRateEt.setText("");
						CoName=ComponentSp.getSelectedItem().toString();
						//	ComponentSpEt.setText(CoName);
						String dd="select Component_Size from MI_Components_Prices where Component_Name='"+CoName+"'";
						db.open();
						List<String> spinnerArray1=new ArrayList<String>();
						spinnerArray1=db.getSpinnerData(dd);
						System.out.println("------qqq-"+dd);
						db.close();
						ArrayAdapter<String> spinnerArrayAdapter2 = new ArrayAdapter<String>(MiSurveySystemAct.this, android.R.layout.simple_spinner_dropdown_item,spinnerArray1);
						componentSizeSp.setAdapter(spinnerArrayAdapter2);
						//loadSpinner(spinnerArray1);
					}
					else
					{
						ComponentQtyEt.setText("");
						ComponentTotalEt.setText("");
						componentRateEt.setText("");
					}


				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0)
				{


				}
			});


			componentSizeSp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {


					int i=(int) arg3;

					if(i!=0)
					{

						CoSize=componentSizeSp.getSelectedItem().toString();
						//	ComponentSpsizeEt.setText(CoSize);
						db.open();

						String v=db.getSingleValue("select Component_Price from  MI_Components_Prices   where Component_Name='"+CoName+"' and Component_Size='"+CoSize+"'");

						componentRateEt.setText(v);
						db.close();




					}


				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {


				}
			});

			dynamic_Al.add(ComponentSp);
			dynamic_Al.add(componentSizeSp);
			dynamic_Al.add(ComponentQtyEt);

			ArrayList<View> LocalEntryblock=new ArrayList<View>();

			LocalEntryblock.add(ComponentSp);
			LocalEntryblock.add(componentSizeSp);
			LocalEntryblock.add(componentRateEt);
			LocalEntryblock.add(ComponentQtyEt);
			LocalEntryblock.add(ComponentTotalEt);
			LocalEntryblock.add(ComponentRemarksEt);

			ComponentDetails_Al.add(LocalEntryblock);
			Al.add(dynamic_Al);

			if (ComponentDetails_Al.size() == 2) {
				((Button) findViewById(R.id.componentSpRemove)).setVisibility(0);
			}

		}
		catch(Exception e)
		{
		}


	}
	private void GetGpsCoordinates(String FieldType)
	{
		try
		{
			gps=new GPSTracker(MiSurveySystemAct.this);
			if(GPSTracker.acc1!=0.0)
			{
				Toast toast = null;
				toast=Toast.makeText(MiSurveySystemAct.this,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 4)",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.blue);
				toast.show();
				//Toast.makeText(context,Float.toString(GPSTracker.acc1)+"<--(It should be atleast less than 3)",2000).show();
			}
			//	Toast.makeText(context,Boolean.toString(GPSTracker.flag),2000).show();
			locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if(FieldType.equalsIgnoreCase("WaterSourceGps"))
			{

				if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
				{
					buildAlertMessageNoGps();
				}  else
				{
					MiWaterSource_La.setText("La-"+String.valueOf(gps.getLatitude()));
					MiWaterSource_Lg.setText("Lg-"+String.valueOf(gps.getLongitude()));

					waterSource_LaLg=String.valueOf(gps.getLatitude())+","+String.valueOf(gps.getLongitude());

				}
			}
			if(FieldType.equalsIgnoreCase("HeadControlGps"))
			{
				//locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
				if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
				{
					buildAlertMessageNoGps();
				}  else {

					MiHeadcontrol_La.setText("La-"+String.valueOf(gps.getLatitude()));
					MiHeadcontrol_Lg.setText("Lg-"+String.valueOf(gps.getLongitude()));

					Headcontrol_LaLg=String.valueOf(gps.getLatitude())+","+String.valueOf(gps.getLongitude());
				}
			}
			if(FieldType.equalsIgnoreCase("TraclingGps"))
			{
				//locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
				if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
				{
					buildAlertMessageNoGps();
				}  else {

					MiTrackling_La.setText("La-"+String.valueOf(gps.getLatitude()));
					MiTrackling_Lg.setText("Lg-"+String.valueOf(gps.getLongitude()));

					Trackling_LaLg=String.valueOf(gps.getLatitude())+","+String.valueOf(gps.getLongitude());
				}
			}
		}
		catch(Exception e)
		{

		}
	}


	//	public void loadSpinner(List<String> ll)
	//	{
	//		if(!ComponentDetails.isEmpty())
	//		{
	//			ArrayList<View> local=ComponentDetails.get(row-1);
	//			Spinner a =(Spinner) local.get(1);
	//			ArrayAdapter<String> spinnerArrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, ll);
	//			a.setAdapter(spinnerArrayAdapter2);
	//
	//		}
	//	}


	private void takePhoto()
	{
		try
		{		
			Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(cameraIntent,CAMERA_REQUEST);
		}catch(Exception e)
		{

		}
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
		try {


			if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) 
			{  

				if(photoNo.equalsIgnoreCase("one"))
				{
					try
					{
						ByteArrayOutputStream out1 = new ByteArrayOutputStream();
						photo = (Bitmap) data.getExtras().get("data"); 
						((ImageView)findViewById(R.id.Miphoto1IV)).setImageBitmap(photo);
						photo.compress(Bitmap.CompressFormat.PNG, 100, out1);
						byte[] ba1 = out1.toByteArray();
						CapurePhotos.put("photoOne",Base64.encode(ba1));
					}
					catch(Exception e)
					{
						System.out.println("---problem-");
					}

				}else if(photoNo.equalsIgnoreCase("two"))
				{
					ByteArrayOutputStream out2 = new ByteArrayOutputStream();
					photo = (Bitmap) data.getExtras().get("data"); 
					((ImageView)findViewById(R.id.Miphoto2IV)).setImageBitmap(photo);
					photo.compress(Bitmap.CompressFormat.PNG, 100, out2);
					byte[] ba2 = out2.toByteArray();
					CapurePhotos.put("photoTwo",Base64.encode(ba2));


				}

			}
		} catch (Exception e) {

		}
	}
	public void RemoveVoilation(String removeType)
	{
		try
		{
			if (removeType.equalsIgnoreCase("componentSpRemove")) {
				if (ComponentDetails_Al.size() == 2) {
					//				test.removeAllViews();
					//				ComponentDetails_Al.clear();
					test.removeViewAt((ComponentDetails_Al.size() - 1));
					ComponentDetails_Al.remove(ComponentDetails_Al.size() - 1);
					((Button) findViewById(R.id.componentSpRemove)).setVisibility(8);
				} else {
					test.removeViewAt((ComponentDetails_Al.size() - 1));
					ComponentDetails_Al.remove(ComponentDetails_Al.size() - 1);

				}
			}
		}
		catch(Exception e)
		{

		}
	}

	public void CommanAction(View v)
	{
		try
		{

			//		String ss=String.valueOf(gps.acc);
			//		Toast toast = null;
			//		toast=Toast.makeText(MiSurveySystemAct.this, ss,Toast.LENGTH_SHORT);
			//		View view = toast.getView();
			//		toast.setGravity(Gravity.CENTER, 0, 0);
			//		view.setBackgroundResource(R.color.red);
			//		toast.show();

			switch (v.getId()) {

			/*case R.id.MiCheck_locationBt:
			Uri gmmIntentUri = Uri.parse("geo:0,0?q="+waterSource_LaLg+"(label)");
			Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
			mapIntent.setPackage("com.google.android.apps.maps");
			startActivity(mapIntent);
			break;
			 */
			case R.id.mi_FunStatusRb:
				((LinearLayout)findViewById(R.id.Mi_fertigation_mainLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_NotExistLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(8);
				((RadioButton)findViewById(R.id.Not_FollowedRb)).setChecked(true);
				((LinearLayout)findViewById(R.id.component_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.non_functioningLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_nonfunctioningLL)).setVisibility(8);
				//((LinearLayout)findViewById(R.id.nonfunc_ll)).setVisibility(8);

				break;
			case R.id.func_No:
				((LinearLayout)findViewById(R.id.Mi_fertigation_mainLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_NotExistLL)).setVisibility(8);
				((RadioButton)findViewById(R.id.borewellRb)).setChecked(true);
				((LinearLayout)findViewById(R.id.component_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.non_functioningLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(0);

				((LinearLayout)findViewById(R.id.notexist_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.func_ll)).setVisibility(0);
				//((LinearLayout)findViewById(R.id.nonfunc_ll)).setVisibility(0);
				break;



				//		case R.id.mi_nonFunStatusRb:
				//			((LinearLayout)findViewById(R.id.Mi_fertigation_mainLL)).setVisibility(8);
				//			((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);
				//			((LinearLayout)findViewById(R.id.mi_NotExistLL)).setVisibility(8);
				//			((RadioButton)findViewById(R.id.borewellRb)).setChecked(true);
				//
				//			((LinearLayout)findViewById(R.id.non_functioningLL)).setVisibility(0);
				//			((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(0);
				//			((LinearLayout)findViewById(R.id.notexist_ll)).setVisibility(8);
				//			((LinearLayout)findViewById(R.id.notexist_ll)).setVisibility(0);
				//			((LinearLayout)findViewById(R.id.func_ll)).setVisibility(0);
				//			break;
				//		case R.id.nonfunc_No:
				//			((LinearLayout)findViewById(R.id.nonfunc_ll)).setVisibility(8);
				//			((LinearLayout)findViewById(R.id.func_ll)).setVisibility(8);
				//			break;
			case R.id.mi_ExistStatusRb:
				((LinearLayout)findViewById(R.id.Mi_fertigation_mainLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.non_functioningLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_nonfunctioningLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.component_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.mi_NotExistLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.func_ll)).setVisibility(0);
				try
				{
					String temp=((EditText) findViewById(R.id.misancextentEt)).getText().toString();
					if(!temp.equalsIgnoreCase(""))
					{
						double temp1=Double.parseDouble(temp)*500;
						((TextView)findViewById(R.id.mi_transport_cost)).setText(Double.toString(temp1));
					}
				}
				catch (Exception e) 
				{

					((EditText) findViewById(R.id.misancextentEt)).setError("Enter Extent");
					((EditText) findViewById(R.id.misancextentEt)).requestFocus();
				}
				break;
			case R.id.notexist_No:

				((LinearLayout)findViewById(R.id.mi_NotExistLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.func_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.mi_nonfunctioningLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.component_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.non_functioningLL)).setVisibility(8);
				((LinearLayout)findViewById(R.id.Mi_fertigation_mainLL)).setVisibility(8);
				((TextView)findViewById(R.id.mi_transport_cost)).setText("");
				test.removeAllViews();
				try
				{
					if(ComponentDetails_Al!=null)
					{
						ComponentDetails_Al.clear();
					}
					((TextView)findViewById(R.id.totaltv)).setText("");
					((TextView)findViewById(R.id.subsidytv)).setText("");
					((TextView)findViewById(R.id.nonsubsidytv)).setText("");
					((TextView)findViewById(R.id.vattv)).setText("");					
					((TextView)findViewById(R.id.totalnonsubtv)).setText("");

				}
				catch (Exception e)
				{

				}
				break;
			case R.id.FollowedRb:
				((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(0);

				break;
			case R.id.Not_FollowedRb:
				((LinearLayout)findViewById(R.id.FertigationLL)).setVisibility(8);

				break;

			case R.id.borewellRb:
				((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.mi_nonfunctioningLL)).setVisibility(8);

				break;
			case R.id.non_functioningRb:
				((LinearLayout)findViewById(R.id.component_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.mi_nonfunctioningLL)).setVisibility(0);
				((LinearLayout)findViewById(R.id.mi_BoreWellLL)).setVisibility(8);

				((RadioButton)findViewById(R.id.borewellRb)).setChecked(false);

				break;
			case R.id.NonfunOtherCb:

				if(((CheckBox)findViewById(R.id.NonfunOtherCb)).isChecked())
				{
					((EditText)findViewById(R.id.NonfunOtherEt)).setVisibility(0);


					//				((CheckBox)findViewById(R.id.NonfunRepairsCb)).setChecked(false);
					//				((CheckBox)findViewById(R.id.NonfunDamageCb)).setChecked(false);
					//				((CheckBox)findViewById(R.id.NonfunCloggingCb)).setChecked(false);
					//				((CheckBox)findViewById(R.id.NonfunLateralsCb)).setChecked(false);
					//				((CheckBox)findViewById(R.id.NonfunValueCb)).setChecked(false);
					//				((CheckBox)findViewById(R.id.NonfunCouplersCb)).setChecked(false);
				}else if(!((CheckBox)findViewById(R.id.NonfunOtherCb)).isChecked())
				{
					((EditText)findViewById(R.id.NonfunOtherEt)).setVisibility(8);
					((EditText)findViewById(R.id.NonfunOtherEt)).setText("");
				}

				break;


			case R.id.ExistOthersRb:


				if(((CheckBox)findViewById(R.id.ExistOthersRb)).isChecked())
				{
					((EditText)findViewById(R.id.ExistOthersEt)).setVisibility(0);


					//					((CheckBox)findViewById(R.id.Crop_witheredawayRb)).setChecked(false);
					//					((CheckBox)findViewById(R.id.MI_systemsoldAwayRb)).setChecked(false);
					//					((CheckBox)findViewById(R.id.notExist_DamagedRb)).setChecked(false);
					//					((CheckBox)findViewById(R.id.notExist_TheftRb)).setChecked(false);

				}else if(!((CheckBox)findViewById(R.id.ExistOthersRb)).isChecked())
				{
					((EditText)findViewById(R.id.ExistOthersEt)).setVisibility(8);
					((EditText)findViewById(R.id.ExistOthersEt)).setText("");
				}
				break;

			case R.id.MiWaterSourceGpsBt:
				GetGpsCoordinates("WaterSourceGps");

				break;

			case R.id.MiHeadControlGpsBt:
				GetGpsCoordinates("HeadControlGps");

				break;

			case R.id.MiTraclingGpsBt:
				GetGpsCoordinates("TraclingGps");

				break;


			case R.id.Miphoto1IV:
				takePhoto();
				photoNo="one";

				break;

			case R.id.Miphoto2IV:
				takePhoto();
				photoNo="Two";
				break;

			case R.id.componentSpAdd:
				((Button) findViewById(R.id.componentSpRemove)).setVisibility(0);
				dynamic();
				break;

			case R.id.componentSpRemove:
				RemoveVoilation("componentSpRemove");
				break;

			default:
				break;
			}
		}
		catch(Exception e)
		{

		}
	}
	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		//dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);	  
		//Animation shake = AnimationUtils.loadAnimation(context, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		//yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				if(DialogType.equalsIgnoreCase("Submitted"))
				{
					startActivity(new Intent(MiSurveySystemAct.this, Get_FormerDetails.class));
				}				
				if(DialogType.equalsIgnoreCase("GPS Disable"))
				{
					launchGPSOptions();
					dialog.cancel();
				}else //if (DialogType.equalsIgnoreCase("FidStatus") || DialogType.equalsIgnoreCase("Take Photo") || DialogType.equalsIgnoreCase("Gps Coordinates") ||DialogType.equalsIgnoreCase("Submitted") ) 
				{
					//WebserviceCall.FidStatus="";
					dialog.dismiss();
				}
				//				else if (DialogType.equalsIgnoreCase("Gps Coordinates")) {
				//					dialog.dismiss();
				//				}else if(DialogType.equalsIgnoreCase("Submitted")){
				//					dialog.dismiss();
				//				}


				return;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}

	private void buildAlertMessageNoGps()
	{

		AlertDialog(context, "Your GPS seems to be disabled,Please enable it?","GPS Disable");

	}
	private void launchGPSOptions() 
	{


		Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		startActivity(intent);

		//		final ComponentName toLaunch = new ComponentName(
		//				"com.android.settings", "com.android.settings.SecuritySettings");
		//		final Intent intent = new Intent(
		//				Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		//		intent.addCategory(Intent.CATEGORY_LAUNCHER);
		//		intent.setComponent(toLaunch);
		//		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

	} 

	public void finalCheckboxData()
	{
		try
		{
			String notExist,nonfunctioning,fertigation;






			//		if (((RadioButton) findViewById(R.id.mi_nonFunStatusRb)).isChecked()) {
			//
			//			strSTATUSOFMISYSTEM="NF";
			//
			//
			//		}  
			if (((RadioButton) findViewById(R.id.notexist_No)).isChecked()) 
			{

				strSTATUSOFMISYSTEM="NE";


			}
			else if (((RadioButton) findViewById(R.id.mi_FunStatusRb)).isChecked()) {

				strSTATUSOFMISYSTEM="F";


			}
			else
			{
				strSTATUSOFMISYSTEM="NF";
			}
			///////

			if(((RadioButton) findViewById(R.id.mi_ExistStatusRb)).isChecked())
			{
				if(((RadioButton) findViewById(R.id.mi_FunStatusRb)).isChecked())
				{
					if (((RadioButton) findViewById(R.id.FollowedRb)).isChecked()) 
					{

						if(((RadioButton) findViewById(R.id.equipmentRb)).isChecked())
						{
							fertigation="Y-Y-N";
							strFUNCTIONAL=fertigation;
						}
						if(((RadioButton) findViewById(R.id.existingRb)).isChecked())
						{
							fertigation="Y-N-Y";
							strFUNCTIONAL=fertigation;
						}
					}else if (((RadioButton) findViewById(R.id.Not_FollowedRb)).isChecked()) {
						fertigation="N-N-N";
						strFUNCTIONAL=fertigation;


					}
					strNOTEXISTS=null;
					strNOTFUNCTIONING=null;
				}
				else
				{
					if (((RadioButton) findViewById(R.id.non_functioningRb)).isChecked()) 
					{
						nonfunctioning="N"+"-"+"N"+"-"+"N"+"-"+"N";
						if(((CheckBox) findViewById(R.id.NonfunRepairsCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((CheckBox) findViewById(R.id.NonfunDamageCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((CheckBox) findViewById(R.id.NonfunCloggingCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((CheckBox) findViewById(R.id.NonfunLateralsCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((CheckBox) findViewById(R.id.NonfunValueCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((CheckBox) findViewById(R.id.NonfunCouplersCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}

						if(!((CheckBox) findViewById(R.id.NonfunOtherCb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"N";
							strNOTFUNCTIONING=nonfunctioning;
						}else
						{
							nonfunctioning=nonfunctioning+"-"+((EditText) findViewById(R.id.NonfunOtherEt)).getText().toString();
							strNOTFUNCTIONING=nonfunctioning;
						}

					}

					if (((RadioButton) findViewById(R.id.borewellRb)).isChecked()) 
					{
						nonfunctioning="Y";
						if(((RadioButton) findViewById(R.id.DryingboreRb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((RadioButton) findViewById(R.id.transformerfailureRb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y";
						}else {
							nonfunctioning=nonfunctioning+"-"+"N";
						}
						if(((RadioButton) findViewById(R.id.MotorRepairRb)).isChecked())
						{
							nonfunctioning=nonfunctioning+"-"+"Y"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N";
							strNOTFUNCTIONING=nonfunctioning;
						}else {
							nonfunctioning=nonfunctioning+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N"+"-"+"N";
							strNOTFUNCTIONING=nonfunctioning;
						}



					}
					strNOTEXISTS=null;
					strFUNCTIONAL=null;
				}
			}
			else
			{
				if(((CheckBox) findViewById(R.id.notExist_TheftRb)).isChecked())
				{
					notExist="Y";
				}else {
					notExist="N";
				}
				if(((CheckBox) findViewById(R.id.notExist_DamagedRb)).isChecked())
				{
					notExist=notExist+"-"+"Y";
				}else {
					notExist=notExist+"-"+"N";
				}
				if(((CheckBox) findViewById(R.id.MI_systemsoldAwayRb)).isChecked())
				{
					notExist=notExist+"-"+"Y";
				}else {
					notExist=notExist+"-"+"N";
				}
				if(((CheckBox) findViewById(R.id.Crop_witheredawayRb)).isChecked())
				{
					notExist=notExist+"-"+"Y";
				}else {
					notExist=notExist+"-"+"N";
				}
				if(!((CheckBox) findViewById(R.id.ExistOthersRb)).isChecked())
				{
					notExist=notExist+"-"+"N";
					strNOTEXISTS=notExist;
				}else {
					notExist=notExist+"-"+((EditText) findViewById(R.id.ExistOthersEt)).getText().toString();
					strNOTEXISTS=notExist;
				}
				strNOTFUNCTIONING=null;
				strFUNCTIONAL=null;
			}

		}
		catch(Exception e)
		{

		}

	}

	public void FinalMiSubmit(View v)
	{

		SharedPreferences.Editor editor = getSharedPreferences("MY_PREFS_NAME",MODE_PRIVATE).edit();
		editor.putString("Miaoname",((EditText)findViewById(R.id.InvestigatorSp1)).getText().toString());	
		editor.putString("Deptname",((EditText)findViewById(R.id.DeptofficialSp1)).getText().toString());	
		editor.commit();

		try
		{

			MiMobile=MiMobileEt.getText().toString();
			if(((LinearLayout)findViewById(R.id.addmorecropll)).isShown())
			{
				if (((Spinner) findViewById(R.id.miCropTypeSp1)).getSelectedItem().toString().equalsIgnoreCase("---Select---")) {

					//AlertDialog(context, "Select Crop Type","Validation");
					((Spinner) findViewById(R.id.miCropTypeSp1)).requestFocusFromTouch();
					//((Spinner) findViewById(R.id.InvestigatorSp)).setBackgroundColor(R.color.red);

					return;

				} if (((Spinner) findViewById(R.id.miCropNameSp1)).getSelectedItem().toString().equalsIgnoreCase("---Select---")) {

					//AlertDialog(context, "Select Crop Name","Validation");
					((Spinner) findViewById(R.id.miCropNameSp1)).requestFocusFromTouch();
					//((Spinner) findViewById(R.id.InvestigatorSp)).setBackgroundColor(R.color.red);

					return;


				}  if (((EditText) findViewById(R.id.miextentEt1)).getText().toString().equalsIgnoreCase("")) 
				{
					((EditText) findViewById(R.id.miextentEt1)).setError("Enter Extent");
					((EditText) findViewById(R.id.miextentEt1)).requestFocus();
					return;
				}
				if (((EditText) findViewById(R.id.milateralEt1)).getText().toString().equalsIgnoreCase("")) 
				{
					((EditText) findViewById(R.id.milateralEt1)).setError("Enter Lateral Spacing");
					((EditText) findViewById(R.id.milateralEt1)).requestFocus();
					return;
				}

//				try
//				{
//					String temp=((EditText) findViewById(R.id.misancextentEt)).getText().toString();
//					double temp1=Double.parseDouble(temp);
//					String temp2=((EditText) findViewById(R.id.miextentEt)).getText().toString();
//					String temp3=((EditText) findViewById(R.id.miextentEt1)).getText().toString();
//					double temp4=Double.parseDouble(temp2)+Double.parseDouble(temp3);
//					if(temp1>temp4)
//					{
//						AlertDialog(context, "Sanctioned Extent is Greater Than Total Extent","");
//						((EditText) findViewById(R.id.misancextentEt)).requestFocus();
//						return;
//					}
//				}
//				catch(Exception e)
//				{
//
//				}
			}
//			else
//			{
//				try
//				{
//					String temp=((EditText) findViewById(R.id.misancextentEt)).getText().toString();
//					double temp1=Double.parseDouble(temp);
//					String temp2=((EditText) findViewById(R.id.miextentEt)).getText().toString();
//
//					double temp4=Double.parseDouble(temp2);
//					if(temp1>temp4)
//					{
//						AlertDialog(context, "Sanctioned Extent is Greater Than Total Extent ","");
//						((EditText) findViewById(R.id.misancextentEt)).requestFocus();
//						return;
//					}
//				}
//				catch(Exception e)
//				{
//
//				}
//			}
			if (MiMobileEt.getText().toString().equalsIgnoreCase("") || MiMobile.length()!=10) 
			{
				MiMobileEt.setError("Enter Valid Mobile No.");
				MiMobileEt.requestFocus();
				return;
			} else if (((EditText) findViewById(R.id.miDepthborewellEt)).getText().toString().equalsIgnoreCase("")) 
			{
				((EditText) findViewById(R.id.miDepthborewellEt)).setError("Enter Depth of Bore well");
				((EditText) findViewById(R.id.miDepthborewellEt)).requestFocus();
				return;
			}
			else if (((EditText) findViewById(R.id.miDepthborewellEt1)).getText().toString().equalsIgnoreCase("")) 
			{
				((EditText) findViewById(R.id.miDepthborewellEt1)).setError("Enter Discharge of Bore well");
				((EditText) findViewById(R.id.miDepthborewellEt1)).requestFocus();
				return;
			}
			else if (((Spinner) findViewById(R.id.miCropTypeSp)).getSelectedItem().toString().equalsIgnoreCase("---Select---")) {

				//AlertDialog(context, "Select Crop Type","Validation");
				((Spinner) findViewById(R.id.miCropTypeSp)).requestFocusFromTouch();
				//((Spinner) findViewById(R.id.InvestigatorSp)).setBackgroundColor(R.color.red);

				return;

			}else if (((Spinner) findViewById(R.id.miCropNameSp)).getSelectedItem().toString().equalsIgnoreCase("---Select---")) {

				//AlertDialog(context, "Select Crop Name","Validation");
				((Spinner) findViewById(R.id.miCropNameSp)).requestFocusFromTouch();
				//((Spinner) findViewById(R.id.InvestigatorSp)).setBackgroundColor(R.color.red);

				return;


			} else if (((EditText) findViewById(R.id.miextentEt)).getText().toString().equalsIgnoreCase("")) 
			{
				((EditText) findViewById(R.id.miextentEt)).setError("Enter Extent");
				((EditText) findViewById(R.id.miextentEt)).requestFocus();
				return;                                                                                                                                                                                                                                                                                           
			}
			else if(((EditText) findViewById(R.id.misancextentEt)).getText().toString().equalsIgnoreCase("")) 
			{
				((EditText) findViewById(R.id.misancextentEt)).setError("Enter Extent");
				((EditText) findViewById(R.id.misancextentEt)).requestFocus();
				return;
			}

			else if (((EditText) findViewById(R.id.milateralEt)).getText().toString().equalsIgnoreCase("")) 
			{
				((EditText) findViewById(R.id.milateralEt)).setError("Enter Lateral Spacing");
				((EditText) findViewById(R.id.milateralEt)).requestFocus();
				return;
			}

			//		else if (((RadioButton) findViewById(R.id.mi_nonFunStatusRb)).isChecked() &&((CheckBox) findViewById(R.id.NonfunOtherCb)).isChecked() && ((EditText) findViewById(R.id.NonfunOtherEt)).getText().toString().equalsIgnoreCase("")) 
			//		{
			//			((EditText) findViewById(R.id.NonfunOtherEt)).setError("Enter Non Functioning Other");
			//			((EditText) findViewById(R.id.NonfunOtherEt)).requestFocus();
			//			return;
			//		}
			else if (((RadioButton) findViewById(R.id.mi_ExistStatusRb)).isChecked() && ((CheckBox) findViewById(R.id.ExistOthersRb)).isChecked() && ((EditText) findViewById(R.id.ExistOthersEt)).getText().toString().equalsIgnoreCase("")) 
			{
				((EditText) findViewById(R.id.ExistOthersEt)).setError("Enter Not Exist Others");
				((EditText) findViewById(R.id.ExistOthersEt)).requestFocus();
				return;
			}
			else if(CapurePhotos.size()<2)
			{
				AlertDialog(context, "Please Capture Photo","Take Photo");
			}else if ((MiWaterSource_La.getText().toString()).equalsIgnoreCase("La-0.0") || (MiWaterSource_La.getText().toString()).equalsIgnoreCase("") || (MiWaterSource_La.getText().toString()).equalsIgnoreCase("null"))
			{
				AlertDialog(context, "Get WaterSource GPS","Take Photo");
			}
			else if ((MiHeadcontrol_La.getText().toString()).equalsIgnoreCase("La-0.0") || (MiHeadcontrol_La.getText().toString()).equalsIgnoreCase("null") || (MiHeadcontrol_La.getText().toString()).equalsIgnoreCase("")) 
			{
				AlertDialog(context, "Get Head Control Unit GPS","Gps Coordinates");
			}else if ((MiTrackling_La.getText().toString()).equalsIgnoreCase("null") || (MiTrackling_La.getText().toString()).equalsIgnoreCase("La-0.0") || (MiTrackling_La.getText().toString()).equalsIgnoreCase("")) 
			{
				AlertDialog(context, "Get Tracking of Field GPS","Gps Coordinates");

			}

			else {



				miplace=((EditText) findViewById(R.id.miplaceEt)).getText().toString();
				InvestgatorName=strInvestigatorDetails+"-"+miplace;
				DeptStaffName=strDeptOfficialDetails+"-"+miplace;
				strdischargevalue=((EditText) findViewById(R.id.miDepthborewellEt)).getText().toString();
				strdischargevalue=strdischargevalue+"-"+((EditText) findViewById(R.id.miDepthborewellEt1)).getText().toString();
				//strCROP=((EditText) findViewById(R.id.microp)).getText().toString();
				strAREAPROPOSED=((EditText) findViewById(R.id.miextentEt)).getText().toString();
				strLateral_space=((EditText) findViewById(R.id.milateralEt)).getText().toString();
				if(((LinearLayout)findViewById(R.id.addmorecropll)).isShown())
				{
					strAREAPROPOSED1=((EditText) findViewById(R.id.miextentEt1)).getText().toString();
					strLateral_space1=((EditText) findViewById(R.id.milateralEt1)).getText().toString();
				}
				else
				{
					strAREAPROPOSED1="0";
					strLateral_space1="0";
					strCROP1="";
					strCROPTYPE1="";
				}
				//LogoutAlert("do you want confirm this Details?","proceed");
				finalCheckboxData();

				strComponentDetails="";
				if (!(ComponentDetails_Al.isEmpty() || ((RadioButton)findViewById(R.id.notexist_No)).isChecked())) {
					float totalamounts = 0;
					String dd = null;
					for (int i = 0; i < ComponentDetails_Al.size(); i++) {
						ArrayList<View> localArrayListb = new ArrayList<View>();
						localArrayListb.addAll(ComponentDetails_Al.get(i));

						for (int j = 0; j < localArrayListb.size(); j++) {

							if (j == 0 || j==1)
							{
								Spinner tv1 = (Spinner) localArrayListb.get(j);
								if(tv1.getSelectedItem().toString().equalsIgnoreCase("---Select---"))
								{
									//System.out.println("-----------aa-");
									if(j==0)
									{
										AlertDialog(context, "Select Component Name", "hh");
										return;
									}
									else
									{
										AlertDialog(context, "Select Component Size", "hh");
										return;
									} 
								}else
								{
									if(j==0)
									{
										dd=tv1.getSelectedItem().toString();
									}
									else
									{
										dd=dd+"-"+tv1.getSelectedItem().toString();
									}

								}

							} else {
								EditText tv = (EditText) localArrayListb.get(j);
								if(j==3 && tv.getText().toString().equals(""))
								{
									AlertDialog(context, "Enter Component Quantity ", "hh");
									return;
								}
								dd = dd + "-" + tv.getText().toString();
							}

						}
						if(i<(ComponentDetails_Al.size()-1))
						{
							strComponentDetails = strComponentDetails+dd + "|";
						}
						else
						{
							strComponentDetails = strComponentDetails+dd ;
						}

						System.out.println("----"+strComponentDetails.toString());
						totalamounts=totalamounts+Float.parseFloat(((TextView)localArrayListb.get(4)).getText().toString());
						caltot=totalamounts;

					}
					caltot=caltot+Float.parseFloat(((TextView)findViewById(R.id.mi_transport_cost)).getText().toString());

					
					subsidy =  (50.0f/100.0f)*caltot ;
					nonsubsidy=(50.0f/100.0f)*caltot ;
					vat=(5f/100.0f)*caltot;
					totalnonsubsidy= vat+nonsubsidy; 
				}
				else
				{
					caltot=0;
					strComponentDetails="";
					subsidy=0;
					nonsubsidy=0;
					vat=0;
					totalnonsubsidy=0;
				}

				//				if (((Spinner) findViewById(R.id.InvestigatorSp)).getSelectedItem().toString().equalsIgnoreCase("---Select---")) 
				//				{
				//
				//					//AlertDialog(context, "Select Investigator Name","Validation");
				//					((Spinner) findViewById(R.id.InvestigatorSp)).requestFocusFromTouch();
				//					//((Spinner) findViewById(R.id.InvestigatorSp)).setBackgroundColor(R.color.red);
				//
				//					return;
				//
				//				}
				//				else if (((Spinner) findViewById(R.id.DeptofficialSp)).getSelectedItem().toString().equalsIgnoreCase("---Select---"))
				//				{
				//					//AlertDialog(context, "Select Dept. official Name","Validation");
				//
				//					((Spinner) findViewById(R.id.DeptofficialSp)).requestFocusFromTouch();
				//					//((Spinner) findViewById(R.id.DeptofficialSp)).setBackgroundColor(R.color.red);
				//
				//					return;
				//
				//				}
				if (((EditText) findViewById(R.id.InvestigatorSp1)).getText().toString().equalsIgnoreCase("")) 
				{
					((EditText) findViewById(R.id.InvestigatorSp1)).setError("Enter MIAO Name");
					((EditText) findViewById(R.id.InvestigatorSp1)).requestFocus();
					return;
				}
				else if (((EditText) findViewById(R.id.DeptofficialSp1)).getText().toString().equalsIgnoreCase("")) 
				{
					((EditText) findViewById(R.id.DeptofficialSp1)).setError("Enter MIC Representative Name");
					((EditText) findViewById(R.id.DeptofficialSp1)).requestFocus();
					return;
				}
				else if (((EditText) findViewById(R.id.miplaceEt)).getText().toString().equalsIgnoreCase("")) 
				{
					((EditText) findViewById(R.id.miplaceEt)).setError("Enter Place");
					((EditText) findViewById(R.id.miplaceEt)).requestFocus();
					return;
				}
				//			System.out.println("--status---"+strSTATUSOFMISYSTEM);
				//			System.out.println("---func--"+MiSurveySystemAct.strFUNCTIONAL);
				//			System.out.println("--notexist---"+MiSurveySystemAct.strNOTEXISTS);
				//			System.out.println("-notfunc= ----"+MiSurveySystemAct.strNOTFUNCTIONING);
				strInvestigatorDetails1=((EditText) findViewById(R.id.InvestigatorSp1)).getText().toString();
				strDeptOfficialDetails1=((EditText) findViewById(R.id.DeptofficialSp1)).getText().toString();
				strsanctioned_area=((EditText) findViewById(R.id.misancextentEt)).getText().toString();
				if(((TextView)findViewById(R.id.mi_transport_cost)).getVisibility()==View.VISIBLE)
				{
					strtranspotationcost=((TextView)findViewById(R.id.mi_transport_cost)).getText().toString();
				}
				else
				{
					strtranspotationcost="";
				}
				if(CheckConnection.isNetworkAvailable(MiSurveySystemAct.this))
				{
					Loaddata("InsertInspectionDetails");
				}else {
					//select DISTINCT Staff_ID from InspectionStaffDetails where Staff_Name='hari' and User_Name='miaouser'
					try
					{
						db.open();
						strInvestigatorDetails=db.getSingleValue("select Staff_ID from InspectionStaffDetails where Staff_Name='"+strInvestigatorDetails+"'");
						strDeptOfficialDetails=	db.getSingleValue("select Staff_ID from InspectionStaffDetails where Staff_Name='"+strDeptOfficialDetails+"'");
						DeptStaffName=strDeptOfficialDetails1+"-"+miplace;
						InvestgatorName=strInvestigatorDetails1+"-"+miplace;
						db.close();
					}
					catch(Exception e)
					{
						Toast toast = null;
						toast=Toast.makeText(MiSurveySystemAct.this, "Please Download Offline Data",Toast.LENGTH_LONG);
						View view = toast.getView();
						toast.setGravity(Gravity.BOTTOM, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
						return;
					}
					DecimalFormat df = new DecimalFormat("#.##");
					ContentValues cv=new ContentValues();
					cv.put("MobileNumber",MiMobile );cv.put("Dischargevalue",strdischargevalue );cv.put("Survey_CROP",strCROP );cv.put("Area_Proposed",strAREAPROPOSED );
					cv.put("Survey_STATUSOFMISYSTEM", strSTATUSOFMISYSTEM);cv.put("FarmerFieldPhoto1",CapurePhotos.get("photoOne") );cv.put("FarmerFieldPhoto2",CapurePhotos.get("photoTwo") );cv.put("WaterSource_GPS_Coordinates",waterSource_LaLg );cv.put("HeadControlUnit_GPS_Coordinates",Headcontrol_LaLg );
					cv.put("TrackingOfTheField_GPS_Coordinates",Trackling_LaLg );cv.put("Survey_FUNCTIONAL",strFUNCTIONAL );cv.put("Survey_NOTEXISTS", strNOTEXISTS);cv.put("Survey_NOTFUNCTIONING",strNOTFUNCTIONING );cv.put("Survey_InvestigatorDetails",InvestgatorName );cv.put("Survey_DeptOfficialDetails", DeptStaffName);cv.put("Survey_ComponentDetails",strComponentDetails );cv.put("Status_Flag","P" );
					cv.put("CropName",miCropNameSp.getSelectedItem().toString());
					cv.put("totalamount",df.format(caltot));
					cv.put("subsidyamount",df.format(subsidy));
					cv.put("nonsubsidyamount",df.format(nonsubsidy));
					cv.put("vat",df.format(vat));
					cv.put("totalnonsubsidyamount",df.format(totalnonsubsidy));
					cv.put("Lateral_space",strLateral_space);
					cv.put("Lateral_space1",strLateral_space1);
					cv.put("Area_Proposed1",strAREAPROPOSED1);
					cv.put("Survey_CROP1",strCROP1);
					cv.put("CROP_TYPE",strCROPTYPE);
					cv.put("CROP_TYPE1",strCROPTYPE1);
					cv.put("TRANSPORT_COST",strtranspotationcost);
					cv.put("SANCTIONED_EXTENT",strsanctioned_area);
					db.open();
					boolean staus=db.updateTableData("APMIP_FARMER_DETAILS", cv, "Status_Flag='N' and FarmerId='"+MIFarmer_ID+"' and User_ID='"+Login_Page.UserId+"'");
					db.close();
					if(staus==true)
					{
						AlertDialog(context, "Successfully Submitted","Submitted");
					}
					else
					{
						Toast toast = null;
						toast=Toast.makeText(MiSurveySystemAct.this, "Please Download Offline Data",Toast.LENGTH_LONG);
						View view = toast.getView();
						toast.setGravity(Gravity.BOTTOM, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}

					//								db.execSQL("UPDATE APMIP_FARMER_DETAILS set MobileNumber='"+MiMobile+"',Dischargevalue='"+strdischargevalue+"',Survey_CROP='"+strCROP+"',Area_Proposed='"+strAREAPROPOSED+"'" +
					//										",Survey_STATUSOFMISYSTEM='"+strSTATUSOFMISYSTEM+"',FarmerFieldPhoto1='"+CapurePhotos.get("photoOne")+"',FarmerFieldPhoto2='"+CapurePhotos.get("photoTwo")+"',WaterSource_GPS_Coordinates='"+waterSource_LaLg+"',HeadControlUnit_GPS_Coordinates='"+Headcontrol_LaLg+"'," +
					//												"TrackingOfTheField_GPS_Coordinates='"+Trackling_LaLg+"',Survey_FUNCTIONAL='"+strFUNCTIONAL+"',Survey_NOTEXISTS='"+strNOTEXISTS+"',Survey_NOTFUNCTIONING='"+strNOTFUNCTIONING+"',Survey_InvestigatorDetails='"+InvestgatorName+"',Survey_DeptOfficialDetails='"+DeptStaffName+"',Survey_ComponentDetails='"+strComponentDetails+"',Status_Flag='p' where Status_Flag='N' and FarmerId='"+MIFarmer_ID+"' and User_ID='"+Login_Page.UserId+"'");
					//								db.close();
				}


			}
		}
		catch(Exception e)
		{

		}
	}
	public void onBackPressed()
	{
		startActivity(new Intent(MiSurveySystemAct.this,Get_FormerDetails.class));
		finish();
	}
}
