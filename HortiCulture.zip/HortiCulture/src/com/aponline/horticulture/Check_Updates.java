package com.aponline.horticulture;


import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.WebserviceCall;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.location.Location;
import android.location.LocationListener;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.widget.Toast;


public class Check_Updates extends Activity implements LocationListener
{

	Context context;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	String versionName = "Version not found";


	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==15)
				{
					//Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id="+ Check_Updates.this.getPackageName()));

					if((Float.parseFloat(versionName))<(Float.parseFloat(WebserviceCall.VersionNo)))
					{
						Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id="+ Check_Updates.this.getPackageName()));
						
						Check_Updates.this.startActivity(localIntent);
						Check_Updates.this.finish();
						return;
						
					}else {
						startActivity(new Intent(Check_Updates.this, Login_Page.class));
						Check_Updates.this.finish();
					}
				}



				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast.makeText(Check_Updates.this, "No New Data",Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Check_Updates.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Check_Updates.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Check_Updates.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		//progressDialog.setCancelable(false);
		//progressDialog.setMessage("Please Wait.......");
		//progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}


	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		context=this;
		setContentView(R.layout.splash_screen);
		try {
			if(CheckConnection.isNetworkAvailable(Check_Updates.this))
			{
				versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
				Loaddata("Check_Version");
			}else {
				startActivity(new Intent(Check_Updates.this,Login_Page.class));
				Check_Updates.this.finish();
			}
			
		} catch (NameNotFoundException e) {
			
			e.printStackTrace();
		}

		
		
		
		
//		LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
//		boolean enabled = service.isProviderEnabled(LocationManager.GPS_PROVIDER);
//		if (!enabled) {
//			  Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//			  startActivity(intent);
//			} 

//		try {
//			versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
//			
//			if(Float.parseFloat(versionName)<1.0)
//			{
//				Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.aponline.sgis")); //+ SplashScreen.this.getPackageName()));
//				startActivity(localIntent);
//				finish();
//			}else {
//				startActivity(new Intent(Check_Updates.this, Login_Page.class));
//				Check_Updates.this.finish();
//				
//				
//			}
//
//		} catch (NameNotFoundException e) 
//		{
//			
//			e.printStackTrace();
//
//		}

		//Loaddata("Check_Version");
	}


	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
}
