package com.aponline.horticulture;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.aponline.Hc.database.DBAdapter;
import com.aponline.Hc.server.CheckConnection;
import com.aponline.Hc.server.RequestAadhaar;
import com.aponline.Hc.server.ServerResponseListener;
import com.aponline.rdservices.model.PidData;
import com.aponline.rdservices.model.Resp;

public class Farmer_Authentication extends AppCompatActivity implements ServerResponseListener
{
	RequestAadhaar nAadhaar;

	String aadharNo="";
	int aadhaarAttempt=1;

	Context context;
	DBAdapter db;
	ActionBar ab;
	EditText farmer_auth_aaadhar_no,farmer_auth_pincode,farmer_auth_martial_aadhar_no;
	RadioButton martial_status_y,martial_status_n,martial_status_widow;
	Button farmer_auth_scan_btn;
	String aadhaarID,maritalStatus,pincode,spouseAadahrno;
	RadioGroup farmer_auth_maritalStatus_rg;
	CheckBox aadharck,spouseaadharck;
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
			super.onCreate(savedInstanceState);
			context=this;
			db=new DBAdapter(this);
			nAadhaar=new RequestAadhaar();
			setContentView(R.layout.farmer_auth);
			this.ab=getSupportActionBar();
			this.ab.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.menu_bg));
			this.ab.setTitle("Farmer Authentication");
			martial_status_y=(RadioButton)findViewById(R.id.farmer_auth_martial_status_Y);
			martial_status_n=(RadioButton)findViewById(R.id.farmer_auth_martial_status_N);
			martial_status_widow=(RadioButton)findViewById(R.id.farmer_auth_martial_status_widow);
			farmer_auth_aaadhar_no=(EditText)findViewById(R.id.farmer_auth_aaadhar_no);
			farmer_auth_pincode=(EditText)findViewById(R.id.farmer_auth_pincode);
			farmer_auth_scan_btn=(Button)findViewById(R.id.farmer_auth_scan_btn);
			farmer_auth_martial_aadhar_no=(EditText)findViewById(R.id.farmer_auth_martial_aadhar_no);
			farmer_auth_maritalStatus_rg=(RadioGroup)findViewById(R.id.farmer_auth_maritalStatus_rg);
		aadharck=(CheckBox)findViewById(R.id.farmer_auth_aaadhar_no_ck);
		spouseaadharck=(CheckBox)findViewById(R.id.farmer_auth_martial_aadhar_no_ck);
		aadharck.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked) {
                	farmer_auth_aaadhar_no.setTransformationMethod(new PasswordTransformationMethod());
                	//farmer_auth_aaadhar_no.setInputType(InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                	
                } else {
                	
                	farmer_auth_aaadhar_no.setTransformationMethod(null);
                }
            }
        });
		spouseaadharck.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked) {
                	farmer_auth_martial_aadhar_no.setTransformationMethod(new PasswordTransformationMethod());
                	//farmer_auth_martial_aadhar_no.setInputType(InputType.TYPE_CLASS_NUMBER|129);
                	
                } else {
                	farmer_auth_martial_aadhar_no.setTransformationMethod(null);
                	//farmer_auth_martial_aadhar_no.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                }
            }
        });
			martial_status_y.setOnCheckedChangeListener(new OnCheckedChangeListener()
			{

				@Override
				public void onCheckedChanged(CompoundButton arg0, boolean arg1)
				{
					if(arg1==true)
					{
						((EditText)findViewById(R.id.farmer_auth_martial_aadhar_no)).setVisibility(0);
						spouseaadharck.setVisibility(0);
						((EditText)findViewById(R.id.farmer_auth_martial_aadhar_no)).requestFocus();
					}
					else
					{
						((EditText)findViewById(R.id.farmer_auth_martial_aadhar_no)).setVisibility(8);
						((EditText)findViewById(R.id.farmer_auth_martial_aadhar_no)).setText("");
						spouseaadharck.setChecked(false);
					}					
				}
			});
			farmer_auth_scan_btn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) 
				{
					if(farmer_auth_aaadhar_no.getText().toString().equalsIgnoreCase(""))
					{
						farmer_auth_aaadhar_no.setError("Enter Aadhaar No");
						farmer_auth_aaadhar_no.requestFocus();
						return;
					}
					else
					{
						if(farmer_auth_aaadhar_no.getText().toString().length()<12)
						{
							farmer_auth_aaadhar_no.setError("Enter 12 digit Aadhaar No");
							farmer_auth_aaadhar_no.requestFocus();
							return;
						}
						else
						{
							aadhaarID=farmer_auth_aaadhar_no.getText().toString().trim();
						}

					}
					if(farmer_auth_pincode.getText().toString().equalsIgnoreCase(""))
					{
						farmer_auth_pincode.setError("Enter Pincode");
						farmer_auth_pincode.requestFocus();
						return;
					}
					else
					{
						if(farmer_auth_pincode.getText().toString().length()<6)
						{
							farmer_auth_pincode.setError("Enter 6 digit Pincode");
							farmer_auth_pincode.requestFocus();
							return;
						}
						else
						{
							pincode=farmer_auth_pincode.getText().toString().trim();
						}
					}
					if (farmer_auth_maritalStatus_rg.getCheckedRadioButtonId() == -1)
					{
						Toast.makeText(Farmer_Authentication.this, "Please select Marital Status", Toast.LENGTH_SHORT).show();
						return;
					}
					else
					{
						if(martial_status_y.isChecked())
						{
							maritalStatus="Y";
							if(farmer_auth_martial_aadhar_no.getText().toString().equalsIgnoreCase(""))
							{

								farmer_auth_martial_aadhar_no.setError("Enter Aadhaar No");
								farmer_auth_martial_aadhar_no.requestFocus();
								return; 
							}
							else
							{
								if(farmer_auth_martial_aadhar_no.getText().toString().length()<12)
								{
									farmer_auth_martial_aadhar_no.setError("Enter 12 digit Aadhaar No");
									farmer_auth_martial_aadhar_no.requestFocus();
									return;
								}
								else
								{
									spouseAadahrno=farmer_auth_martial_aadhar_no.getText().toString().trim();
								}  
							}
						}
						else
						{
							if(martial_status_n.isChecked())
							{
								spouseAadahrno="";
								maritalStatus="N";
							}
							else if (martial_status_widow.isChecked()) 
							{
								spouseAadahrno="";
								maritalStatus="W";
							}
						}

					}
					if(farmer_auth_martial_aadhar_no.getVisibility()==View.VISIBLE)
					{
						if(spouseAadahrno.equalsIgnoreCase(aadhaarID))
						{
							Dialogs.AlertDialogs(Farmer_Authentication.this,"Information!!","Aadhar No and Spouse Aadhar No should not be same");
							return;
						}
					}
					if(!CheckConnection.isNetworkAvailable(context))
					{
						Toast toast = null;
						toast=Toast.makeText(Farmer_Authentication.this, "Check Internet Connection",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
						return;
					}
					((LinearLayout)findViewById(R.id.aadhar_details)).setVisibility(8);
					boolean check=isAppInstalled(context,"com.acpl.registersdk");
					boolean check1=isAppInstalled(context,"com.secugen.rdservice"); 
					if(check || check1)
					{
						userAuthentication();
					}
					else
					{
						Dialogs.AlertDialogs(Farmer_Authentication.this,"Bio-Device Information!!","Please Install FM220 Registered Device App from PlayStore for Startek"
								+ " or SecuGen Rd Service for Secugen");
					}
				}
			});
		}
		catch(Exception e)
		{

		}
	}



	PidData pidData;

	public  boolean isAppInstalled(Context context, String packageName) {
		try {
			context.getPackageManager().getApplicationInfo(packageName, 0);
			return true;
		}
		catch (PackageManager.NameNotFoundException e) {
			return false;
		}
	}
	public void onActivityResult(int requestCode, int resultCode, Intent intent) 
	{
		if(requestCode == 2)
		{
			if (resultCode == Activity.RESULT_OK) 
			{
				try 
				{
					if (intent != null) 
					{
						String result = intent.getStringExtra("PID_DATA"); 
						if (result != null) 
						{
							try 
							{
								CommonFunctions.writeLog(this, "PidData", result);

								Serializer serializer = new Persister();
								pidData = serializer.read(PidData.class, result);

								Resp deviceResp=pidData._Resp;

								if(deviceResp.errCode.equalsIgnoreCase("0"))					
								{
									//nAadhaar.Verify(this,this,  "Insert_Authenticate_FarmerRegistration", pidData, aadharNo, userID, HomeData.UserID, aadhaarAttempt+"FA", "FMR",User_Type);
									nAadhaar.Verify(this, this,  "Insert_Authenticate_FarmerRegistration", pidData, aadhaarID, maritalStatus, pincode, spouseAadahrno, aadhaarAttempt+"FA", "FMR");
								}
								else
								{
									Dialogs.AlertDialogs(this,"Bio-Device Information!!",deviceResp.errInfo);
								}


							}
							catch (Exception e) 
							{
								CommonFunctions.writeLog(this, "fpCaptureSuccess", e.getMessage());
								e.printStackTrace();
								Dialogs.AlertDialogs(this,"Bio-Device Information!!",e.getMessage());
							}	

						}
						else
						{
							Dialogs.AlertDialogs(this,"Bio-Device Information!!","Data not found");
						}                          
					}
				}
				catch (Exception e) 
				{
					Log.e("Error", "Error while deserialize pid data", e);
					Dialogs.AlertDialogs(this,"Bio-Device Information!!",e.getMessage());
				}
			}
		}
	} 


	protected void userAuthentication()
	{
		try 
		{
			
			PackageManager pm = getPackageManager();			
			Intent intent = new Intent();
			String pidOption = RequestAadhaar.getPIDOptions("FMR");
			CommonFunctions.writeLog(this, "userAuthentication", pidOption);

			if (pidOption != null) 
			{				
				intent.setAction("in.gov.uidai.rdservice.fp.CAPTURE");
				intent.putExtra("PID_OPTIONS",pidOption);
				startActivityForResult(intent, 2);
			}

		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}


	protected void ValidateAadharResponse(String response)
	{

		try 
		{
			if(response.contains(","))
			{
				String data[]=response.split(",");
				String resType=data[0];
				if(resType.equalsIgnoreCase("FINGER_AUTH"))
				{
					if(data[2].equalsIgnoreCase("Success"))
					{
						Toast.makeText(Farmer_Authentication.this,"Success",Toast.LENGTH_LONG).show();
					}

					else
					{
						if(aadhaarAttempt >= 3 )
						{
							aadhaarAttempt=1;
							aadharNo="";
						}
						else
						{
							aadhaarAttempt++;
							userAuthentication();
						}
					}
				}
			}
			else
			{
				Dialogs.AlertDialog(this, response);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}

	}

	@Override
	public void Success(String response) 
	{
		//ValidateAadharResponse(response);
		if(response.equalsIgnoreCase("Sucessfully Authenticated"))
		{
			try
			{
				((LinearLayout)findViewById(R.id.aadhar_details)).setVisibility(0);
				String temp=RequestAadhaar.aadhar_result;
				String temp1[]=temp.split("_");
				if(temp1.length==8)
				{
					CommonFunctions.writeLog(Farmer_Authentication.this, "string split",String .valueOf(temp1.length));
					((TextView)findViewById(R.id.farmer_auth_aadhar)).setText(temp1[0]);
					((TextView)findViewById(R.id.farmer_auth_farmer_name)).setText(temp1[1]);
					((TextView)findViewById(R.id.farmer_auth_father)).setText(temp1[2]);
					((TextView)findViewById(R.id.farmer_auth_address)).setText(temp1[3]+","+temp1[4]+","+temp1[5]);
					((TextView)findViewById(R.id.farmer_auth_application_no)).setText(temp1[7]);
				}
			}
			catch(Exception e)
			{
				CommonFunctions.writeLog(Farmer_Authentication.this, "aadhar exception",e.getMessage());
			}

		}
		Dialogs.AlertDialog(this,"Response: "+response);	
	}


	@Override
	public void Fail(String response)
	{
		Dialogs.AlertDialog(this,response);			
	}


	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialog(this, "Network not Available, Please try again!!");	
	}


	@Override
	public void AppUpdate() 
	{

	}


}
