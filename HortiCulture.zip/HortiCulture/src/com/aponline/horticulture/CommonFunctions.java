package com.aponline.horticulture;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import android.content.ContentValues;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

public class CommonFunctions 
{

	public static void writeLog(Context context,String methodName,String strLog) 
	{

		try 
		{
			String className=context.getClass().getSimpleName();
			boolean isNewFile = false;
			String Dir = Environment.getExternalStorageDirectory().getPath()+ "/Aadhar_Auth/ErrorLog/"+className+"/";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHH");
			String FileNameFormate = dateFormat.format(new Date());
			String FileName = Dir + "/"+methodName+"_" + FileNameFormate +".txt";

			SimpleDateFormat logTimeFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
			String logTime = logTimeFormat.format(new Date());
			File dir = new File(Dir);
			if (!dir.exists()) 
			{
				dir.mkdirs();
			}
			File logFile = new File(FileName);
			if (!logFile.exists())
			{
				isNewFile = true;
				logFile.createNewFile();
			}
			FileOutputStream fOut;
			OutputStreamWriter myOutWriter;
			fOut = new FileOutputStream(logFile, true);
			myOutWriter = new OutputStreamWriter(fOut);
			if (isNewFile)
			{
				myOutWriter.append(logTime + " " + strLog);
			} 
			else 
			{
				myOutWriter.append("\n" + logTime + " " + strLog);
			}
			myOutWriter.flush();
			myOutWriter.close();
		} 
		catch (Exception ex)
		{

		}
	}

	public static ArrayList<HashMap<String,String>> LoadXmlDataToMap(String stringXml,String MainTag,List<String> elementList)
	{
		ArrayList<HashMap<String,String>> root=new ArrayList<HashMap<String,String>>();
		HashMap<String, String> person=new HashMap<String, String>();

		Document doc=convertStringToDocument(stringXml);

		Element docElem = (Element)doc.getDocumentElement();//doc.documentElement();
		NodeList nodeList=docElem.getElementsByTagName(MainTag);
		if(nodeList.getLength()==0)
		{
			Log.d("Inside", "Inside No Tag");
			person.put("ERROR","NO DATA FOUND");
			root.add(person);
			return root;
		}
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			person=new HashMap<String, String>();
			Element element = (Element) nodeList.item(i);
			for(int j=0;j<elementList.size();j++)	
			{
				String key=elementList.get(j);
				NodeList name = element.getElementsByTagName(key);
				Element line = (Element) name.item(0);
				String value=getCharacterDataFromElement(line);

				person.put(key, value);
			}
			root.add(person);
		}
		return root;
	}
	public static ArrayList<ContentValues> LoadXmlDataToContentValue(String stringXml,String MainTag,List<String> elementList)
	{
		ArrayList<ContentValues> root=new ArrayList<ContentValues>();
		ContentValues person=new ContentValues();

		Document doc=convertStringToDocument(stringXml);

		Element docElem = (Element)doc.getDocumentElement();//doc.documentElement();
		NodeList nodeList=docElem.getElementsByTagName(MainTag);
		if(nodeList.getLength()==0)
		{
			Log.d("Inside", "Inside No Tag");
			person.put("ERROR","NO DATA FOUND");
			root.add(person);
			return root;
		}
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			person=new ContentValues();
			Element element = (Element) nodeList.item(i);
			for(int j=0;j<elementList.size();j++)	
			{
				String key=elementList.get(j);
				NodeList name = element.getElementsByTagName(key);
				Element line = (Element) name.item(0);
				String value=getCharacterDataFromElement(line);

				person.put(key, value);
			}
			root.add(person);
		}
		return root;
	}
	private static Document convertStringToDocument(String xmlStr) 
	{
		//		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
		//		DocumentBuilder builder;  
		//		try 
		//		{  
		//			builder = factory.newDocumentBuilder();  
		//			Document doc = (Document) builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
		//			return doc;
		//		} catch (Exception e)
		//		{  
		//			e.printStackTrace();  
		//		} 
		DocumentBuilder db;
		try 
		{
			db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xmlStr));

			Document doc = (Document)db.parse(is);
			return doc;
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	public static String getSingleValueFromXML(String stringXML,String tag) 
	{
		Document doc=convertStringToDocument(stringXML);
		Element docElem = (Element)doc.getDocumentElement();
		NodeList nodeList=docElem.getElementsByTagName(tag);
		Element element = (Element) nodeList.item(0);
		if (element instanceof CharacterData)
		{
			CharacterData cd = (CharacterData) element;
			return cd.getData();
		}
		return "";
	}
	public static Boolean checkXmlTag(String stringXML,String tag) 
	{
		Document doc=convertStringToDocument(stringXML);
	//	Element docElem = (Element)doc.getDocumentElement();
		NodeList nodeList=doc.getElementsByTagName(tag);
		if(nodeList.getLength()==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	private static String getCharacterDataFromElement(Element e) 
	{
		Node child = e.getFirstChild();
		if (child instanceof CharacterData)
		{
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}
	
	public static void writeFile(byte[] data, File fileName) throws IOException
	{

		File file =fileName;
		boolean deleted = file.delete();
		FileOutputStream out = new FileOutputStream(fileName);
		out.write(data);
		out.close();
	}
	public static void writeFile(String data, File fileName) throws IOException
	{

		File file =fileName;
		boolean deleted = file.delete();
//		FileOutputStream out = new FileOutputStream(fileName);
//		out.write(data);
//		out.close();
		
		FileOutputStream fOut;
		OutputStreamWriter myOutWriter;
		fOut = new FileOutputStream(file, true);
		myOutWriter = new OutputStreamWriter(fOut);
//		if (isNewFile)
//		{
//			myOutWriter.append(logTime + " " + strLog);
//		} 
//		else 
//		{
//			myOutWriter.append("\n" + logTime + " " + strLog);
//		}
		myOutWriter.flush();
		myOutWriter.close();
	} 
		
		
		
		
		
	
	public static boolean createDirIfNotExists(String path) 
	{
		boolean ret = true;

		File file = new File(path);
		if (!file.exists()) 
		{
			if (!file.mkdirs()) 
			{
				ret = false;
			}
		}
		return ret;
	}
	
//	public static boolean validateAadharNumber(String aadharNumber)
//	{
//		Pattern aadharPattern = Pattern.compile("\\d{12}");
//		boolean isValidAadhar = aadharPattern.matcher(aadharNumber).matches();
//		if(isValidAadhar)
//		{
//			isValidAadhar = VerhoeffAlgorithm.validateVerhoeff(aadharNumber);
//		}
//		return isValidAadhar;
//	} 
}
