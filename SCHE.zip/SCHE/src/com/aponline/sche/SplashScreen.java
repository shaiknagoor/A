package com.aponline.sche;




import com.aponline.sche.server.RequestServer;
import com.aponline.sche.server.ServerResponseListener;
import com.aponline.sche.server.WebserviceCall;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class SplashScreen extends AppCompatActivity implements ServerResponseListener
{
	ImageView home_icon;
	int versionName;
	Context mcontext;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splashscreen);
		mcontext=this;
		home_icon=(ImageView)findViewById(R.id.home_splash);
		home_icon.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				   Intent mainIntent = new Intent(SplashScreen.this,Login.class);
			          startActivity(mainIntent);
			        finish();
				
			}
		});
	
		try {
			 versionName = mcontext.getPackageManager().getPackageInfo(mcontext.getPackageName(), 0).versionCode;
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestServer request=new RequestServer(mcontext);
		request.addParam("Username", "APSCHE");
		request.addParam("Password","APSCHETAB");
		request.ProccessRequest(SplashScreen.this,"GetVersionJSON");
	}
	@Override
	public void Success(String response) {
		if(versionName<(WebserviceCall.VersionNo))
		{
			Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id="+ SplashScreen.this.getPackageName()));
			
			SplashScreen.this.startActivity(localIntent);
			SplashScreen.this.finish();
			return;
			
		}
		
	}
	@Override
	public void Fail(String response) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void NetworkNotAvail() {
		Toast toast = null;
		toast=Toast.makeText(SplashScreen.this, "Check Internet Connection",Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
		
	}
	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub
		
	}
	 
}
