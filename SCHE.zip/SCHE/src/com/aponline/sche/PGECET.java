package com.aponline.sche;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.aponline.sche.server.WebserviceCall;

public class PGECET extends AppCompatActivity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pgecetpage);
		getSupportActionBar().setTitle("PGECET");
		((TextView)findViewById(R.id.pgecet_notify_date)).setText(WebserviceCall.records.get("NOTIF_DATE"));
		((TextView)findViewById(R.id.pgecet_sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.pgecet_sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.pgecet_hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.pgecet_exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
		((TextView)findViewById(R.id.pgecet_total)).setText(WebserviceCall.records.get("TOTAL_YESTURDAY"));
		((TextView)findViewById(R.id.pgecet_sub_today_tv)).setText("Applications submitted till " +WebserviceCall.records.get("RTIME")+" today");
		((TextView)findViewById(R.id.pgecet_sub_today_total)).setText(WebserviceCall.records.get("TOTAL_TODAY"));
	
		}
		catch(Exception e)
		{
			
		}
	}
}
