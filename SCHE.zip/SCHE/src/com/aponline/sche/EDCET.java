package com.aponline.sche;



import com.aponline.sche.server.WebserviceCall;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class EDCET extends AppCompatActivity
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edcetpage);
		getSupportActionBar().setTitle("EdCET 2018");

		((TextView)findViewById(R.id.edcet_notify_date)).setText(WebserviceCall.records.get("NOTIF_DATE"));
		((TextView)findViewById(R.id.edcet_sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.edcet_sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.edcet_hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.edcet_exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
		((TextView)findViewById(R.id.edcet_total)).setText(WebserviceCall.records.get("TOTAL_YESTURDAY"));
		((TextView)findViewById(R.id.edcet_sub_today_tv)).setText("Applications submitted till " +WebserviceCall.records.get("RTIME")+" today");
		//((TextView)findViewById(R.id.edcet_sub_today_total)).setText(WebserviceCall.records.get("TOTAL_TODAY"));
		((TextView)findViewById(R.id.edcet_maths)).setText(WebserviceCall.records.get("MATHS_YESTURDAY"));
		((TextView)findViewById(R.id.edcet_biology)).setText(WebserviceCall.records.get("BIOLOGY_YESTURDAY"));
		((TextView)findViewById(R.id.edcet_social)).setText(WebserviceCall.records.get("SOCIAL_YESTURDAY"));
		((TextView)findViewById(R.id.edcet_physics)).setText(WebserviceCall.records.get("PHYSICS_YESTURDAY"));
		((TextView)findViewById(R.id.edcet_english)).setText(WebserviceCall.records.get("ENGLISH_YESTURDAY"));
		((TextView)findViewById(R.id.edcet_sub_today_total)).setText(WebserviceCall.records.get("TOTAL_TODAY"));
		}
		catch(Exception e)
		{
			
		}
	}
	
	
}
