

package com.aponline.sche;

import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorListener;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.CycleInterpolator;

public class ElasticAction {

   

    public static void doAction(View view, int duration, float scaleX, float scaleY){
        try {
            if(view.getScaleX() == 1) {
                ViewCompat.animate(view).setDuration(duration).scaleX(scaleX).scaleY(scaleY).setInterpolator(new CycleInterpolator(0.5f))
                        .setListener(new ViewPropertyAnimatorListener() {

                            @Override
                            public void onAnimationStart(final View view) {
                            }

                            @Override
                            public void onAnimationEnd(final View v) {
                            }

                            @Override
                            public void onAnimationCancel(final View view) {
                            }
                        }).withLayer().start();
            }
        }
        catch (Exception e){
           
        }
    }

    public static void doAction(ViewGroup view, int duration, float scaleX, float scaleY){
        try {
            if(view.getScaleX() == 1) {
                ViewCompat.animate(view).setDuration(duration).scaleX(scaleX).scaleY(scaleY).setInterpolator(new CycleInterpolator(0.5f))
                        .setListener(new ViewPropertyAnimatorListener() {

                            @Override
                            public void onAnimationStart(final View view) {
                            }

                            @Override
                            public void onAnimationEnd(final View v) {
                            }

                            @Override
                            public void onAnimationCancel(final View view) {
                            }
                        }).withLayer().start();

                for (int index = 0; index < ((ViewGroup) view).getChildCount(); ++index) {
                    View nextChild = ((ViewGroup) view).getChildAt(index);
                    ViewCompat.animate(nextChild).setDuration(duration).scaleX(scaleX).scaleY(scaleY).setInterpolator(new CycleInterpolator(0.5f))
                            .setListener(new ViewPropertyAnimatorListener() {

                                @Override
                                public void onAnimationStart(final View view) {
                                }

                                @Override
                                public void onAnimationEnd(final View v) {
                                }

                                @Override
                                public void onAnimationCancel(final View view) {
                                }
                            }).withLayer().start();
                }
            }
        }
        catch (Exception e){
            
        }
    }
}
