package com.aponline.sche;





import com.aponline.apcet.toast.Toasty;
import com.aponline.sche.server.RequestServer;
import com.aponline.sche.server.ServerResponseListener;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	int duration = 500;
	LinearLayout apeamcet_ll,apedcet_ll,aplawcet_ll,apecet_ll,apicet_ll,appgcet_ll,appecet_ll;
	ProgressDialog progressDialog;
	Handler mHandler;

	Context context;
	private long mLastClickTime = 0;
	boolean doubleBackToExitPressedOnce = false;
	String methodname;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.content_homepage);
		context=this;
		apeamcet_ll=(LinearLayout)findViewById(R.id.apeamcet_ll);
		apedcet_ll=(LinearLayout)findViewById(R.id.apedcet_ll);
		aplawcet_ll=(LinearLayout)findViewById(R.id.aplawcet_ll);
		apecet_ll=(LinearLayout)findViewById(R.id.apecet_ll);
		apicet_ll=(LinearLayout)findViewById(R.id.apicet_ll);
		appgcet_ll=(LinearLayout)findViewById(R.id.appgcet_ll);
		appecet_ll=(LinearLayout)findViewById(R.id.appecet_ll);
		apeamcet_ll.setOnClickListener(this);
		apedcet_ll.setOnClickListener(this);
		aplawcet_ll.setOnClickListener(this);
		apecet_ll.setOnClickListener(this);
		apicet_ll.setOnClickListener(this);
		appgcet_ll.setOnClickListener(this);
		appecet_ll.setOnClickListener(this);
	}
	@Override
	public void onClick(View arg0) 
	{
		if(arg0.getId()==R.id.apeamcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();

					methodname="EamcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"EamcetRecordsJSON");

				}
			}, duration);
		}
		else if(arg0.getId()==R.id.apedcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
			//		Toasty.error(MainActivity.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					methodname="EdcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"EdcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.aplawcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
		//			Toasty.error(MainActivity.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					methodname="LawcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"LawcetRecordsJSON");
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.apecet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					Toasty.error(MainActivity.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					/*methodname="EcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"EcetRecordsJSON");*/
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.apicet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					Toasty.error(MainActivity.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					/*methodname="IcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"IcetRecordsJSON");*/
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.appgcet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					Toasty.error(MainActivity.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					/*methodname="PGEcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"PGEcetRecordsJSON");*/
					
				}
			}, duration);
		}
		else if(arg0.getId()==R.id.appecet_ll)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 


			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run()
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();
					Toasty.error(MainActivity.this, "This feature will be enabled shortly", Toast.LENGTH_SHORT, true).show();
					/*methodname="PEcetRecordsJSON";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(MainActivity.this,"PEcetRecordsJSON");*/
				}
			}, duration);
		}

	}



	@Override
	public void onBackPressed() 
	{
		if (doubleBackToExitPressedOnce) 
		{
			super.onBackPressed();
			return;
		}

		this.doubleBackToExitPressedOnce = true;
		Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

		new Handler().postDelayed(new Runnable() 
		{

			@Override
			public void run() 
			{
				doubleBackToExitPressedOnce=false;                       
			}
		}, 2000);
	}
	@Override
	public void Success(String response)
	{

		if(methodname.equalsIgnoreCase("EamcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,APEAMCET.class));
		}
		else if(methodname.equalsIgnoreCase("LawcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,LAWCET.class));
		}
		else if(methodname.equalsIgnoreCase("EdcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,EDCET.class));
		}
		else if(methodname.equalsIgnoreCase("EcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,ECET.class));
		}
		else if(methodname.equalsIgnoreCase("IcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,ICET.class));
		}
		else if(methodname.equalsIgnoreCase("PGEcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,PGECET.class));
		}
		else if(methodname.equalsIgnoreCase("PEcetRecordsJSON"))
		{
			startActivity(new Intent(MainActivity.this,PECET.class));
		}
		
	}
	@Override
	public void Fail(String response) 
	{
		Toast toast = null;
		toast=Toast.makeText(MainActivity.this, response,Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
	
	}
	@Override
	public void NetworkNotAvail()
	{
		Toast toast = null;
		toast=Toast.makeText(MainActivity.this, "Check Internet Connection",Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
	}
	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub

	} 

}
