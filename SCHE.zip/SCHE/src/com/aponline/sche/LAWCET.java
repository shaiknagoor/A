package com.aponline.sche;

import com.aponline.sche.server.WebserviceCall;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class LAWCET extends AppCompatActivity
{

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lawcetpage);
		getSupportActionBar().setTitle("AP LAWCET & AP PGLCET-2018");
		((TextView)findViewById(R.id.lawcet_notify_date)).setText(WebserviceCall.records.get("NOTIF_DATE"));
		((TextView)findViewById(R.id.lawcet_sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.lawcet_sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.lawcet_hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.lawcet_exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
		((TextView)findViewById(R.id.lawcet_total)).setText(WebserviceCall.records.get("TOTAL_YESTURDAY"));
		((TextView)findViewById(R.id.lawcet_sub_today_tv)).setText("Applications submitted till " +WebserviceCall.records.get("RTIME")+" today");
		((TextView)findViewById(R.id.lawcet_sub_today_total)).setText(WebserviceCall.records.get("TOTAL_TODAY"));
		((TextView)findViewById(R.id.lawcet_3years)).setText(WebserviceCall.records.get("LAWCET3_YESTURDAY"));
		((TextView)findViewById(R.id.lawcet_5years)).setText(WebserviceCall.records.get("LAWCET5_YESTURDAY"));
		((TextView)findViewById(R.id.pglcet)).setText(WebserviceCall.records.get("PGLCET_YESTURDAY"));
		//((TextView)findViewById(R.id.lawcet_sub_today_total)).setText(WebserviceCall.records.get("TOTAL_TODAY"));
		}
		catch(Exception e)
		{
			
		}
	}
}
