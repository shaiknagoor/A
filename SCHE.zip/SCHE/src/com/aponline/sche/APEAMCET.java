package com.aponline.sche;


import com.aponline.sche.adapter.ReportAdapter;
import com.aponline.sche.server.RequestServer;
import com.aponline.sche.server.ServerResponseListener;
import com.aponline.sche.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class APEAMCET extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	
LinearLayout eamcet_summary_btn,eamcet_att_header;
int duration = 500;
ProgressDialog progressDialog;
Handler mHandler;
Context context;
ReportAdapter adapter;
private long mLastClickTime = 0;

String methodname;
ListView eamcet_att_lv;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.apeamcet_layout);
		getSupportActionBar().setTitle("EAMCET 2018");
		context=this;
		eamcet_att_lv=(ListView)findViewById(R.id.eamcet_att_lv);
		eamcet_summary_btn=(LinearLayout)findViewById(R.id.eamcet_summary_btn);
		eamcet_att_header=(LinearLayout)findViewById(R.id.eamcet_att_header);
		eamcet_summary_btn.setOnClickListener(this);
		((TextView)findViewById(R.id.notify_date)).setText(WebserviceCall.records.get("NOTIF_DATE"));
		((TextView)findViewById(R.id.sub_end_date)).setText(WebserviceCall.records.get("SUB_END_DATE"));
		((TextView)findViewById(R.id.sub_last_date)).setText(WebserviceCall.records.get("SUB_LAST_DATE"));
		((TextView)findViewById(R.id.hall_ticket_date)).setText(WebserviceCall.records.get("HALL_TICKET_DATE"));
		((TextView)findViewById(R.id.exam_date)).setText(WebserviceCall.records.get("EXAM_DATE"));
		((TextView)findViewById(R.id.total)).setText(WebserviceCall.records.get("YESTURDAY_TOTAL"));
		((TextView)findViewById(R.id.app_sub_today_tv)).setText("Applications submitted till " +WebserviceCall.records.get("RTIME")+" today");
		((TextView)findViewById(R.id.app_sub_today_total)).setText(WebserviceCall.records.get("TOTAL_TODAY"));
		
		((TextView)findViewById(R.id.engg_total)).setText(WebserviceCall.records.get("ENGINEERING_TODAY"));
		((TextView)findViewById(R.id.medical_total)).setText(WebserviceCall.records.get("MEDICAL_TODAY"));
		((TextView)findViewById(R.id.both_total)).setText(WebserviceCall.records.get("BOTH_TODAY"));
		try
		{
			int total=	Integer.parseInt(WebserviceCall.records.get("ENGINEERING_TODAY"))+Integer.parseInt(WebserviceCall.records.get("MEDICAL_TODAY"))+Integer.parseInt(WebserviceCall.records.get("BOTH_TODAY"));
			((TextView)findViewById(R.id.total)).setText(Integer.toString(total));
		}
		catch(Exception e)
		{

		}
		}catch(Exception e)
		{
			
		}


	}

	@Override
	public void Success(String response) {
		if(methodname.equalsIgnoreCase("Eamcet_Cand_Attendence"))
		{
			eamcet_att_lv.setVisibility(0);
			eamcet_att_header.setVisibility(0);
			adapter=new ReportAdapter(context, WebserviceCall.eamcet_att);
			eamcet_att_lv.setAdapter(adapter);
			eamcet_att_lv.requestFocusFromTouch();
		}
		
	}

	@Override
	public void Fail(String response) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void NetworkNotAvail() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onClick(View arg0) {
		
		if(arg0.getId()==R.id.eamcet_summary_btn)
		{
			ElasticAction.doAction(arg0, duration, 0.85f, 0.85f); 

			new Handler().postDelayed(new Runnable() 
			{
				@Override
				public void run() 
				{
					if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
					{
						return;
					}
					mLastClickTime = SystemClock.elapsedRealtime();

					methodname="Eamcet_Cand_Attendence";
					RequestServer request=new RequestServer(context);
					request.addParam("Username", "APSCHE");
					request.addParam("Password","APSCHETAB");

					request.ProccessRequest(APEAMCET.this,"Eamcet_Cand_Attendence");

				}
			}, duration);
		}
	}
}
