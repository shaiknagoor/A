package com.aponline.sche.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.sche.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


public class ReportAdapter extends BaseAdapter
{
	ArrayList<HashMap<String,String>> localArrayList=new ArrayList<HashMap<String,String>>();
	Context mContext;
	private LayoutInflater mInflater;
	private Holder mHolder;

	public ReportAdapter(Context baseContext,ArrayList<HashMap<String,String>> data)
	{
		this.mContext=baseContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(baseContext);
	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position)
	{
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(convertView == null)
		{
			convertView=this.mInflater.inflate(R.layout.eamcet_att_row, null);

			this.mHolder= new Holder();
			this.mHolder.session=(TextView) convertView.findViewById(R.id.eamcet_session);
			this.mHolder.doe=(TextView) convertView.findViewById(R.id.eamcet_doe);
			this.mHolder.alloted=(TextView) convertView.findViewById(R.id.eamcet_alloted);		
			this.mHolder.present=(TextView) convertView.findViewById(R.id.eamcet_present);
			this.mHolder.absent=(TextView) convertView.findViewById(R.id.eamcet_absent);		
			this.mHolder.testcenters=(TextView) convertView.findViewById(R.id.eamcet_testcenters);
			
			
			
			convertView.setTag(mHolder);
		}
		else
			this.mHolder=(Holder)convertView.getTag();

		HashMap<String, String> data=this.localArrayList.get(position);
		
		this.mHolder.session.setText("Eamcet Shift "+Integer.toString((position+1)));
		this.mHolder.doe.setText(data.get("EXAM_DATE"));
		this.mHolder.alloted.setText(data.get("ALLOTTED_CANDIDATES"));
		this.mHolder.present.setText(data.get("PRESENT_CANDIDATES"));		
		this.mHolder.absent.setText(data.get("ABSENT_CANDIDATES"));
		this.mHolder.testcenters.setText(data.get("TEST_CENTERS"));
		
		

		return convertView;

	}
	public class Holder
	{
		TextView session;
		TextView doe;
		TextView alloted;
		TextView present;
		TextView absent;
		TextView testcenters;
	
	}
}