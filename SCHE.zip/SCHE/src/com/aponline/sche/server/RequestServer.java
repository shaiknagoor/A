package com.aponline.sche.server;

import java.util.HashMap;



import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

public class RequestServer extends Thread implements ErrorCodes
{
	ServerResponseListener listener;
	Handler mUIHandler;
	Context mContext;
	HashMap<String, String> paramList;
	public static String methodName;
	ProgressDialog progressDialog;

	public RequestServer(Context context)
	{
		this.mContext=context;
		this.paramList=new HashMap<String, String>();
	}
	public void addParam(String key, String value)
	{
		paramList.put(key, value);
	}
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	public void ProccessRequest(ServerResponseListener listener,String method)
	{
		this.listener=listener;
		this.methodName=method;
		if(isNetworkAvailable(mContext))
		{
			Loaddata();
		}
		else
		{
			this.listener.NetworkNotAvail();
		}
	}
	private void Loaddata()
	{
		progressDialog=new ProgressDialog(mContext);
		try 
		{
			Handler localHadler=new Handler()
			{
				public void dispatchMessage(Message paramMessage)
				{
					super.dispatchMessage(paramMessage);

					if(progressDialog.isShowing())
						progressDialog.dismiss();
					if(paramMessage.what==mSuccess)
					{
						listener.Success(methodName);
					}
					else if(paramMessage.what==mErrorResFromWebServices)
					{
						listener.Fail(WebserviceCall.Error);
					}
					else if(paramMessage.what==mFailure)
					{
						listener.Fail("Failed to transfer the data to server");
					}
					else if(paramMessage.what==mXmlPullParserException)
					{
						listener.Fail("Data parsing error, Please try again!!");
					} 
					else if(paramMessage.what==mException||paramMessage.what==mIOException)
					{
						listener.Fail("Failed to connect to the server");
					}
					else if(paramMessage.what==mHandlerFailure||paramMessage.what==mSocketTimeoutException)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==mUpdateVersion)
					{
						listener.AppUpdate();
					}
					else if(paramMessage.what==5)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					while(true)
					{
						return;
					}
				}
			};
			this.mUIHandler=localHadler;
			progressDialog.setCancelable(false);
			progressDialog.setMessage("Proccesing your request, Please Wait......");
			if(!progressDialog.isShowing())
				progressDialog.show();
		//	progressDialog.setContentView(setCustomeLayout());
			new ParseThread().start();
			return;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
//	public View setCustomeLayout()
//	{
//		LayoutInflater mInflater = LayoutInflater.from(mContext);
//		View layout = mInflater.inflate(R.layout.my_progress, null);
//		return layout;
//	}

	public class ParseThread extends Thread
	{

		public ParseThread()
		{
		}

		public void run()
		{
			Message localMessage = new Message();
			try 
			{
				System.out.println("***********Inside Parsethread**********");
				//WebserviceCall com=new WebserviceCall(mContext);

				WebserviceCall com=new WebserviceCall(mContext);
				int i = 0;

				if(methodName.equalsIgnoreCase("EamcetRecordsJSON"))
				{
					i = com.EamcetRecordsJSON(paramList);
				}
				else if(methodName.equalsIgnoreCase("EamcetSMSJSON"))
				{
					i = com.EamcetSMSJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("VerifyUserJSON"))
				{
					i = com.EamcetSMSJSON(paramList); 
				}
				
				else if(methodName.equalsIgnoreCase("LawcetRecordsJSON"))
				{
					i = com.LawcetRecordsJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("EdcetRecordsJSON"))
				{
					i = com.EdcetRecordsJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("EcetRecordsJSON"))
				{
					i = com.EcetRecordsJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("IcetRecordsJSON"))
				{
					i = com.IcetRecordsJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("PGEcetRecordsJSON"))
				{
					i = com.PGEcetRecordsJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("PEcetRecordsJSON"))
				{
					i = com.PEcetRecordsJSON(paramList); 
				}
				else if(methodName.equalsIgnoreCase("Eamcet_Cand_Attendence"))
				{
					i = com.Eamcet_Cand_Attendence(paramList); 
				}
				else if(methodName.equalsIgnoreCase("GetVersionJSON"))
				{
					i = com.VersionChecking(paramList); 
				}
				
				localMessage.what = i;
				System.out.println(i);
				if (mUIHandler != null)
				{
					mUIHandler.sendMessage(localMessage);
				}
				return;
			}
			catch (Exception e) 
			{
				while (true)
				{
					e.printStackTrace();
					localMessage.what = 98;
					mUIHandler.sendMessage(localMessage);
					return;
				}
			}
		}
	}
}
