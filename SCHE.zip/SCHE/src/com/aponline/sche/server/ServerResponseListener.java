package com.aponline.sche.server;
public interface ServerResponseListener 
{
     public void Success(String response);
     public void Fail(String response);
     public void NetworkNotAvail();
	public void AppUpdate();
}
