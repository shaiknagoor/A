package com.aponline.sche;




import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;

import android.content.res.Resources;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import android.widget.TextView;
import android.widget.Toast;



import com.aponline.sche.server.RequestServer;
import com.aponline.sche.server.ServerResponseListener;
import com.aponline.sche.server.WebserviceCall;




public class Login extends AppCompatActivity implements ServerResponseListener,SmsListener
{
	ProgressDialog progressDialog;
	Handler mHandler;

	Context context;
	EditText username,password,mobile_no,otp;
	Button submit,otp_submit;
	String Mobile_number,Username,Password;
	LinearLayout login_ll,otp_ll;
	TextView resend_otp;
	private final SmsReceiver mybroadcast = new SmsReceiver();
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		//		startActivity(new Intent(Login.this,MainActivity.class));
		//		finish();

		context=this;
		//HomeData.readDeviceDetails(Login.this);
		if (Build.VERSION.SDK_INT >= 23)
		{
			requestPermissions();

		}
		else
		{

			intilialize();
		}


	}

	public void requestOtp()
	{

		RequestServer request=new RequestServer(context);

		request.addParam("Username",Username);
		request.addParam("Password", Password);
		request.addParam("MobileNo", Mobile_number);
		request.ProccessRequest(Login.this,"VerifyUserJSON");
		//Loaddata("EamcetSMSJSON",Username,Password,Mobile_number);
	}

	@Override
	public void Success(String response) 
	{
		otp_ll.setVisibility(0);
		login_ll.setVisibility(8);

	}
	@Override
	public void Fail(String response)
	{

		Toast toast = null;
		toast=Toast.makeText(Login.this,response,Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();
	}
	@Override
	public void NetworkNotAvail() 
	{

		Toast toast = null;
		toast=Toast.makeText(Login.this, "Check Internet Connection",Toast.LENGTH_SHORT);
		View view = toast.getView();
		toast.setGravity(Gravity.BOTTOM, 0, 200);
		view.setBackgroundResource(R.color.red);
		toast.show();

	}
	@Override
	public void AppUpdate()
	{
	}
	@Override
	public void messageReceived(String messageText)
	{
		messageText = messageText.replaceAll("\\D+","");
		otp.setText(messageText);

	}
	public void onResume() 
	{
		super.onResume();


	}

	public void onPause() 
	{
		super.onPause();
		try
		{
			if(mybroadcast!=null)

				unregisterReceiver(mybroadcast);
		}
		catch(Exception e)
		{

		}
	}

	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;

	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.READ_SMS))
			permissionsNeeded.add("Read SMS");
		if (!addPermission(permissionsList, Manifest.permission.RECEIVE_SMS))
			permissionsNeeded.add("Receive SMS");


		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				// Need Rationale
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				try
				{

					ActivityCompat.requestPermissions(Login.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
					return;

				} catch (Resources.NotFoundException e) {
					e.printStackTrace();
				}

				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}
		else
		{
			intilialize();
		}

	}


	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}
		return true;
	}

	@SuppressLint("NewApi")
	@Override
	public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){

		switch (permsRequestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			// Initial
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_SMS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.RECEIVE_SMS, PackageManager.PERMISSION_GRANTED);

			// Fill with results
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			// Check for ACCESS_FINE_LOCATION
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
					perms.get(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED)

			{
				intilialize();

			}
			else
			{
				// Permission Denied
				Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
				.show();
			}
		}
		break;
		default:
			super.onRequestPermissionsResult(permsRequestCode, permissions, grantResults);
		}
	}


	public void intilialize()
	{
		HomeData.readDeviceDetails(Login.this);
		Calendar c = Calendar.getInstance(); 
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		HomeData.current_date= sdf.format(c.getTime());
		IntentFilter filter = new IntentFilter();
		filter.addAction("android.provider.Telephony.SMS_RECEIVED");
		registerReceiver(mybroadcast, filter);
		SmsReceiver.bindListener(Login.this,"");
		if(HomeData.isLogin(this))
		{
			startActivity(new Intent(Login.this,MainActivity.class));
			finish();
			return;
		}


		username=(EditText)findViewById(R.id.username_et);
		password=(EditText)findViewById(R.id.pwd_et);
		mobile_no=(EditText)findViewById(R.id.mobile_no);
		otp=(EditText)findViewById(R.id.OTP);
		submit=(Button)findViewById(R.id.loginBtt1);
		otp_submit=(Button)findViewById(R.id.OTP_Submit);
		login_ll=(LinearLayout)findViewById(R.id.login_ll);
		otp_ll=(LinearLayout)findViewById(R.id.otp_ll);
		resend_otp=(TextView)findViewById(R.id.resend_otp);





		submit.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) 
			{
				Mobile_number=mobile_no.getText().toString();
				Username=username.getText().toString();
				Password=password.getText().toString();
				if(Username.isEmpty())
				{
					username.requestFocus();
					username.setError("Enter UserName");

					return;
				}else if (Password.isEmpty()) 
				{
					password.requestFocus();
					password.setError("Enter Password");

					return;
				}
				else if(Mobile_number.isEmpty())
				{
					mobile_no.requestFocus();
					mobile_no.setError("Enter Mobile No");

					return;
				}
				else if(Mobile_number.length()<10)
				{
					mobile_no.requestFocus();
					mobile_no.setError("Enter  10 digit Mobile No");
					return;
				}


				requestOtp();

			}
		});

		otp_submit.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View arg0) 
			{
				if(otp.getText().toString().equalsIgnoreCase(""))
				{
					otp.requestFocus();
					otp.setError("Enter OTP");

					return;
				}
				if(WebserviceCall.otp.equalsIgnoreCase(otp.getText().toString()))
				{



					HomeData.userID=Mobile_number; 
					HomeData.SaveCreadentials(Login.this,Username,Password);

					startActivity(new Intent(Login.this,MainActivity.class));
					finish();
				}
				else
				{
					Toast toast = null;
					toast=Toast.makeText(Login.this, "Incorrect OTP Entered",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 200);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}

			}
		});
		resend_otp.setOnClickListener(new OnClickListener() 
		{

			@Override
			public void onClick(View arg0) 
			{
				requestOtp();

			}
		});
	}
}