package com.aponline.sche;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

@SuppressLint({ "NewApi", "SimpleDateFormat" })
public class HomeData 
{


	public static int sApiLevel = 0; 
	public static String sAppVersion,sAppVersionName;    
	public static Boolean sCheckMeEnable;    
	public static String sCountry;
	public static String sCountrySortName; 
	public static String sDeviceId;   
	public static String sModel;
	public static String sOSVersion;
	public static String current_date;
	public static String smUpgrade_Content;
	public static int smUpgrade_count;
	public static boolean smUpgrade_displayflag=true;
	public static String smUpgrade_header;
	public static String smAppSettingVersion;

	//public static String userRole;
	public static String userID;
	protected static String Password = "";

	public static void readDeviceDetails(Context paramContext) 
	{
//		String str1 = ((TelephonyManager)paramContext.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
//		if (str1 == null)
//			str1 = Secure.getString(paramContext.getContentResolver(),Secure.ANDROID_ID);
//		if (str1 == null)
//			str1 = "NODeviceID";
//		String deviceID = Build.SERIAL;
		
		String str2 = Build.VERSION.RELEASE;
		String str3 = Build.MODEL;
		int i = Integer.parseInt(Build.VERSION.SDK);
		SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("user_settings", 0);
		String str4 = localSharedPreferences.getString("UserLocation", "");
		String str5 = localSharedPreferences.getString("UserLocationSortName", "");
		//	    if ((str4.equalsIgnoreCase("")) && (smLocationUrl != null) && (smLocationUrl.length() > 0))
		//	      getCountry_LocationUrl(paramContext, smLocationUrl);
		PackageManager manager = paramContext.getPackageManager();
		String str6 = "";
		try
		{
			PackageInfo info = manager.getPackageInfo(paramContext.getPackageName(), 0);
			sAppVersionName = info.versionName;
			str6=""+info.versionCode;
								
			sApiLevel = i;
			Log.d("API LEVEL", Integer.toString(sApiLevel));
			sAppVersion = str6;
			Log.d("APP VERSION",sAppVersion); 
		//	sDeviceId =str1;//"867970024928752";// 
		//	Log.d("Device ID",sDeviceId);   
			sOSVersion = str2;
			Log.d("OS Version",sOSVersion); 
			sModel = str3; 
			Log.d("MODEL",sModel);
			sCountry = str4;
			Log.d("COUNTRY",sCountry);  
			sCountrySortName = str5;                  
			Log.d("COUNTRY SORT", sCountrySortName);  



			return;
		}
		catch (Exception localException)   
		{
			while (true)
				localException.printStackTrace();
		}
	}
	public static Boolean isLogin(Context mContext) 
	{
		SharedPreferences pref = mContext.getSharedPreferences("MyPref", Context.MODE_PRIVATE);     
		if(pref.contains("AppInstalled"))
		{



			if(pref.getBoolean("IsLogin", false))
			{
				userID=pref.getString("UserName", null);
				Password=pref.getString("Password", null);

				try 
				{
					String installedDate=pref.getString("AppLaunchDate", null);
					String preAppVersion=pref.getString("Version", null);

					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
					
					Date installDate = dateFormat.parse(installedDate);
					Date currenDate=dateFormat.parse(current_date);

					long difference = Math.abs(currenDate.getTime() - installDate.getTime());
					long differenceDates = difference / (24 * 60 * 60 * 1000);
					String dayDifference = Long.toString(differenceDates);

					Log.e("HERE","HERE: " + dayDifference);

					if(Integer.parseInt(preAppVersion) < Integer.parseInt(HomeData.sAppVersion) || differenceDates >= 30 )
					{
						return false;   
					}
					else
					{
						return true;   
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					return false;   
				}
				
			}


		}
		return false;
	}
	public static void isLogOut(Context mContext) 
	{
		SharedPreferences pref = mContext.getSharedPreferences("MyPref", Context.MODE_PRIVATE);     
		if(pref.contains("AppInstalled"))
		{
			Editor editor = pref.edit();   
			editor.putBoolean("IsLogin", false); 
			editor.commit();
		}
		return;
	}

	public static void SaveCreadentials(Context mContext, String userName, String password)
	{
		userID=userName;
		Password=password;
		SharedPreferences pref = mContext.getSharedPreferences("MyPref", Context.MODE_PRIVATE);    
		if(!pref.contains("AppInstalled"))
		{
			Editor editor = pref.edit();   
			editor.putBoolean("AppInstalled", true);  
			editor.putString("AppLaunchDate",HomeData.current_date);    
			editor.putString("DeviceID", HomeData.sDeviceId);  
			editor.putString("Version", ""+HomeData.sAppVersion); 
			editor.putString("UserName", userName); 
			editor.putString("Password", password); 
			editor.putBoolean("IsLogin", true); 
			editor.commit(); 
		}
		else
		{
			Editor editor = pref.edit();   
			editor.putString("AppLaunchDate",HomeData.current_date);    
			editor.putString("DeviceID", HomeData.sDeviceId);  
			editor.putString("Version", ""+HomeData.sAppVersion); 
			editor.putString("UserName", userName); 
			editor.putString("Password", password); 
			editor.putBoolean("IsLogin", true); 
			editor.commit();
		}
	}
}
