package com.aponline.sche;

public interface SmsListener {
	 public void messageReceived(String messageText);
}
