package com.example.a1520050.biometricapp.rdservices.model;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Text;

public class Skey 
{

	public Skey()
	{
		
	}
	
	@Text
	public String data;
	
	@Attribute(name = "ci",required=false)
	public String ci;
}
