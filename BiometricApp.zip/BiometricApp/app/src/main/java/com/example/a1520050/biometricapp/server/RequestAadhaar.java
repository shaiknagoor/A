package com.example.a1520050.biometricapp.server;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;


import com.example.a1520050.biometricapp.ClsUser;
import com.example.a1520050.biometricapp.HomeData;
import com.example.a1520050.biometricapp.R;
import com.example.a1520050.biometricapp.database.UserDataBase;
import com.example.a1520050.biometricapp.rdservices.model.DeviceInfo;
import com.example.a1520050.biometricapp.rdservices.model.Opts;
import com.example.a1520050.biometricapp.rdservices.model.PidData;
import com.example.a1520050.biometricapp.rdservices.model.PidOptions;
import com.example.a1520050.biometricapp.rdservices.model.Skey;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.StringWriter;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;


@SuppressLint({ "HandlerLeak", "InflateParams", "SimpleDateFormat" })
public class RequestAadhaar implements ErrorCodes
{
	ServerResponseListener listener;
	Handler mUIHandler;
	ProgressDialog progressDialog;
	String userID;
	String schoolsID;
	PidData pidData;
	public static String AadharStatus;
	public static String AadharResponse;
	public static String AadhaarIRISbase64EncodedData;
	Context mContext;
	String UID;
	String ReqType;
	String is_User;
	String verifyAttempt;
	String userType,verifyType; 
	String methodName;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	UserDataBase userDataBase;

	String namespace ="http://apo.org/";//"http://tempuri.org/";
	//staging private String url="http://125.20.160.195:8090/AADHAR2/AadharAuthentication?wsdl";//"http://125.20.160.198/AADHAR2/AadharAuthentication?wsdl";
	//"http://125.16.9.147:8080/APONLINEAUAGATEWAYPreProd/APONLINEAUAGATEWAY.asmx";//"http://125.16.9.147:8080/APONLINEAUAGATEWAYPreProd/APONLINEAUAGATEWAY.asmx";

	//Live 
	private String url;//="http://125.16.9.147:8080/APONLINEAUASERVICE2.0/APONLINEAUASERVICE.asmx";//"http://125.16.9.147:8080/APONLINEAUAGATEWAYAIRTEL2.0/APONLINEAUAGATEWAY.asmx";//="http://125.20.160.198:80/AADHAR/AadharAuthentication?wsdl";
	//	private SecIrisManager secIrisManager; 
	public void Verify(Context paramContext,ServerResponseListener listener,String methodName,PidData pidData,String aadhaarID,String userID,String schoolCode,String verifyAttempt,String verifyType,String UserType)
	{
		url= HomeData.url;

		this.listener=listener;
		this.mContext=paramContext;
		this.UID=aadhaarID;
		this.methodName=methodName;
		this.verifyAttempt=verifyAttempt;
		this.verifyType=verifyType;
		this.pidData=pidData;
		this.userID=userID;
		this.schoolsID=schoolCode;
		this.userType=UserType;
//		if(this.userType.equalsIgnoreCase("Student"))
//		{
//			url=HomeData.url;
//		}

		userDataBase=new UserDataBase(mContext);
		if(isNetworkAvailable(mContext))
		{
			Loaddata();
		}
		else
		{
			this.listener.NetworkNotAvail();
		}
		
	}	
	private void Loaddata()
	{
		progressDialog=new ProgressDialog(mContext);
		try 
		{
			Handler localHadler=new Handler()
			{
				public void dispatchMessage(Message paramMessage)
				{
					super.dispatchMessage(paramMessage);

					if(progressDialog.isShowing())
						progressDialog.dismiss();
					if(paramMessage.what==mSuccess)
					{
						listener.Success(AadharResponse);
					}
					else if(paramMessage.what==mErrorResFromWebServices)
					{
						listener.Fail(WebserviceCall.Error);
					}
					else if(paramMessage.what==mFailure)
					{
						listener.Fail("Failed to transfer the data to server");
					}
					else if(paramMessage.what==mXmlPullParserException)
					{
						listener.Fail("Data parsing error, Please try again!!");
					} 
					else if(paramMessage.what==mException||paramMessage.what==mIOException)
					{
						listener.Fail("Failed to connect to the server");
					}
					else if(paramMessage.what==mHandlerFailure||paramMessage.what==mSocketTimeoutException)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==mUpdateVersion)
					{
						listener.AppUpdate();
					}
					else if(paramMessage.what==5)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					while(true)
					{
						return;
					}
				}
			};
			this.mUIHandler=localHadler;
			progressDialog.setCancelable(false);
			//progressDialog.setMessage(" Please Wait......");
			if(!progressDialog.isShowing())
				progressDialog.show();
			progressDialog.setContentView(setCustomeLayout());
			new AadhaarThread().start();
			return;
		} 
		catch (Exception e) 
		{
			//CommonFunctions.writeLog(mContext, "Loaddata", e.getMessage());
			e.printStackTrace();
		}
	}
	private class AadhaarThread extends Thread
	{
		public void run()
		{
			Message localMessage = new Message();
			try 
			{
				int i = 0;

				i = requestAUAServer();

				localMessage.what = i;
				if (mUIHandler != null)
				{

					mUIHandler.sendMessage(localMessage);

				}
				return;
			}catch (Exception e) 
			{
				while (true)
				{
					e.printStackTrace();
					mUIHandler.sendMessage(localMessage);
					localMessage.what = mSocketTimeoutException;
					//CommonFunctions.writeLog(mContext, "run", e.getMessage());
					return;
				}
			}
		}

	}
	public View setCustomeLayout()
	{
		LayoutInflater mInflater = LayoutInflater.from(mContext);
		View layout = mInflater.inflate(R.layout.my_progress, null);
		((TextView)layout.findViewById(R.id.attendance_progressTv)).setText("Validating with Aadhaar, Please wait...");

		return layout;
	}
	@SuppressLint("SimpleDateFormat")
	public int requestAUAServer()
	{
		try
		{
//			String service="";
//			if(verifyType.equalsIgnoreCase("FMR"))
//			{
//				//methodName="AADHAAR_FINGER_AUTHENTICATION";
//				service="FINGER_AUTH";
//			}
//			else
//			{
//				//methodName="AADHAAR_IRIS_AUTHENTICATION";
//				service="IRIS_AUTH";
//			}

			DeviceInfo deviceInfo=pidData._DeviceInfo;
			Skey skey=pidData._Skey;

			Calendar c = Calendar.getInstance(); 					
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss.SSS"); 
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			String createdDate = sdf.format(c.getTime());
			createdDate=createdDate+HomeData.sDeviceId;
			SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS");
			SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			String srt = sdf1.format(c.getTime());
			String srt1 = sdf2.format(c.getTime());


			SOAP_ACTION = namespace + methodName; 
			//CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-request :-"+SOAP_ACTION);
			request = new SoapObject(namespace, methodName);

			request.addProperty("uid",HomeData.serverResp.optString("AADHAAR"));//"728286696008" 
			request.addProperty("tid",createdDate);
			request.addProperty("udc",HomeData.sDeviceId); 
			//			request.addProperty("fdc","NC");
			//			request.addProperty("ip","NA");
			request.addProperty("srt",srt);
			request.addProperty("crt",srt);
			request.addProperty("skey", skey.data); 
			request.addProperty("pid", pidData._Data);
			request.addProperty("Hmac", pidData._Hmac);
			request.addProperty("ci",skey.ci);//ci=20191230
			//request.addProperty("bt",verifyType);
			//request.addProperty("attemptCount",verifyAttempt);
			request.addProperty("attempt",verifyAttempt);
			//request.addProperty("pincode","500084");				
			//request.addProperty("version","2.0");
//			request.addProperty("scheme","SIMS");
//			request.addProperty("department","SIMS");
//			request.addProperty("service",service);//  FINGER_AUTH
//		 	request.addProperty("consent","Y");
			request.addProperty("schoolCode",schoolsID);
			request.addProperty("childId",userID);
			request.addProperty("Type",userType); 
			request.addProperty("deviceVersion",HomeData.sAppVersion);
			request.addProperty("rdsId",deviceInfo.rdsId);
			request.addProperty("rdsVer",deviceInfo.rdsVer);
			request.addProperty("dpId",deviceInfo.dpId);
			request.addProperty("dc",deviceInfo.dc);
			request.addProperty("mi",deviceInfo.mi);
			request.addProperty("mc",deviceInfo.mc);

			//CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-request :-"+request.toString());

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;  
			envelope.setOutputSoapObject(request);
			androidHttpTransport = new HttpTransportSE(url,100000);
			androidHttpTransport.debug = true;

			androidHttpTransport.call(SOAP_ACTION, envelope);//"IRIS_AUTH|237210669874|Student Attendance Not Allowed 8.30 AM to 10.30 AM";
 			String result = envelope.getResponse().toString();//FINGER_AUTH|815365525372|Biometric Mismatch (300)|Fingerprint data is not given properly or Fingerprint Mismatch
			//Data truncation
			//FINGER_AUTH|237210669874|Attendance already Captured|Sucessfully Verified
			//IRIS_AUTH|237210669874|Already Device Tagged|Sucessfully Verified--->OneTimeDeviceRegitration
			//IRIS_AUTH|237210669874|Success|Sucessfully Verified ----->Attendance
			//IRIS_AUTH|237210669874|Biometric Mismatch (300)|Fingerprint data is not given properly or Fingerprint Mismatch
 			//IRIS_AUTH|237210669874|Aadhar Number Already Seeded|Sucessfully Verified
			AadharResponse=result.replace("|", ",");
			//CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-result :-"+result);

//			Calendar c1 = Calendar.getInstance(); 
//			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
//			String endrt = sdf2.format(c1.getTime());
			try 
			{
				String finalResult;
				if(AadharResponse.contains(","))
				{
					finalResult=AadharResponse.split(",")[2];
					if(finalResult.equalsIgnoreCase("Please Update Your Device Version"))
					{
						return mUpdateVersion;
					}
				}
				else
				{
					finalResult="INAVALID RESPONSE";
				}

//				ContentValues contentValues=new ContentValues();
//				contentValues.put("TRASACTIONID", createdDate);
//				contentValues.put("DEVICEID", HomeData.sDeviceId);
//				contentValues.put("UID", UID);
//				contentValues.put("ATTEMPT", verifyAttempt);
//				contentValues.put("BT", verifyType);
//				contentValues.put("SCHOOLCODE", schoolsID);
//				contentValues.put("USERID", userID);
//				contentValues.put("USERTYPE", userType);
//				contentValues.put("AADHAAR_RESPONSE", result);
//				contentValues.put("CreatedBy", HomeData.UserID);
//				contentValues.put("CreatedDate", endrt);
//				contentValues.put("RESULT",finalResult);
//				contentValues.put("SRT",srt);
//
//				db.open();
//				db.insertTableDate("AADHAAR_REQUEST_DETAILS", contentValues);
//				db.close();

				/*List<ClsUser> list=userDataBase.getAllTableData();
				ClsUser user1=null;
				if(list!=null&&list.size()>0)
				{
					for(int i=0;i<list.size();i++)
					{
						//String id=list.get(i).getUserId();
						if(list.contains(UID))
						{
							ClsUser user=userDataBase.getSingleUser(UID);
							user1=new ClsUser(user.getUserId(),user.getUserInTime(),srt1,verifyType);
							userDataBase.updateUserDetails(user1,user.getUserId());
						}
						else
						{
							user1=new ClsUser(UID,srt1,"",verifyType);
							userDataBase.insertUserDetails(user1);
						}
					}
				}
				else
				{
					user1=new ClsUser(UID,srt1,"",verifyType);
					userDataBase.insertUserDetails(user1);
				}*/

			} 
			catch (Exception e)
			{
				//	CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-IOException :-"+e.getMessage());
				//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
				e.printStackTrace();
			}

			return mSuccess;//"Success"; 
			//} 

		} 
		catch (SocketTimeoutException e)
		{
			//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			//	CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-IOException :-"+e.getMessage());
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			//CommonFunctions.writeLog(mContext, "requestAUAServer", e.getMessage());
			e.printStackTrace();
			//	CommonMethods.writeLog("AADHAAR_FINGER_AUTHENTICATION-Exception :-"+e.getMessage());
			return mException;
		}

	}


	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}


	public static String getPIDOptions(String verifyType) 
	{
		try 
		{
			int iCount=0;
			int fingerCount = 0;
			String pidVer ="";
			if(verifyType.equalsIgnoreCase("IIR"))
			{
				iCount=1;
				pidVer ="1.0";
			}
			else
			{
				fingerCount=1;
				pidVer ="2.0";
			}


			String timeOut = "12000";
			String posh = "UNKNOWN";


			Opts opts = new Opts();
			opts.fCount = String.valueOf(fingerCount);
			opts.fType = "0";
			opts.iCount = String.valueOf(iCount);
			opts.iType = "0";
			opts.pCount = "0";
			opts.pType = "0";
			opts.format = "0";
			opts.pidVer = "2.0";
			opts.timeout = timeOut;
			opts.posh = posh;
			String env = "P";//PP
			opts.env = env;

			PidOptions pidOptions = new PidOptions();
			pidOptions.ver = pidVer;
			pidOptions.Opts = opts;

			Serializer serializer = new Persister();
			StringWriter writer = new StringWriter();
			serializer.write(pidOptions, writer);
			return writer.toString();
		} 
		catch (Exception e) 
		{
			Log.e("Error", e.toString());
			//CommonFunctions.writeLog("userAuthenticationstarted", "inside user autnentication1");
			
		}
		return null;
	}
	
	public static String getPIDOptions1(Context paramContext,String verifyType) 
	{
		try 
		{
			int iCount=0;
			int fingerCount = 0;
			String pidVer ="";
			if(verifyType.equalsIgnoreCase("IIR"))
			{
				iCount=1;
				pidVer ="1.0";
			}
			else
			{
				fingerCount=1;
				pidVer ="2.0";
			}


			String timeOut = "12000";
			String posh = "UNKNOWN";


			Opts opts = new Opts();
			opts.fCount = String.valueOf(fingerCount);
			opts.fType = "0";
			opts.iCount = String.valueOf(iCount);
			opts.iType = "0";
			opts.pCount = "0";
			opts.pType = "0";
			opts.format = "0";
			opts.pidVer = "2.0";
			opts.timeout = timeOut;
			opts.posh = posh;
			String env = "P";//PP
			opts.env = env;

			PidOptions pidOptions = new PidOptions();
			pidOptions.ver = pidVer;
			pidOptions.Opts = opts;

			Serializer serializer = new Persister();
			StringWriter writer = new StringWriter();
			serializer.write(pidOptions, writer);
			return writer.toString();
		} 
		catch (Exception e) 
		{
			Log.e("Error", e.toString());
			//CommonFunctions.writeLog(paramContext,"getpidoption", e.getMessage());
			
		}
		return null;
	}
}
