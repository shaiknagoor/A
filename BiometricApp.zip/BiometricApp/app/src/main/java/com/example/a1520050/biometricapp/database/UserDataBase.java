package com.example.a1520050.biometricapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.ListView;

import com.example.a1520050.biometricapp.ClsUser;
import com.example.a1520050.biometricapp.HomeData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 1520050 on 4/11/2018.
 */

public class UserDataBase extends SQLiteOpenHelper {

    private static final String TAG = "UserDataBase";
    public static  String DATABASE_NAME = "StudentDB";
    private static final int DATABASE_VERSION = 1;
    public  UserDataBase(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(HomeData.User_Details_List);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.w(TAG, i + " to " + i1+ ", which will destroy all old data");
    }
    public void insertUserDetails(ClsUser clsUser)
    {
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("USER_ID",clsUser.getUserId());
        cv.put("USER_IN_TIME",clsUser.getUserInTime());
        cv.put("USER_OUT_TIME",clsUser.getUserOutTime());
        cv.put("VERIFY_TYPE",clsUser.getUserVerifyType());
        database.insert(HomeData.UserDetailsTable,null,cv);
    }
    public void updateUserDetails(ClsUser clsUser, String id)
    {
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("USER_ID",id);
        cv.put("USER_IN_TIME",clsUser.getUserInTime());
        cv.put("USER_OUT_TIME",clsUser.getUserOutTime());
        cv.put("VERIFY_TYPE",clsUser.getUserVerifyType());

        database.update(HomeData.UserDetailsTable,cv,"USER_ID=?",new String[]{String.valueOf(id)});
    }
    public List<ClsUser> getAllTableData()
    {
        List<ClsUser> usersList=null;
        String query="SELECT * FROM "+HomeData.UserDetailsTable;

        SQLiteDatabase database=this.getWritableDatabase();
        Cursor cursor=database.rawQuery(query,null);

        if(cursor!=null&&cursor.getCount()>0)
        {
            usersList=new ArrayList<>();
            cursor.moveToFirst();

            do{
                ClsUser clsUser=new ClsUser();
                clsUser.setUserId(cursor.getString(0));
                clsUser.setUserInTime(cursor.getString(1));
                clsUser.setUserOutTime(cursor.getString(2));
                clsUser.setUserVerifyType(cursor.getString(3));

                usersList.add(clsUser);

            }while (cursor.moveToNext());

        }
        return usersList;
    }

    public ClsUser getSingleUser(String id)
    {
        ClsUser clsUser=null;

        SQLiteDatabase database=this.getWritableDatabase();
        Cursor cursor=database.rawQuery("SELECT * FROM "+HomeData.UserDetailsTable+" WHERE USER_ID=?",new String[]{String.valueOf(id)});
        if(cursor!=null&&cursor.getCount()>0)
        {
            cursor.moveToFirst();
                clsUser=new ClsUser();
                clsUser.setUserId(cursor.getString(0));
                clsUser.setUserInTime(cursor.getString(1));
                clsUser.setUserOutTime(cursor.getString(2));
                clsUser.setUserVerifyType(cursor.getString(3));

        }
        return clsUser;
    }
}
