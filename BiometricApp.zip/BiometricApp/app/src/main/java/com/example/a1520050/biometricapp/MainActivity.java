package com.example.a1520050.biometricapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a1520050.biometricapp.adapter.UserDetailsAdapter;
import com.example.a1520050.biometricapp.database.UserDataBase;
import com.example.a1520050.biometricapp.rdservices.model.PidData;
import com.example.a1520050.biometricapp.rdservices.model.RDServiceInfo;
import com.example.a1520050.biometricapp.rdservices.model.Resp;
import com.example.a1520050.biometricapp.server.RequestAadhaar;
import com.example.a1520050.biometricapp.server.RequestServer;
import com.example.a1520050.biometricapp.server.ServerResponseListener;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements ServerResponseListener{
    PidData pidData;
    RequestAadhaar nAadhaar;
    int aadhaarAttempt=1;
    ListView userDetailsList;
    String treasuryID;
    InputMethodManager imm;
    LinearLayout linearLayout,listLayout;
    String userID;
    UserDataBase dataBase;
    public static String User_Type="Invigilator";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginact);

        if (Build.VERSION.SDK_INT >= 23)
        {
            requestPermissions();
        }
        else
        {
            HomeData.readDeviceDetails(this);
        }
        userDetailsList=(ListView)findViewById(R.id.user_detailsLV);
        linearLayout=(LinearLayout)findViewById(R.id.userDetailsLL);
        listLayout=(LinearLayout)findViewById(R.id.liistLL);
        nAadhaar=new RequestAadhaar();

        imm = (InputMethodManager)MainActivity.this.getSystemService(Service.INPUT_METHOD_SERVICE);
        imm.showSoftInput(((EditText)findViewById(R.id.login_userEt)), 0);

        dataBase=new UserDataBase(this);
    }


    final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;

    private void requestPermissions()
    {
        List<String> permissionsNeeded = new ArrayList<String>();

        final List<String> permissionsList = new ArrayList<String>();

        if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
            permissionsNeeded.add("Read State");
        if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
            permissionsNeeded.add("Access Fine Location");
        if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
            permissionsNeeded.add("Access Coarse Location");
        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("Write enternal Contacts");
        if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add("Write enternal Contacts");
        if (!addPermission(permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add("Camera");
        if (!addPermission(permissionsList, Manifest.permission.USE_FINGERPRINT))
            permissionsNeeded.add("USB");


        if (permissionsList.size() > 0)
        {
            if (permissionsNeeded.size() > 0)
            {
                // Need Rationale
                String message = "You need to grant access to " + permissionsNeeded.get(0);
                for (int i = 1; i < permissionsNeeded.size(); i++)

                    message = message + ", " + permissionsNeeded.get(i);

                ActivityCompat.requestPermissions(MainActivity.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                return;
            }
            ActivityCompat.requestPermissions(MainActivity.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
            return;
        }
        HomeData.readDeviceDetails(this);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        switch (requestCode)
        {
            case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
            {
                Map<String, Integer> perms = new HashMap<String, Integer>();
                // Initial
                perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.USE_FINGERPRINT, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
                // Fill with results
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                // Check for ACCESS_FINE_LOCATION
                if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                {
                    // All Permissions Granted
                    HomeData.readDeviceDetails(this);
                }
                else
                {
                    // Permission Denied
                    Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT).show();
                }
            }
            break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private boolean addPermission(List<String> permissionsList, String permission)
    {
        if (ContextCompat.checkSelfPermission(MainActivity.this,permission) != PackageManager.PERMISSION_GRANTED)
        {
            permissionsList.add(permission);
            // Check for Rationale Option
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
                return false;
        }
        return true;
    }
    public void proceed(View v)
    {
        treasuryID=((EditText)findViewById(R.id.login_userEt)).getText().toString().trim();
        if(treasuryID.equalsIgnoreCase("")||treasuryID.length()!=7)//
        {
            ((EditText)findViewById(R.id.login_userEt)).setError("ENTER VALID TREASURY ID");
            ((EditText)findViewById(R.id.login_userEt)).requestFocus();
            return;
        }

        View view = MainActivity.this.getCurrentFocus();
        if (view != null)
        {
            imm.hideSoftInputFromWindow(((EditText)findViewById(R.id.login_userEt)).getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
        RequestServer request=new RequestServer(MainActivity.this);
        request.addParam("AadhaarId", treasuryID);
        request.ProccessRequest(MainActivity.this, "getEmployeeInfo");
    }

    public void iris(View v)
    {
        if(HomeData.isSamsung)
        {
            String pidOption = RequestAadhaar.getPIDOptions("IIR");
            if(hasPermission())
            {
                //String buildVersion=android.os.Build.DISPLAY;//LMY47X.T116IRDDU1BQF1(NewVer)  LMY47X.T116IRDDU1BPK4(OldVer)
                Intent intent= new Intent();
                PackageManager packageManager = getPackageManager();
                intent.setAction("in.gov.uidai.rdservice.iris.CAPTURE");
                List<ResolveInfo> activities = packageManager.queryIntentActivities(intent, 0);
                String pkgName = activities.get(0).activityInfo.packageName; //MAKE SURE YOU HAVE SLECTED SAMSUNG RD SERVICE
                String activity = activities.get(0).activityInfo.name;
                intent.setClassName(pkgName, activity);
                intent.putExtra("PID_OPTIONS",pidOption);
                if(activities.size()>0)
                {
                    //intent.setAction("in.gov.uidai.rdservice.iris.INFO");
                    startActivityForResult(intent, 1);

                }

                else
                {

                    CommonFunctions.writeLog(MainActivity.this, "Rd service (in.gov.uidai.rdservice.iris.INFO) samsung problem","");
                    Dialogs.AlertDialogs(MainActivity.this, "Please Update Device Software (RD Services Not Installed)");
                }
            }
            else
            {
                startActivityForResult(new Intent(MainActivity.this,Activation.class), 999);
            }
        }
        else
        {
            Dialogs.AlertDialogs(MainActivity.this, "Only Samsung device supports IRIS Verification ");

        }
    }
    public  void fmr(View view)
    {
        if(appInstalledOrNot("com.mantra.clientmanagement")&&appInstalledOrNot("com.mantra.rdservice"))
        {
            userAuthentication();
        }
        else
        {
            CommonFunctions.writeLog(MainActivity.this, "Mantra Rd service not installed","");
            Dialogs.AlertDialogs(MainActivity.this, "Bio-Device Information!!","Please install Mantra Management Client Application");
        }
    }
    private boolean hasPermission()
    {
        try
        {
            String BIOMETRIC_LICENSE_PERMISSION = "com.sec.enterprise.biometric.permission.IRIS_RECOGNITION";
            PackageManager packageManager = this.getApplicationContext().getPackageManager();
            if (packageManager.checkPermission(BIOMETRIC_LICENSE_PERMISSION, this.getApplicationContext().getPackageName()) == PackageManager.PERMISSION_GRANTED) {
                // Print.d(TAG + ">>> hasPermission : true");
                return true;
            }
        }
        catch (Exception e)
        {
            CommonFunctions.writeLog(this, "hasPermission", e.getMessage());
        }
        //  Print.d( TAG + ">>> hasPermission : false");
        return false;
    }
    private boolean appInstalledOrNot(String uri)
    {
        PackageManager pm = getPackageManager();
        try
        {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }

        return false;
    }

    protected void userAuthentication()
    {
        try
        {


            String pidOption = RequestAadhaar.getPIDOptions("FMR");
            if (pidOption != null)
            {
                Intent intent = new Intent();
                intent.setAction("in.gov.uidai.rdservice.fp.CAPTURE");
                intent.putExtra("PID_OPTIONS", pidOption);
                startActivityForResult(intent, 2);
            }

           /* PackageManager pm = getPackageManager();
            Intent intent = new Intent();
            String pidOption = RequestAadhaar.getPIDOptions("FMR");
            CommonFunctions.writeLog(this, "userAuthentication", pidOption);

            if (pidOption != null)
            {
                intent.setAction("in.gov.uidai.rdservice.fp.CAPTURE");
                intent.putExtra("PID_OPTIONS",pidOption);
                startActivityForResult(intent, 1);
            }
*/
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

   /* public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        if(requestCode==999)
        {
            if (!hasPermission())
            {
                finish();
            }
        }
        else if(requestCode == 1)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                try
                {
                    if (intent != null)
                    {
                        String result = intent.getStringExtra("PID_DATA");
                        if (result != null)
                        {
                            try
                            {
                                CommonFunctions.writeLog(this, "PidData", result);
                                Serializer serializer = new Persister();
                                pidData = serializer.read(PidData.class, result);

                                Resp deviceResp=pidData._Resp;

                                if(deviceResp.errCode.equalsIgnoreCase("0"))
                                {
                                    nAadhaar.Verify(MainActivity.this,MainActivity.this,"aadharAUA",pidData,treasuryID,userID,HomeData.UserID, aadhaarAttempt+"FA","FMR","Teacher"); //237210669874
                                    //nAadhaar.Verify(this, this,  "GetAadhaarDetails", pidData, "985483175319",aadhaarAttempt+"FA","FMR");
                                }
                                else
                                {
                                    Dialogs.AlertDialogs(this,"Bio-Device Information!!",deviceResp.errInfo);
                                }


                            }
                            catch (Exception e)
                            {
                                CommonFunctions.writeLog(this, "fpCaptureSuccess", e.getMessage());
                                e.printStackTrace();
                                Dialogs.AlertDialogs(this,"Bio-Device Information!!",e.getMessage());
                            }

                        }
                        else
                        {
                            Dialogs.AlertDialogs(this,"Bio-Device Information!!","Data not found");
                        }
                    }
                }
                catch (Exception e)
                {
                    Log.e("Error", "Error while deserialize pid data", e);
                    Dialogs.AlertDialogs(this,"Bio-Device Information!!",e.getMessage());
                }
            }
        }
        else if(requestCode == 2)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                try
                {
                    CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "result code "+resultCode);
                    if (intent != null)
                    {
                        String result = intent.getStringExtra("PID_DATA");
                        if (result != null)
                        {
                            try
                            {
                                CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "Result "+result);
                                CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "Before serializer");

                                Serializer serializer = new Persister();
                                pidData = serializer.read(PidData.class, result);
                                CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "After serializer");
                                Resp deviceResp=pidData._Resp;

                                if(deviceResp.errCode.equalsIgnoreCase("0"))
                                {
                                    nAadhaar.Verify(MainActivity.this,MainActivity.this,"aadharIRIS",pidData,treasuryID, userID, HomeData.UserID, aadhaarAttempt+"EA", "IIR","Teacher");

                                    //nAadhaar.Verify(this,this,"GetAadhaarDetails",pidData,"985483175319", aadhaarAttempt+"EA","IIR"); //237210669874
                                }
                                else
                                {
                                    AlertDialogs("Bio-Device Information!!",deviceResp.errInfo);
                                    CommonFunctions.writeLog(MainActivity.this, "Bio-Device Information fingerprint mantra",deviceResp.errCode+"/"+deviceResp.errInfo+"/"+result);
                                }

                            }
                            catch (Exception e)
                            {
                                CommonFunctions.writeLog(this, "fpCaptureSuccess", e.getMessage());
                                e.printStackTrace();


                                Writer writer = new StringWriter();
                                e.printStackTrace(new PrintWriter(writer));
                                String s = writer.toString();
                                CommonFunctions.writeLog(this, "fpCaptureSuccess : Trace:\n", s);
                            }

                        }
                    }
                } catch (Exception e) {
                    Log.e("Error", "Error while deserialize pid data", e);
                    CommonFunctions.writeLog(this, "fpCaptureSuccess2", e.getMessage());

                    Writer writer = new StringWriter();
                    e.printStackTrace(new PrintWriter(writer));
                    String s = writer.toString();
                    CommonFunctions.writeLog(this, "fpCaptureSuccess2 : Trace:\n", s);
                }
            }
        }
    }
*/

    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        if(requestCode==999)
        {
            if (!hasPermission())
            {
                finish();

            }
        }
        else if(requestCode==3)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                try
                {
                    if (intent != null)
                    {
                        //String result = data.getStringExtra("DEVICE_INFO");
                        String rdService = intent.getStringExtra("RD_SERVICE_INFO");
                        //CommonFunctions.writeLog(LoginActivity.this, "RD_SERVICE_INFO(OnActivityResult)", rdService);
                        //String display = "";
                        if (rdService != null)
                        {
                            //display = "RD Service Info :\n" + rdService + "\n\n";
                            Serializer serializer = new Persister();
                            RDServiceInfo info = serializer.read(RDServiceInfo.class, rdService);
                            if(info.status.equalsIgnoreCase("READY"))
                            {
                                treasuryID=((EditText)findViewById(R.id.login_userEt)).getText().toString().trim();
                                if(treasuryID.equalsIgnoreCase("")||treasuryID.length()!=7)//
                                {
                                    ((EditText)findViewById(R.id.login_userEt)).setError("ENTER VALID TREASURY ID");
                                    ((EditText)findViewById(R.id.login_userEt)).requestFocus();
                                    return;
                                }

                                View view = MainActivity.this.getCurrentFocus();
                                if (view != null)
                                {
                                    imm.hideSoftInputFromWindow(((EditText)findViewById(R.id.login_userEt)).getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                                }
                                RequestServer request=new RequestServer(MainActivity.this);
                                request.addParam("AadhaarId", treasuryID);
                                request.ProccessRequest(MainActivity.this, "getEmployeeInfo");
                            }
                            else
                            {
                                Dialogs.AlertDialogs(MainActivity.this, "Device Status :"+info.status+"\n Info :"+info.info);
                                return;

                            }
                        }
                        else
                        {
                            Dialogs.AlertDialogs(MainActivity.this, "RD Services Checking failed, Please try Again!!");
                            return;
                        }
                    }
                    else
                    {
                        Dialogs.AlertDialogs(MainActivity.this, "RD Services Checking failed, Please try Again!!");
                        return;
                    }
                }
                catch (Exception e)
                {
                    //Log.e("Error", "Error while deserialze device info", e);
                    Dialogs.AlertDialogs(MainActivity.this, "Please restart your device and Please try Again!!");
                    return;
                }
            }
        }
        else if(requestCode == 1)
        {

            //CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "result code "+resultCode);

            if (resultCode == Activity.RESULT_OK)
            {
                String result = intent.getStringExtra("PID_DATA");
                //Log.d("IndiaIdentityClient", "capture data:"+result);
                if(result != null)
                {
                    //CommonFunctions.writeLog(this, "IRIS CaptureSuccess(OneTimeREG)", "Result "+result);
                    //CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "Before serializer");
                    try
                    {
                        Serializer serializer = new Persister();
                        pidData = serializer.read(PidData.class, result);
                        //CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "After serializer");
                        Resp deviceResp=pidData._Resp;

                        if(deviceResp.errCode.equalsIgnoreCase("0"))
                        {
                            //findViewById(R.id.one_iris_ll).setVisibility(View.GONE);
                            //	nAadhaar.Verify(this,this,"aadharIRIS",pidData,aadhaarNo, userID, HomeData.UserID, aadhaarAttempt+"EA", "IIR",User_Type);
                            nAadhaar.Verify(MainActivity.this,MainActivity.this,"aadharIRIS",pidData,treasuryID, userID, HomeData.UserID, aadhaarAttempt+"EA", "IIR",User_Type);
                        }
                        else
                        {
                            AlertDialogs("RD Service Information!!",deviceResp.errInfo);
                            /*findViewById(R.id.one_iris_ll).setVisibility(View.GONE);
                            findViewById(R.id.userNameEntry_ll).setVisibility(View.GONE);
                            findViewById(R.id.userDetails_ll).setVisibility(View.VISIBLE);*/
                        }
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                        //CommonFunctions.writeLog(this, "IRIS CaptureSuccess", e.getMessage());
                    }
                }


            }
            else
            {
                //findViewById(R.id.one_iris_ll).setVisibility(View.GONE);
            }

        }
        else if(requestCode == 2)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                try
                {
                    //CommonFunctions.writeLog(this, "Finger CaptureSuccess", "result code "+resultCode);
                    if (intent != null)
                    {
                        String result = intent.getStringExtra("PID_DATA");
                        if (result != null)
                        {
                            try
                            {
                                //CommonFunctions.writeLog(this, "Finger CaptureSuccess(OneTimeREG)", "Result "+result);
                                //CommonFunctions.writeLog(this, "Finger CaptureSuccess(OneTimeREG)", "Before serializer");

                                Serializer serializer = new Persister();
                                pidData = serializer.read(PidData.class, result);
                                //CommonFunctions.writeLog(this, "IRIS CaptureSuccess", "After serializer");
                                Resp deviceResp=pidData._Resp;

                                if(deviceResp.errCode.equalsIgnoreCase("0"))
                                {
                                    nAadhaar.Verify(MainActivity.this,MainActivity.this,"aadharAUA",pidData,treasuryID,userID,HomeData.UserID, aadhaarAttempt+"FA","FMR",User_Type); //237210669874
                                }
                                else
                                {

                                    AlertDialogs("RD Service Information!!",deviceResp.errInfo);
                                    //findViewById(R.id.userNameEntry_ll).setVisibility(View.GONE);
                                    //findViewById(R.id.userDetails_ll).setVisibility(View.VISIBLE);
                                }

                            }
                            catch (Exception e)
                            {
                                //CommonFunctions.writeLog(this, "fpCaptureSuccess", e.getMessage());
                                e.printStackTrace();


                                //								Writer writer = new StringWriter();
                                //								e.printStackTrace(new PrintWriter(writer));
                                //								String s = writer.toString();
                                //								CommonFunctions.writeLog(this, "fpCaptureSuccess : Trace:\n", s);
                            }

                        }
                    }
                } catch (Exception e) {
                    //Log.e("Error", "Error while deserialize pid data", e);
                    //CommonFunctions.writeLog(this, "fpCaptureSuccess2", e.getMessage());

                    //					Writer writer = new StringWriter();
                    //					e.printStackTrace(new PrintWriter(writer));
                    //					String s = writer.toString();
                    //					CommonFunctions.writeLog(this, "fpCaptureSuccess2 : Trace:\n", s);
                }
            }
        }
    }
    public void AlertDialogs(String title, final String msg)
    {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
        dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.alertdialog1);
        dialog.setCancelable(false);
        Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
        TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
        TextView titleTv=(TextView)dialog.findViewById(R.id.alert_titleTv);
        msgTv.setText(msg);
        titleTv.setText(title);
        Button yes =(Button)dialog.findViewById(R.id.ok_button);
        yes.startAnimation(shake);

        yes.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               /* if(checkDashboardInfo)
                {
                    checkForceCloseApp(msg);
                }*/
                dialog.dismiss();
                return;
            }
        });
        if(!dialog.isShowing())
            dialog.show();
    }

   /* @SuppressWarnings("deprecation")
    @SuppressLint("ShowToast")
    protected void ValidateAadharResponse(String response)
    {

        try
        {
            if(response.contains(","))
            {
                String data[]=response.split(",");
                String resType=data[0];
                if(data[2].equalsIgnoreCase("Success")||data[2].equalsIgnoreCase("Already Device Tagged")||data[2].equalsIgnoreCase("In-Time of Teacher is Captured")||data[2].equalsIgnoreCase("Out-Time of Teacher is Captured"))
                {
                    if(resType.equalsIgnoreCase("IRIS_AUTH"))
                    {
                        Toast.makeText(MainActivity.this,"IRIS Success",Toast.LENGTH_LONG).show();
                    }
                    if(resType.equalsIgnoreCase("FINGER_AUTH"))
                    {
                        Toast.makeText(MainActivity.this,"Finger Success",Toast.LENGTH_LONG).show();
                    }

                }
                else
                {
                    if(aadhaarAttempt >= 3||data[2].equalsIgnoreCase("Already Device Tagged With Other School"))
                    {
                        aadhaarAttempt=1;
                    }
                    else
                    {
                        aadhaarAttempt++;
                        //userAuthentication();
                        linearLayout.setVisibility(View.VISIBLE);

                    }
                }
            }
            else
            {
                aadhaarAttempt=1;
                //AlertDialogs("Information!!",response);
                listLayout.setVisibility(View.VISIBLE);
                SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                Calendar c = Calendar.getInstance();
                String srt = sdf2.format(c.getTime());
                ClsUser user=new ClsUser(treasuryID,srt,srt,"IIR");
                UserDataBase userDataBase=new UserDataBase(MainActivity.this);
                userDataBase.insertUserDetails(user);

                List<ClsUser> list=userDataBase.getAllTableData();
                if(list!=null&&list.size()>0)
                {
                    UserDetailsAdapter adapter=new UserDetailsAdapter(MainActivity.this,list);
                    userDetailsList.setAdapter(adapter);
                }

            }
        }
        catch (Exception e)
        {
            //CommonFunctions.writeLog(this, "ValidateAadharResponse", e.getMessage());
            e.printStackTrace();
        }

    }*/

    @SuppressWarnings("deprecation")
    @SuppressLint("ShowToast")
    protected void ValidateAadharResponse(String response)
    {

        linearLayout.setVisibility(View.GONE);
        try
        {
            if(response.contains(","))
            {
                String data[]=response.split(",");
                String resType=data[0];
                String verifyType="";
                if(data[2].equalsIgnoreCase("Success")||data[2].equalsIgnoreCase("Already Device Tagged")||data[2].equalsIgnoreCase("In-Time of Teacher is Captured")||data[2].equalsIgnoreCase("Out-Time of Teacher is Captured"))
                {
                    if(resType.equalsIgnoreCase("IRIS_AUTH"))
                    {
                        verifyType="IRIS";
                        Toast.makeText(MainActivity.this,"IRIS Success",Toast.LENGTH_LONG).show();
                    }

                    if(resType.equalsIgnoreCase("FINGER_AUTH"))
                    {
                        verifyType="FINGER";
                        Toast.makeText(MainActivity.this,"Finger Success",Toast.LENGTH_LONG).show();
                    }

                    listLayout.setVisibility(View.VISIBLE);
                    linearLayout.setVisibility(View.GONE);
                    SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                    Calendar c = Calendar.getInstance();
                    String srt = sdf2.format(c.getTime());
                    //ClsUser user=new ClsUser(treasuryID,srt,"",verifyType);
                    UserDataBase userDataBase=new UserDataBase(MainActivity.this);

                    List<ClsUser> list=userDataBase.getAllTableData();
                    ClsUser user1=null;
                    boolean isDone=false;
                    List<String> idsList=new ArrayList<>();
                     if(list!=null&&list.size()>0)
                    {
                        for(int i=0;i<list.size();i++) {
                            idsList.add(list.get(i).getUserId());
                        }
                            if (!isDone)
                            {
                                if(idsList!=null&&idsList.size()>0)
                                {
                                    if(idsList.contains(treasuryID))
                                    {
                                        ClsUser user = userDataBase.getSingleUser(treasuryID);
                                        user1 = new ClsUser(user.getUserId(), user.getUserInTime(), srt, verifyType);
                                        userDataBase.updateUserDetails(user1, user.getUserId());
                                        isDone = true;
                                    }
                                    else
                                    {
                                        user1 = new ClsUser(treasuryID, srt, "", verifyType);
                                        userDataBase.insertUserDetails(user1);
                                        isDone = true;
                                    }
                                }
                            }


                            /*if (isDone) {
                                break;
                            }
                            else
                                {
                                //String id=list.get(i).getUserId();
                                treasuryID = ((EditText) findViewById(R.id.login_userEt)).getText().toString().trim();
                                Log.d("ID", list.get(i).getUserId() + "," + treasuryID);
                                if (list.get(i).getUserId().equalsIgnoreCase(treasuryID)) {
                                    ClsUser user = userDataBase.getSingleUser(treasuryID);
                                    user1 = new ClsUser(user.getUserId(), user.getUserInTime(), srt, verifyType);
                                    userDataBase.updateUserDetails(user1, user.getUserId());
                                    isDone = true;
                                }
                                else
                                    {
                                    user1 = new ClsUser(treasuryID, srt, "", verifyType);
                                    userDataBase.insertUserDetails(user1);
                                    isDone = true;
                                }

                            }*/

                    }
                    else
                    {
                        user1=new ClsUser(treasuryID,srt,"",verifyType);
                        userDataBase.insertUserDetails(user1);
                    }

                    List<ClsUser> list1=userDataBase.getAllTableData();
                    if(list1!=null&&list1.size()>0)
                    {
                        UserDetailsAdapter adapter=new UserDetailsAdapter(MainActivity.this,list1);
                        userDetailsList.setAdapter(adapter);
                    }
                    AlertDialogs1(this,"Captured Successfully",getResources().getDrawable(R.drawable.success));
                    /*((EditText)findViewById(R.id.login_userEt)).setText("");
                    findViewById(R.id.userNameEntry_ll).setVisibility(View.VISIBLE);
                    findViewById(R.id.userDetails_ll).setVisibility(View.GONE);*/

                }
                else
                {
                    if(aadhaarAttempt >= 3||data[2].equalsIgnoreCase("Already Device Tagged With Other School"))
                    {
                        aadhaarAttempt=1;
                        AlertDialogs1(this,data[2],getResources().getDrawable(R.drawable.fail));
                        findViewById(R.id.userNameEntry_ll).setVisibility(View.GONE);
                       /* findViewById(R.id.userDetails_ll).setVisibility(View.VISIBLE);

                        if(resType.equalsIgnoreCase("IRIS_AUTH"))
                        {
                            findViewById(R.id.one_iris_ll).setVisibility(View.GONE);
                        }*/

                    }
                    else
                    {
                        Toast toast = null;
                        toast=Toast.makeText(MainActivity.this, data[2],Toast.LENGTH_LONG);
                        View view = toast.getView();
                        ViewGroup viewgroup=(ViewGroup) toast.getView();
                        ((TextView)viewgroup.getChildAt(0)).setTextSize(25);
                        toast.setGravity(Gravity.CENTER, 0, 250);
                        view.setBackgroundResource(R.color.red);

                        toast.show();
                        aadhaarAttempt++;
                        userAuthentication();
                    }
                }
            }
            else
            {
                aadhaarAttempt=1;
                AlertDialogs("Information!!",response);
               /* findViewById(R.id.userNameEntry_ll).setVisibility(View.VISIBLE);
                findViewById(R.id.userDetails_ll).setVisibility(View.GONE);*/
            }
        }
        catch (Exception e)
        {
            //CommonFunctions.writeLog(this, "ValidateAadharResponse", e.getMessage());
            e.printStackTrace();
        }

    }
    public void AlertDialogs1(Context context,String msg,Drawable drawable)
    {

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
        dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.alertdialog3);
        dialog.setCancelable(false);
        Animation shake = AnimationUtils.loadAnimation(context, R.anim.zoom_out);
        TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
        TextView titleTv=(TextView)dialog.findViewById(R.id.alert_titleTv);
        ((ImageView)dialog.findViewById(R.id.attendance_ResultIV)).setImageDrawable(drawable);
        msgTv.setText(msg);
        titleTv.setText("Information!!");
        Button yes =(Button)dialog.findViewById(R.id.ok_button);
        yes.startAnimation(shake);

        yes.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                return;
            }
        });
        if(!dialog.isShowing())
            dialog.show();

    }

    @Override
    public void Success(String response)
    {
        try
        {
            if(!response.equalsIgnoreCase("getEmployeeInfo"))
            {
                ValidateAadharResponse(response);
            }
            else
            {

               // findViewById(R.id.userNameEntry_ll).setVisibility(View.GONE);
                //findViewById(R.id.userDetails_ll).setVisibility(View.VISIBLE);

                //	serverResp

                userID=treasuryID;//HomeData.serverResp.optString("TRESAURYID");

                //				String zeroDigit="";
                //				for(int j=userID.length();j < 7;j++)
                //				{
                //					zeroDigit=zeroDigit+"0";
                //				}
                //				userID=zeroDigit+userID;

                ((TextView)findViewById(R.id.tv_user_name)).setText(HomeData.serverResp.optString("TEACHERNAME"));
                linearLayout.setVisibility(View.VISIBLE);

                HomeData.UserID=HomeData.serverResp.optString("SCHOOLCODE");
                 }
        }
        catch (Exception e)
        {
            //CommonFunctions.writeLog(this, "Success", e.getMessage());
            e.printStackTrace();
        }
    }
   /* @Override
    public void Success(String response) {
        Toast.makeText(getApplicationContext(),"Success: "+response,Toast.LENGTH_LONG).show();

        try
        {
            if(!response.equalsIgnoreCase("getEmployeeInfo"))
            {
                ValidateAadharResponse(response);
            }
            else
            {
               *//* userID=treasuryID;
                listLayout.setVisibility(View.VISIBLE);

                List<ClsUser> list=dataBase.getAllTableData();
                if(list!=null&& list.size()>0)
                {
                    UserDetailsAdapter adapter=new UserDetailsAdapter(MainActivity.this,list);
                    userDetailsList.setAdapter(adapter);
                }


*//*
                userID=treasuryID;
                ((TextView)findViewById(R.id.tv_user_name)).setText(HomeData.serverResp.optString("TEACHERNAME"));
                linearLayout.setVisibility(View.VISIBLE);

                HomeData.UserID=HomeData.serverResp.optString("SCHOOLCODE");
            }
        }
        catch (Exception e)
        {
            //CommonFunctions.writeLog(this, "Success", e.getMessage());
            e.printStackTrace();
        }
    }*/

    @Override
    public void Fail(String response) {

        Toast.makeText(getApplicationContext(),"Fail: "+response,Toast.LENGTH_LONG).show();
    }

    @Override
    public void NetworkNotAvail() {
        Toast.makeText(getApplicationContext(),"NetworkNotAvail: ",Toast.LENGTH_LONG).show();

    }

    @Override
    public void AppUpdate() {

    }
}
