package com.example.a1520050.biometricapp.server;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;


import com.example.a1520050.biometricapp.HomeData;

import org.json.JSONObject;
import org.json.XML;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;

@SuppressLint("SimpleDateFormat")
public class WebserviceCall implements ErrorCodes
{

	String TransDate;
	String TotalTrans;
	public static String Error;
	StringBuilder stringBuilder;
	String namespace = "http://apo.org/";

	@SuppressWarnings("unused")
	private String url,attendaceUrl;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;
	Context paramContext;
	public static String serverResponse;

	public WebserviceCall(Context paraContext)
	{
		this.paramContext=paraContext;
		this.url= HomeData.url;
	}

	@SuppressWarnings("static-access")
	public int getEmployeeInfo(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="getEmployeeInfo";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			request.addProperty("deviceId", HomeData.sDeviceId); 
			request.addProperty("deviceVersion",HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(HomeData.url,80000);
			androidHttpTransport.debug = true;
			//<DEVICEDATA><list><DISTNAME>VIZIANAGARAM</DISTNAME><BLKNAME>KOMARADA</BLKNAME><VILNAME>YENDABHADRA</VILNAME><SCHNAME>MPPS MASIMANDA</SCHNAME></list></DEVICEDATA>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result = envelope.getResponse().toString();//<ERROR>Teacher Details Not Available</ERROR>
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("TEACHERINFO"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("TEACHERINFO");

				HomeData.UserID=jDeviceData.optString("SCHOOLCODE");
				SharedPreferences pref = paramContext.getSharedPreferences("MyPref", paramContext.MODE_PRIVATE);  
				Editor editor = pref.edit();   
				editor.putString("UserID", HomeData.UserID);  
				editor.commit();
				HomeData.serverResp=jDeviceData;
				return mSuccess;
			}
			else if(jObject.has("ERROR"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString("ERROR");
				if(HomeData.rErrorMsgFromServer.equalsIgnoreCase("Please Update Your Device Version"))
				{
					return mUpdateVersion;
				}
				return mErrorResFromWebServices;
			}
			else
			{
				Error= "Data Not Found,Please try again!!";
				return mFailure;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}


}
