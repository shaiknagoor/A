package com.example.a1520050.biometricapp;

import android.content.ContentValues;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class CommonFunctions 
{

	public static void writeLog(Context context,String methodName,String strLog) 
	{

		try 
		{
			String className=context.getClass().getSimpleName();
			boolean isNewFile = false;
			String Dir = Environment.getExternalStorageDirectory().getPath()+ "/Aadhar_Auth/ErrorLog/"+className+"/";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHH");
			String FileNameFormate = dateFormat.format(new Date());
			String FileName = Dir + "/"+methodName+"_" + FileNameFormate +".txt";

			SimpleDateFormat logTimeFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
			String logTime = logTimeFormat.format(new Date());
			File dir = new File(Dir);
			if (!dir.exists()) 
			{
				dir.mkdirs();
			}
			File logFile = new File(FileName);
			if (!logFile.exists())
			{
				isNewFile = true;
				logFile.createNewFile();
			}
			FileOutputStream fOut;
			OutputStreamWriter myOutWriter;
			fOut = new FileOutputStream(logFile, true);
			myOutWriter = new OutputStreamWriter(fOut);
			if (isNewFile)
			{
				myOutWriter.append(logTime + " " + strLog);
			} 
			else 
			{
				myOutWriter.append("\n" + logTime + " " + strLog);
			}
			myOutWriter.flush();
			myOutWriter.close();
		} 
		catch (Exception ex)
		{

		}
	}
}
