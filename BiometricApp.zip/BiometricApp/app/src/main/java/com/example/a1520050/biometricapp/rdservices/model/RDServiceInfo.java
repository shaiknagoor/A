package com.example.a1520050.biometricapp.rdservices.model;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "RDService")
public class RDServiceInfo 
{
	public RDServiceInfo() 
	{
	}

	@Attribute(name = "status",required=false)
	public String status;
	@Attribute(name = "info",required=false)
	public String info;

	@ElementList(name = "Interface", required = false, inline = true)
	public List<Interface> inter_face;
}
