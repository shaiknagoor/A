package com.example.a1520050.biometricapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import org.json.JSONObject;

/**
 * Created by 1520050 on 4/3/2018.
 */

public class HomeData {
    public static String sDeviceId;
    public static String sAppVersionName;
    public static int sApiLevel = 0;
    public static String sAppVersion;
    public static String sOSVersion;
    public static String sModel;
    public static boolean isSamsung=false;
    public static String sCountry;
    public static String sCountrySortName;
    public static String UserDetailsTable="User_Details_List";
    public static String rErrorMsgFromServer="";
    public static String UserID;
    public static JSONObject serverResp;

    //SSC eHazar LIVE
    public static String url="http://125.20.160.198/SSCExams/SSCInvislation?wsdl";

    public static String APMIP_FARMER_DETAILS="CREATE TABLE IF NOT EXISTS APMIP_FARMER_DETAILS("
            +"AUTO_ID integer primary key autoincrement,"
            +"User_ID TEXT,"
            +"Password TEXT,"
            +"User_DistrictId TEXT,"
            +"User_ROLE_ID TEXT,"
            +"User_STATUS TEXT,"
            +"FarmerId TEXT,"
            +"RequestId TEXT,"
            +"AADHAARNUMBER TEXT,"
            +"FarmerName TEXT,"
            +"FatherName TEXT,"
            +"MobileNumber TEXT,"
            +"Caste TEXT,"
            +"Social_staus TEXT,"
            +"FarmerAddress TEXT,"
            +"Survey_No TEXT,"
            +"CropName TEXT,"
            +"Area_Proposed TEXT,"
            +"FARMERSTATUS TEXT,"
            +"CATEGORY TEXT,"
            +"Status_Code TEXT,"
            +"MI_Company_Name TEXT,"
            +"MI_System_Type TEXT,"
            +"Installation_Year TEXT,"
            +"Subsidy TEXT,"
            +"District_id TEXT,"
            +"Mandal_id TEXT,"
            +"Panchayat_Code TEXT,"
            +"Village_Code TEXT,"
            +"Habitation_Id TEXT,"

            +"FarmerFieldPhoto1 TEXT,"
            +"FarmerFieldPhoto2 TEXT,"
            +"WaterSource_GPS_Coordinates TEXT,"
            +"HeadControlUnit_GPS_Coordinates TEXT,"
            +"TrackingOfTheField_GPS_Coordinates TEXT,"
            +"Dischargevalue TEXT,"
            +"Survey_CROP TEXT,"
            +"Survey_AREAPROPOSED TEXT,"
            +"Survey_STATUSOFMISYSTEM TEXT,"
            +"Survey_FUNCTIONAL TEXT,"
            +"Survey_NOTEXISTS TEXT,"
            +"Survey_NOTFUNCTIONING TEXT,"
            +"Survey_InvestigatorDetails TEXT,"
            +"Survey_DeptOfficialDetails TEXT,"
            +"Survey_ComponentDetails TEXT,"

            +"Status_Flag TEXT default 'N',"
            +"CREATED_DATE default current_timestamp);";
    public static String VILLAGE_TRAINING_DETAILS="CREATE TABLE IF NOT EXISTS VILLAGE_TRAINING_DETAILS("
            +"AUTO_ID integer primary key autoincrement,"
            +"District_id TEXT,"
            +"Mandal_id TEXT,"
            +"Panchayat_id TEXT,"
            +"Village_id TEXT,"
            +"Major_crop TEXT,"
            +"AGRONOMIC_WATER_MANAGEMENT TEXT,"
            +"AGRONOMIC_NUTRIENT_MANAGEMENT TEXT,"
            +"AGRONOMIC_PESTDISEASE_MANAGEMENT TEXT,"
            +"AGRONOMIC_HARVEST_HANDLING TEXT,"
            +"ASPECT_FERTIGATION TEXT,"
            +"ASPECT_MISYSTEM_MAINTENANCE TEXT,"
            +"ASPECT_AFETR_SALESSERVICE TEXT,"
            +"FARMERS_PROBLEMS TEXT,"
            +"ACTION_TAKEN TEXT,"
            +"RESOURCEPERSON_DESIGNATION TEXT,"
            +"RESOURCEPERSON_NAME TEXT,"
            +"FARMERSPARTICIPATEDCOUNT TEXT,"
            +"PHOTO_ONE TEXT,"
            +"PHOTO_TWO TEXT,"
            +"PHOTO_THREE TEXT,"
            +"CREATED_BY TEXT,"
            +"GPSCOORDINATES TEXT,"
            +"STATUS_FLAG TEXT default 'N',"
            +"TRAINING_DATE TEXT);";

    public static String MI_Companies_List="CREATE TABLE IF NOT EXISTS MI_Companies_List("
            + "SUPPLIER_ID TEXT,"
            + "SUPPLIER_NAME TEXT,"
            + "DISTRICT_ID TEXT);";

    public static String User_Details_List="CREATE TABLE IF NOT EXISTS User_Details_List("
            + "USER_ID TEXT,"
            + "USER_IN_TIME TEXT,"
            + "USER_OUT_TIME TEXT,"
            + "VERIFY_TYPE TEXT);";

    public static void readDeviceDetails(Context paramContext)
    {
        String str1 = ((TelephonyManager)paramContext.getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
        if (str1 == null)
            str1 = Settings.Secure.getString(paramContext.getApplicationContext().getContentResolver(), "android_id");
        if (str1 == null)
            str1 = "NODeviceID";
        String str2 = Build.VERSION.RELEASE;
        String str3 = Build.MODEL;
        int i = Integer.parseInt(Build.VERSION.SDK);
        SharedPreferences localSharedPreferences = paramContext.getApplicationContext().getSharedPreferences("user_settings", 0);
        String str4 = localSharedPreferences.getString("UserLocation", "");
        String str5 = localSharedPreferences.getString("UserLocationSortName", "");
        //	    if ((str4.equalsIgnoreCase("")) && (smLocationUrl != null) && (smLocationUrl.length() > 0))
        //	      getCountry_LocationUrl(paramContext, smLocationUrl);
        PackageManager localPackageManager = paramContext.getApplicationContext().getPackageManager();
        String str6 = "";
        try
        {
            str6 = ""+localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 0).versionCode;
            sAppVersionName =localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 0).versionName;
            sApiLevel = i;
            Log.d("API LEVEL", Integer.toString(sApiLevel));
            sAppVersion = str6;
            Log.d("APP VERSION",sAppVersion);
            sDeviceId =str1;//"358520071003458";"868159026563606";
            Log.d("Device ID",sDeviceId);
            sOSVersion = str2;
            Log.d("OS Version",sOSVersion);
            sModel = str3;
            Log.d("MODEL",sModel);
            if(sModel.equalsIgnoreCase("SM-T116IR"))
            {
                isSamsung=true;
            }
            sCountry = str4;
            Log.d("COUNTRY",sCountry);
            sCountrySortName = str5;
            Log.d("COUNTRY SORT", sCountrySortName);

            return;
        }
        catch (Exception localException)
        {
            while (true)
                localException.printStackTrace();
        }
    }
}
