package com.example.a1520050.biometricapp.rdservices.model;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Root;

@Root(name = "Interface")
public class Interface {

	public Interface() {

	}
	
	@Attribute(name = "id",required=false)
	public String id;
	@Attribute(name = "path",required=false)
	public String path;
}
