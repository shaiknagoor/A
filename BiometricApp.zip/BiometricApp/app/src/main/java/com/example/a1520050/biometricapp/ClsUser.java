package com.example.a1520050.biometricapp;

/**
 * Created by 1520050 on 4/11/2018.
 */

public class ClsUser {
    String userId,userInTime,userOutTime,userVerifyType;

    public ClsUser() {
    }

    public ClsUser(String userId, String userInTime, String userOutTime, String userVerifyType) {
        this.userId = userId;
        this.userInTime = userInTime;
        this.userOutTime = userOutTime;
        this.userVerifyType = userVerifyType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserInTime() {
        return userInTime;
    }

    public void setUserInTime(String userInTime) {
        this.userInTime = userInTime;
    }

    public String getUserOutTime() {
        return userOutTime;
    }

    public void setUserOutTime(String userOutTime) {
        this.userOutTime = userOutTime;
    }

    public String getUserVerifyType() {
        return userVerifyType;
    }

    public void setUserVerifyType(String userVerifyType) {
        this.userVerifyType = userVerifyType;
    }

    @Override
    public String toString() {
        return "ClsUser{" +
                "userId='" + userId + '\'' +
                ", userInTime='" + userInTime + '\'' +
                ", userOutTime='" + userOutTime + '\'' +
                ", userVerifyType='" + userVerifyType + '\'' +
                '}';
    }
}
