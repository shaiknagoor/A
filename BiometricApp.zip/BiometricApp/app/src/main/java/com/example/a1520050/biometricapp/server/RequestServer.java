package com.example.a1520050.biometricapp.server;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.Log;


import com.example.a1520050.biometricapp.HomeData;

import java.util.HashMap;

@SuppressLint("HandlerLeak")
public class RequestServer extends Thread implements ErrorCodes
{

	ServerResponseListener listener;
	Handler mUIHandler;
	Context mContext;
	HashMap<String, String> paramList;
	public static String methodName;
	ProgressDialog progressDialog;

	public RequestServer(Context context) 
	{
		this.mContext=context;
		this.paramList=new HashMap<String, String>();
	}
	public void addParam(String key, String value)
	{
		paramList.put(key, value);
	}
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	@SuppressWarnings("static-access")
	public void ProccessRequest(ServerResponseListener listener,String method)
	{
		this.listener=listener;
		this.methodName=method;
		if(isNetworkAvailable(mContext))
		{
			Loaddata();
		}
		else
		{
			this.listener.NetworkNotAvail();
		}
	}
	private void Loaddata()
	{
		progressDialog=new ProgressDialog(mContext);
		try 
		{
			Handler localHadler=new Handler()
			{
				public void dispatchMessage(Message paramMessage)
				{
					super.dispatchMessage(paramMessage);

					if(progressDialog.isShowing())
						progressDialog.dismiss();
					if(paramMessage.what==mSuccess)
					{
						listener.Success(methodName);
					}
					else if(paramMessage.what==mErrorResFromWebServices)
					{
						listener.Fail(HomeData.rErrorMsgFromServer);
					}
					else if(paramMessage.what==mFailure)
					{
						listener.Fail(WebserviceCall.Error);
					}
					else if(paramMessage.what==mXmlPullParserException)
					{
						listener.Fail("Data parsing error, Please try again!!");
					} 
					else if(paramMessage.what==mException||paramMessage.what==mIOException)
					{
						listener.Fail("Failed to connect to the server");
					}
					else if(paramMessage.what==mHandlerFailure||paramMessage.what==mSocketTimeoutException)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==mUpdateVersion)
					{
						listener.AppUpdate();
					}
					else if(paramMessage.what==5)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					while(true)
					{
						return;
					}
				}
			};
			this.mUIHandler=localHadler;
			progressDialog.setCancelable(false);
			String s= "Please Wait...........";			
			SpannableString ss2=  new SpannableString(s);
			ss2.setSpan(new RelativeSizeSpan(2f), 0, ss2.length(), 0);  
			ss2.setSpan(new ForegroundColorSpan(Color.BLACK), 0, ss2.length(), 0); 
			progressDialog.setMessage(ss2);

			if(!progressDialog.isShowing())
				progressDialog.show();
			//progressDialog.setContentView(setCustomeLayout());
			new ParseThread().start();
			return;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public class ParseThread extends Thread
	{

		public ParseThread()
		{
		}

		public void run()
		{
			Message localMessage = new Message();
			try 
			{
				System.out.println("***********Inside Parsethread**********");
				WebserviceCall com=new WebserviceCall(mContext);
				int i = 0;

				if(methodName.equalsIgnoreCase("getEmployeeInfo"))
				{
					i = com.getEmployeeInfo(paramList);			
				}

				localMessage.what = i;
				System.out.println(i);
				if (mUIHandler != null)
				{
					mUIHandler.sendMessage(localMessage);
				}
				return;
			}
			catch (Exception e) 
			{
				while (true)
				{
					e.printStackTrace();
					localMessage.what = 98;
					mUIHandler.sendMessage(localMessage);
					return;
				}
			}
		}
	}


}
