package com.example.a1520050.biometricapp;


import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.sec.biometric.license.SecBiometricLicenseManager;

public class Activation extends Activity 
{

	final static String TAG = "Activation";

	Context mContext;
	Button ActivateBtn;
	SecBiometricLicenseManager mLicenseMgr;



	BroadcastReceiver mReceiver = new BroadcastReceiver() 
	{
		@Override
		public void onReceive(Context context, Intent intent)
		{
			try 
			{
				System.out.println("Received " + intent.getAction());
				String action = intent.getAction();
				if (action.equals(SecBiometricLicenseManager.ACTION_LICENSE_STATUS))
				{
					unregisterReceiver(mReceiver);

					Bundle extras = intent.getExtras();
					String status = extras.getString(SecBiometricLicenseManager.EXTRA_LICENSE_STATUS);
					int err_code = extras.getInt(SecBiometricLicenseManager.EXTRA_LICENSE_ERROR_CODE);

					if (status.equals("success")) 
					{
						Toast toast = Toast.makeText(mContext, "", Toast.LENGTH_SHORT);
						toast.setText("status = " + status + " , " + " License activated");
						toast.show();
						finish();
					}
					else 
					{
						Toast toast = Toast.makeText(mContext, "", Toast.LENGTH_SHORT);
						toast.setText("status = " + status + " , " + "error code = " + err_code);
						toast.show();
						ActivateBtn.setEnabled(true);
					}
				}
			} 
			catch (Exception e)
			{
				CommonFunctions.writeLog(Activation.this, "onReceive", e.getMessage());
				e.printStackTrace();
			}

		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		try 
		{
			Log.d(TAG, ">>> onCreate");
			super.onCreate(savedInstanceState);

			setContentView(R.layout.activation);	
			mContext = this.getApplicationContext();
			mLicenseMgr = SecBiometricLicenseManager.getInstance(mContext);
			ActivateBtn = (Button) findViewById(R.id.activate_license);
			ActivateBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View arg0) 
				{
					ActivateBtn.setEnabled(false);
					if (!activateIrisLicense()) 
					{
						unregisterReceiver(mReceiver);
						finish();
					}
				}
			});
		}
		catch (Exception e)
		{
			CommonFunctions.writeLog(Activation.this, "onCreate", e.getMessage());
			e.printStackTrace();
		}
	}

	protected Boolean activateIrisLicense() 
	{
		try 
		{
			IntentFilter filter = new IntentFilter();        
			filter.addAction(SecBiometricLicenseManager.ACTION_LICENSE_STATUS);
			filter.addAction(SecBiometricLicenseManager.ACTION_LICENSE_STATUS);
			registerReceiver(mReceiver, filter);

			String key = "067D5C756BC2CA8B0BF392AF740B772011B3DCADE7C1F97FF6BF6E8648EA030C5D3932771A40333EFD703A19A2EC9551D37AFD199E4FE9006AF5ED77DA8B8C94";
			//"B08A7DD8D1F9C860A4C955E3A9D1017807CD798C73A47288DC04764A3E85E464A291497F2C7D727CE81EE3F8674628062796385C04968C0DBCE62E08449FDF14";
			String packageName = getApplicationContext().getPackageName();
			Log.i("Activation", "packageName: "+packageName);
			mLicenseMgr.activateLicense(key,packageName);
			return true;
		} 
		catch(Exception e) 
		{
			CommonFunctions.writeLog(Activation.this, "activateIrisLicense", e.getMessage());
			e.printStackTrace();
		}

		Toast toast = Toast.makeText(mContext, "", Toast.LENGTH_SHORT);
		toast.setText("status = fail , error code = unknown error");
		toast.show();

		return false;
	}



}
