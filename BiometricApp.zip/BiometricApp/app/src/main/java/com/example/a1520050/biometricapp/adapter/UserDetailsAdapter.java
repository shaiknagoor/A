package com.example.a1520050.biometricapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.example.a1520050.biometricapp.ClsUser;
import com.example.a1520050.biometricapp.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UserDetailsAdapter extends BaseAdapter
{
	List<ClsUser> localArrayList;
	Context mContext;
	private LayoutInflater mInflater;
	private Holder mHolder;

	public UserDetailsAdapter(Context baseContext, List<ClsUser> data)
	{
		this.mContext=baseContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(baseContext);
	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position)
	{
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(convertView == null)
		{
			convertView=this.mInflater.inflate(R.layout.single_user_details, null);
//			convertView = this.mInflater.inflate(R.layout.sell, null);
			this.mHolder= new Holder();
			this.mHolder.userId=(TextView) convertView.findViewById(R.id.user_Id);
			this.mHolder.userInTime=(TextView) convertView.findViewById(R.id.in_time);
			this.mHolder.userOutTime=(TextView) convertView.findViewById(R.id.out_time);
			this.mHolder.verifyType=(TextView) convertView.findViewById(R.id.verify_type);

			convertView.setTag(mHolder);
		}
		else
			this.mHolder=(Holder)convertView.getTag();

		ClsUser user=localArrayList.get(position);
		this.mHolder.userId.setText(user.getUserId());
		this.mHolder.userInTime.setText(user.getUserInTime());
		this.mHolder.userOutTime.setText(user.getUserOutTime());
		this.mHolder.verifyType.setText(user.getUserVerifyType());


		return convertView;

	}
	public class Holder
	{
		TextView userId;
		TextView userInTime;
		TextView userOutTime;
		TextView verifyType;
	}
}
