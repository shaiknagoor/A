package com.aponline.fisheriesgis.adapter;

import java.util.ArrayList;





import com.aponline.fisheriesgis.R;
import com.aponline.fisheriesgis.adapter.Seedfarmadapter.Holder;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class FishLandAdapter extends BaseAdapter {

	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;

	public FishLandAdapter(Context applicationContext,ArrayList<ArrayList<String>> data) {
		// TODO Auto-generated constructor stub\
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		System.out.println("--"+localArrayList.size());
		return localArrayList.size();
	}

	@Override
	public Object getItem(int paramInt) {
		// TODO Auto-generated method stub
		return Integer.valueOf(paramInt);
	}

	@Override
	public long getItemId(int paramInt) {
		// TODO Auto-generated method stub


		return paramInt;
	}

	@Override
	public View getView(int position, View paramView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.seedfarmreport, null);
			this.mHolder = new Holder();
			this.mHolder.serialno = ((TextView)paramView.findViewById(R.id.serialno));
			this.mHolder.district = ((TextView)paramView.findViewById(R.id.district));
			this.mHolder.mandal = ((TextView)paramView.findViewById(R.id.mandal));
			this.mHolder.panchayat = ((TextView)paramView.findViewById(R.id.panchayat));
			this.mHolder.village = ((TextView)paramView.findViewById(R.id.village));
			this.mHolder.seedfarmcenter = ((TextView)paramView.findViewById(R.id.seedfarmcenter));
			this.mHolder.uploadstatus = ((TextView)paramView.findViewById(R.id.upload_status));
			/*this.mHolder.latitude = ((TextView)paramView.findViewById(R.id.latitude));
			this.mHolder.longitude = ((TextView)paramView.findViewById(R.id.longitude));*/
			paramView.setTag(this.mHolder);


		}
		else 
		
			this.mHolder=(Holder)paramView.getTag();	
			
			ArrayList<String> local=localArrayList.get(position);
			this.mHolder=(Holder)paramView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));

		this.mHolder.serialno.setText(""+(position+1));
		this.mHolder.district.setText(local.get(0));
		this.mHolder.mandal.setText(local.get(1));
		this.mHolder.panchayat.setText(local.get(2));
		this.mHolder.village.setText(local.get(3));
		this.mHolder.seedfarmcenter.setText(local.get(4));
		this.mHolder.uploadstatus.setText(local.get(5));
		/*this.mHolder.latitude.setText(local.get(5));
		this.mHolder.longitude.setText(local.get(6));
		*/
		return paramView;

	}


	public class Holder
	{
		TextView serialno;
		TextView district;
		TextView mandal;
		TextView panchayat;
		TextView village;
		TextView seedfarmcenter;
		TextView latitude;
		TextView longitude;
		TextView uploadstatus;


		public Holder()
		{
		}
	}

}
