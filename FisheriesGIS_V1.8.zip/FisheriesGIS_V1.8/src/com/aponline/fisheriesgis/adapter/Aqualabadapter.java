package com.aponline.fisheriesgis.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.aponline.fisheriesgis.R;
import com.aponline.fisheriesgis.adapter.FishLandAdapter.Holder;

public class Aqualabadapter extends BaseAdapter {

	ArrayList<ArrayList<String>> localArrayList=new ArrayList<ArrayList<String>>();
	Context mContext;
	private LayoutInflater mInflater;
	Holder mHolder;

	public Aqualabadapter(Context applicationContext,ArrayList<ArrayList<String>> data) {
		// TODO Auto-generated constructor stub\
		this.mContext=applicationContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(applicationContext);

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub

		System.out.println("--"+localArrayList.size());
		return localArrayList.size();
	}

	@Override
	public Object getItem(int paramInt) {
		// TODO Auto-generated method stub
		return Integer.valueOf(paramInt);
	}

	@Override
	public long getItemId(int paramInt) {
		// TODO Auto-generated method stub


		return paramInt;
	}

	@Override
	public View getView(int position, View paramView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(paramView==null)
		{
			paramView = this.mInflater.inflate(R.layout.aqualabreport, null);
			this.mHolder = new Holder();
			this.mHolder.serialno = ((TextView)paramView.findViewById(R.id.aquaserialno));
			this.mHolder.district = ((TextView)paramView.findViewById(R.id.aquadistrict));
			this.mHolder.mandal = ((TextView)paramView.findViewById(R.id.aquamandal));
			this.mHolder.panchayat = ((TextView)paramView.findViewById(R.id.aquapanchayat));
			this.mHolder.village = ((TextView)paramView.findViewById(R.id.aquavillage));
			this.mHolder.aqualabcenter = ((TextView)paramView.findViewById(R.id.aquacentername));

			this.mHolder.typeofaqualab = ((TextView)paramView.findViewById(R.id.typeofaqualab));
			this.mHolder.categoryofaqualab = ((TextView)paramView.findViewById(R.id.categoryofaqualab));
			this.mHolder.categoryofanalysis = ((TextView)paramView.findViewById(R.id.categoryofanalysis));
			this.mHolder.uploadstatus = ((TextView)paramView.findViewById(R.id.upload_status));

		/*	this.mHolder.latitude = ((TextView)paramView.findViewById(R.id.aqualatitude));
			this.mHolder.longitude = ((TextView)paramView.findViewById(R.id.aqualongitude));*/
			paramView.setTag(this.mHolder);


		}
		else 

			this.mHolder=(Holder)paramView.getTag();	

		ArrayList<String> local=localArrayList.get(position);
		this.mHolder=(Holder)paramView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));

		this.mHolder.serialno.setText(""+(position+1));
		this.mHolder.district.setText(local.get(0));
		this.mHolder.mandal.setText(local.get(1));
		this.mHolder.panchayat.setText(local.get(2));
		this.mHolder.village.setText(local.get(3));

		this.mHolder.aqualabcenter.setText(local.get(4));
		this.mHolder.typeofaqualab.setText(local.get(5));
		this.mHolder.categoryofaqualab.setText(local.get(6));
		this.mHolder.categoryofanalysis.setText(local.get(7));
		this.mHolder.uploadstatus.setText(local.get(8));

		/*this.mHolder.latitude.setText(local.get(8));
		this.mHolder.longitude.setText(local.get(9));*/

		return paramView;

	}


	public class Holder
	{
		TextView serialno;
		TextView district;
		TextView mandal;
		TextView panchayat;
		TextView village;
		TextView aqualabcenter;
		TextView typeofaqualab;
		TextView categoryofaqualab;
		TextView categoryofanalysis;
		TextView uploadstatus;

		TextView latitude;
		TextView longitude;



		public Holder()
		{
		}
	}

}
