package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

public class AquaCulturePage extends AppCompatActivity implements OnItemSelectedListener, OnClickListener,ServerResponseListener
{
	private static final int REQUEST_CAMERA = 0, SELECT_FILE = 1;
	DBAdapter db;
	int flag=0;
	Spinner sp;
	android.support.v7.app.ActionBar ab;
	public static double latitude,longitude;
	StringBuilder UserRegXmlDoc; 
	public static String UserName,Password;
	String strBaseimage="";
	ProgressDialog progressDialog;
	private int mYear, mMonth, mDay, mHour, mMinute;;
	Handler mHandler;
	Context context;
	String roleID;
	String distrID,districtName; 
	String mandalID,mandalName;
	int PHOTO_CAPTURE=100;
	static int percentage=0;
	ArrayList<String> typeofculture= new ArrayList<String>();
	ArrayList<String> typeofland= new ArrayList<String>();
	GPSTracker gps;
	private static String divisionID="",instiTypeID="",instiLoctinID="",desigID="",panchayatID="",villageID="",building="",aqalab_id="",name="",mobile_no="",emailid="",noofperson="",adharno="",FarmerName="",SurveyNo="",landownership="",farmstatus="",culture="",landownership_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.aquaculture_old);
			ab=getSupportActionBar();
			ab.setTitle("Aquaculture");
			gps=new GPSTracker(AquaCulturePage.this);
			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 
			ab=getSupportActionBar();
			LoadUserDetails();
			db=new DBAdapter(this);	
			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from AquaCulture_Master where UserId ='"+HomeData.userID+"'ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(false);
			}
			else
			{
				
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);

			}

			((Spinner)findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);

			((Spinner)findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.farmername_sp)).setOnItemSelectedListener(this);
			
			
			
			((Spinner)findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setOnClickListener(this);
			((TextView)findViewById(R.id.registrationdate)).setOnClickListener(this);


			//	((EditText)findViewById(R.id.totalwater_txt)).addTextChangedListener(new CustomTextWatcher(((EditText)findViewById(R.id.totalwater_txt)),((TextView)findViewById(R.id.effectviewater_txt))));

			findViewById(R.id.submit_btn).setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) 
				{
					// TODO Auto-generated method stub
					validatedata();
				}
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block

			CommonFunctions.writeLog("Aquaculture", "oncreate", e.getMessage());
			e.printStackTrace();
		}

	}
	
	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));
			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}


	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("Aquaculture", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.fish_landing_center_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}
	}

	private void onCaptureImageResult(Intent data,ImageView v,String s)
	{
		try
		{
			Bitmap photo = (Bitmap) data.getExtras().get("data");
			int width=photo.getWidth();
			int height=photo.getHeight();

			Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo	.getHeight(), Bitmap.Config.ARGB_8888);		
			Canvas canvas = new Canvas(scaled);
			Paint paint = new Paint();  
			paint.setColor(Color.RED);
			paint.setTextSize(14);  
			paint.setFlags(Paint.ANTI_ALIAS_FLAG);

			canvas.drawBitmap(photo, 0, 0, null);
			float fKoordX = 3f, fKoordY = 5f;
			canvas.drawPoint(fKoordX, fKoordY, paint);

			canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
			canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

			v.setImageBitmap(scaled);
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
			byte[] byteArray = stream.toByteArray();
			switch(s)
			{
			case "aqualab":
				building= Base64.encodeToString(byteArray,Base64.DEFAULT);
				break;
			default:
				break;

			}


		}
		catch (Exception e)
		{
			CommonFunctions.writeLog("Aquaculture", "onCaptureImageResult", e.getMessage());

			e.printStackTrace();
		}

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void Success(String response) 
	{
		// TODO Auto-generated method stub
		ContentValues aquaculturelist = new ContentValues();
		try 
		{
			aquaculturelist.put("IsSync","Y");
			db.open();
			boolean stat=db.updateTableData("AquaCulture_Master", aquaculturelist,"UserId='"+HomeData.userID +"' and trim(AquacultureID)='"+aqalab_id.trim()+"' and VillageID='"+villageID+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");
			db.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		CommonFunctions.writeLog("Aquaculture", "Success", e.getMessage());
		Dialogs.AlertDialogs(this,"Information!!", "Pleae Try Again");
		e.printStackTrace();
	}


		Dialogs.AlertDialogs(this,"Information!!", "Data Successfully Uploaded");


		((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
		((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
		((Spinner)findViewById(R.id.typeoffarm_sp)).setSelection(0);
		((Spinner)findViewById(R.id.farmstatus)).setSelection(0);
		((Spinner)findViewById(R.id.farmregistered)).setSelection(0);
		//((Spinner)findViewById(R.id.registeredwith)).setSelection(0);
		((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
		((ImageView) findViewById(R.id.aqua_lab_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.aquaculture));
		((TextView)findViewById(R.id.latitude)).setText("");
		((TextView)findViewById(R.id.longitude)).setText("");
		((EditText)findViewById(R.id.landdetail)).setText("");
		((EditText)findViewById(R.id.surveyno_et)).setText("");
		((EditText)findViewById(R.id.adharno_et)).setText("");
		((EditText)findViewById(R.id.mobileno_et)).setText("");
		((EditText)findViewById(R.id.registrationno_et)).setText("");
		((TextView)findViewById(R.id.registrationdate)).setText("");
		((EditText)findViewById(R.id.totalwater_txt)).setText("");
		((EditText)findViewById(R.id.effectviewater_txt)).setText("");
		((EditText)findViewById(R.id.farm_name)).setText("");
		((CheckBox)findViewById(R.id.dkt)).setChecked(false);
		((CheckBox)findViewById(R.id.pattaland)).setChecked(false);
		((CheckBox)findViewById(R.id.lease)).setChecked(false);
		((CheckBox)findViewById(R.id.others)).setChecked(false);
		((CheckBox)findViewById(R.id.fish)).setChecked(false);
		((CheckBox)findViewById(R.id.prwan)).setChecked(false);
		((CheckBox)findViewById(R.id.bwfish)).setChecked(false);
		((CheckBox)findViewById(R.id.bwshrimp)).setChecked(false);
		((CheckBox)findViewById(R.id.crab)).setChecked(false);
		((CheckBox)findViewById(R.id.other)).setChecked(false);
		((EditText)findViewById(R.id.extentinha)).setText("");;
		((EditText)findViewById(R.id.totalareaoffarminha)).setText("");
		((EditText)findViewById(R.id.no_of_ponds)).setText("");
		//((EditText)findViewById(R.id.registeredwith)).setText("");
		((Spinner)findViewById(R.id.registeredwith)).setSelection(0);
		building="";

	}

	@Override
	public void Fail(String response) {
		// TODO Auto-generated method stub
		Dialogs.AlertDialogs(this,"Information!!", response);
	}

	@Override
	public void NetworkNotAvail() {
		// TODO Auto-generated method stub
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate() {
		// TODO Auto-generated method stub

		startActivity(new Intent(AquaCulturePage.this,AppUpdatePage.class));
		finish();
		return;

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) 
		{

		case R.id.aqua_lab_center_imageview:

			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();

				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE);
			}

			break;

		case R.id.registrationdate:

			showdate(((TextView)findViewById(R.id.registrationdate)));
			break;

			//	case R.id.craft_particulars:


			// ((LinearLayout)findViewById(R.id.craft_particulars)).setBackgroundColor(R.color.orange);


			//      break;

		default:
			break;
		}
	}
	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void showdate(final TextView t)
	{
		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);

		DatePickerDialog dpd = new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener()
		{
			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth)
			{
				t.setText((monthOfYear + 1)+ "/"+ dayOfMonth + "/" + year);
			}
		}, mYear, mMonth, mDay);
		dpd.getDatePicker().setMaxDate(c.getTimeInMillis());
		dpd.show();

	}
	private void validatedata()
	{

		/*if(((Spinner)findViewById(R.id.districtSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		{
			AlertDialogs("Information!!", " Please Select District");
			((Spinner)findViewById(R.id.districtSp)).requestFocus();
			return;
		}

		if(((Spinner)findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		{
			AlertDialogs("Information!!", " Please Select Mandal");
			((Spinner)findViewById(R.id.mandalSp)).requestFocus();
			return;
		}*/

		try {
			if(((Spinner)findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner)findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}


			if(((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner)findViewById(R.id.village_spinner)).requestFocus();
				return;
			}

			if(((Spinner)findViewById(R.id.farmername_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Farmer Name");
				((Spinner)findViewById(R.id.farmername_sp)).requestFocus();
				return;
			}


			if(((Spinner)findViewById(R.id.typeoffarm_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Type of Farm");
				((Spinner)findViewById(R.id.typeoffarm_sp)).requestFocus();
				return;
			}




			if(((EditText)findViewById(R.id.landdetail)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.landdetail)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.landdetail)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.adharno_et)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.adharno_et)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.adharno_et)).requestFocus();
				return;
			}

			adharno=((EditText)findViewById(R.id.adharno_et)).getText().toString();


			if(Character.isDigit(adharno.charAt(0)))
			{
				if(!CommonFunctions.validateAadharNumber(adharno))
				{
					//AlertDialogs("Information!!", " Please Enter Valid Aadhaar Number");
					((EditText)findViewById(R.id.adharno_et)).requestFocus();
					((EditText)findViewById(R.id.adharno_et)).setError(" Please Enter Valid Aadhaar Number");
					return;
				}
			}

			if(((EditText)findViewById(R.id.mobileno_et)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.mobileno_et)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.mobileno_et)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.farm_name)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.farm_name)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.farm_name)).requestFocus();
				return;
			}





			if(((Spinner)findViewById(R.id.farmstatus)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Farm Status");
				((Spinner)findViewById(R.id.farmstatus)).requestFocus();
				return;
			}



			if(((Spinner)findViewById(R.id.registeredwith)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select registered with");
				((Spinner)findViewById(R.id.registeredwith)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.registrationno_et)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.registrationno_et)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.registrationno_et)).requestFocus();
				return;
			}



			if(((EditText)findViewById(R.id.totalwater_txt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.totalwater_txt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.totalwater_txt)).requestFocus();
				return;
			}


			if(((EditText)findViewById(R.id.effectviewater_txt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.effectviewater_txt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.effectviewater_txt)).requestFocus();
				return;
			}

			if(((CheckBox)findViewById(R.id.fish)).isChecked()==false&&((CheckBox)findViewById(R.id.prwan)).isChecked()==false&&((CheckBox)findViewById(R.id.bwfish)).isChecked()==false&&((CheckBox)findViewById(R.id.bwshrimp)).isChecked()==false&&((CheckBox)findViewById(R.id.crab)).isChecked()==false&&((CheckBox)findViewById(R.id.other)).isChecked()==false)
			{


				AlertDialogs("Information!!", " Please Select Type of Culture");

				return;
			}

			if(((CheckBox)findViewById(R.id.pattaland)).isChecked()==false&&((CheckBox)findViewById(R.id.dkt)).isChecked()==false&&((CheckBox)findViewById(R.id.lease)).isChecked()==false&&((CheckBox)findViewById(R.id.others)).isChecked()==false)
			{

				AlertDialogs("Information!!", " Please Select Type of Land");

				return;
			}

			if(((EditText)findViewById(R.id.surveyno_et)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.surveyno_et)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.surveyno_et)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.extentinha)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.extentinha)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.extentinha)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.totalareaoffarminha)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.totalareaoffarminha)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.totalareaoffarminha)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.no_of_ponds)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.no_of_ponds)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.no_of_ponds)).requestFocus();
				return;
			}


			if(((CheckBox)findViewById(R.id.fish)).isChecked()==true)
			{
				//	culture=((CheckBox)findViewById(R.id.fish)).getText().toString();
				typeofculture.add("1");
			}
			if(((CheckBox)findViewById(R.id.prwan)).isChecked()==true)
			{
				//culture=((CheckBox)findViewById(R.id.prwan)).getText().toString();
				typeofculture.add("2");
			}
			if(((CheckBox)findViewById(R.id.bwfish)).isChecked()==true)
			{
				//	culture=((CheckBox)findViewById(R.id.bwfish)).getText().toString();
				typeofculture.add("3");
			}
			if(((CheckBox)findViewById(R.id.bwshrimp)).isChecked()==true)
			{
				//culture=((CheckBox)findViewById(R.id.bwshrimp)).getText().toString();
				typeofculture.add("4");

			}
			if(((CheckBox)findViewById(R.id.crab)).isChecked()==true)
			{
				//	culture=((CheckBox)findViewById(R.id.crab)).getText().toString();
				typeofculture.add("5");

			}
			if(((CheckBox)findViewById(R.id.other)).isChecked()==true)
			{
				//		culture=((CheckBox)findViewById(R.id.other)).getText().toString();
				typeofculture.add("6");

			}

			if(((CheckBox)findViewById(R.id.pattaland)).isChecked()==true)
			{
				//		culture=((CheckBox)findViewById(R.id.other)).getText().toString();
				typeofland.add("1");

			}

			if(((CheckBox)findViewById(R.id.dkt)).isChecked()==true)
			{
				//		culture=((CheckBox)findViewById(R.id.other)).getText().toString();
				typeofland.add("2");

			}

			if(((CheckBox)findViewById(R.id.lease)).isChecked()==true)
			{
				//		culture=((CheckBox)findViewById(R.id.other)).getText().toString();
				typeofland.add("3");

			}

			if(((CheckBox)findViewById(R.id.others)).isChecked()==true)
			{
				//		culture=((CheckBox)findViewById(R.id.other)).getText().toString();
				typeofland.add("4");

			}










			if(building.equalsIgnoreCase(""))
			{
				AlertDialogs("Information!!", " Please Capture  Aqua Lab Photo");
				return;
			}
			if(!building.equalsIgnoreCase(""))
			{
				if(latitude==0.000000 && longitude==0.000000)
				{
					AlertDialogs("Information!!", " Please Capture Photo Again");
					return;

				}

			}





			if(latitude==0.000000 && longitude==0.000000)
			{
				AlertDialogs("Information!!", " Please Submit The Details Again");
				return;

			}

			db.open();
			String lname =((EditText)findViewById(R.id.landdetail)).getText().toString();

			landownership_id=db.getSingleValue("select distinct Id from Ownership_Detail where Name='"+lname+"'");

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			CommonFunctions.writeLog("Aquaculture", "validatedata", e1.getMessage());

			e1.printStackTrace();
		}





		JSONObject data=new JSONObject();
		try 
		{

			JSONObject seedData=new JSONObject();

			seedData.put("USERID", HomeData.userID);
			seedData.put("DEVICEID", HomeData.sDeviceId);
			seedData.put("ACID",aqalab_id);
			seedData.put("SurveyNo",((EditText)findViewById(R.id.surveyno_et)).getText().toString());
			seedData.put("AadharNo",((EditText)findViewById(R.id.adharno_et)).getText().toString());
			seedData.put("MobileNo",((EditText)findViewById(R.id.mobileno_et)).getText().toString());
			seedData.put("REGISTRATIONNO",((EditText)findViewById(R.id.registrationno_et)).getText().toString());

			seedData.put("TWSA",((EditText)findViewById(R.id.totalwater_txt)).getText().toString());
			seedData.put("EWSA",((EditText)findViewById(R.id.effectviewater_txt)).getText().toString());

			seedData.put("NoofPonds",((EditText)findViewById(R.id.no_of_ponds)).getText().toString());

			//	seedData.put("Tyoeofculture",((EditText)findViewById(R.id.adharno_et)).getText().toString());
			seedData.put("FarmType",((Spinner)findViewById(R.id.typeoffarm_sp)).getSelectedItemPosition());
			seedData.put("LandOwnershipDetails",landownership_id);
			seedData.put("FarmStatus",((Spinner)findViewById(R.id.farmstatus)).getSelectedItemPosition());

			seedData.put("REGISTEREDWITH",((Spinner)findViewById(R.id.registeredwith)).getSelectedItemPosition());
			seedData.put("NameoftheFarm",((Spinner)findViewById(R.id.farmername_sp)).getSelectedItem().toString());
			seedData.put("FarmCulture",android.text.TextUtils.join(",", typeofculture));

			seedData.put("TYPESOFLAND",android.text.TextUtils.join(",", typeofland));

			seedData.put("EXTENT",((EditText)findViewById(R.id.extentinha)).getText().toString());
			seedData.put("TOTALFARMAREA",((EditText)findViewById(R.id.totalareaoffarminha)).getText().toString());




			seedData.put("BASE64PHOTO",building);
			seedData.put("LONGITUDE", longitude);
			seedData.put("LATITUDE", latitude);
			data.put("Version", HomeData.sAppVersion);
			data.put("AQUACULTUREGEOTAGGING", seedData);
		//	RequestServer request=new RequestServer(this);
			//request.addParam("VERSION",HomeData.sAppVersion);
			//request.addParam("JSON", data.toString());
			//request.addParam("image", building);
		//	request.ProccessRequest(this, "AQUACULTURE_UPDATELOCATIONDETAILS");
			
			
			WebserviceCall request=new WebserviceCall(this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "AQUACULTURE_UPDATELOCATIONDETAILS");
			
			return;


		} 
		catch (JSONException e)
		{
			CommonFunctions.writeLog("Aquaculture", "AQUACULTUREGEOTAGGING", e.getMessage());

			e.printStackTrace();
		}




	}


	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) {
		// TODO Auto-generated method stub
		try {
			switch (parent.getId()) 
			{
			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(AquaCulturePage.this, "select distinct MandalName from AquaCulture_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);
					}
					else
					{
						loadSpinnerData("select distinct MandalName from AquaCulture_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;

			case R.id.mandalSp:

				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
				((Spinner)findViewById(R.id.typeoffarm_sp)).setSelection(0);		
				((Spinner)findViewById(R.id.farmstatus)).setSelection(0);
				((Spinner)findViewById(R.id.farmregistered)).setSelection(0);
				//		((EditText)findViewById(R.id.registeredwith)).setText("");

				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.aquaculture));
				((TextView)findViewById(R.id.latitude)).setText("");
				((TextView)findViewById(R.id.longitude)).setText("");

				((EditText)findViewById(R.id.landdetail)).setText("");

				((EditText)findViewById(R.id.surveyno_et)).setText("");
				((EditText)findViewById(R.id.adharno_et)).setText("");
				((EditText)findViewById(R.id.mobileno_et)).setText("");
				((EditText)findViewById(R.id.registrationno_et)).setText("");
				((TextView)findViewById(R.id.registrationdate)).setText("");
				((EditText)findViewById(R.id.totalwater_txt)).setText("");
				((EditText)findViewById(R.id.effectviewater_txt)).setText("");
				//	((EditText)findViewById(R.id.registeredwith)).setText("");

				building="";

				String mandalname=parent.getSelectedItem().toString().trim();  
				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
				if(!mandalname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					mandalID=db.getSingleValue("select distinct MandalID from AquaCulture_Master where MandalName='"+mandalname +"' and DistrictID='"+distrID+"'");															
					db.close();
					loadSpinnerData("select distinct PanchayatName from AquaCulture_Master where MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID.trim()+"' order by PanchayatName",((Spinner)findViewById(R.id.panchayat_spinner)));
				}

				break;
			case R.id.panchayat_spinner:
				String panchayatname=parent.getSelectedItem().toString().trim(); 
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
				if(!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID=db.getSingleValue("select distinct PanchayatID from AquaCulture_Master where PanchayatName='"+panchayatname+"' and MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID.trim()+"'");

					db.close();
					loadSpinnerData("select distinct VillageName from AquaCulture_Master where PanchayatID='"+panchayatID.trim()+"' and MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID.trim()+"' order by VillageName",((Spinner)findViewById(R.id.village_spinner)));
				}

				break;

			case R.id.village_spinner:
				String villagename=parent.getSelectedItem().toString();
				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
				if(!villagename.equalsIgnoreCase("--Select--"))
				{
					db.open();
					villageID=db.getSingleValue("select distinct VillageID from AquaCulture_Master where VillageName='"+villagename+"' and PanchayatID='"+panchayatID+"' and MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID.trim()+"'");
					db.close();
					loadSpinnerData("select distinct FarmerName from AquaCulture_Master where trim(MandalID)='"+mandalID.trim()+"' and trim (PanchayatID)='"+panchayatID.trim()+"'and trim (VillageID)='"+villageID.trim()+"' and trim(DistrictID)='"+distrID.trim()+"' order by FarmerName ",((Spinner)findViewById(R.id.farmername_sp)));
				}

				break;


			case R.id.farmername_sp:

				FarmerName=parent.getSelectedItem().toString();

				if(!FarmerName.equalsIgnoreCase("--Select--"))
				{
					db.open();
					//		aqalab_id=db.getSingleValue("select distinct AquacultureID from Aquaculture where AquacultureName='"+aqualab_name+"'");

					String SurveyNo=db.getSingleValue("select SurveyNo from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");
					String adharno=db.getSingleValue("select AdhaarNo from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");

					String mobileno=db.getSingleValue("select MobileNo from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");
					String registrationno=db.getSingleValue("select RegirstraionNo from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");

					String registrationdate=db.getSingleValue("select RegistrationDate from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");

					String totalwater=db.getSingleValue("select TotalAreaOfFarm from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");

					String effectivewater=db.getSingleValue("select WaterSpreadinha from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");

					String landdetails=db.getSingleValue("select LandOwnership from AquaCulture_Master where trim(VillageID)='"+villageID.trim()+"' and PanchayatID='"+panchayatID+"' and trim(MandalID)='"+mandalID.trim()+"' and DistrictID='"+distrID+"' and trim(FarmerName)='"+FarmerName.trim()+"'");

					//	String landdetails=db.getSingleValue("select Name from Landownership where Id='"+landdetails_id+"'");

					String aquculture_name=db.getSingleValue("select AquacultureName from AquaCulture_Master where trim(FarmerName)='"+FarmerName.trim()+"'");


					aqalab_id=db.getSingleValue("select distinct AquacultureID from AquaCulture_Master where AquacultureName='"+aquculture_name+"'");



					String reg_particular_id= db.getSingleValue("select RegisteredWith from AquaCulture_Master where trim(MandalID)='"+mandalID.trim()+"' and trim (PanchayatID)='"+panchayatID.trim()+"'and trim (VillageID)='"+villageID.trim()+"' and trim(DistrictID)='"+distrID.trim()+"' and trim(FarmerName)='"+FarmerName.trim()+"'");


					//		String reg_particular=db.getSingleValue("select Name from Registered_With where Id='"+reg_particular_id+"'");


					((EditText)findViewById(R.id.surveyno_et)).setText(SurveyNo);
					((EditText)findViewById(R.id.adharno_et)).setText(adharno);
					((EditText)findViewById(R.id.mobileno_et)).setText(mobileno);
					((EditText)findViewById(R.id.registrationno_et)).setText(registrationno);
					((TextView)findViewById(R.id.registrationdate)).setText(registrationdate);
					((EditText)findViewById(R.id.totalwater_txt)).setText(totalwater);
					((EditText)findViewById(R.id.effectviewater_txt)).setText(effectivewater);
					((EditText)findViewById(R.id.landdetail)).setText(landdetails);
					((EditText)findViewById(R.id.farm_name)).setText(aquculture_name);

					//		((EditText)findViewById(R.id.registeredwith)).setText(reg_particular);

					db.close();

				}

				break;
			default:
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block

			CommonFunctions.writeLog("Aquaculture", "onItemSelected", e.getMessage());
			e.printStackTrace();
		} 
	}




	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}
