package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Locale;

import org.json.JSONObject;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.JSONParser;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class SeedFarmCenterPage extends AppCompatActivity implements OnItemSelectedListener, OnClickListener,ServerResponseListener
{
	ActionBar ab;
	GPSTracker gps;
	DBAdapter db;
	
	String strBaseimage="";
	double latitude,longitude;
	String panchayatID="",villageID="",SeedFormID="";
	String roleID;
	String distrID,districtName; 
	String mandalID,mandalName;
	int PHOTO_CAPTURE=100;


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{

		try 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.seedfarm);
			db=new DBAdapter(this);	
			ab=getSupportActionBar();
			ab.setTitle("Seed Farm Center");
			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 

			gps=new GPSTracker(SeedFarmCenterPage.this);
			LoadUserDetails();
			Log.d("User ID", HomeData.userID);

			((Spinner)findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.seedfarm_sp)).setOnItemSelectedListener(this);

			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from SeedFarmCenters_Master where UserId ='"+HomeData.userID+"' ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(false);
			}
			else
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);

			}

			((ImageView)findViewById(R.id.fish_landing_center_imageview)).setOnClickListener(this);
			findViewById(R.id.submit_btn).setOnClickListener(this);
	//		findViewById(R.id.mapview).setOnClickListener(this);

		} 
		catch (Exception e)
		{
			CommonFunctions.writeLog("MappingSeedFarm", "oncreate", e.getMessage());
			e.printStackTrace();
			AlertDialogsForceBack("Information!!", "Please Re-Login once/Try Again!!");
		}


	}

	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));
			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}
	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("MappingSeedFarm", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.fish_landing_center_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}
	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.fish_landing_center_imageview:
			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();

				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE);
			}
			break;
		case R.id.submit_btn:
			validatedata();
			break;
			
		
		default:
			break;
		}
	}

	private void validatedata()
	{

		try 
		{
			if(((Spinner)findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Mandal");
				((Spinner)findViewById(R.id.mandalSp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner)findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner)findViewById(R.id.village_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.seedfarm_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Seed Farm Center");
				((Spinner)findViewById(R.id.seedfarm_sp)).requestFocus();
				return;
			}
			if(strBaseimage.equalsIgnoreCase(""))
			{
				AlertDialogs("Information!!", " Please Capture  Seed Farm Center Photo");
				return;
			}
			if(latitude== 0 || longitude== 0)
			{
				AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
				return;

			}
			if(SeedFormID == null || SeedFormID.equalsIgnoreCase("null") || SeedFormID.equalsIgnoreCase("0")|| SeedFormID.equalsIgnoreCase(""))
			{
			//	((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
				AlertDialogs("Information!!", "FLC ID Not found, Please try again!!");
				return;
			}

			JSONObject seedData=new JSONObject();
			seedData.put("DEVICEID", HomeData.sDeviceId);
			seedData.put("SEEDFARMID", SeedFormID);
			seedData.put("LONGITUDE", ""+longitude);
			seedData.put("BASE64PHOTO",strBaseimage);//"iVBORw0KGgoAAAANSUhEUgAAAJYAAADICAIAAACF548yAAAAA3NCSVQICAjb"
			seedData.put("LATITUDE", ""+latitude);
			seedData.put("USERID", HomeData.userID);
			
			JSONObject data=new JSONObject();
			data.put("Version", HomeData.sAppVersion);
			data.put("SeedFarmgeotagging", seedData);

			WebserviceCall request=new WebserviceCall(SeedFarmCenterPage.this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "SeedFarm_UpdateGeoTagging");

		} 
		catch (Exception e1) 
		{
			CommonFunctions.writeLog("MappingSeedFarm", "validatedata", e1.getMessage());
			e1.printStackTrace();
			
			AlertDialogs("Information!!", "Somethimg went wrong, Please try again!!");
		}



	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void Success(String response) 
	{

		try 
		{
			ContentValues seedfarmlist = new ContentValues();
			seedfarmlist.put("Image", strBaseimage);
			seedfarmlist.put("Latitude",""+latitude);
			seedfarmlist.put("Longitude",""+longitude);	
			seedfarmlist.put("IsSync","Y");
			db.open();
			db.updateTableData("SeedFarmCenters_Master", seedfarmlist,"UserId='"+HomeData.userID +"' and SeedRegId='"+SeedFormID+"' and VillageID='"+villageID+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");			
			db.close();

			

			if(!roleID.equalsIgnoreCase("3"))
				((Spinner)findViewById(R.id.mandalSp)).setSelection(0);

			((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
			((TextView)findViewById(R.id.indicator_type)).setText("");		
			((TextView) findViewById(R.id.category)).setText("");;
			((TextView) findViewById(R.id.ownership)).setText("");
			((TextView) findViewById(R.id.latitude)).setText("");
			((TextView) findViewById(R.id.longitude)).setText("");
			((ImageView) findViewById(R.id.fish_landing_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.pic4));
			strBaseimage="";
			Dialogs.AlertDialogs(this,"Information!!", JSONParser.msg);
		} 
		catch (Exception e)
		{
			CommonFunctions.writeLog("MappingSeedFarm", "Success", e.getMessage());
			Dialogs.AlertDialogs(this,"Information!!", "Upload Failed, Please Try Again");
			e.printStackTrace();
			return;
		}

	}

	@Override
	public void Fail(String response)
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}

	@Override
	public void NetworkNotAvail()
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate()
	{
		startActivity(new Intent(SeedFarmCenterPage.this,AppUpdatePage.class));
		finish();
		return;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) {

		try 
		{
			strBaseimage="";
			((ImageView) findViewById(R.id.fish_landing_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.pic4));
			((TextView)findViewById(R.id.indicator_type)).setText("");		
			((TextView) findViewById(R.id.category)).setText("");;
			((TextView) findViewById(R.id.ownership)).setText("");
			((TextView) findViewById(R.id.latitude)).setText("");
			((TextView) findViewById(R.id.longitude)).setText("");
			
			switch (parent.getId()) 
			{
			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(SeedFarmCenterPage.this, "select distinct MandalName from SeedFarmCenters_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);
					}
					else
					{
						loadSpinnerData("select distinct MandalName from SeedFarmCenters_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;
			case R.id.mandalSp:
				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
				String mandalname=parent.getSelectedItem().toString().trim();  
				if(!mandalname.equalsIgnoreCase("--Select--"))
				{
					if(!roleID.equalsIgnoreCase("3"))
					{
						db.open();
						mandalID=db.getSingleValue("select MandalID from SeedFarmCenters_Master where MandalName='"+mandalname +"' and DistrictID='"+distrID+"'");															
						db.close();
					}				
					loadSpinnerData("select distinct PanchayatName from SeedFarmCenters_Master where DistrictID='"+distrID+"'and MandalID='"+mandalID+"' order by PanchayatName ",((Spinner)findViewById(R.id.panchayat_spinner)));
				}
				break;
			case R.id.panchayat_spinner:
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
				
				String panchayatname=parent.getSelectedItem().toString().trim(); 
				if(!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID=db.getSingleValue("select PanchayatID from SeedFarmCenters_Master where PanchayatName='"+panchayatname+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"'");
					db.close();
					loadSpinnerData("select distinct VillageName from SeedFarmCenters_Master where PanchayatID='"+panchayatID +"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'",((Spinner)findViewById(R.id.village_spinner)));
				}
				break;

			case R.id.village_spinner:
				((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
				String villagename=parent.getSelectedItem().toString();
				if(!villagename.equalsIgnoreCase("--Select--"))
				{
					db.open();
					villageID=db.getSingleValue("select VillageID from SeedFarmCenters_Master where VillageName='"+villagename+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");
					db.close();
					loadSpinnerData("select SeedFarmName from SeedFarmCenters_Master where MandalID='"+mandalID +"' and PanchayatID='"+panchayatID+"'and VillageID='"+villageID+"'and DistrictID='"+distrID+"' order by SeedFarmName ",((Spinner)findViewById(R.id.seedfarm_sp)));

				}
				break;

			case R.id.seedfarm_sp:
				String seedfarmname=parent.getSelectedItem().toString();
				if(!seedfarmname.equalsIgnoreCase("--Select--"))
				{

					db.open();
					Cursor cursor=db.getTableDataCursor("select SeedRegId,CategoryOfSeedFarm,IndicatorType,Ownership from SeedFarmCenters_Master "
							+ "where SeedFarmName='"+seedfarmname+"' and VillageID='"+villageID+"' and PanchayatID='"+panchayatID+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'");
					if(cursor.getCount()>0)
					{
						cursor.moveToFirst();
						SeedFormID=cursor.getString(cursor.getColumnIndex("SeedRegId"));
						((TextView)findViewById(R.id.category)).setText(cursor.getString(cursor.getColumnIndex("CategoryOfSeedFarm")));
						((TextView)findViewById(R.id.indicator_type)).setText(cursor.getString(cursor.getColumnIndex("IndicatorType")));
						((TextView)findViewById(R.id.ownership)).setText(cursor.getString(cursor.getColumnIndex("Ownership")));
					}
					else
					{
						AlertDialogs("Information!!", "Seed farm details not found, Please contact APOnline");
						cursor.close();
						db.close();
						((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
						return;
					}
					cursor.close();
					db.close();

					if(SeedFormID == null || SeedFormID.equalsIgnoreCase("null") || SeedFormID.equalsIgnoreCase("0")|| SeedFormID.equalsIgnoreCase(""))
					{
						((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
						AlertDialogs("Information!!", "Seed farm details not found, Please contact APOnline");
					}
					latitude=gps.getLatitude();
					longitude=gps.getLongitude();
				}
				break;



			default:
				break;
			}
		}
		catch (Exception e) 
		{
			CommonFunctions.writeLog("MappingSeedFarm", "onItemSelected", e.getMessage());
			e.printStackTrace();
		}
	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) 
	{

	}


}
