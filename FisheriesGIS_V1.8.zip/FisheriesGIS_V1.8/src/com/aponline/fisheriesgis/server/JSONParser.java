package com.aponline.fisheriesgis.server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.os.Handler;
import android.os.Message;

import com.aponline.fisheriesgis.HomeData;
import com.aponline.fisheriesgis.database.DBAdapter;

@SuppressLint("NewApi")
public class JSONParser extends Thread implements ErrorCodes 
{
	Handler mUIHandler;
	Context mContext;
	String methodName;
	String response;
	public static String Error, Data, msg;
	DBAdapter db;

	public JSONParser(Context mContext,Handler handler,String methodName,String response) 
	{
		this.mContext = mContext;
		this.mUIHandler=handler;
		this.methodName=methodName;
		this.response=response;
		db=new DBAdapter(mContext);		
	}

	public JSONParser(Context mContext)
	{
		this.mContext = mContext;
		db=new DBAdapter(mContext);		
	}

	public void run()
	{
		Error="";
		msg="";
		Message localMessage = new Message();
		int resCode=mFailure;
		try 
		{
			if (methodName.equalsIgnoreCase("GetUserDetails")) 
			{
				resCode = GetUserDetails(new JSONObject(response));
			}
			else if (methodName.equalsIgnoreCase("GetFLC")) 
			{
				resCode = GetFLC(new JSONArray(response));
			}
			else if (methodName.equalsIgnoreCase("GetSeedFarms")) 
			{
				resCode = GetSeedFarms(new JSONArray(response));
			}
			else if (methodName.equalsIgnoreCase("GetMITanks")) 
			{
				resCode = GetMITank(new JSONArray(response));
			}
			else if (methodName.equalsIgnoreCase("GetAquaLabs")) 
			{
				resCode = GetAquaLabs(new JSONArray(response));
			}
			else if (methodName.equalsIgnoreCase("GetAquaculture")) 
			{
				resCode = GetAquaculture(new JSONArray(response));
			}

			else if (methodName.equalsIgnoreCase("GetAquaCultureFarmDetails")) 
			{
				resCode = GetAquaCultureFarmDetails(new JSONArray(response));
			}

			else if (methodName.equalsIgnoreCase("GetCFSRPONDS")) 
			{
				resCode = GetCFSRPONDS(new JSONArray(response));
			}
			else if (methodName.equalsIgnoreCase("UpdateFLCLocationDetails")) 
			{
				resCode = UpdateFLCLocationDetails(new JSONObject(response));              
			}
			else if (methodName.equalsIgnoreCase("AQUACULTURE_UPDATELOCATIONDETAILS")) 
			{
				resCode = AQUACULTURE_UPDATELOCATIONDETAILS(new JSONObject(response));             
			}
			else if (methodName.equalsIgnoreCase("SeedFarm_UpdateGeoTagging")) 
			{
				resCode = UpdateSeedFarmLocationDetails(new JSONObject(response));
			}
			else if (methodName.equalsIgnoreCase("UPDATELOCATIONDETAILS_AL")) 
			{
				resCode = UpdateaqualabLocationDetails(new JSONObject(response));
			}
			else if (methodName.equalsIgnoreCase("UPDATECFSRPONDSDETAILS")) 
			{
				resCode = UPDATECFSRPONDSDETAILS(new JSONObject(response));              
			}			
			else if (methodName.equalsIgnoreCase("AQUA_ADDPONDDETAILS")) 
			{
				resCode = AQUA_ADDPONDDETAILS(new JSONObject(response));              
			}			
			else if (methodName.equalsIgnoreCase("MITANK_UPDATELOCATIONDETAILS")) 
			{
				resCode = UpdateMITankLocationDetails(new JSONObject(response));
			}
			else if (methodName.equalsIgnoreCase("GetAquaCulturePondDetails")) 
			{
				resCode = GetAquaCulturePondDetails(new JSONArray(response));
			}
		}
		catch (JSONException e) 
		{
			e.printStackTrace();
			resCode=mJSONException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			resCode=mException;
		}
		finally 
		{
			localMessage.what = resCode;
			mUIHandler.sendMessage(localMessage);
		}
	}

	
	public int checkForError(JSONObject response) throws JSONException, Exception
	{

		JSONObject jsonObject =response;//{"STATUS":false,"MESSAGE":null}
		if (jsonObject.length() > 0) 
		{
			if (jsonObject.has("Data")) 
			{
				Data = jsonObject.optString("Data").toString();
				if(Data.equalsIgnoreCase("Update Version"))
				{
					return mUpdateVersion;
				}
			}
			if (jsonObject.has("MESSAGE")&&!jsonObject.getBoolean("STATUS")) 
			{
				Error = jsonObject.optString("MESSAGE");
				if(Error.equalsIgnoreCase("Update Version"))
				{
					return mUpdateVersion;	
				}
				else
				{
					return mErrorResFromWebServices;
				}
			}
			return 10; 
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int GetUserDetails(JSONObject response) throws JSONException, Exception
	{
		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{

				ContentValues flcdetails=new ContentValues();
				flcdetails.put("UserId",jsonObject.optString("UserId").trim());
				flcdetails.put("Password",HomeData.Password);
				flcdetails.put("UserName",jsonObject.optString("UserName").trim());  
				flcdetails.put("MobileNo",jsonObject.optString("MobileNo").trim()); 
				flcdetails.put("Email",jsonObject.optString("Email").trim()); 
				flcdetails.put("RoleID",jsonObject.optString("RoleID").trim());  
				flcdetails.put("Role_Name",jsonObject.optString("Role_Name").trim());  
				flcdetails.put("DistrictID",jsonObject.optString("DistID").trim());  
				flcdetails.put("DistrictName",jsonObject.optString("DistrictName").trim());  
				flcdetails.put("MandalID",jsonObject.optString("ManID").trim());
				flcdetails.put("MandalName",jsonObject.optString("MandalName").trim());
				flcdetails.put("CreatedBy",HomeData.userID);

				db.open();
				db.deleteTableData("UserDetailsMaster",null);
				db.insertTableData("UserDetailsMaster",flcdetails);
				db.close();
			}
			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int GetFLC(JSONArray response) throws JSONException, Exception 
	{
		JSONArray jsonArray = response;
		if (jsonArray.length() > 0) 
		{
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			for(int i=0;i<jsonArray.length();i++)
			{
				if(i==0)
				{
					db.open();
					db.deleteTableData("FishLandCenter_Master","UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				JSONObject jsonObject1=jsonArray.getJSONObject(i);
				ContentValues flcdetails=new ContentValues();
				flcdetails.put("UserId",HomeData.userID);
				flcdetails.put("DistrictName",jsonObject1.optString("District_description").trim());  
				flcdetails.put("DistrictID",jsonObject1.optString("DISTRICT_ID").trim()); 
				flcdetails.put("MandalName",jsonObject1.optString("Mandal_Description").trim()); 
				flcdetails.put("MandalID",jsonObject1.optString("MANDAL_ID").trim());  
				flcdetails.put("PanchayatName",jsonObject1.optString("PANCHAYAT_NAME").trim());  
				flcdetails.put("PanchayatID",jsonObject1.optString("Panchayat_Id").trim());  
				flcdetails.put("VillageName",jsonObject1.optString("VILLAGE_NAME").trim());  
				flcdetails.put("VillageID",jsonObject1.optString("VILLAGE_ID").trim());
				flcdetails.put("FLC_Id",jsonObject1.optString("FLCENTER_ID").trim());
				flcdetails.put("FLC_Name",jsonObject1.optString("MarineFishLandingCentreName").trim());
				flcdetails.put("IsSync",jsonObject.optString("IsGeoTagged").trim());


				db.open();
				db.insertTableData("FishLandCenter_Master",flcdetails);
				db.close();
			}
			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int GetSeedFarms(JSONArray response) throws JSONException, Exception 
	{ 

		JSONArray jsonArray =response;
		if(jsonArray.length()!=0)
		{     
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			for(int i=0;i<jsonArray.length();i++)
			{	

				if(i==0)
				{
					db.open();
					db.deleteTableData("SeedFarmCenters_Master","UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				jsonObject=jsonArray.getJSONObject(i);
				ContentValues seedfarmlist = new ContentValues();
				seedfarmlist.put("UserId",HomeData.userID);
				seedfarmlist.put("DistrictID", jsonObject.optString("DISTRICTID").trim());
				seedfarmlist.put("DistrictName", jsonObject.optString("District_description").trim());
				seedfarmlist.put("MandalID", jsonObject.optString("MANDALID").trim());
				seedfarmlist.put("MandalName",jsonObject.optString("Mandal_Description").trim());
				seedfarmlist.put("PanchayatID",jsonObject.optString("PanchayatId").trim());
				seedfarmlist.put("PanchayatName",jsonObject.optString("PANCHAYAT_NAME").trim());
				seedfarmlist.put("VillageID",jsonObject.optString("VILLAGEID").trim());
				seedfarmlist.put("VillageName",jsonObject.optString("VILLAGE_NAME").trim());
				seedfarmlist.put("SeedRegId",jsonObject.optString("SeedRegId").trim());
				seedfarmlist.put("SeedFarmName",jsonObject.optString("NameOftheSeedFarm").trim());
				seedfarmlist.put("IsSync",jsonObject.optString("IsGeoTagged").trim());
				seedfarmlist.put("IndicatorType",jsonObject.optString("IndicatorType").trim());
				seedfarmlist.put("CategoryOfSeedFarm",jsonObject.optString("IndicatorCatType").trim());
				seedfarmlist.put("Ownership",jsonObject.optString("OwnershipType").trim());

				db.open();
				db.insertTableData("SeedFarmCenters_Master",seedfarmlist);
				db.close();

			}
			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}


	public int GetCFSRPONDS(JSONArray response) throws JSONException, Exception 
	{ 
		JSONArray jsonArray =response;
		if(jsonArray.length()!=0)
		{      
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}

			for(int i=0;i<jsonArray.length();i++)
			{

				if(i==0)
				{
					db.open();
					db.deleteTableData("CaptiveFishSeedRearingPonds_Masters", "UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				jsonObject=jsonArray.getJSONObject(i);
				ContentValues seedfarmlist = new ContentValues();
				seedfarmlist.put("UserId",HomeData.userID);
				seedfarmlist.put("CaptiveFishSeedRegId", jsonObject.optString("CaptiveFishSeedRegId").trim());
				seedfarmlist.put("FinancialYear", jsonObject.optString("FinancialYear").trim());
				seedfarmlist.put("DistrictID", jsonObject.optString("DistrictID").trim());
				seedfarmlist.put("DistrictName", jsonObject.optString("DistrictName").trim());
				seedfarmlist.put("MandalID", jsonObject.optString("MandalId").trim());
				seedfarmlist.put("MandalName", jsonObject.optString("Mandal").trim());
				seedfarmlist.put("PanchayatID", jsonObject.optString("PanchayatId").trim());
				seedfarmlist.put("PanchayatName", jsonObject.optString("Panchayat").trim());
				seedfarmlist.put("VillageID", jsonObject.optString("VillageId").trim());
				seedfarmlist.put("VillageName", jsonObject.optString("Village").trim());
				seedfarmlist.put("Public_WaterBody", jsonObject.optString("NameOfTheTank").trim());
				seedfarmlist.put("Public_waterbody_id", jsonObject.optString("PWBID").trim());
				seedfarmlist.put("NameOfCaptiveFishSeedFarm", jsonObject.optString("NameOfCaptiveFishSeedFarm").trim());
				seedfarmlist.put("CaptiveConstructedID", jsonObject.optString("CaptiveConstructedID").trim());

				seedfarmlist.put("CaptiveConstructedType", jsonObject.optString("CaptiveConstructedType").trim());
				seedfarmlist.put("DateofSanction", jsonObject.optString("SanctionDate").trim());
				seedfarmlist.put("Amount_Sanctione", jsonObject.optString("SanctionAmount").trim());
				seedfarmlist.put("DateofComplition", jsonObject.optString("DateOfComplition").trim());
				seedfarmlist.put("ExtentInHa", jsonObject.optString("ExtentInHa").trim());
				seedfarmlist.put("NoofPonds", jsonObject.optString("NoOfPonds").trim());
				seedfarmlist.put("Expenditure", jsonObject.optString("TotalExpenditureAmount").trim());

				seedfarmlist.put("CapativeRearingAreaID", jsonObject.optString("CapativeRearingAreaID").trim());
				seedfarmlist.put("CapativeRearingAreaName", jsonObject.optString("CapativeRearingAreaName").trim());

				seedfarmlist.put("IsSync", jsonObject.optString("ISActive").trim());
				seedfarmlist.put("Image", jsonObject.optString("IsGeoTagged").trim());

				db.open();
				db.insertTableData("CaptiveFishSeedRearingPonds_Masters",seedfarmlist);
				db.close();

			}

			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}

	}

	//	
	//	public int GetCFSRPONDS(JSONArray response) throws JSONException, Exception 
	//	{ 
	//		JSONArray jsonArray =response;
	//		if(jsonArray.length()!=0)
	//		{      
	//			JSONObject jsonObject = jsonArray.getJSONObject(0);
	//			int res=checkForError(jsonObject);
	//			if(res!=10)
	//			{
	//				return res;
	//			}
	//
	//			for(int i=0;i<jsonArray.length();i++)
	//			{
	//
	//				if(i==0)
	//				{
	//					db.open();
	//					db.deleteTableData("Aqua_ponds_Polustion_Master", "UserId='"+HomeData.userID+"' and IsSync!='Y'");
	//					db.close();
	//				}
	//
	//				jsonObject=jsonArray.getJSONObject(i);
	//				ContentValues seedfarmlist = new ContentValues();
	//				seedfarmlist.put("UserId",HomeData.userID);
	//				seedfarmlist.put("CaptiveFishSeedRegId", jsonObject.optString("CaptiveFishSeedRegId").trim());
	//				seedfarmlist.put("FinancialYear", jsonObject.optString("FinancialYear").trim());
	//				seedfarmlist.put("DistrictID", jsonObject.optString("DistrictID").trim());
	//				seedfarmlist.put("DistrictName", jsonObject.optString("DistrictName").trim());
	//				seedfarmlist.put("MandalID", jsonObject.optString("MandalId").trim());
	//				seedfarmlist.put("MandalName", jsonObject.optString("Mandal").trim());
	//				seedfarmlist.put("PanchayatID", jsonObject.optString("PanchayatId").trim());
	//				seedfarmlist.put("PanchayatName", jsonObject.optString("Panchayat").trim());
	//				seedfarmlist.put("VillageID", jsonObject.optString("VillageId").trim());
	//				seedfarmlist.put("VillageName", jsonObject.optString("Village").trim());
	//				seedfarmlist.put("Public_WaterBody", jsonObject.optString("NameOfTheTank").trim());
	//				seedfarmlist.put("Public_waterbody_id", jsonObject.optString("PWBID").trim());
	//				seedfarmlist.put("NameOfCaptiveFishSeedFarm", jsonObject.optString("NameOfCaptiveFishSeedFarm").trim());
	//				seedfarmlist.put("CaptiveConstructedID", jsonObject.optString("CaptiveConstructedID").trim());
	//
	//				seedfarmlist.put("CaptiveConstructedType", jsonObject.optString("CaptiveConstructedType").trim());
	//				seedfarmlist.put("DateofSanction", jsonObject.optString("SanctionDate").trim());
	//				seedfarmlist.put("Amount_Sanctione", jsonObject.optString("SanctionAmount").trim());
	//				seedfarmlist.put("DateofComplition", jsonObject.optString("DateOfComplition").trim());
	//				seedfarmlist.put("ExtentInHa", jsonObject.optString("ExtentInHa").trim());
	//				seedfarmlist.put("NoofPonds", jsonObject.optString("NoOfPonds").trim());
	//				seedfarmlist.put("Expenditure", jsonObject.optString("TotalExpenditureAmount").trim());
	//
	//				seedfarmlist.put("CapativeRearingAreaID", jsonObject.optString("CapativeRearingAreaID").trim());
	//				seedfarmlist.put("CapativeRearingAreaName", jsonObject.optString("CapativeRearingAreaName").trim());
	//
	//				seedfarmlist.put("IsSync", jsonObject.optString("ISActive").trim());
	//				seedfarmlist.put("Image", jsonObject.optString("IsGeoTagged").trim());
	//
	//				db.open();
	//				db.insertTableData("CaptiveFishSeedRearingPonds_Masters",seedfarmlist);
	//				db.close();
	//
	//			}
	//
	//			return mSuccess;
	//		}
	//		else
	//		{
	//			Error = "Data Not Found";
	//			return mErrorResFromWebServices;
	//		}
	//
	//	}
	//	



	public int GetAquaCultureFarmDetails(JSONArray response) throws JSONException, Exception 
	{ 
		JSONArray jsonArray =response;
		if(jsonArray.length()!=0)
		{      
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}

			for(int i=0;i<jsonArray.length();i++)
			{

				if(i==0)
				{
					db.open();
					db.deleteTableData("AquaCulturePond_Master", "UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				jsonObject=jsonArray.getJSONObject(i);
				ContentValues seedfarmlist = new ContentValues();
				seedfarmlist.put("UserId",HomeData.userID);
				seedfarmlist.put("DistrictID", jsonObject.optString("District").trim());
				seedfarmlist.put("DistrictName", jsonObject.optString("DISTRICTNAME").trim());
				seedfarmlist.put("MandalID", jsonObject.optString("Mandal").trim());
				seedfarmlist.put("MandalName",jsonObject.optString("MANDALNAME").trim());
				seedfarmlist.put("PanchayatID",jsonObject.optString("Panchayat").trim());
				seedfarmlist.put("PanchayatName",jsonObject.optString("GPNAME").trim());
				seedfarmlist.put("VillageID",jsonObject.optString("Village").trim());
				seedfarmlist.put("VillageName",jsonObject.optString("VILLAGENAME").trim());

				seedfarmlist.put("FarmerName",jsonObject.optString("NameoftheFarmer").trim());
				seedfarmlist.put("FatherOrHusbandName",jsonObject.optString("FatherorHusbandName").trim());
				seedfarmlist.put("AdharNo",jsonObject.optString("AadharNumber").trim());
				seedfarmlist.put("MobileNO",jsonObject.optString("MobileNo").trim());
				seedfarmlist.put("FarmOrFarmerAddress",jsonObject.optString("FarmerAddress").trim());
				seedfarmlist.put("AquaFarmName",jsonObject.optString("AQUAFARMNAME").trim());

				seedfarmlist.put("FarmType",jsonObject.optString("FarmType").trim());

				seedfarmlist.put("FarmTypeId",jsonObject.optString("FarmTypeID").trim());

				seedfarmlist.put("SourceId",jsonObject.optString("SourceId").trim());
				seedfarmlist.put("SourceOfWater",jsonObject.optString("SourceName").trim());
				seedfarmlist.put("NoOfPonds",jsonObject.optString("NoOfPonds").trim());

				seedfarmlist.put("AppNo",jsonObject.optString("AQCID").trim());
				seedfarmlist.put("PondNo",jsonObject.optString("PondNO").trim());

				
				

				seedfarmlist.put("OwnerShipID",jsonObject.optString("OwnerShipID").trim());

				seedfarmlist.put("IsEnroledID",jsonObject.optString("IsEnroledID").trim());
				seedfarmlist.put("EnrolmentNo",jsonObject.optString("EnrolmentNo").trim());
				
				
				//				seedfarmlist.put("KMLFIleName",jsonObject.optString("KMLFIleName").trim());
				//				seedfarmlist.put("KMLFile",jsonObject.optString("KMLFile").trim());

				/*	seedfarmlist.put("AquacultureID",jsonObject.optString("AQCID").trim());
				seedfarmlist.put("AquacultureName",jsonObject.optString("AQUAFARMNAME").trim());
				seedfarmlist.put("LandOwnership",jsonObject.optString("LandType").trim());
				seedfarmlist.put("RegisteredWith",jsonObject.optString("RegisteredWith").trim());
				seedfarmlist.put("SurveyNo",jsonObject.optString("SurveyNo").trim());
				seedfarmlist.put("AdhaarNo",jsonObject.optString("AadharNumber").trim());
				seedfarmlist.put("MobileNo",jsonObject.optString("MobileNO").trim());
				seedfarmlist.put("RegirstraionNo",jsonObject.optString("RegistrationNo").trim());
				//	aqualablist.put("RegistrationDate",jsonObject.optString("RegDate").trim());
				seedfarmlist.put("TotalAreaOfFarm",jsonObject.optString("TotalExtentAreainHa").trim());
				seedfarmlist.put("WaterSpreadinha",jsonObject.optString("TotalWaterSpreadareainHa").trim());
				seedfarmlist.put("FarmerName",jsonObject.optString("NameoftheFarmer").trim());
				seedfarmlist.put("IsSync",jsonObject.optString("IsGeoTagged").trim());*/

				db.open();
				db.insertTableData("AquaCulturePond_Master",seedfarmlist);
				db.close();

			}

			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}

	}
	private int GetAquaCulturePondDetails(JSONArray response) throws JSONException, Exception 
	{
		JSONArray jsonArray =response;
		if(jsonArray.length()!=0)
		{      
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}

			for(int i=0;i<jsonArray.length();i++)
			{

				if(i==0)
				{
					db.open();
					db.deleteTableData("AquaCulturePondDeatils_Master", "UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				jsonObject=jsonArray.getJSONObject(i);
				ContentValues seedfarmlist = new ContentValues();
				seedfarmlist.put("AQCID",jsonObject.optString("AQCID").trim());
				seedfarmlist.put("UserId",HomeData.userID);
				seedfarmlist.put("DistrictID", jsonObject.optString("DistrictID").trim());
				seedfarmlist.put("DistrictName", jsonObject.optString("District").trim());
				seedfarmlist.put("MandalID", jsonObject.optString("MandalID").trim());
				seedfarmlist.put("MandalName",jsonObject.optString("Mandal").trim());
				seedfarmlist.put("PanchayatID",jsonObject.optString("GPID").trim());
				seedfarmlist.put("PanchayatName",jsonObject.optString("GPNAME").trim());
				seedfarmlist.put("VillageID",jsonObject.optString("VillageID").trim());
				seedfarmlist.put("VillageName",jsonObject.optString("Village").trim());
				seedfarmlist.put("NameoftheFarmer",jsonObject.optString("NameoftheFarmer").trim());
				seedfarmlist.put("FatherOrHusbandName",jsonObject.optString("FatherorHusbandName").trim());
				seedfarmlist.put("AadharNumber",jsonObject.optString("AadharNumber").trim());
				seedfarmlist.put("MobileNO",jsonObject.optString("MobileNo").trim());
				seedfarmlist.put("FarmerAddress",jsonObject.optString("FarmerAddress").trim());
				seedfarmlist.put("AquaFarmName",jsonObject.optString("AQUAFARMNAME").trim());
				seedfarmlist.put("FarmType",jsonObject.optString("FarmType").trim());
				seedfarmlist.put("FarmTypeID",jsonObject.optString("FarmTypeID").trim());
				seedfarmlist.put("FarmAddress",jsonObject.optString("FarmAddress").trim());
				seedfarmlist.put("NoOfPonds",jsonObject.optString("NoOfPonds").trim());
				seedfarmlist.put("PondNo",jsonObject.optString("PondNo").trim());
				seedfarmlist.put("WaterSourceId",jsonObject.optString("WaterSourceId").trim());
				seedfarmlist.put("OwnerShipID",jsonObject.optString("OwnerShipID").trim());
				seedfarmlist.put("PondTypeID",jsonObject.optString("PondTypeID").trim());
				seedfarmlist.put("SurveyNo",jsonObject.optString("SurveyNo").trim());
				seedfarmlist.put("RegisteredWithId",jsonObject.optString("RegisteredWithId").trim());
				seedfarmlist.put("EnrolledMPEDA",jsonObject.optString("EnrolledMPEDA").trim());
				seedfarmlist.put("EnrollmentNO",jsonObject.optString("EnrollmentNO").trim());
				seedfarmlist.put("RegistrationNo",jsonObject.optString("RegistrationNo").trim());
				seedfarmlist.put("PondStatusId",jsonObject.optString("PondStatusId").trim());
				seedfarmlist.put("NoofCrops",jsonObject.optString("NoofCrops").trim());
				seedfarmlist.put("DefunctPeriod",jsonObject.optString("DefunctPeriod").trim());
				seedfarmlist.put("TotalExtentAreaOfPond",jsonObject.optString("TotalExtentAreaOfPond").trim());
				seedfarmlist.put("EffectiveWaterSpreadArea",jsonObject.optString("EffectiveWaterSpreadArea").trim());
				seedfarmlist.put("AssistanceRegID",jsonObject.optString("AssistanceRegID").trim());
				
				db.open();
				db.insertTableData("AquaCulturePondDeatils_Master",seedfarmlist);
				db.close();

			}

			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int GetAquaculture(JSONArray response) throws JSONException, Exception 
	{ 

		JSONArray jsonArray =response;
		if(jsonArray.length()!=0)
		{ 
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			for(int i=0;i<jsonArray.length();i++)
			{

				if(i==0)
				{
					db.open();
					db.deleteTableData("AquaCulture_Master", "UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				jsonObject=jsonArray.getJSONObject(i);
				ContentValues aqualablist = new ContentValues();
				aqualablist.put("UserId",HomeData.userID);
				aqualablist.put("DistrictID", jsonObject.optString("District").trim());
				aqualablist.put("DistrictName",jsonObject.optString("DISTRICTNAME").trim());
				aqualablist.put("MandalID",jsonObject.optString("Mandal").trim());
				aqualablist.put("MandalName",jsonObject.optString("MANDALNAME").trim());
				aqualablist.put("PanchayatID",jsonObject.optString("Panchayat").trim());
				aqualablist.put("PanchayatName",jsonObject.optString("GPNAME").trim());
				aqualablist.put("VillageID",jsonObject.optString("Village").trim());
				aqualablist.put("VillageName",jsonObject.optString("VILLAGENAME").trim());
				aqualablist.put("AquacultureID",jsonObject.optString("AQCID").trim());
				aqualablist.put("AquacultureName",jsonObject.optString("AQUAFARMNAME").trim());
				aqualablist.put("LandOwnership",jsonObject.optString("LandType").trim());
				aqualablist.put("RegisteredWith",jsonObject.optString("RegisteredWith").trim());
				aqualablist.put("SurveyNo",jsonObject.optString("SurveyNo").trim());
				aqualablist.put("AdhaarNo",jsonObject.optString("AadharNumber").trim());
				aqualablist.put("MobileNo",jsonObject.optString("MobileNO").trim());
				aqualablist.put("RegirstraionNo",jsonObject.optString("RegistrationNo").trim());
			    //aqualablist.put("OwnerShipID",jsonObject.optString("OwnerShipID").trim());
				aqualablist.put("TotalAreaOfFarm",jsonObject.optString("TotalExtentAreainHa").trim());
				aqualablist.put("WaterSpreadinha",jsonObject.optString("TotalWaterSpreadareainHa").trim());
				aqualablist.put("FarmerName",jsonObject.optString("NameoftheFarmer").trim());
				aqualablist.put("IsSync",jsonObject.optString("IsGeoTagged").trim());

				db.open();
				db.insertTableData("AquaCulture_Master",aqualablist);
				db.close();

			}
			return mSuccess;

		} 
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}


	public int GetAquaLabs(JSONArray response) throws JSONException, Exception 
	{ 

		JSONArray jsonArray =response;
		if(jsonArray.length()!=0)
		{ 
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			for(int i=0;i<jsonArray.length();i++)
			{

				if(i==0)
				{
					db.open();
					db.deleteTableData("AquaLab_Master","UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}
				jsonObject=jsonArray.getJSONObject(i);

				ContentValues aqualablist = new ContentValues();
				aqualablist.put("UserId",HomeData.userID);
				aqualablist.put("DistrictID", jsonObject.optString("District_ID").trim());
				aqualablist.put("DistrictName",jsonObject.optString("District_description").trim());
				aqualablist.put("MandalID",jsonObject.optString("Mandal_ID").trim());
				aqualablist.put("MandalName",jsonObject.optString("Mandal_Description").trim());
				aqualablist.put("PanchayatID",jsonObject.optString("Panchayat_Id").trim());
				aqualablist.put("PanchayatName",jsonObject.optString("Panchayat_Name").trim());
				aqualablist.put("VillageID",jsonObject.optString("Village_Id").trim());
				aqualablist.put("VillageName",jsonObject.optString("Village_Name").trim());
				aqualablist.put("Aqualab_id",jsonObject.optString("AqualabID").trim());
				aqualablist.put("AquaLab_Name",jsonObject.optString("AquaLabName").trim());					
				aqualablist.put("IsSync",jsonObject.optString("IsGeoTagged").trim());
				aqualablist.put("TypeofAqua_Lab",jsonObject.optString("TYPE").trim());
				aqualablist.put("Categoryof_Aqualab",jsonObject.optString("CATEGORY").trim());
				aqualablist.put("Categoryof_Analysis",jsonObject.optString("ANALYSISTYPE").trim());
				aqualablist.put("Nameofofficer",jsonObject.optString("LabOwnerName").trim());
				aqualablist.put("Mobile_no",jsonObject.optString("MobileNumber").trim());
				aqualablist.put("websiteoremail",jsonObject.optString("EmailId").trim());
				aqualablist.put("Address",jsonObject.optString("AddressOfAquaLab").trim());
				aqualablist.put("NoOfTechnical_Person",jsonObject.optString("NoofTechnicalPersons").trim());
				aqualablist.put("Adhar_No",jsonObject.optString("AadharNo").trim());
				aqualablist.put("UserId",HomeData.userID);

				db.open();
				db.insertTableData("AquaLab_Master",aqualablist);
				db.close();

			}
			return mSuccess;

		} 

		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}

	}


	public int GetMITank(JSONArray response) throws JSONException, Exception 
	{ 

		JSONArray jsonArray =response;



		if(jsonArray.length()!=0)
		{ 
			JSONObject jsonObject = jsonArray.getJSONObject(0);
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			for(int i=0;i<jsonArray.length();i++)
			{
				if(i==0)
				{
					db.open();
					db.deleteTableData("IWBCenters_Master", "UserId='"+HomeData.userID+"' and IsSync!='Y'");
					db.close();
				}

				jsonObject=jsonArray.getJSONObject(i);

				ContentValues mitank = new ContentValues();
				mitank.put("UserId",HomeData.userID);
				mitank.put("DistrictID", jsonObject.optString("District_ID").trim());
				mitank.put("DistrictName",jsonObject.optString("District_description").trim());
				mitank.put("MandalID",jsonObject.optString("Mandal_ID").trim());
				mitank.put("MandalName",jsonObject.optString("Mandal_Description").trim());
				mitank.put("PanchayatID",jsonObject.optString("Panchayat_Id").trim());
				mitank.put("PanchayatName",jsonObject.optString("Panchayat_Name").trim());
				mitank.put("VillageID",jsonObject.optString("Village_Id").trim());
				mitank.put("VillageName",jsonObject.optString("Village_Name").trim());
				mitank.put("MITank_ID",jsonObject.optString("MITANKID").trim());
				mitank.put("MITank_Name",jsonObject.optString("MITankName").trim());
				mitank.put("IsSync",jsonObject.optString("IsGeoTagged").trim());
				mitank.put("NameOfTheOfficer",jsonObject.optString("OfficeName").trim());
				mitank.put("MobileNo",jsonObject.optString("MobileNo").trim());
				mitank.put("Designation",jsonObject.optString("Designation").trim());



				db.open();
				db.insertTableData("IWBCenters_Master",mitank);
				db.close();

			}
			return mSuccess;
		}
		else
		{
			Error = "Data Not Found";
			return mErrorResFromWebServices;
		}
	}

	public int UpdateSeedFarmLocationDetails(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}	
			}
			return mSuccess;
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}


	}


	public int AQUA_ADDPONDDETAILS(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}
	public int UPDATECFSRPONDSDETAILS(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

	public int UpdateFLCLocationDetails(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}


	public int AQUACULTURE_UPDATELOCATIONDETAILS(JSONObject response) throws JSONException, Exception 
	{

		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

	public int UpdateaqualabLocationDetails(JSONObject response) throws JSONException, Exception 
	{
		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}

	public int UpdateMITankLocationDetails(JSONObject response) throws JSONException, Exception 
	{
		JSONObject jsonObject =response;
		if (jsonObject.length() > 0) 
		{
			int res=checkForError(jsonObject);
			if(res!=10)
			{
				return res;
			}
			else
			{
				if(jsonObject.has("STATUS") && jsonObject.has("MESSAGE"))
				{
					if (jsonObject.getBoolean("STATUS") && jsonObject.getString("MESSAGE").trim().equalsIgnoreCase("SUCCESSFULLY UPDATED")) 
					{
						msg=jsonObject.optString("MESSAGE").toString();
						return mSuccess;
					}
				}

			}
		}
		else
		{
			Error = "Upload Failed, Please try again!!";
			return mErrorResFromWebServices;
		}
		return mFailure;
	}


}
