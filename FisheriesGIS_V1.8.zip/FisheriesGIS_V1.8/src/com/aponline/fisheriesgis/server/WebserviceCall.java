package com.aponline.fisheriesgis.server;

import java.net.SocketTimeoutException;
import java.util.HashMap;

import com.aponline.fisheriesgis.HomeData;
import com.aponline.fisheriesgis.database.DBAdapter;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.conn.ConnectTimeoutException;
import cz.msebera.android.httpclient.entity.StringEntity;


@SuppressLint("NewApi")
public class WebserviceCall implements ErrorCodes
{
	Boolean isMasterDownload=false;

	ServerResponseListener listener;
	Handler mUIHandler;
	Context mContext;
	HashMap<String, String> paramList;
	public static String methodName; 
	ProgressDialog progressDialog;
	String proccessMsg="Proccessing,Please wait.................";

	String error;
	String RequestType;

	Activity mActivity;
	private static AsyncHttpClient client = new AsyncHttpClient();
	//Stagin  

	//
   //String baseUrl="http://125.16.9.138:8090/fisheriesws/api/mobile/";

	//LIVE 	
	
	String baseUrl="http://apfisheries.aponline.gov.in/fisheriesws/api/mobile/";

	DBAdapter db;

	public WebserviceCall(Context context,String requestType)
	{
		this.mContext=context;
		this.RequestType=requestType;
		this.paramList=new HashMap<String, String>();
		progressDialog=new ProgressDialog(context);
		db=new DBAdapter(context);
	}
	public WebserviceCall(Activity context,String requestType)
	{
		mActivity=context;
		this.mContext=context;
		this.RequestType=requestType;
		this.paramList=new HashMap<String, String>();
		progressDialog=new ProgressDialog(context);
		db=new DBAdapter(context);
	}
	private String getAbsoluteUrl(String relativeUrl) 
	{
		StringBuilder builder=new StringBuilder();
		builder.append(baseUrl);
		builder.append(relativeUrl+"?");
		return builder.toString();
	}
	private RequestParams createRequest() 
	{
		RequestParams params=new RequestParams();
		for ( String key : paramList.keySet() )
		{		
			params.put(key, paramList.get(key));
		}
		return params;
	}
	public void addParam(String key, String value)
	{
		paramList.put(key, value);
	}
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "chec"
				+ "king if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{
			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false; 

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	public void ProccessRequest(ServerResponseListener listener,String method)
	{
		this.listener=listener;
		methodName=method;
		if(isNetworkAvailable(mContext))
		{
			Loaddata();
		}
		else
		{
			this.listener.NetworkNotAvail();
		}
	}
	private void Loaddata()
	{
		progressDialog=new ProgressDialog(mContext);
		try 
		{
			Handler localHadler=new Handler()
			{
				public void dispatchMessage(Message paramMessage)
				{
					super.dispatchMessage(paramMessage);

					if(progressDialog.isShowing())
						progressDialog.dismiss();
					if(paramMessage.what==mSuccess)
					{
						if(isMasterDownload)
						{
							if(methodName.equalsIgnoreCase("GetSeedFarms"))
							{
								proccessMsg="FLC Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetFLC");
							}
							else if(methodName.equalsIgnoreCase("GetFLC"))
							{
								proccessMsg="MI Tanks Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetMITanks");
							}
							else if(methodName.equalsIgnoreCase("GetMITanks"))
							{
								proccessMsg="Aqua Labs Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetAquaLabs");
							}
							else if(methodName.equalsIgnoreCase("GetAquaLabs"))
							{
								proccessMsg="Aquaculture Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetAquaculture");
							}
							else if(methodName.equalsIgnoreCase("GetAquaculture"))
							{
								proccessMsg="CaptiveFish Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetCFSRPONDS");
							}

							//							else if(methodName.equalsIgnoreCase("Aqua_polustion"))
							//							{
							//								proccessMsg="Aquaculture Data Downloading, Please wait.................";
							//								ProccessRequest(listener, "GetAquaculture");
							//							}

							else
							{
								isMasterDownload=false;
								listener.Success("DOWNLOAD_MASTER_DATA");
							}
						}
						else
						{
							listener.Success(methodName);
						}
					}
					else if(paramMessage.what==mErrorResFromWebServices)
					{
						listener.Fail(JSONParser.Error);
					}
					else if(paramMessage.what==mFailure)
					{
						listener.Fail("Failed to transfer the data to server");
					}
					else if(paramMessage.what==mXmlPullParserException)
					{
						listener.Fail("Data parsing error, Please try again!!");
					}
					else if(paramMessage.what==mHandlerFailure||paramMessage.what==mSocketTimeoutException)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==mException||paramMessage.what==mIOException)
					{
						listener.Fail("Failed to connect to the server");
					}
					else if(paramMessage.what==mJSONException)
					{
						listener.Fail("Data not found");
					}
					else if(paramMessage.what==mUpdateVersion)
					{
						listener.AppUpdate();
					}
					else if(paramMessage.what==5)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==111||paramMessage.what==107)
					{
						if(!progressDialog.isShowing())
							progressDialog.show();
						getData();
					}
					while(true)
					{
						return;
					}
				}
			};
			this.mUIHandler=localHadler;
			progressDialog.setCancelable(false);
			progressDialog.setMessage(proccessMsg);
			if(!progressDialog.isShowing())
				progressDialog.show();
			//			progressDialog.setContentView(setCustomeLayout());
			if(RequestType.equalsIgnoreCase("POST"))//methodName.equalsIgnoreCase("SeedFarm_UpdateGeoTagging")||methodName.equalsIgnoreCase("UpdateFLCLocationDetails")||methodName.equalsIgnoreCase("UPDATELOCATIONDETAILS_AL")||methodName.equalsIgnoreCase("MITANK_UPDATELOCATIONDETAILS")||methodName.equalsIgnoreCase("AQUACULTURE_UPDATELOCATIONDETAILS")||methodName.equalsIgnoreCase("UPDATECFSRPONDSDETAILS"))
				postData();
			else
			{
				if(methodName.equalsIgnoreCase("GetUserDetails"))
				{
					new LogUtility(mActivity, mUIHandler, false, false, true).start();
				}
				else
				{
					getData();
				}
			}
			return;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			listener.Fail("Please try again!!");
		}
	}
	private void postData() 
	{
		StringEntity param;
		try 
		{
			param = new StringEntity(paramList.get("JSON"));
			client.setTimeout(180000);
			//	client.setConnectTimeout(180000);
			client.post(mContext,getAbsoluteUrl(methodName),param,"application/json", new AsyncHttpResponseHandler() 
			{

				@Override
				public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) 
				{
					try 
					{
						ContentValues contentValues=new ContentValues();
						contentValues.put("GISType", methodName);
						contentValues.put("RequestData", paramList.get("JSON"));
						contentValues.put("ResultData", new String(responseBody));
						contentValues.put("UserId", HomeData.userID);
						db.open();
						db.insertTableData("UploadTranactionDetails", contentValues);
						db.close();
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
					new JSONParser(mContext,mUIHandler,methodName,new String(responseBody)).start();
				}

				@Override
				public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error)
				{
					try 
					{
						ContentValues contentValues=new ContentValues();
						contentValues.put("GISType", methodName);
						contentValues.put("RequestData", paramList.get("JSON"));
						contentValues.put("ResultData", (new String(responseBody))+"ERROR :"+error.getMessage());
						contentValues.put("UserId", HomeData.userID);
						db.open();
						db.insertTableData("UploadTranactionDetails", contentValues);
						db.close();
					}
					catch (Exception e) 
					{
						e.printStackTrace();
					}
					checkError(statusCode, headers, responseBody, error);
				}

			});
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			mUIHandler.sendEmptyMessage(mFailure);
		}
	}
	private void getData() 
	{

		try 
		{
			if(methodName.equalsIgnoreCase("DOWNLOAD_MASTER_DATA"))
			{
				isMasterDownload=true;
				methodName="GetSeedFarms";
			}
			client.setConnectTimeout(240000);
			client.get(getAbsoluteUrl(methodName),createRequest(), new AsyncHttpResponseHandler() 
			{

				@Override
				public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) 
				{
					new JSONParser(mContext,mUIHandler,methodName,new String(responseBody)).start();
				}

				@Override
				public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error)
				{
					checkError(statusCode, headers, responseBody, error);
				}

			});
		}
		catch (Exception e)
		{
			e.printStackTrace();
			mUIHandler.sendEmptyMessage(mFailure);
		}

	}
	protected void checkError(int statusCode, Header[] headers, byte[] responseBody, Throwable error) 
	{
		Message localMessage = new Message();
		try
		{

			if (error instanceof ConnectTimeoutException || error instanceof SocketTimeoutException)
			{
				localMessage.what = mSocketTimeoutException;
			} 
			else 
			{
				localMessage.what = mException;
			}
			if(isMasterDownload)
			{
				localMessage.what = mSuccess;
				if(methodName.equalsIgnoreCase("GetSeedFarms"))
				{
					localMessage.what = mSuccess;
					//					proccessMsg="FLC Data Downloading, Please wait.................";
					//					ProccessRequest(listener, "GetFLC");
				}
				else if(methodName.equalsIgnoreCase("GetFLC"))
				{
					localMessage.what = mSuccess;
					//					proccessMsg="MI Tanks Data Downloading, Please wait.................";
					//					ProccessRequest(listener, "GetMITanks");
				}
				else if(methodName.equalsIgnoreCase("GetMITanks"))
				{
					localMessage.what = mSuccess;
					//					proccessMsg="Aqua Labs Data Downloading, Please wait.................";
					//					ProccessRequest(listener, "GetAquaLabs");
				}
				else if(methodName.equalsIgnoreCase("GetAquaLabs"))
				{
					localMessage.what = mSuccess;
					//					proccessMsg="Aquaculture Data Downloading, Please wait.................";
					//					ProccessRequest(listener, "GetAquaculture");
				}
				else if(methodName.equalsIgnoreCase("GetAquaculture"))
				{
					localMessage.what = mSuccess;
					//					proccessMsg="CaptiveFish Data Downloading, Please wait.................";
					//					ProccessRequest(listener, "GetCFSRPONDS");
				}

				//				else if(methodName.equalsIgnoreCase("GetPolustion"))
				//				{
				//					localMessage.what = mSuccess;
				//					//					proccessMsg="CaptiveFish Data Downloading, Please wait.................";
				//					//					ProccessRequest(listener, "GetCFSRPONDS");
				//				}



				else
				{
					localMessage.what = mSuccess;
					isMasterDownload=false;
				}
			}
		} 
		catch (Exception e) 
		{
			localMessage.what = mException;

			e.printStackTrace();
		}
		finally 
		{
			mUIHandler.sendMessage(localMessage);
		}
	}
}
