package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.JSONParser;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

@SuppressLint({ "NewApi", "ResourceAsColor" })
public class FishLandingCentersPage extends AppCompatActivity implements OnItemSelectedListener, OnClickListener, ServerResponseListener 
{
	ActionBar ab;
	GPSTracker gps;
	DBAdapter db;
	String strBaseimage="";
	double latitude,longitude;
	String panchayatID="",villageID="",flcID="";
	String roleID;
	String distrID,districtName; 
	String mandalID,mandalName;
	int PHOTO_CAPTURE=100;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{

		try
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.fishlandingcenters_page);
			ab = getSupportActionBar();
			ab.setTitle("MARINE FISH LANDING CENTER");
			gps = new GPSTracker(FishLandingCentersPage.this);
			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true);

			db = new DBAdapter(this);

			LoadUserDetails();
			Log.d("User ID", HomeData.userID);

			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from FishLandCenter_Master where UserId ='"+HomeData.userID+"' ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(false);
			}
			else
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
			}

			((Spinner) findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner) findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);
			((Spinner) findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner) findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((Spinner) findViewById(R.id.marinename_sp)).setOnItemSelectedListener(this);
			((ImageView) findViewById(R.id.fish_landing_center_imageview)).setOnClickListener(this);
			((TextView) findViewById(R.id.total_et)).setOnClickListener(this);
			((EditText) findViewById(R.id.mechanised_et)).addTextChangedListener(new CustomTextWatcher(((EditText) findViewById(R.id.mechanised_et)),((TextView) findViewById(R.id.total_et))));
			((EditText) findViewById(R.id.motarised_et)).addTextChangedListener(new CustomTextWatcher(((EditText) findViewById(R.id.motarised_et)),((TextView) findViewById(R.id.total_et))));
			((EditText) findViewById(R.id.tradestional_et)).addTextChangedListener(new CustomTextWatcher(((EditText) findViewById(R.id.tradestional_et)),((TextView) findViewById(R.id.total_et))));
			((EditText) findViewById(R.id.male_txt)).addTextChangedListener(new CustomTextWatcher(((EditText) findViewById(R.id.male_txt)),((TextView) findViewById(R.id.totalpopulation_txt))));
			((EditText) findViewById(R.id.female_txt)).addTextChangedListener(new CustomTextWatcher(((EditText) findViewById(R.id.female_txt)),((TextView) findViewById(R.id.totalpopulation_txt))));
			((EditText) findViewById(R.id.children_txt)).addTextChangedListener(new CustomTextWatcher(((EditText) findViewById(R.id.children_txt)),((TextView) findViewById(R.id.totalpopulation_txt))));

			findViewById(R.id.submit_btn).setOnClickListener(this);


			((TextView) findViewById(R.id.totalclick)).setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v) 
				{

					String no1 = ((EditText) findViewById(R.id.Castnets_et)).getText().toString();
					if (no1.equalsIgnoreCase("")) 
					{
						no1 = "0";
					}

					String no2 = ((EditText) findViewById(R.id.Gillnets_et)).getText().toString();
					if (no2.equalsIgnoreCase("")) 
					{
						no2 = "0";
					}

					String no3 = ((EditText) findViewById(R.id.Trammelnets_et)).getText().toString();
					if (no3.equalsIgnoreCase("")) 
					{
						no3 = "0";
					}
					String no4 = ((EditText) findViewById(R.id.Trawlnets_et)).getText().toString();
					if (no4.equalsIgnoreCase("")) 
					{
						no4 = "0";
					}
					String no5 = ((EditText) findViewById(R.id.tuna_long_lines_et)).getText().toString();
					if (no5.equalsIgnoreCase(""))
					{
						no5 = "0";
					}
					String no6 = ((EditText) findViewById(R.id.hookandlines_et)).getText().toString();
					if (no6.equalsIgnoreCase(""))
					{
						no6 = "0";
					}
					String no7 = ((EditText) findViewById(R.id.shore_seines_et)).getText().toString();
					if (no7.equalsIgnoreCase(""))
					{
						no7 = "0";
					}
					String no8 = ((EditText) findViewById(R.id.ringnets_et)).getText().toString();
					if (no8.equalsIgnoreCase(""))
					{
						no8 = "0";
					}
					String no9 = ((EditText) findViewById(R.id.other_et)).getText().toString();
					if (no9.equalsIgnoreCase(""))
					{
						no9 = "0";
					}
					int total = Integer.parseInt(no1)+ Integer.parseInt(no2) + Integer.parseInt(no3)+ Integer.parseInt(no4) + Integer.parseInt(no5)+ Integer.parseInt(no6) + Integer.parseInt(no7)+ Integer.parseInt(no8) + Integer.parseInt(no9);

					((TextView) findViewById(R.id.totalonnet)).setText(String.valueOf(total));

				}
			});

		} 
		catch (Exception e) 
		{
			CommonFunctions.writeLog("FishLandingCenters", "oncreate", e.getMessage());
			e.printStackTrace();
			AlertDialogsForceBack("Information!!", "Please Re-Login once/Try Again!!");
		}

	}
	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));
			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}
	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try 
		{
			db.open();
			ArrayList<String> lables = db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lables);
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch (Exception e) 
		{
			CommonFunctions.writeLog("FishLandingCenters", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.fish_landing_center_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}
	}

	@Override
	public void onClick(View v) 
	{

		switch (v.getId()) 
		{

		case R.id.fish_landing_center_imageview:
			if (gps.canGetLocation()) 
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();
				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE);

			}

			break;
		case R.id.submit_btn:
			validatedata();
			break;

		default:
			break;
		}
	}

	private void validatedata() 
	{

		try 
		{
			if (((Spinner) findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--")) 
			{
				AlertDialogs("Information!!", " Please Select Mandal");
				((Spinner) findViewById(R.id.mandalSp)).requestFocus();
				return;
			}
			if (((Spinner) findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--")) 
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner) findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}
			if (((Spinner) findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner) findViewById(R.id.village_spinner)).requestFocus();
				return;
			}
			if (((Spinner) findViewById(R.id.marinename_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--")) 
			{
				AlertDialogs("Information!!", " Please Select Fish Landing Center");
				((Spinner) findViewById(R.id.marinename_sp)).requestFocus();
				return;
			}

			if (strBaseimage.equalsIgnoreCase("")) 
			{
				AlertDialogs("Information!!"," Please Capture  Fish Landing Center Photo");
				return;
			}

			if(latitude== 0 || longitude== 0)
			{
				AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
				return;

			}
			if(flcID == null || flcID.equalsIgnoreCase("null") || flcID.equalsIgnoreCase("0")|| flcID.equalsIgnoreCase(""))
			{
				((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
				AlertDialogs("Information!!", "FLC ID Not found, Please try again!!");
				return;
			}


			JSONObject obj1 = new JSONObject();
			obj1.put("NETTYPE", "1");
			obj1.put("NOOFNETS", ((EditText) findViewById(R.id.Castnets_et)).getText().toString());

			JSONObject obj2 = new JSONObject();
			obj2.put("NETTYPE", "2");
			obj2.put("NOOFNETS", ((EditText) findViewById(R.id.Gillnets_et)).getText().toString());

			JSONObject obj3 = new JSONObject();
			obj3.put("NETTYPE", "3");
			obj3.put("NOOFNETS", ((EditText) findViewById(R.id.Trammelnets_et)).getText().toString());

			JSONObject obj4 = new JSONObject();
			obj4.put("NETTYPE", "4");
			obj4.put("NOOFNETS", ((EditText) findViewById(R.id.Trawlnets_et)).getText().toString());

			JSONObject obj5 = new JSONObject();
			obj5.put("NETTYPE", "5");
			obj5.put("NOOFNETS",
					((EditText) findViewById(R.id.tuna_long_lines_et)).getText().toString());

			JSONObject obj6 = new JSONObject();
			obj6.put("NETTYPE", "6");
			obj6.put("NOOFNETS",((EditText) findViewById(R.id.hookandlines_et)).getText().toString());

			JSONObject obj7 = new JSONObject();
			obj7.put("NETTYPE", "7");
			obj7.put("NOOFNETS",((EditText) findViewById(R.id.shore_seines_et)).getText().toString());

			JSONObject obj8 = new JSONObject();
			obj8.put("NETTYPE", "8");
			obj8.put("NOOFNETS", ((EditText) findViewById(R.id.ringnets_et)).getText().toString());

			JSONObject obj9 = new JSONObject();
			obj9.put("NETTYPE", "9");
			obj9.put("NOOFNETS", ((EditText) findViewById(R.id.other_et)).getText().toString());


			JSONObject obj10 = new JSONObject();
			obj10.put("BOATTYPE", "1");
			obj10.put("NOOFBOATS",((EditText) findViewById(R.id.mechanised_et)).getText().toString());

			JSONObject obj11 = new JSONObject();
			obj11.put("BOATTYPE", "2");
			obj11.put("NOOFBOATS", ((EditText) findViewById(R.id.motarised_et)).getText().toString());

			JSONObject obj12 = new JSONObject();
			obj12.put("BOATTYPE", "3");
			obj12.put("NOOFBOATS",((EditText) findViewById(R.id.tradestional_et)).getText().toString());

			JSONArray array = new JSONArray();
			if (!obj1.getString("NOOFNETS").equalsIgnoreCase(""))
			{
				array.put(obj1);
			}

			if (!obj2.getString("NOOFNETS").equalsIgnoreCase("")) 
			{
				array.put(obj2);

			}
			if (!obj3.getString("NOOFNETS").equalsIgnoreCase(""))
			{
				array.put(obj3);
			}
			if (!obj4.getString("NOOFNETS").equalsIgnoreCase("")) 
			{
				array.put(obj4);
			}
			if (!obj5.getString("NOOFNETS").equalsIgnoreCase(""))
			{
				array.put(obj5);
			}

			if (!obj6.getString("NOOFNETS").equalsIgnoreCase(""))
			{
				array.put(obj6);
			}
			if (!obj7.getString("NOOFNETS").equalsIgnoreCase(""))
			{
				array.put(obj7);
			}
			if (!obj8.getString("NOOFNETS").equalsIgnoreCase("")) 
			{
				array.put(obj8);
			}
			if (!obj9.getString("NOOFNETS").equalsIgnoreCase(""))
			{
				array.put(obj9);
			}

			JSONArray array2 = new JSONArray();
			if (!obj10.getString("NOOFBOATS").equalsIgnoreCase("")) 
			{
				array2.put(obj10);
			}

			if (!obj11.getString("NOOFBOATS").equalsIgnoreCase(""))
			{
				array2.put(obj11);
			}
			if (!obj12.getString("NOOFBOATS").equalsIgnoreCase(""))
			{
				array2.put(obj12);
			}

			JSONObject seedData = new JSONObject();
			seedData.put("DEVICEID", HomeData.sDeviceId);
			seedData.put("FLCID", flcID);
			seedData.put("LONGITUDE", longitude);
			seedData.put("BASE64PHOTO", strBaseimage);
			seedData.put("LATITUDE", latitude);
			seedData.put("USERID", HomeData.userID);
			seedData.put("MALE", ((EditText) findViewById(R.id.male_txt)).getText().toString());
			seedData.put("FEMALE", ((EditText) findViewById(R.id.female_txt)).getText().toString());
			seedData.put("CHILDREN",((EditText) findViewById(R.id.children_txt)).getText().toString());
			seedData.put("Total",((TextView) findViewById(R.id.totalpopulation_txt)).getText().toString());
			seedData.put("NETS", array);
			seedData.put("BOATS", array2);



			JSONObject data = new JSONObject();
			data.put("Version", HomeData.sAppVersion);
			data.put("Flcgeotagging", seedData);

			WebserviceCall request=new WebserviceCall(this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "UpdateFLCLocationDetails");
			return;

		} 
		catch (Exception e)
		{
			CommonFunctions.writeLog("FishLandingCenters", "UpdateFLCLocationDetails", e.getMessage());
			e.printStackTrace();
			AlertDialogs("Information!!", "Somethimg went wrong, Please try again!!");
		}



	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void Success(String response)
	{
		try 
		{
			ContentValues contentValues = new ContentValues();
			contentValues.put("Image", strBaseimage);
			contentValues.put("Latitude",""+latitude);
			contentValues.put("Longitude",""+longitude);	
			contentValues.put("IsSync","Y");
			db.open();
			db.updateTableData("FishLandCenter_Master",contentValues,"UserId='" + HomeData.userID + "' and FLC_Id='"+ flcID + "' and VillageID='"+villageID+ "' and DistrictID='"+distrID+ "' and MandalID='"+mandalID+ "' and PanchayatID='"+panchayatID+ "'");
			db.close();


			if(!roleID.equalsIgnoreCase("3"))
				((Spinner)findViewById(R.id.mandalSp)).setSelection(0);

			((EditText) findViewById(R.id.tradestional_et)).setFocusable(false);
			((EditText) findViewById(R.id.motarised_et)).setFocusable(false);

			((Spinner) findViewById(R.id.panchayat_spinner)).setSelection(0);
			((Spinner) findViewById(R.id.village_spinner)).setSelection(0);
			((Spinner) findViewById(R.id.marinename_sp)).setSelection(0);
			((EditText) findViewById(R.id.mechanised_et)).setText("");
			((EditText) findViewById(R.id.motarised_et)).setText("");
			((EditText) findViewById(R.id.tradestional_et)).setText("");
			((TextView) findViewById(R.id.total_et)).setText("");
			((TextView) findViewById(R.id.latitude)).setText("");
			((TextView) findViewById(R.id.longitude)).setText("");

			((EditText) findViewById(R.id.male_txt)).setText("");
			((EditText) findViewById(R.id.female_txt)).setText("");
			((EditText) findViewById(R.id.children_txt)).setText("");
			((TextView) findViewById(R.id.totalpopulation_txt)).setText("");

			((EditText) findViewById(R.id.Castnets_et)).setText("");
			((EditText) findViewById(R.id.Gillnets_et)).setText("");
			((EditText) findViewById(R.id.Trammelnets_et)).setText("");
			((EditText) findViewById(R.id.Trawlnets_et)).setText("");
			((EditText) findViewById(R.id.tuna_long_lines_et)).setText("");

			((EditText) findViewById(R.id.hookandlines_et)).setText("");
			((EditText) findViewById(R.id.shore_seines_et)).setText("");
			((EditText) findViewById(R.id.ringnets_et)).setText("");
			((EditText) findViewById(R.id.other_et)).setText("");
			((TextView) findViewById(R.id.totalonnet)).setText("");

			((ImageView) findViewById(R.id.fish_landing_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.icon1));
			strBaseimage = "";

			Dialogs.AlertDialogs(this, "Information!!", JSONParser.msg);
		} 
		catch (Exception e) 
		{
			CommonFunctions.writeLog("FishLandingCenters", "Success", e.getMessage());
			e.printStackTrace();
			Dialogs.AlertDialogs(this,"Information!!", "Upload Failed, Please Try Again");
		}
	}

	@Override
	public void Fail(String response)
	{
		Dialogs.AlertDialogs(this, "Information!!", response);
	}

	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this, "Information!!",				"Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate()
	{
		startActivity(new Intent(FishLandingCentersPage.this, AppUpdatePage.class));
		finish();
		return;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations = R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv = (TextView) dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes = (Button) dialog.findViewById(R.id.ok_button);
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				dialog.dismiss();
				return;
			}
		});
		if (!dialog.isShowing())
			dialog.show();
	}
	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) 
	{
		try 
		{
			strBaseimage="";
			((EditText) findViewById(R.id.mechanised_et)).setText("");
			((EditText) findViewById(R.id.motarised_et)).setText("");
			((EditText) findViewById(R.id.tradestional_et)).setText("");
			((TextView) findViewById(R.id.total_et)).setText("");
			((TextView) findViewById(R.id.latitude)).setText("");
			((TextView) findViewById(R.id.longitude)).setText("");
			((EditText) findViewById(R.id.male_txt)).setText("");
			((EditText) findViewById(R.id.female_txt)).setText("");
			((EditText) findViewById(R.id.children_txt)).setText("");
			((TextView) findViewById(R.id.totalpopulation_txt)).setText("");
			((EditText) findViewById(R.id.Castnets_et)).setText("");
			((EditText) findViewById(R.id.Gillnets_et)).setText("");
			((EditText) findViewById(R.id.Trammelnets_et)).setText("");
			((EditText) findViewById(R.id.Trawlnets_et)).setText("");
			((EditText) findViewById(R.id.tuna_long_lines_et)).setText("");
			((EditText) findViewById(R.id.hookandlines_et)).setText("");
			((EditText) findViewById(R.id.shore_seines_et)).setText("");
			((EditText) findViewById(R.id.ringnets_et)).setText("");
			((EditText) findViewById(R.id.other_et)).setText("");
			((TextView) findViewById(R.id.totalonnet)).setText("");
			((ImageView) findViewById(R.id.fish_landing_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.icon1));


			switch (parent.getId()) 
			{
			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(FishLandingCentersPage.this, "select distinct MandalName from FishLandCenter_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);
					}
					else
					{
						loadSpinnerData("select distinct MandalName from FishLandCenter_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;
			case R.id.mandalSp:
				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
				String MandalName = parent.getSelectedItem().toString().trim();
				if (!MandalName.equalsIgnoreCase("--Select--"))
				{
					if(!roleID.equalsIgnoreCase("3"))
					{
						db.open();
						mandalID=db.getSingleValue("select MandalID from FishLandCenter_Master where MandalName='"+MandalName +"' and DistrictID='"+distrID+"'");															
						db.close();
					}				
					loadSpinnerData("select distinct PanchayatName from FishLandCenter_Master where DistrictID='"+distrID+"'and MandalID='"+mandalID+"' order by PanchayatName ",((Spinner)findViewById(R.id.panchayat_spinner)));
				} 
				break;
			case R.id.panchayat_spinner:
				((Spinner) findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner) findViewById(R.id.marinename_sp)).setSelection(0);
				String panchayatname = parent.getSelectedItem().toString().trim();
				if (!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID = db.getSingleValue("select PanchayatID from FishLandCenter_Master where PanchayatName='"+ panchayatname+ "' and MandalID='"+mandalID+ "' and DistrictID='"+ distrID+ "'");
					db.close();
					loadSpinnerData("select distinct VillageName from FishLandCenter_Master where PanchayatID='"+panchayatID+ "' and MandalID='"+mandalID+ "' and DistrictID='"+ distrID+ "' order by VillageName ",((Spinner) findViewById(R.id.village_spinner)));
				} 
				break;

			case R.id.village_spinner:
				((Spinner) findViewById(R.id.marinename_sp)).setSelection(0);
				String villagename = parent.getSelectedItem().toString();
				if (!villagename.equalsIgnoreCase("--Select--")) 
				{
					db.open();
					villageID = db.getSingleValue("select VillageID from FishLandCenter_Master where VillageName='"+ villagename+ "' and PanchayatID='"+ panchayatID+ "' and MandalID='"+ mandalID+ "' and DistrictID='"+ distrID + "'");
					db.close();
					loadSpinnerData("select FLC_Name from FishLandCenter_Master where VillageID='"+ villageID+ "' and PanchayatID='"+ panchayatID+ "' and MandalID='"+mandalID+ "' and DistrictID='"+distrID+ "' order by FLC_Name ",((Spinner) findViewById(R.id.marinename_sp)));
				} 
				break;
			case R.id.marinename_sp:
				String marinename = parent.getSelectedItem().toString();
				if (!marinename.equalsIgnoreCase("--Select--")) 
				{
					db.open();
					flcID = db.getSingleValue("select FLC_Id from FishLandCenter_Master where FLC_Name='"+marinename+ "' and VillageID='"+ villageID+ "' and PanchayatID='"+ panchayatID+ "' and MandalID='"+ mandalID+ "' and DistrictID='"+distrID+ "'");
					db.close();

					if(flcID == null || flcID.equalsIgnoreCase("null") || flcID.equalsIgnoreCase("0")|| flcID.equalsIgnoreCase(""))
					{
						((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
						AlertDialogs("Information!!", "Details not found, Please contact APOnline");
					}
					latitude=gps.getLatitude();
					longitude=gps.getLongitude();
				}
				break;

			default:
				break;
			}
		} 
		catch (Exception e)
		{

			CommonFunctions.writeLog("FishLandingCenters", "onItemSelected", e.getMessage());
			e.printStackTrace();

		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0)
	{

	}

}