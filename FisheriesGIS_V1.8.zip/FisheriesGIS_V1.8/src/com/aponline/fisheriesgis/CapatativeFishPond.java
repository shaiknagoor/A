package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;

import org.json.JSONException;
import org.json.JSONObject;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class CapatativeFishPond extends AppCompatActivity implements OnItemSelectedListener, OnClickListener,ServerResponseListener
{

	public static String strBaseimage="";
	public static String compoundwallcheck="",toilecheck="",watercheck="",electricitycheck="",travischeck="",pendingamount="",typeofseedfarm=""
			,category="",seedfarmname="",rearingpond="",rearingpondid=""
			,dateofsanction="",amountofsanction=""
			,dateofcomplition="",extentinha="",noofpound="",expenditure="";

	RadioButton cyes,cno,ts,tno,ws,wno,travisyes,travisno,eyes,eno;
	public static String abc="";
	DBAdapter db;
	int typeoffarm_id;

	int flag=0;
	private int mYear,mMonth,mDay,category_id;

	public static String gender="",buildingownedorrent="",iscovered="";
	String tranche="";
	Spinner sp;

	public static double latitude,longitude;
	StringBuilder UserRegXmlDoc; 
	public static String UserName,Password;
	ProgressDialog progressDialog;
	Handler mHandler;
	Context context;
	GPSTracker gps; 
	private String panchayatID="",villageID="",PWBID="",CFSID="";
	String roleID;
	LinearLayout mandal_layout;
	String distrID,districtName; 
	String mandalID,mandalName;
	int PHOTO_CAPTURE=100;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{

		// TODO Auto-generated method stub
		try 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.capativefish);
			ActionBar ab=getSupportActionBar();
			ab.setTitle("Capative fish seed rearing ponds");
			gps=new GPSTracker(CapatativeFishPond.this);

			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 
			ab=getSupportActionBar();
			mandal_layout=(LinearLayout) findViewById(R.id.mandal_layout);
			db=new DBAdapter(this);	
			LoadUserDetails();

			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from CaptiveFishSeedRearingPonds_Masters where UserId ='"+HomeData.userID+"'ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);		
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(false);
			}
			else
			{

				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);

			}

			((Spinner)findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);


			((Spinner)findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.publicwaterbody_sp)).setOnItemSelectedListener(this);
			//			((TextView)findViewById(R.id.dateofsanction)).setOnClickListener(this);
			//			((TextView)findViewById(R.id.dateofcompliton)).setOnClickListener(this);

			//((Spinner)findViewById(R.id.category_rearing_area_sp)).setOnItemSelectedListener(this);
			((ImageView)findViewById(R.id.fish_landing_center_imageview)).setOnClickListener(this);


			findViewById(R.id.submit_btn).setOnClickListener(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					validatedata();
				}
			});
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			CommonFunctions.writeLog("CapatativeFishRearingPonds", "oncreate", e.getMessage());

			e.printStackTrace();
		}

	}

	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));
			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}
	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("CapatativeFishRearingPonds", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.fish_landing_center_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());
				e.printStackTrace();
			}

		}
	}

	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.fish_landing_center_imageview:
			if (gps.canGetLocation()) 
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();
				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}
				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE);

			}
			break;

		case R.id.dateofsanction:

			showdate(((TextView)findViewById(R.id.dateofsanction)));
			break;

		case R.id.dateofcompliton:

			showdate(((TextView)findViewById(R.id.dateofcompliton)));
			break;

		default:
			break;
		}
	}

	private void validatedata()
	{


		try 
		{
			if(((Spinner)findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Mandal");
				((Spinner)findViewById(R.id.mandalSp)).requestFocus();
				return;
			}

			if(((Spinner)findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner)findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner)findViewById(R.id.village_spinner)).requestFocus();
				return;
			}

			if(((Spinner)findViewById(R.id.publicwaterbody_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Name of Public Water Body");
				((Spinner)findViewById(R.id.publicwaterbody_sp)).requestFocus();
				return;
			}

			if (strBaseimage.equalsIgnoreCase("")) 
			{
				AlertDialogs("Information!!"," Please Capture  Fish Landing Center Photo");
				return;
			}

			if(latitude== 0 || longitude== 0)
			{
				AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
				return;

			}
			if(CFSID == null || CFSID.equalsIgnoreCase("null") || CFSID.equalsIgnoreCase("0")|| CFSID.equalsIgnoreCase(""))
			{
				((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
				AlertDialogs("Information!!", "CFSID ID Not found, Please try again!!");
				return;
			}	

			abc=((Spinner)findViewById(R.id.publicwaterbody_sp)).getSelectedItem().toString();
			String lat,lon;
			lat=((TextView) findViewById(R.id.latitude)).getText().toString();
			lon=((TextView) findViewById(R.id.longitude)).getText().toString();


			JSONObject seedData=new JSONObject();
			seedData.put("USERID", HomeData.userID);		
			seedData.put("DEVICEID", HomeData.sDeviceId);
			seedData.put("CFSRID", CFSID);
			seedData.put("PWBID", PWBID);
			seedData.put("LONGITUDE", longitude);
			seedData.put("LATITUDE", latitude);
			seedData.put("SCHEMEID",rearingpondid);
			seedData.put("SanctionDate",((TextView)findViewById(R.id.dateofsanction)).getText().toString());
			seedData.put("SanctionAmount",((TextView)findViewById(R.id.amount_of_sanction)).getText().toString());
			seedData.put("DateOfCompletion",((TextView)findViewById(R.id.dateofcompliton)).getText().toString());
			seedData.put("ExtentInHa",((TextView)findViewById(R.id.extentinha)).getText().toString());
			seedData.put("NoOfPonds",((TextView)findViewById(R.id.noofponds)).getText().toString());
			seedData.put("TotalExpenditureAmount",((TextView)findViewById(R.id.expenditure)).getText().toString());
			seedData.put("BASE64PHOTO",strBaseimage);//"iVBORw0KGgoAAAANSUhEUgAAAJYAAADICAIAAACF548yAAAAA3NCSVQICAjb"

			JSONObject data=new JSONObject();
			data.put("Version", HomeData.sAppVersion);
			data.put("CFSRPONDSGEOTAGGING", seedData);

			WebserviceCall request=new WebserviceCall(CapatativeFishPond.this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "UPDATECFSRPONDSDETAILS");
			return;


		} 
		catch (JSONException e)
		{
			CommonFunctions.writeLog("CapatativeFishRearingPonds", "CFSRPONDSGEOTAGGING", e.getMessage());

			e.printStackTrace();
		}

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void Success(String response) 
	{

		try
		{
			ContentValues seedfarmlist = new ContentValues();
			seedfarmlist.put("Latitude",""+latitude);
			seedfarmlist.put("IsSync","Y");
			seedfarmlist.put("Longitude",""+longitude);	

			db.open();
			boolean stat=db.updateTableData("CaptiveFishSeedRearingPonds_Masters", seedfarmlist,"UserId='"+HomeData.userID +"' and trim(Public_WaterBody)='"+abc+"' and VillageID='"+villageID+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");

			/*	db.execSQL("insert into SeedFarm_Center (Latitude,Longitude) values('"+lat+"','"+lon+"') where User_Id='"+HomeData.userID +"'");*/
			db.close();


			Dialogs.AlertDialogs(this,"Information!!", "Data Successfully Uploaded");

			if(!roleID.equalsIgnoreCase("3"))
				((Spinner)findViewById(R.id.mandalSp)).setSelection(0);


			((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.publicwaterbody_sp)).setSelection(0);
			((Spinner)findViewById(R.id.category_rearing_area_sp)).setSelection(0);
			
			

			((TextView)findViewById(R.id.dateofsanction)).setText("");
			((TextView)findViewById(R.id.amount_of_sanction)).setText("");
			((TextView)findViewById(R.id.dateofcompliton)).setText("");
			((TextView)findViewById(R.id.extentinha)).setText("");
			((TextView)findViewById(R.id.noofponds)).setText("");
			((TextView)findViewById(R.id.expenditure)).setText("");
			((TextView)findViewById(R.id.rearingpond)).setText("");
			//			((TextView)findViewById(R.id.indicator_type)).setText("");		
			//			((TextView) findViewById(R.id.category)).setText("");;
			//			((TextView) findViewById(R.id.ownership)).setText("");
			((TextView) findViewById(R.id.latitude)).setText("");
			((TextView) findViewById(R.id.longitude)).setText("");


			((ImageView) findViewById(R.id.fish_landing_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.pic4));
			strBaseimage="";
			latitude=0;
			longitude=0;
		}
		catch (Exception e) 
		{
			CommonFunctions.writeLog("FishLandingCenters", "Success", e.getMessage());
			e.printStackTrace();
			Dialogs.AlertDialogs(this,"Information!!", "Upload Failed, Please Try Again");
		}

	}

	@Override
	public void Fail(String response)
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}

	@Override
	public void NetworkNotAvail()
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate()
	{
		startActivity(new Intent(CapatativeFishPond.this,AppUpdatePage.class));
		finish();
		return;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id)
	{


		try 
		{
			strBaseimage="";
			((TextView)findViewById(R.id.dateofsanction)).setText("");
			((TextView)findViewById(R.id.amount_of_sanction)).setText("");
			((TextView)findViewById(R.id.dateofcompliton)).setText("");
			((TextView)findViewById(R.id.extentinha)).setText("");
			((TextView)findViewById(R.id.noofponds)).setText("");
			((TextView)findViewById(R.id.expenditure)).setText("");
			((TextView)findViewById(R.id.rearingpond)).setText("");


			switch (parent.getId()) 
			{
			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(this, "select distinct MandalName from CaptiveFishSeedRearingPonds_Masters where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);
					}
					else
					{
						loadSpinnerData("select distinct MandalName from CaptiveFishSeedRearingPonds_Masters where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;
			case R.id.mandalSp:
				String mandalname=parent.getSelectedItem().toString().trim();  
				if(!mandalname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					mandalID=db.getSingleValue("select MandalID from CaptiveFishSeedRearingPonds_Masters where MandalName='"+mandalname +"' and DistrictID='"+distrID+"'");															
					db.close();
					loadSpinnerData("select distinct PanchayatName from CaptiveFishSeedRearingPonds_Masters where DistrictID='"+distrID.trim()+"'and MandalID='"+mandalID.trim()+"' order by PanchayatName ",((Spinner)findViewById(R.id.panchayat_spinner)));
				}
				else
				{
					((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
					((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
					((Spinner)findViewById(R.id.publicwaterbody_sp)).setSelection(0);

					//		((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
				}
				break;
			case R.id.panchayat_spinner:

				String panchayatname=parent.getSelectedItem().toString().trim(); 
				if(!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID=db.getSingleValue("select PanchayatID from CaptiveFishSeedRearingPonds_Masters where PanchayatName='"+panchayatname+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"'");
					db.close();
					loadSpinnerData("select distinct VillageName from CaptiveFishSeedRearingPonds_Masters where PanchayatID='"+panchayatID +"' and MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID.trim()+"' ORDER BY VillageName",((Spinner)findViewById(R.id.village_spinner)));
				}
				else
				{
					((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
					((Spinner)findViewById(R.id.publicwaterbody_sp)).setSelection(0);

				}
				break;

			case R.id.village_spinner:

				String villagename=parent.getSelectedItem().toString();
				if(!villagename.equalsIgnoreCase("--Select--"))
				{
					db.open();
					villageID=db.getSingleValue("select VillageID from CaptiveFishSeedRearingPonds_Masters where VillageName='"+villagename+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");
					db.close();
					loadSpinnerData("select Public_WaterBody from CaptiveFishSeedRearingPonds_Masters where MandalID='"+mandalID +"' and PanchayatID='"+panchayatID.trim()+"'and VillageID='"+villageID.trim()+"'and DistrictID='"+distrID.trim()+"' order by Public_WaterBody",((Spinner)findViewById(R.id.publicwaterbody_sp)));

				}
				else
				{
					((Spinner)findViewById(R.id.publicwaterbody_sp)).setSelection(0);
					//		((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
				}
				break;

			case R.id.publicwaterbody_sp:

				String indicator="",ownership="";

				seedfarmname=parent.getSelectedItem().toString();
				if(!seedfarmname.equalsIgnoreCase("--Select--"))
				{


					
					db.open();
					Cursor data1=db.getTableDataCursor("select * from CaptiveFishSeedRearingPonds_Masters where Public_WaterBody='"+seedfarmname+"' and MandalID='"+mandalID +"' and PanchayatID='"+panchayatID.trim()+"'and VillageID='"+villageID.trim()+"'and DistrictID='"+distrID.trim()+"'");

					if(data1.getCount()>0&&data1.moveToFirst())
					{
						PWBID=data1.getString(data1.getColumnIndex("Public_waterbody_id"));
						CFSID=data1.getString(data1.getColumnIndex("CaptiveFishSeedRegId"));
						//((EditText)findViewById(R.id.rearingpond)).setText(data.getString(data.getColumnIndex("ReadringPond")));//rearingpond
						((TextView)findViewById(R.id.dateofsanction)).setText(data1.getString(data1.getColumnIndex("DateofSanction")));//(dateofsanction);
						((TextView)findViewById(R.id.amount_of_sanction)).setText(data1.getString(data1.getColumnIndex("Amount_Sanctione")));//(amountofsanction);
						((TextView)findViewById(R.id.dateofcompliton)).setText(data1.getString(data1.getColumnIndex("DateofComplition")));//(dateofcomplition);
						((TextView)findViewById(R.id.extentinha)).setText(data1.getString(data1.getColumnIndex("ExtentInHa")));//(extentinha);
						((TextView)findViewById(R.id.noofponds)).setText(data1.getString(data1.getColumnIndex("NoofPonds")));//(noofpound);
						((TextView)findViewById(R.id.expenditure)).setText(data1.getString(data1.getColumnIndex("Expenditure")));//(expenditure);

						((TextView)findViewById(R.id.rearingpond)).setText(data1.getString(data1.getColumnIndex("CaptiveConstructedType")));//(rearingpond);

						rearingpondid=data1.getString(data1.getColumnIndex("CaptiveConstructedID"));

						String category_rearing_areaID=data1.getString(data1.getColumnIndex("CapativeRearingAreaID"));
						if(category_rearing_areaID==null||category_rearing_areaID.equalsIgnoreCase(""))
							category_rearing_areaID="0";

						((Spinner)findViewById(R.id.category_rearing_area_sp)).setSelection(Integer.parseInt(category_rearing_areaID));

					}
					db.close();


					//					db.open();
					//					SeedFormID=db.getSingleValue("select  Public_waterbody_id from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_WaterBody='"+seedfarmname+"'");
					//					rearingpond=db.getSingleValue("select ReadringPond from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+SeedFormID+"'");
					//					dateofsanction=db.getSingleValue("select DateofSanction from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+SeedFormID+"'");
					//					amountofsanction=db.getSingleValue("select Amount_Sanctione from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+SeedFormID+"'");
					//
					//					dateofcomplition=db.getSingleValue("select DateofComplition from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+SeedFormID+"'");
					//					extentinha=db.getSingleValue("select ExtentInHa from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+SeedFormID+"'");
					noofpound=db.getSingleValue("select NoofPonds from CaptiveFishSeedRearingPonds_Masters where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+PWBID+"'");
					//					expenditure=db.getSingleValue("select Expenditure from CaptiveFishSeedRearingPonds_Master where DistrictID='"+distrID+"' and Mandal_ID='"+mandalID+"' and Panchayat_ID='"+panchayatID+"'  and Village_ID='"+villageID+"' and Public_waterbody_id='"+SeedFormID+"'");
					//
					//					((EditText)findViewById(R.id.rearingpond)).setText(rearingpond);
					//					((TextView)findViewById(R.id.dateofsanction)).setText(dateofsanction);
					//					((EditText)findViewById(R.id.amount_of_sanction)).setText(amountofsanction);
					//					((TextView)findViewById(R.id.dateofcompliton)).setText(dateofcomplition);
					//					((EditText)findViewById(R.id.extentinha)).setText(extentinha);
					//					((EditText)findViewById(R.id.noofponds)).setText(noofpound);
					//					((EditText)findViewById(R.id.expenditure)).setText(expenditure);
					//
					//					//		loadSpinnerData("select distinct Categoryofseedfarm from SeedFarm_Center where SeedRegId='"+SeedFormID+"'",((Spinner)findViewById(R.id.category)));
					//					db.close();


				}
				else
				{
					((Spinner)findViewById(R.id.publicwaterbody_sp)).setSelection(0);

					//((Spinner)findViewById(R.id.Location_InstitutionSp)).setSelection(0);
				}
				break;


			default:
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block

			CommonFunctions.writeLog("CapatativeFishPond", "onItemSelected", e.getMessage());

			e.printStackTrace();
		}
	}
	public void showdate(final TextView t)
	{
		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);

		DatePickerDialog dpd = new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener()
		{
			@Override
			public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth)
			{
				t.setText((monthOfYear + 1)+ "/"+ dayOfMonth + "/" + year);
			}
		}, mYear, mMonth, mDay);
		dpd.getDatePicker().setMaxDate(c.getTimeInMillis());
		dpd.show();

	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}


}

