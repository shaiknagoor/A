package com.aponline.fisheriesgis;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

@SuppressLint("NewApi")
public class Loginpage extends AppCompatActivity implements ServerResponseListener 
{

	Button loginBt,regbt;
	public static String UserName,Password;
	DBAdapter db;
	ViewFlipper vf;

	EditText loginpage_userEt,loginpage_pswEt;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		try 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.login_page);

			if (Build.VERSION.SDK_INT >= 23)
			{
				requestPermissions();
			}
			else
			{
				Check_Login();
			}
		}
		catch (Exception e) 
		{
			CommonFunctions.writeLog("Loginpage", "oncreate", e.getMessage());
			e.printStackTrace();
		}

	}

	private void Check_Login() 
	{
		HomeData.readDeviceDetails(this);
		db=new DBAdapter(this);
		try 
		{
			db.createDataBase();
			db.close();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			db.close();
		}
		
		db.open();
		db.createNewTable();
		db.close();

		try 
		{
			((TextView)findViewById(R.id.versionId)).setText("V"+HomeData.sAppVersionName);
			loginBt=(Button)findViewById(R.id.loginBt);
			loginpage_userEt=(EditText)findViewById(R.id.loginpage_userEt);
			loginpage_pswEt=(EditText)findViewById(R.id.loginpage_pswEt);
			regbt=(Button) findViewById(R.id.registerBt);
			vf=(ViewFlipper) findViewById(R.id.view_flipper);
			vf.startFlipping();

			loginBt.setOnClickListener(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					try 
					{
						((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(loginpage_pswEt.getWindowToken(), 0);
						UserName=loginpage_userEt.getText().toString();
						Password=loginpage_pswEt.getText().toString();

						if(UserName.equals(""))
						{
							loginpage_userEt.setError("Enter User Name");
							loginpage_userEt.requestFocus();
							return;
						}
						else if(Password.equals(""))
						{
							loginpage_pswEt.setError("Enter Password"); 
							loginpage_pswEt.requestFocus();
							return; 
						}

						HomeData.userID=UserName;
						HomeData.Password=Password;

						HashMap<String, String> params=new HashMap<>();
						params.put("USERID", HomeData.userID);
						params.put("PASSWORD", HomeData.Password);
						params.put("VERSIONID", HomeData.sAppVersion);

						WebserviceCall request=new WebserviceCall(Loginpage.this,"GET");
						request.addParam("JSON", new JSONObject(params).toString());
						request.ProccessRequest(Loginpage.this, "GetUserDetails");

					} 
					catch (Exception e)
					{
						CommonFunctions.writeLog("Loginpage", "GetUserDetails", e.getMessage());
						e.printStackTrace();
					}
				}
			});
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@Override
	public void Success(String response)
	{
		Intent i= new Intent (Loginpage.this,Homepage.class);
		startActivity(i);
		Loginpage.this.finish();
	}
	@Override
	public void Fail(String response) 
	{
		AlertDialogs("Information!!", response);

	}
	@Override
	public void NetworkNotAvail()
	{
		AlertDialogs("Information", "Network not available, Please try again!!");
	}
	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(Loginpage.this,AppUpdatePage.class));
		finish();
		return;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}

		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("Write enternal Contacts");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("camera");
		if (!addPermission(permissionsList, Manifest.permission.GET_ACCOUNTS))
			permissionsNeeded.add("get Accounts");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
			permissionsNeeded.add("Access Fine Location");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.READ_CONTACTS))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_CONTACTS))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.READ_SMS))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_CALL_LOG))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.READ_CALL_LOG))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.READ_CALENDAR))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_CALENDAR))
			permissionsNeeded.add("InterNet");
		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				ActivityCompat.requestPermissions(Loginpage.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}
		Check_Login();
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		switch (requestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_CALL_LOG, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_CALL_LOG, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.GET_ACCOUNTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_FINE_LOCATION, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_COARSE_LOCATION, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_CONTACTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_CONTACTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_CONTACTS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_SMS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_CALENDAR, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_CALENDAR, PackageManager.PERMISSION_GRANTED);
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
			{
				Check_Login();
			}
			else
			{
				Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
				.show();
			}
		}
		break;
		default:
			super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		}
	}
	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}

		return true;
	}
}
