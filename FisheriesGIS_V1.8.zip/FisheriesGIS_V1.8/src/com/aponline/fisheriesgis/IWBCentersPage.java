package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.json.JSONObject;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.JSONParser;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

public class IWBCentersPage extends AppCompatActivity implements OnItemSelectedListener, OnClickListener,ServerResponseListener {

	ActionBar ab;
	GPSTracker gps;
	DBAdapter db;
	String strBase64image="";
	double latitude,longitude;
	String panchayatID="",villageID="",MITank_ID="";
	String roleID;
	String distrID,districtName; 
	String mandalID,mandalName;
	int PHOTO_CAPTURE=100;
	static int percentage=0;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		try 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.mitank_detail);
			ab=getSupportActionBar();
			ab.setTitle("INLAND Water Bodies");
			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 
			ab=getSupportActionBar();
			db=new DBAdapter(this);		

			gps=new GPSTracker(this);
			LoadUserDetails();
			Log.d("User ID", HomeData.userID);

			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from IWBCenters_Master where UserId ='"+HomeData.userID+"' ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(false);
			}
			else
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);

			}
			((EditText)findViewById(R.id.totalwater_txt)).addTextChangedListener(new CustomTextWatcher(((EditText)findViewById(R.id.totalwater_txt)),((TextView)findViewById(R.id.effectviewater_txt))));
			((Spinner)findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mitank_sp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.seasonality_sp)).setOnItemSelectedListener(this);
			((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setOnClickListener(this);
			findViewById(R.id.submit_btn).setOnClickListener(this);
		} 
		catch (Exception e) 
		{
			CommonFunctions.writeLog("MappingMITank", "oncreate", e.getMessage());
			e.printStackTrace();
			AlertDialogsForceBack("Information!!", "Please Re-Login once/Try Again!!");
		}
	}

	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));
			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}
	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();	


			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("MappingMITank", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.aqua_lab_center_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBase64image= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}
	}


	@Override
	public void onClick(View v) 
	{

		switch (v.getId()) 
		{

		case R.id.aqua_lab_center_imageview:
			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();

				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE);
			}
			break;
		case R.id.submit_btn:
			validatedata();
			break;


		default:
			break;
		}
	}

	private void validatedata()
	{

		try 
		{
			if(((Spinner)findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Mandal");
				((Spinner)findViewById(R.id.mandalSp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner)findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner)findViewById(R.id.village_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.mitank_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select MI Tank Center");
				((Spinner)findViewById(R.id.mitank_sp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.typeofwater_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Type of water");
				((Spinner)findViewById(R.id.typeofwater_sp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.ownershipwater_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Ownership");
				((Spinner)findViewById(R.id.ownershipwater_sp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.seasonality_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Seasonality");
				((Spinner)findViewById(R.id.seasonality_sp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.sourceofwater_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Source of Water");
				((Spinner)findViewById(R.id.sourceofwater_sp)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.nameofofficer_edt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.nameofofficer_edt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.nameofofficer_edt)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.mobileno_edt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.mobileno_edt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.mobileno_edt)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.designation_edt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.designation_edt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.designation_edt)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.totalwater_txt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.totalwater_txt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.totalwater_txt)).requestFocus();
				return;
			}

			if(strBase64image.equalsIgnoreCase(""))
			{
				AlertDialogs("Information!!", " Please Capture  Aqua Lab Photo");
				return;
			}

			if(latitude== 0 || longitude== 0)
			{
				AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
				return;

			}
			if(MITank_ID == null || MITank_ID.equalsIgnoreCase("null") || MITank_ID.equalsIgnoreCase("0")|| MITank_ID.equalsIgnoreCase(""))
			{
				((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
				AlertDialogs("Information!!", "FLC ID Not found, Please try again!!");
				return;
			}


			String nameofofficer=((EditText)findViewById(R.id.nameofofficer_edt)).getText().toString();
			String mobile_no=((EditText)findViewById(R.id.mobileno_edt)).getText().toString();
			String designation=((EditText)findViewById(R.id.designation_edt)).getText().toString();
			int waterbodytype_id=((Spinner)findViewById(R.id.typeofwater_sp)).getSelectedItemPosition();
			int waterbody_ownershipid=((Spinner)findViewById(R.id.ownershipwater_sp)).getSelectedItemPosition();
			int sesonalityid=((Spinner)findViewById(R.id.seasonality_sp)).getSelectedItemPosition();
			int watersourceid=((Spinner)findViewById(R.id.sourceofwater_sp)).getSelectedItemPosition();
			String totalwater_spread=((EditText)findViewById(R.id.totalwater_txt)).getText().toString();
			String effectivewater_ha=((TextView)findViewById(R.id.effectviewater_txt)).getText().toString();
			int modeofdisposingid=((Spinner)findViewById(R.id.modeofdisposing_sp)).getSelectedItemPosition();


			JSONObject seedData=new JSONObject();
			seedData.put("USERID", HomeData.userID);
			seedData.put("DEVICEID", HomeData.sDeviceId);
			seedData.put("MITID",MITank_ID);
			seedData.put("LONGITUDE", longitude);
			seedData.put("LATITUDE", latitude);
			seedData.put("Nameoftheofficer",nameofofficer);
			seedData.put("MobileNo",mobile_no);
			seedData.put("Designation",designation);
			seedData.put("NameoftheTank",((Spinner)findViewById(R.id.mitank_sp)).getSelectedItem().toString());
			seedData.put("WATERBODYTYPEID",String.valueOf(waterbodytype_id));
			seedData.put("WATERBODYOWNERSHIPID",String.valueOf(waterbody_ownershipid));
			seedData.put("SEASONALITYID",String.valueOf(sesonalityid));
			seedData.put("WATERSOURCEID",String.valueOf(watersourceid));
			seedData.put("TOTALWATERSPREADAREAINHA",totalwater_spread);
			seedData.put("EFFECTIVEWATERSPREADAREAINHA",effectivewater_ha);
			seedData.put("MODEOFDISPOSINGID",String.valueOf(modeofdisposingid));
			seedData.put("BASE64PHOTO",strBase64image);


			JSONObject data=new JSONObject();
			data.put("Version", HomeData.sAppVersion);
			data.put("MITANKSGEOTAGGING", seedData);

			WebserviceCall request=new WebserviceCall(this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "MITANK_UPDATELOCATIONDETAILS");

		}
		catch (Exception e1)
		{
			CommonFunctions.writeLog("MappingMITank", "validatedata", e1.getMessage());
			e1.printStackTrace();
			AlertDialogs("Information!!", "Somethimg went wrong, Please try again!!");
		}

	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void Success(String response)
	{

		try 
		{
			ContentValues mitanklist = new ContentValues();
			mitanklist.put("Image", strBase64image);
			mitanklist.put("Latitude",""+latitude);
			mitanklist.put("Longitude",""+longitude);	
			mitanklist.put("IsSync","Y");

			db.open();
			db.updateTableData("IWBCenters_Master",mitanklist,"UserId='"+HomeData.userID +"' and MITank_ID='"+MITank_ID+"' and VillageID='"+villageID+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");
			db.close();



			

			if(!roleID.equalsIgnoreCase("3"))
				((Spinner)findViewById(R.id.mandalSp)).setSelection(0);

			((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.mitank_sp)).setSelection(0);
			((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
			((ImageView) findViewById(R.id.aqua_lab_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.pic4));
			((TextView)findViewById(R.id.latitude)).setText("");
			((TextView)findViewById(R.id.longitude)).setText("");
			((Spinner)findViewById(R.id.seasonality_sp)).setSelection(0);
			((Spinner)findViewById(R.id.typeofwater_sp)).setSelection(0);
			((Spinner)findViewById(R.id.ownershipwater_sp)).setSelection(0);
			((Spinner)findViewById(R.id.seasonality_sp)).setSelection(0);
			((Spinner)findViewById(R.id.sourceofwater_sp)).setSelection(0);
			((Spinner)findViewById(R.id.modeofdisposing_sp)).setSelection(0);
			((TextView)findViewById(R.id.effectviewater_txt)).setText("");
			((EditText)findViewById(R.id.totalwater_txt)).setText("");
			((EditText)findViewById(R.id.nameofofficer_edt)).setText("");
			((EditText)findViewById(R.id.mobileno_edt)).setText("");
			((EditText)findViewById(R.id.designation_edt)).setText("");

			strBase64image="";
			Dialogs.AlertDialogs(this,"Information!!", JSONParser.msg);
		} 
		catch (Exception e)
		{
			CommonFunctions.writeLog("MappingMITank", "Success", e.getMessage());
			Dialogs.AlertDialogs(this,"Information!!", "Upload Failed, Please Try Again");
			e.printStackTrace();
		}

	}

	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}

	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(IWBCentersPage.this,AppUpdatePage.class));
		finish();
		return;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) 
	{

		try 
		{
			if(parent.getId() != R.id.seasonality_sp)
			{
				strBase64image="";
				((ImageView) findViewById(R.id.aqua_lab_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.pic4));
				((TextView) findViewById(R.id.latitude)).setText("");
				((TextView) findViewById(R.id.longitude)).setText("");
			}
			
			switch (parent.getId()) 
			{
			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(IWBCentersPage.this, "select distinct MandalName from IWBCenters_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);
					}
					else
					{
						loadSpinnerData("select distinct MandalName from IWBCenters_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;
			case R.id.mandalSp:
				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.mitank_sp)).setSelection(0);

				((Spinner)findViewById(R.id.typeofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.ownershipwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.seasonality_sp)).setSelection(0);
				((Spinner)findViewById(R.id.sourceofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.modeofdisposing_sp)).setSelection(0);

				((EditText)findViewById(R.id.nameofofficer_edt)).setText("");
				((EditText)findViewById(R.id.mobileno_edt)).setText("");
				((EditText)findViewById(R.id.designation_edt)).setText("");
				((EditText)findViewById(R.id.totalwater_txt)).setText("");
				((TextView)findViewById(R.id.effectviewater_txt)).setText("");

				String mandalname=parent.getSelectedItem().toString().trim();  
				if(!mandalname.equalsIgnoreCase("--Select--"))
				{
					if(!roleID.equalsIgnoreCase("3"))
					{
						db.open();
						mandalID=db.getSingleValue("select MandalID from IWBCenters_Master where MandalName='"+mandalname +"' and DistrictID='"+distrID+"'");															
						db.close();
					}	
					loadSpinnerData("select distinct PanchayatName from IWBCenters_Master where MandalID='"+mandalID+"' and DistrictID='"+distrID+"' order by PanchayatName",((Spinner)findViewById(R.id.panchayat_spinner)));
				}
				break;
			case R.id.panchayat_spinner:
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.mitank_sp)).setSelection(0);

				((Spinner)findViewById(R.id.typeofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.ownershipwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.seasonality_sp)).setSelection(0);
				((Spinner)findViewById(R.id.sourceofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.modeofdisposing_sp)).setSelection(0);

				((EditText)findViewById(R.id.nameofofficer_edt)).setText("");
				((EditText)findViewById(R.id.mobileno_edt)).setText("");
				((EditText)findViewById(R.id.designation_edt)).setText("");
				((EditText)findViewById(R.id.totalwater_txt)).setText("");
				((TextView)findViewById(R.id.effectviewater_txt)).setText("");
				String panchayatname=parent.getSelectedItem().toString().trim(); 
				if(!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID=db.getSingleValue("select distinct PanchayatID from IWBCenters_Master where PanchayatName='"+panchayatname+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'");
					db.close();
					loadSpinnerData("select distinct VillageName from IWBCenters_Master where PanchayatID='"+panchayatID +"' and MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID+"' order by VillageName",((Spinner)findViewById(R.id.village_spinner)));
				}
				break;

			case R.id.village_spinner:
				((Spinner)findViewById(R.id.mitank_sp)).setSelection(0);

				((Spinner)findViewById(R.id.typeofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.ownershipwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.seasonality_sp)).setSelection(0);
				((Spinner)findViewById(R.id.sourceofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.modeofdisposing_sp)).setSelection(0);

				((EditText)findViewById(R.id.nameofofficer_edt)).setText("");
				((EditText)findViewById(R.id.mobileno_edt)).setText("");
				((EditText)findViewById(R.id.designation_edt)).setText("");
				((EditText)findViewById(R.id.totalwater_txt)).setText("");
				((TextView)findViewById(R.id.effectviewater_txt)).setText("");
				String villagename=parent.getSelectedItem().toString();
				if(!villagename.equalsIgnoreCase("--Select--"))
				{
					db.open();
					villageID=db.getSingleValue("select distinct VillageID from IWBCenters_Master where VillageName='"+villagename+"' and PanchayatID='"+panchayatID+"' and MandalID='"+mandalID.trim()+"' and DistrictID='"+distrID+"'");
					db.close();
					loadSpinnerData("select distinct MITank_Name from IWBCenters_Master where MandalID='"+mandalID.trim()+"' and PanchayatID='"+panchayatID.trim()+"'and VillageID='"+villageID.trim()+"' and DistrictID='"+distrID.trim()+"' order by MITank_Name",((Spinner)findViewById(R.id.mitank_sp)));
				}
				break;

			case R.id.mitank_sp:
				
				((Spinner)findViewById(R.id.typeofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.ownershipwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.seasonality_sp)).setSelection(0);
				((Spinner)findViewById(R.id.sourceofwater_sp)).setSelection(0);
				((Spinner)findViewById(R.id.modeofdisposing_sp)).setSelection(0);
				
				((EditText)findViewById(R.id.nameofofficer_edt)).setText("");
				((EditText)findViewById(R.id.mobileno_edt)).setText("");
				((EditText)findViewById(R.id.designation_edt)).setText("");
				((EditText)findViewById(R.id.totalwater_txt)).setText("");
				((TextView)findViewById(R.id.effectviewater_txt)).setText("");
				String MITank_Name=parent.getSelectedItem().toString();
				if(!MITank_Name.equalsIgnoreCase("--Select--"))
				{
					db.open();
					Cursor cursor=db.getTableDataCursor("select MITank_ID,NameOfTheOfficer,MobileNo,Designation from IWBCenters_Master "
							+ "where MITank_Name='"+MITank_Name+"' and VillageID='"+villageID+"' and PanchayatID='"+panchayatID+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'");
					if(cursor.getCount()>0)
					{
						cursor.moveToFirst();
						MITank_ID=cursor.getString(cursor.getColumnIndex("MITank_ID"));
						((TextView)findViewById(R.id.nameofofficer_edt)).setText(cursor.getString(cursor.getColumnIndex("NameOfTheOfficer")));
						((TextView)findViewById(R.id.mobileno_edt)).setText(cursor.getString(cursor.getColumnIndex("MobileNo")));
						((TextView)findViewById(R.id.designation_edt)).setText(cursor.getString(cursor.getColumnIndex("Designation")));
					}
					else
					{
						AlertDialogs("Information!!", "Details not found, Please contact APOnline");
						((Spinner)findViewById(R.id.mitank_sp)).setSelection(0);
					}
					cursor.close();
					db.close();
					
					if(MITank_ID == null || MITank_ID.equalsIgnoreCase("null") || MITank_ID.equalsIgnoreCase("0")|| MITank_ID.equalsIgnoreCase(""))
					{
						((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
						AlertDialogs("Information!!", "Details not found, Please contact APOnline");
					}
					latitude=gps.getLatitude();
					longitude=gps.getLongitude();
				}
				break;

			case R.id.seasonality_sp:
				String seasonality=((Spinner)findViewById(R.id.seasonality_sp)).getSelectedItem().toString().trim();
				if(seasonality.equalsIgnoreCase("Perinnial"))
				{
					percentage=75;
				}
				if(seasonality.equalsIgnoreCase("LONG SEASONAL"))
				{
					percentage=50;
				}
				if(seasonality.equalsIgnoreCase("SHORT SEASONAL"))
				{
					percentage=25;
				}
				break;
			}
		} 
		catch (Exception e)
		{

			CommonFunctions.writeLog("MappingMITank", "onItemSelected", e.getMessage());

			e.printStackTrace();
		}

	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}

