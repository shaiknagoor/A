package com.aponline.fisheriesgis;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.aponline.fisheriesgis.server.LogUtility;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

public class MyService extends IntentService 
{

	public static String Error;
	public static String reachId;
	public static String districtId;
	String namespace = "http://tempuri.org/";
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;

	ArrayList<ArrayList<String>> data;
	ArrayList<HashMap<String, String>> upldXMLData;
	Context mContext;
	public MyService(String name) 
	{
		super(name);
	}
	public MyService() 
	{
		super("MyService");

	}
	@Override
	protected void onHandleIntent(Intent intent)
	{
		mContext=this;
		HomeData.isServiceRunning=true;
		int runningService=intent.getExtras().getInt("task");
		try
		{
			Log.e("started task", ""+runningService);
			Handler handler=new Handler();
			//new LogUtility(mContext, handler, true, true, true).start();

		}  
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		Log.e("finnised task", ""+runningService);
		HomeData.isServiceRunning=false;
	}
}