package com.aponline.fisheriesgis.database;

public class SP 
{
	public static String getDistrictID_SP(String districtName)
	{
		String sp="select distinct DistrictID from Master_District where trim(DistrictName)='"+districtName+"'";
		return sp;
	}
	public static String getDivisionID_SP(String divisionName,String districtID)
	{
		String sp="select distinct DivisionID from Master_Division where trim(DivisionName)='"+divisionName.trim()+"' and DistrictID='"+districtID.trim()+"' ";
		return sp;
	}
	public static String getDivisionList_SP(String districtID)
	{
		String sp="select distinct trim(DivisionName) from  Master_Division where IsActive=1 and DistrictID='"+districtID+"'ORDER BY DivisionName";
		return sp;
	}
	public static String getMandalID_SP(String mandalName,String divisionID,String districtID)
	{
		String sp="select distinct MandalID from Master_Mandal where trim(MandalName)='"+mandalName.trim()+"' and DistrictID='"+districtID+"' and DivisionID='"+divisionID+"'";
		return sp;
	}
	public static String getMandalList_SP(String divisionID,String districtID)
	{
		String sp="select distinct trim(MandalName) from Master_Mandal where DistrictID='"+districtID+"' and DivisionID='"+divisionID+"' ORDER BY MandalName";
		return sp;
	}
	public static String getInstitutionTypeID(String InstitutionType)
	{
		String sp="select distinct Institution_TypeID from Master_Institution_Types where trim(Institution_Type_Name)='"+InstitutionType.trim()+"'";
		return sp;
	}
	public static String getInstitutionID_SP(String insLocation,String districtID,String divisionID,String mandalID)
	{
		String sp="select distinct InstituteID from Master_Institutions where trim(Institute_Location)='"+insLocation.trim()+"' and MandalID='"+mandalID+"' and DivisionID='"+divisionID+"' and DistrictID='"+districtID+"''";
		return sp;
	}
	public static String getInstitutionTypeList_SP(String districtID,String divisionID,String mandalID)
	{
		String sp="select distinct Institution_Type_Name from  Master_Institution_Types "
				+ "where Institution_TypeID in (select distinct Institution_TypeID from Master_Institutions where MandalID='"+mandalID+"' and DivisionID='"+divisionID+"' and DistrictID='"+districtID+"')";
		return sp;
	}
	/*public static String getInstitutionsLocationList_SP()
	{
		String sp="select distinct Institute_Location from Master_Institutions";
		return sp;
	}*/
	public static String getInstitutionsLocationList_SP(String districtID,String divisionID,String mandalID,String insTypeID)
	{
		String sp="select distinct Institute_Location from Master_Institutions where MandalID='"+mandalID+"' and DivisionID='"+divisionID+"' and DistrictID='"+districtID+"' and Institution_TypeID='"+insTypeID+"' ORDER BY Institute_Location";
		return sp;
	}
	
	
	public static String getInstitutionsLocationID_SP(String instituteLocation,String districtID,String divisionID,String mandalID)
	{
		String sp="select distinct InstituteID from Master_Institutions where trim(Institute_Location)='"+instituteLocation.trim()+"' and MandalID='"+mandalID+"' and DivisionID='"+divisionID+"' and DistrictID='"+districtID+"'";
		return sp;
	}
	public static String getDesignationId_SP(String designation)
	{
		String sp="select distinct DesignationID from Master_Designation where trim(DesignationName)='"+designation.trim()+"'";
		return sp;
	}
	public static String getRoleID_SP(String designation)
	{
		String sp="select trim(RoleID) from Master_Designation where trim(DesignationName)='"+designation.trim()+"'";
		return sp;
	}
	public static String getVillageList(String DistrictID,String MandalID)
	{
		String sp="select VillageName from Master_Village where MandalID='"+MandalID+"' and DistrctID='"+DistrictID+"'  ORDER BY VillageName";
		return sp;
	}
	public static String getVillageID(String DistrictID,String MandalID,String VillageName)
	{
		String sp="select VillageID from Master_Village where MandalID='"+MandalID+"' and DistrctID='"+DistrictID+"' and VillageName='"+VillageName+"'";
	//	String sp="select VillageID from Master_Village where VillageName='"+VillageName+"'";
		return sp;
	}
	public static String getSocialStatusID(String socialStatus)
	{
		String sp="select SocialStatusID from Master_SocialStatus where SocialStatusName='"+socialStatus+"'";
		return sp;
	}
	public static String getFarmerAadhaarList_SP(String districtID, String mandalID, String villageID) 
	{
		String sp="select distinct Aadhar_No from FARMER_REG_DETAILS where District_Id='"+districtID+"' and Mandal_Id='"+mandalID+"' and Village_Id='"+villageID+"'";
		return sp;
	}
	public static String getVaccinationDetails_SP(String userID) 
	{
		String sp="Select F.Aadhar_No,F.Farmer_Name,(F.Male_White_Cattle+F.Male_Buffaloes+F.Female_White_Cattle+F.Female_Buffaloes) as TotalAnimals,"
				+ "(V.WhiteCattle_Male_vaccinated+V.WhiteCattle_Female_vaccinated+V.Buffalo_Male_vaccinated+V.Buffalo_Female_vaccinated) as VaccinetedAnimals,"
				+ "F.Is_Sync From FARMER_REG_DETAILS F,FMD_Vaccination_Details V where F.Aadhar_No=V.FarmerRegID and F.Created_By='"+userID+"'";
		return sp;
	}
	public static String FarmerRegistrationSearch_SP(String searchdata)
	{
		String FarmerRegistration_SP="Select F.FarmerName,F.AadhaarNo,F.FarmerFatherName,F.Gender,F.Age,F.IsEnjoymentNature,F.FMobile,F.FEmail,F.FStreetName,"
				+ "F.FHouseNo,D.DISTRICT_DESCRIPTION,M.MANDAL_DESCRIPTION,V.VILLAGE_NAME,F.FPincode,"
				+ "F.BankName,F.BranchName,F.IFSCCode,F.BankAccountNo,F.NameasperBank,"
				+ "F.BankPassBook,F.PattadharPassbook,F.VROCertificate "
				+ "from FARMER_REGISTRATION_DETAILS F,DISTRICT_MASTER D,MANDAL_MASTER M,VILLAGE_MASTER V "
				+ "where F.FDistrictID=D.DISTRICT_ID and F.FMandalID=M.MANDAL_ID and F.FVillageID=V.VILLAGE_ID "
				+ "and M.DISTRICT_ID=D.DISTRICT_ID and V.DISTRICT_ID=M.DISTRICT_ID and V.MANDAL_ID=M.MANDAL_ID "
				+ "and (F.RegistrationNo='"+searchdata+"' OR F.AadhaarNo='"+searchdata+"')";
		return FarmerRegistration_SP;
	}
	public static String FarmerNameSearch_SP(String searchdata,String district,String mandal,String village) 
	{
		String FarmerNameSearch_SP="Select F.FarmerName,F.AadhaarNo,F.FarmerFatherName,F.Gender,F.Age,F.IsEnjoymentNature,F.FMobile,F.FEmail,F.FStreetName,"
				+ "F.FHouseNo,D.DISTRICT_DESCRIPTION,M.MANDAL_DESCRIPTION,V.VILLAGE_NAME,F.FPincode,"
				+ "F.BankName,F.BranchName,F.IFSCCode,F.BankAccountNo,F.NameasperBank,"
				+ "F.BankPassBook,F.PattadharPassbook,F.VROCertificate "
				+ "from FARMER_REGISTRATION_DETAILS F,DISTRICT_MASTER D,MANDAL_MASTER M,VILLAGE_MASTER V "
				+ "where F.FDistrictID=D.DISTRICT_ID and F.FMandalID=M.MANDAL_ID and F.FVillageID=V.VILLAGE_ID "
				+ "and M.DISTRICT_ID=D.DISTRICT_ID and V.DISTRICT_ID=M.DISTRICT_ID and V.MANDAL_ID=M.MANDAL_ID "
				+"and D.DISTRICT_DESCRIPTION='"+district+"' and M.MANDAL_DESCRIPTION='"+mandal+"' and V.VILLAGE_NAME='"+village+"' "
				+ "and (F.FarmerName like '"+searchdata+"%' OR F.FarmerFatherName like '"+searchdata+"%' OR F.FMobile like '"+searchdata+"%')";
		return FarmerNameSearch_SP;
	}
	public static String FarmerDeatils_SP(String district,String mandal,String village,String farmerName,String fatherName,String aadharNo,String mobile) 
	{
		String FarmerNameSearch_SP="Select F.FarmerName,F.AadhaarNo,F.FarmerFatherName,F.Gender,F.Age,F.IsEnjoymentNature,F.FMobile,F.FEmail,F.FStreetName,"
				+ "F.FHouseNo,D.DISTRICT_DESCRIPTION,M.MANDAL_DESCRIPTION,V.VILLAGE_NAME,F.FPincode,"
				+ "F.BankName,F.BranchName,F.IFSCCode,F.BankAccountNo,F.NameasperBank,"
				+ "F.BankPassBook,F.PattadharPassbook,F.VROCertificate "
				+ "from FARMER_REGISTRATION_DETAILS F,DISTRICT_MASTER D,MANDAL_MASTER M,VILLAGE_MASTER V "
				+ "where F.FDistrictID=D.DISTRICT_ID and F.FMandalID=M.MANDAL_ID and F.FVillageID=V.VILLAGE_ID "
				+ "and M.DISTRICT_ID=D.DISTRICT_ID and V.DISTRICT_ID=M.DISTRICT_ID and V.MANDAL_ID=M.MANDAL_ID "
				+"and D.DISTRICT_DESCRIPTION='"+district+"' and M.MANDAL_DESCRIPTION='"+mandal+"' and V.VILLAGE_NAME='"+village+"' "
				+ "and F.FarmerName='"+farmerName+"' and F.FarmerFatherName='"+fatherName+"' and F.AadhaarNo='"+aadharNo+"' and F.FMobile='"+mobile+"'";
		return FarmerNameSearch_SP;
	}

	public static String FarmerLanddetails_Sp(String searchdata)
	{
		String sp="Select F.OwnerName,F.OwnerAadhaarNo,D.DISTRICT_DESCRIPTION,M.MANDAL_DESCRIPTION,V.VILLAGE_NAME,F.SurveyNo,F.PassbookNo,F.KhattaNo,"
				+ "F.LandInAcers,F.TotalExtent,F.TotalLeaseExtent,F.LandType,F.IsEnjoymentNature,F.RelationWithOwner "
				+ "from FARMER_LAND_DETAILS F,DISTRICT_MASTER D,MANDAL_MASTER M,VILLAGE_MASTER V "
				+ "where F.OwnerDistrictID=D.DISTRICT_ID and F.OwnerMandalID=M.MANDAL_ID and F.OwnerVillageID=V.VILLAGE_ID "
				+ "and M.DISTRICT_ID=D.DISTRICT_ID and V.DISTRICT_ID=M.DISTRICT_ID and V.MANDAL_ID=M.MANDAL_ID "
				+ "and F.RegistrationNo='"+searchdata+"'";
		return sp;
	}
	public static String FarmerNameLanddetails_Sp(String searchdata)
	{
		String FarmerNameLanddetails_Sp="Select D.DISTRICT_DESCRIPTION,M.MANDAL_DESCRIPTION,V.VILLAGE_NAME,"
				+ "F.SurveyNo,F.PassbookNo,F.PattadharPassbookNo,F.LandInAcers,F.LandType "
				+ "from FARMER_LAND_DETAILS F,DISTRICT_MASTER D,MANDAL_MASTER M,VILLAGE_MASTER V "
				+ "where F.DistrictID=D.DISTRICT_ID and F.MandalID=M.MANDAL_ID and F.VillageID=V.VILLAGE_ID "
				+ "and M.DISTRICT_ID=D.DISTRICT_ID and V.DISTRICT_ID=M.DISTRICT_ID and V.MANDAL_ID=M.MANDAL_ID "
				+ "and (F.FarmerName || '   -   ' || F.FatherName='"+searchdata+"')";   
		return FarmerNameLanddetails_Sp;
	}
	public static String FarmerDetailsReports_SP()
	{
		String FarmerRegistration_SP="Select F.RegistrationNo,F.FarmerName,F.FarmerFatherName,F.FMobile,"
				+ "D.DISTRICT_DESCRIPTION,M.MANDAL_DESCRIPTION,V.VILLAGE_NAME,F.BankName,F.BranchName,F.BankAccountNo,ifnull(Sum(L.TotalExtent),'0') as TotalExtent "
				+ "from FARMER_REGISTRATION_DETAILS F,DISTRICT_MASTER D,MANDAL_MASTER M,VILLAGE_MASTER V,FARMER_LAND_DETAILS L "
				+ "where F.FDistrictID=D.DISTRICT_ID and F.FMandalID=M.MANDAL_ID and F.FVillageID=V.VILLAGE_ID "
				+ "and M.DISTRICT_ID=D.DISTRICT_ID and V.DISTRICT_ID=M.DISTRICT_ID and V.MANDAL_ID=M.MANDAL_ID "
				+ "and F.RegistrationNo=L.RegistrationNo group by F.RegistrationNo";
		return FarmerRegistration_SP;
	}

	public static String getFarmerMaster_SP(String searchdata,String district,String mandal,String village)
	{
		String FarmerNameSearch_SP="Select FarmerName,AadhaarNo,FarmerFatherName,Gender,Age,IsEnjoymentNature,"
				+ "FMobile,FEmail,FStreetName,FHouseNo,BankName,BranchName,IFSCCode,BankAccountNo,NameasperBank,"
				+ "BankPassBook,PattadharPassbook,VROCertificate from MasterFarmer_Details "
				+ "where (FarmerName like '"+searchdata+"%' OR FarmerFatherName like '"+searchdata+"%' OR FMobile like '"+searchdata+"%')";
		return FarmerNameSearch_SP;
	}
	

}
