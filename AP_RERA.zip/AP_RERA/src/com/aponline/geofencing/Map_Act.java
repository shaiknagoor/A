package com.aponline.geofencing;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnCameraChangeListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;

public class Map_Act extends AppCompatActivity implements OnClickListener
{
	ActionBar ab;
	GPSTracker gps;
	Double c1,c2,c3,c4;
	GoogleMap map;
	private static final double EARTH_RADIUS = 6371000;// meters
	public static ArrayList<ArrayList<LatLng>> latlongArrayList=new ArrayList<ArrayList<LatLng>>();
	static ArrayList<LatLng> LatLngAL = new ArrayList<LatLng>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map_act);

		ab=getSupportActionBar();
		ab.setTitle("AP RERA");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FDD835")));
		ab.setDisplayHomeAsUpEnabled(true);
		
		SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);


		map=mapFragment.getMap();
		map.getUiSettings(). setZoomGesturesEnabled(false);

		Intent intent = getIntent(); 
		
		if(!(intent.getParcelableArrayListExtra("LatLngAL")==null)  )
		{

			LatLngAL = intent.getParcelableArrayListExtra("LatLngAL");
			getPolyline();
		}	else 
		{
			Toast.makeText(getBaseContext(), "Please try some some", Toast.LENGTH_SHORT).show();
		}
		this.map.setOnCameraChangeListener(new OnCameraChangeListener() {

			@Override
			public void onCameraChange(CameraPosition arg0) {
				//map.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(17.458814, 78.367966)) );
				map.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(LatLngAL.get(0).latitude,LatLngAL.get(0).longitude)) );
				map.animateCamera(CameraUpdateFactory.zoomTo(18));
				map.setOnCameraChangeListener(null);


			}
		});

				
		//getPolyline();

	}

//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		// Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.main, menu);
//		return true;
//	}
//
//	@Override
//	public boolean onOptionsItemSelected(MenuItem item) {
//		// Handle action bar item clicks here. The action bar will
//		// automatically handle clicks on the Home/Up button, so long
//		// as you specify a parent activity in AndroidManifest.xml.
//		int id = item.getItemId();
//		if (id == R.id.action_settings) {
//			return true;
//		}
//		return super.onOptionsItemSelected(item);
//	}

	
	private  void getPolyline()
	{


		//latlongArrayList = new ArrayList<ArrayList<LatLng>>();
		//ArrayList<LatLng> LatLngAL = new ArrayList<LatLng>();

		//		LatLngAL.add(new LatLng(17.459201, 78.368161));
		//		LatLngAL.add(new LatLng(17.459130, 78.368517));
		//		LatLngAL.add(new LatLng(17.458772, 78.368432));
		//		LatLngAL.add(new LatLng(17.458879, 78.368059));
		//
		//		latlongArrayList.add(LatLngAL);


		PolygonOptions polygonOptions = new PolygonOptions();
		for (LatLng a11:LatLngAL)
		{

			LatLng data = a11;			
			polygonOptions.add(data);
		}

		Polygon polygon = map.addPolygon(polygonOptions.strokeColor(Color.RED).strokeWidth(2));	

		map.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(LatLngAL.get(0).latitude,LatLngAL.get(0).longitude)) );
		map.animateCamera(CameraUpdateFactory.zoomTo(18));

		try 
		{
			double a=calculateAreaOfGPSPolygonOnEarthInSquareMeters();

			((TextView)findViewById(R.id.AreaTv)).setText("Toatl Area is : "+String.valueOf(a)+" m square");

		} catch (Exception e) {
			// TODO: handle exception
		}


	}
	public static double calculateAreaOfGPSPolygonOnEarthInSquareMeters() {
		return calculateAreaOfGPSPolygonOnSphereInSquareMeters( EARTH_RADIUS);
	}

	private static double calculateAreaOfGPSPolygonOnSphereInSquareMeters( final double radius) {


		final double diameter = radius * 2;
		final double circumference = diameter * Math.PI;

		final List<Double> listY = new ArrayList<Double>();
		final List<Double> listX = new ArrayList<Double>();
		final List<Double> listArea = new ArrayList<Double>();
		// calculate segment x and y in degrees for each point



		final double latitudeRef = LatLngAL.get(0).latitude;
		final double longitudeRef =LatLngAL.get(0).longitude;


		
			for (LatLng a11:LatLngAL)
			{

				final double latitude = a11.latitude;
				final double longitude = a11.longitude;
				listY.add(calculateYSegment(latitudeRef, latitude, circumference));
				//Log.d("", String.format("Y %s: %s", listY.size() - 1, listY.get(listY.size() - 1)));
				listX.add(calculateXSegment(longitudeRef, longitude, latitude, circumference));
				//Log.d("", String.format("X %s: %s", listX.size() - 1, listX.get(listX.size() - 1)));
			}
	

		// calculate areas for each triangle segment
		for (int i = 1; i < listX.size(); i++) {
			final double x1 = listX.get(i - 1);
			final double y1 = listY.get(i - 1);
			final double x2 = listX.get(i);
			final double y2 = listY.get(i);
			listArea.add(calculateAreaInSquareMeters(x1, x2, y1, y2));
			//Log.d("-----area", String.format("area %s: %s", listArea.size() - 1, listArea.get(listArea.size() - 1)));
		}

		// sum areas of all triangle segments
		double areasSum = 0;
		for (final Double area : listArea) {
			areasSum = areasSum + area;
		}
		// get abolute value of area, it can't be negative
		return Math.abs(areasSum);// Math.sqrt(areasSum * areasSum);
	}

	private static Double calculateAreaInSquareMeters(final double x1, final double x2, final double y1, final double y2) {
		return (y1 * x2 - x1 * y2) / 2;
	}

	private static double calculateYSegment(final double latitudeRef, final double latitude, final double circumference) {
		return (latitude - latitudeRef) * circumference / 360.0;
	}

	private static double calculateXSegment(final double longitudeRef, final double longitude, final double latitude,
			final double circumference) {
		return (longitude - longitudeRef) * circumference * Math.cos(Math.toRadians(latitude)) / 360.0;
	} 



	public void onBackPressed()
	{
		startActivity(new Intent(this, Test_MapGapi.class));
		Map_Act.this.finish();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
}
