package com.aponline.geofencing;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.aponline.geofencing.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class MainActivity extends AppCompatActivity implements OnClickListener
{
	ActionBar ab;
	GPSTracker gps;
	Double c1,c2,c3,c4;
	GoogleMap map;
	private static final double EARTH_RADIUS = 6371000;// meters
	public static ArrayList<ArrayList<LatLng>> latlongArrayList=new ArrayList<ArrayList<LatLng>>();
	public static  ArrayList<LatLng> LatLngAL = new ArrayList<LatLng>();
	LinearLayout AddCooLL;
	TextView AddgpsTv;


	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		gps=new GPSTracker(MainActivity.this);

		ab=getSupportActionBar();
		ab.setTitle("AP RERA");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FDD835")));
		ab.setDisplayHomeAsUpEnabled(true);


		findViewById(R.id.ProceedBt).setOnClickListener(this);
		AddCooLL=(LinearLayout)findViewById(R.id.AddCooLL);
		AddgpsTv=(TextView)findViewById(R.id.AddgpsTv);


		AddgpsTv.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				gps=new GPSTracker(MainActivity.this);
				AddCooLL.setVisibility(0);
				final View tr =getLayoutInflater().inflate(R.layout.add_gps_row, null);
				final Button gpsBt=(Button)tr.findViewById(R.id.coordienate);
				final TextView finalgpsTv=(TextView)tr.findViewById(R.id.finalgpsTv);
				gpsBt.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) 
					{
						gpsBt.setText("La-"+String.valueOf(gps.getLatitude())+"\n"+"Lg-"+String.valueOf(gps.getLongitude()));
						finalgpsTv.setText(gps.getLatitude()+","+gps.getLongitude());
						//LatLngAL.add(new LatLng(gps.getLatitude(), gps.getLongitude()));

					}
				});

				TextView delete=(TextView)tr.findViewById(R.id.RemoveTv);
				delete.setOnClickListener(new OnClickListener() 
				{

					@Override
					public void onClick(View v) 
					{
						View row = (View) v.getParent();
						ViewGroup container = ((ViewGroup)row.getParent());
						View view = ((ViewGroup) row).getChildAt(0);
						container.removeView(row);
						container.invalidate();

					}
				});
				AddCooLL.addView(tr);
				if(AddCooLL.getChildCount()>=3)
				{
					findViewById(R.id.ProceedBt).setVisibility(View.VISIBLE);
				}
			}
		});


	}



	private  void getPolyline()
	{


		if(AddCooLL.getChildCount()!=0)
		{
			for (int i = 0; i < AddCooLL.getChildCount(); i++) 
			{
				int Dc=0;

				View child = AddCooLL.getChildAt(i);
				String gg=((TextView)child.findViewById(R.id.finalgpsTv)).getText().toString();
				try 
				{
					if(!(gg.equalsIgnoreCase("")))
					{
						String aa[]=gg.split(",");
						LatLngAL.add(new LatLng(Double.valueOf(aa[0]),Double.valueOf(aa[1])));
						//latlongArrayList.add(LatLngAL);
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					break;
				}


			}
		}


	}
	@Override
	public void onClick(View v) 
	{
		gps=new GPSTracker(this);
		switch (v.getId()) 
		{
		/*case R.id.coordinate1:

			((Button)findViewById(R.id.coordinate1)).setText("La-"+String.valueOf(gps.getLatitude())+"\n"+"Lg-"+String.valueOf(gps.getLongitude()));
			c1=gps.getLatitude();
			c2=gps.getLongitude();
			LatLngAL.add(new LatLng(gps.getLatitude(), gps.getLongitude()));

			break;

		case R.id.coordinate2:

			((Button)findViewById(R.id.coordinate2)).setText("La-"+String.valueOf(gps.getLatitude())+"\n"+"Lg-"+String.valueOf(gps.getLongitude()));
			LatLngAL.add(new LatLng(gps.getLatitude(), gps.getLongitude()));
			break;

		case R.id.coordinate3:

			((Button)findViewById(R.id.coordinate3)).setText("La-"+String.valueOf(gps.getLatitude())+"\n"+"Lg-"+String.valueOf(gps.getLongitude()));
			LatLngAL.add(new LatLng(gps.getLatitude(), gps.getLongitude()));
			break;

		case R.id.coordinate4:

			((Button)findViewById(R.id.coordinate4)).setText("La-"+String.valueOf(gps.getLatitude())+"\n"+"Lg-"+String.valueOf(gps.getLongitude()));
			LatLngAL.add(new LatLng(gps.getLatitude(), gps.getLongitude()));
			break;*/

		case R.id.ProceedBt:

			//			LatLngAL.add(new LatLng(17.459201, 78.368161));
			//			LatLngAL.add(new LatLng(17.459130, 78.368517));
			//			LatLngAL.add(new LatLng(17.458772, 78.368432));
			//			LatLngAL.add(new LatLng(17.458879, 78.368059));

			//			latlongArrayList.add(LatLngAL);
			getPolyline();

			if(!(LatLngAL.isEmpty()))
			{
			Intent intent = new Intent(MainActivity.this, Map_Act.class);
			intent.putParcelableArrayListExtra("LatLngAL", LatLngAL);
			startActivity(intent);
			
			}else 
			{
				Toast toast = null;
				toast=Toast.makeText(MainActivity.this, "Please Capture Gps Coordinates.",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 200);
				//view.setBackgroundResource(R.color.Red);
				toast.show();
			}
			//getPolyline();
			break;

		default:
			break;
		}

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.model_1) 
		{
			startActivity(new Intent(MainActivity.this, Test_Map.class));
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
