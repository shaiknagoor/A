package com.aponline.geofencing;

import java.util.ArrayList;



import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class Test_Map extends FragmentActivity {

	GoogleMap googleMap;
	SharedPreferences sharedPreferences;
	int locationCount = 0;
	public static  ArrayList<LatLng> LatLngAL = new ArrayList<LatLng>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.test_map);
		Dialogs.AlertDialogs(this);
		// Getting Google Play availability status
		int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getBaseContext());

		// Showing status
		if(status!=ConnectionResult.SUCCESS){ // Google Play Services are not available

			int requestCode = 10;
			Dialog dialog = GooglePlayServicesUtil.getErrorDialog(status, this, requestCode);
			dialog.show();

		}else { // Google Play Services are available

			// Getting reference to the SupportMapFragment of activity_main.xml
			SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.testmap);

			// Getting GoogleMap object from the fragment
			googleMap = fm.getMap();
			googleMap.animateCamera(CameraUpdateFactory.zoomTo(18));
			// Enabling MyLocation Layer of Google Map
			googleMap.setMyLocationEnabled(true);

			
//			// Opening the sharedPreferences object
//			sharedPreferences = getSharedPreferences("location", 0);
//
//			// Getting number of locations already stored
//			locationCount = sharedPreferences.getInt("locationCount", 0);
//
//			// Getting stored zoom level if exists else return 0
//			String zoom = sharedPreferences.getString("zoom", "0");
//
//			// If locations are already saved
//			if(locationCount!=0){
//
//				String lat = "";
//				String lng = "";
//
//				// Iterating through all the locations stored
//				for(int i=0;i<locationCount;i++){
//
//					// Getting the latitude of the i-th location
//					lat = sharedPreferences.getString("lat"+i,"0");
//
//					// Getting the longitude of the i-th location
//					lng = sharedPreferences.getString("lng"+i,"0");
//
//					// Drawing marker on the map
//					drawMarker(new LatLng(Double.parseDouble(lat), Double.parseDouble(lng)));
//				}
//
//				// Moving CameraPosition to last clicked position
//				googleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(Double.parseDouble(lat), Double.parseDouble(lng))));
//
//				// Setting the zoom level in the map on last position  is clicked
//				googleMap.animateCamera(CameraUpdateFactory.zoomTo(Float.parseFloat(zoom)));
//			}
//			else {
				//googleMap.animateCamera(CameraUpdateFactory.zoomTo(18));
			//}
		}
		
		googleMap.setOnMapClickListener(new OnMapClickListener() {

			@Override
			public void onMapClick(LatLng point) {
				locationCount++;

				// Drawing marker on the map
				drawMarker(point);

				/** Opening the editor object to write data to sharedPreferences */
				//                SharedPreferences.Editor editor = sharedPreferences.edit();
				// 
				//                // Storing the latitude for the i-th location
				//                editor.putString("lat"+ Integer.toString((locationCount-1)), Double.toString(point.latitude));
				// 
				//                // Storing the longitude for the i-th location
				//                editor.putString("lng"+ Integer.toString((locationCount-1)), Double.toString(point.longitude));
				// 
				//                // Storing the count of locations or marker count
				//                editor.putInt("locationCount", locationCount);
				// 
				//                /** Storing the zoom level to the shared preferences */
				//                editor.putString("zoom", Float.toString(googleMap.getCameraPosition().zoom));
				// 
				//                /** Saving the values stored in the shared preferences */
				//                editor.commit();
				LatLngAL.add(new LatLng(point.latitude,point.longitude));
				Toast.makeText(getBaseContext(), Double.toString(point.latitude)+","+Double.toString(point.longitude), Toast.LENGTH_SHORT).show();

			}
		});

		googleMap.setOnMapLongClickListener(new OnMapLongClickListener() {
			@Override
			public void onMapLongClick(LatLng point) {

				// Removing the marker and circle from the Google Map
				googleMap.clear();

				LatLngAL.removeAll(LatLngAL);
//				// Opening the editor object to delete data from sharedPreferences
//				SharedPreferences.Editor editor = sharedPreferences.edit();
//
//				// Clearing the editor
//				editor.clear();
//
//				// Committing the changes
//				editor.commit();
//
//				// Setting locationCount to zero
//				locationCount=0;

			}
		});


	}
	public void confirm(View v)
	{
		int count= LatLngAL.size();
		Toast.makeText(getBaseContext(), String.valueOf(count), Toast.LENGTH_SHORT).show();
		//startActivity(new Intent(this, Map_Act.class));
		Alert("Your Selected "+String.valueOf(count)+"  Points", "test");
		
	}
	private void drawMarker(LatLng point){
		// Creating an instance of MarkerOptions
		MarkerOptions markerOptions = new MarkerOptions();

		// Setting latitude and longitude for the marker
		markerOptions.position(point);

		// Adding marker on the Google Map
		googleMap.addMarker(markerOptions);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.model_1) 
		{
			startActivity(new Intent(Test_Map.this, Test_MapGapi.class));
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	public void Alert(String msg1,final String type)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("AP Checkpost");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				if(type.equalsIgnoreCase("test"))
				{
					
					Intent intent = new Intent(Test_Map.this, Map_Act.class);
					intent.putParcelableArrayListExtra("LatLngAL", LatLngAL);
					startActivity(intent);
					// setResult(LOGOUT);
			     finish();
				}
				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
}