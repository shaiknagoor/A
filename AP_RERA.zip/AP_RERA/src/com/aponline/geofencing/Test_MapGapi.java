package com.aponline.geofencing;

import java.util.ArrayList;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Test_MapGapi extends AppCompatActivity implements ConnectionCallbacks,OnConnectionFailedListener 
{
	// LogCat tag
	private static final String TAG = MainActivity.class.getSimpleName();

	private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 1000;

	private Location mLastLocation;

	// Google client to interact with Google API
	private GoogleApiClient mGoogleApiClient;

	// boolean flag to toggle periodic location updates
	private boolean mRequestingLocationUpdates = false;

	private LocationRequest mLocationRequest;

	// Location updates intervals in sec
	private static int UPDATE_INTERVAL = 10000; // 10 sec
	private static int FATEST_INTERVAL = 5000; // 5 sec
	private static int DISPLACEMENT = 10; // 10 meters

	// UI elements
	private TextView lblLocation;
	private Button btnShowLocation, btnStartLocationUpdates;

	ActionBar ab;
	public static  ArrayList<LatLng> LatLngAL = new ArrayList<LatLng>();
	LinearLayout AddCooLL;
	TextView AddgpsTv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map_gapi);

		ab=getSupportActionBar();
		ab.setTitle("Geo Fencing");
		ab.setHomeButtonEnabled(true);
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FDD835")));
		ab.setDisplayHomeAsUpEnabled(true);


		//findViewById(R.id.ProceedBt).setOnClickListener(this);
		AddCooLL=(LinearLayout)findViewById(R.id.AddCooLL);
		AddgpsTv=(TextView)findViewById(R.id.AddgpsTv);



		//lblLocation = (TextView) findViewById(R.id.lblLocation);
		//btnShowLocation = (Button) findViewById(R.id.btnShowLocation);
		//btnStartLocationUpdates = (Button) findViewById(R.id.btnLocationUpdates);

		// First we need to check availability of play services
		if (checkPlayServices()) {

			// Building the GoogleApi client
			buildGoogleApiClient();
		}

		// Show location button click listener
		//		btnShowLocation.setOnClickListener(new View.OnClickListener() {
		//
		//			@Override
		//			public void onClick(View v) {
		//				displayLocation();
		//			}
		//		});

		AddgpsTv.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{



				AddCooLL.setVisibility(0);
				final View tr =getLayoutInflater().inflate(R.layout.add_gps_row, null);
				final Button gpsBt=(Button)tr.findViewById(R.id.coordienate);
				final TextView finalgpsTv=(TextView)tr.findViewById(R.id.finalgpsTv);
				gpsBt.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) 
					{
						//displayLocation();
						mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

						if (mLastLocation != null)
						{
							double latitude = mLastLocation.getLatitude();
							double longitude = mLastLocation.getLongitude();

							//lblLocation.setText(latitude + ", " + longitude);

							gpsBt.setText("La-"+String.valueOf(latitude)+"\n"+"Lg-"+String.valueOf(longitude));
							finalgpsTv.setText(latitude+","+longitude);

						} 
						else
						{
							buildGoogleApiClient();
							Toast toast = null;
							toast=Toast.makeText(Test_MapGapi.this, "Please check your Internet connection / location.",Toast.LENGTH_SHORT);
							View view = toast.getView();
							toast.setGravity(Gravity.CENTER, 0, 200);
							view.setBackgroundResource(R.color.Red);
							toast.show();
							return;

							//lblLocation.setText("(Couldn't get the location. Make sure location is enabled on the device)");
						}

					}
				});

				TextView delete=(TextView)tr.findViewById(R.id.RemoveTv);
				delete.setOnClickListener(new OnClickListener() 
				{

					@Override
					public void onClick(View v) 
					{
						View row = (View) v.getParent();
						ViewGroup container = ((ViewGroup)row.getParent());
						View view = ((ViewGroup) row).getChildAt(0);
						container.removeView(row);
						container.invalidate();

					}
				});
				AddCooLL.addView(tr);
				if(AddCooLL.getChildCount()>=3)
				{
					findViewById(R.id.ProceedBt).setVisibility(View.VISIBLE);
				}
			}
		});
	}

	/**
	 * Method to display the location on UI
	 * */
	private void displayLocation() 
	{
		try {


			mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

			if (mLastLocation != null)
			{
				double latitude = mLastLocation.getLatitude();
				double longitude = mLastLocation.getLongitude();

				//lblLocation.setText(latitude + ", " + longitude);

			} else {

				//lblLocation.setText("(Couldn't get the location. Make sure location is enabled on the device)");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Creating google api client object
	 * */
	protected synchronized void buildGoogleApiClient() 
	{
		mGoogleApiClient = new GoogleApiClient.Builder(this)
		.addConnectionCallbacks(this)
		.addOnConnectionFailedListener(this)
		.addApi(LocationServices.API).build();
		
		mGoogleApiClient.connect();
	}

	/**
	 * Method to verify google play services on the device
	 * */
	private boolean checkPlayServices() 
	{
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);

		if (resultCode != ConnectionResult.SUCCESS) 
		{
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode))
			{
				GooglePlayServicesUtil.getErrorDialog(resultCode, this,PLAY_SERVICES_RESOLUTION_REQUEST).show();
			} else 
			{
				Toast.makeText(getApplicationContext(),"This device is not supported.", Toast.LENGTH_LONG).show();
				finish();
			}
			return false;
		}
		return true;
	}

	@Override
	protected void onStart() {
		super.onStart();
		if (mGoogleApiClient != null) 
		{
			mGoogleApiClient.connect();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();

		checkPlayServices();
	}

	/**
	 * Google api callback methods
	 */
	@Override
	public void onConnectionFailed(ConnectionResult result)
	{
		Log.i(TAG, "Connection failed: ConnectionResult.getErrorCode() = " + result.getErrorCode());
	}

	@Override
	public void onConnected(Bundle arg0) {

		// Once connected with google api, get the location
		displayLocation();
	}

	@Override
	public void onConnectionSuspended(int arg0) {
		mGoogleApiClient.connect();
	}
	public void confirm(View v)
	{
		getPolyline();

		if(LatLngAL.size()!=0)
		{
			int count= LatLngAL.size();
			Toast.makeText(getBaseContext(), String.valueOf(count), Toast.LENGTH_SHORT).show();
			//startActivity(new Intent(this, Map_Act.class));

			Intent intent = new Intent(Test_MapGapi.this, Map_Act.class);
			intent.putParcelableArrayListExtra("LatLngAL", LatLngAL);
			startActivity(intent);
		}else 
		{
			Toast.makeText(getBaseContext(), "Plz Capture Gps Coordinates", Toast.LENGTH_SHORT).show();
		}
	}
	private  void getPolyline()
	{


		if(AddCooLL.getChildCount()!=0)
		{
			for (int i = 0; i < AddCooLL.getChildCount(); i++) 
			{
				int Dc=0;

				View child = AddCooLL.getChildAt(i);
				String gg=((TextView)child.findViewById(R.id.finalgpsTv)).getText().toString();
				try 
				{
					String aa[]=gg.split(",");
					LatLngAL.add(new LatLng(Double.valueOf(aa[0]),Double.valueOf(aa[1])));
					//latlongArrayList.add(LatLngAL);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					break;
				}


			}
		}


	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.model_1) 
		{
			startActivity(new Intent(Test_MapGapi.this, Test_Map.class));
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	public void onBackPressed()
	{
		startActivity(new Intent(this, Login_Page.class));
		Test_MapGapi.this.finish();
	}


}
