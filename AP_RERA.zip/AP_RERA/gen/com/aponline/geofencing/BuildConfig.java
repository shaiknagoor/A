/** Automatically generated file. DO NOT MODIFY */
package com.aponline.geofencing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}