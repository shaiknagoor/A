package com.aponline.cropsurvey;


import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Network;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class Check_Updates extends Activity 
{

	Context context;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	String versionName = "Version not found";

	private void Loaddata(final String methodName)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==15)
				{
					//Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id="+ Check_Updates.this.getPackageName()));

					if((Float.parseFloat(versionName))<(Float.parseFloat(WebserviceCall.VersionNo)))
					{
						Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id="+ Check_Updates.this.getPackageName()));

						Check_Updates.this.startActivity(localIntent);
						Check_Updates.this.finish();
						return;

					}else {
						startActivity(new Intent(Check_Updates.this, Login.class));
						Check_Updates.this.finish();
					}
				}

				if(paramMessage.what==10 || paramMessage.what==11 || paramMessage.what==1)

				{
					AlertDialog(Check_Updates.this,"Check Internet Connection and Retry", "");
					//Loaddata("CheckAppVersion");

				}
				//				if(paramMessage.what==100)
				//				{
				//					System.out.println("********Error Occered************");
				//					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
				//					Toast.makeText(Check_Updates.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				//					//return;
				//				}
				//				if(paramMessage.what==11 || paramMessage.what==98|| paramMessage.what==21)
				//				{
				//					System.out.println("********Soap Fault or xml problem**********"); 
				//					Toast.makeText(Check_Updates.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				//				}
				//				if(paramMessage.what==10)
				//				{
				//					System.out.println("********No Internet Connection************");
				//					Toast.makeText(Check_Updates.this,"Timeout",Toast.LENGTH_LONG).show();
				//					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				//				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Version Checking.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName);
		this.conn_obj.checkNetworkAvailability();
		return;
	}
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		context=this;
		setContentView(R.layout.splash_screen);
		try {
			if(CheckConnection.isNetworkAvailable(Check_Updates.this))
			{
				versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
				Loaddata("CheckAppVersion");
			}else {
				startActivity(new Intent(Check_Updates.this,Login.class));
				Check_Updates.this.finish();
			}

		} catch (NameNotFoundException e) {

			e.printStackTrace();
		}

	}

	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				Loaddata("CheckAppVersion");
				dialog.dismiss();				

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}

}
