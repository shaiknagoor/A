package com.aponline.cropsurvey;




import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.aponline.cropsurvey.database.DBAdapter;
import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class CropDataEntry  extends  AppCompatActivity
{
	List<String> mandalList,datelist;
	Spinner mandal_sp;
	DBAdapter db;
	//	ArrayList<ArrayList<String>> entire_crop_area;
	ArrayList<ArrayList<String>> all;
	ArrayList<String> crop_data,crop_area,temp,temp1;
	ArrayList<String> temp2;
	Button submit_crop_data;
	ArrayAdapter<String> MandalAdapter;
	TableLayout crop_table_data;
	ActionBar ab;
	String season;
	String flag_temp1;
	Context context;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	ContentValues cv;
	String normal_pending="0",actual_pending="0";
	TextView normal_pendingUploadCount,actual_pendingUploadCount;
	private static final Pattern TAG_REGEX= Pattern.compile("<CROP_NAME>(.+?)</CROP_NAME>") ;
	private static final Pattern TAG_REGEX1= Pattern.compile("<CROP_AREA>(.+?)</CROP_AREA>") ;
	InputFilter filter;
	String headquarter_id,district_id,user_id,adh,fin_year;
	private void Loaddata(final String methodName,ArrayList<ContentValues> a,ContentValues cv)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{
					final Date d=new Date();
					SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
					AlertDialog(CropDataEntry.this,"Actual Area Already Submitted For "+mandal_sp.getSelectedItem().toString()+" for "+df1.format(d), "exist");
				}
				if(paramMessage.what==22)
				{
					refreshPendingCount();
				}

				if(paramMessage.what==15)
				{
					
						AlertDialog(CropDataEntry.this, "Actual Area SuccessFully Submitted for "+mandal_sp.getSelectedItem().toString(),"");												
						MandalAdapter.remove((String)mandal_sp.getSelectedItem());
						MandalAdapter.notifyDataSetChanged();
						mandal_sp.setSelection(0);
						crop_table_data.removeAllViews();
						submit_crop_data.setVisibility(8);

						if(mandal_sp.getAdapter().getCount()==1)
						{


							Toast toast = null;
							toast=Toast.makeText(CropDataEntry.this, "Actual Area Entry for Today has been Completed",Toast.LENGTH_SHORT);
							View view = toast.getView();
							toast.setGravity(Gravity.BOTTOM, 0, 0);
							view.setBackgroundResource(R.color.red);
							toast.show();
						}
										
				}
				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(CropDataEntry.this, "Please Try Agian",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.BOTTOM, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(CropDataEntry.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==	98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(CropDataEntry.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(CropDataEntry.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName,a,cv);
		this.conn_obj.checkNetworkAvailability();
		return;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.crop_data_entry);
		db=new DBAdapter(this);
		context=this;
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		this.ab=getSupportActionBar();
		ab.setTitle("Actual Area Entry");
		ab.setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_gradient_shape));
		ab.setHomeButtonEnabled(true);
		ab.setDisplayHomeAsUpEnabled(true);
		SharedPreferences prefs = getSharedPreferences("SEASON",MODE_PRIVATE);		
		season = prefs.getString("season","");		
		mandal_sp=(Spinner)findViewById(R.id.mandal_crop_data_entry);
		mandalList=new ArrayList<String>();
		submit_crop_data =(Button)findViewById(R.id.submit_Crop_data);
		crop_table_data=(TableLayout)findViewById(R.id.crop_table_data);
		normal_pendingUploadCount=(TextView)findViewById(R.id.normal_pendingUploadCount);
		actual_pendingUploadCount=(TextView)findViewById(R.id.actual_pendingUploadCountEt);
		SharedPreferences prefs1= getSharedPreferences("Login",MODE_PRIVATE);		
		headquarter_id=	prefs1.getString("headquarter_id","");	
		district_id=	prefs1.getString("district_id","");	
		user_id=prefs1.getString("user_id","");	
		adh=prefs1.getString("adh","");
		SharedPreferences prefs2= getSharedPreferences("fin_year",MODE_PRIVATE);		
		fin_year=	prefs2.getString("fin_year","");
		final Date d=new Date();
		final SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		db.open();

		mandalList=db.getSpinnerData("select MANDAL_NAME from DISTRICT_HQ_MANDAL where DISTRICT_ID='"+district_id+"' and HEADQUARTER_ID='"+headquarter_id+"' and ADH='"+adh+"' order by MANDAL_NAME");

		//datelist=db.getSpinnerDatacrop("select DATE from CROP_ACTUAL_AREA_MASTER where USER_ID='"+Login.user_id+"'");
		db.close();

		MandalAdapter = new ArrayAdapter<String>(CropDataEntry.this,android.R.layout.simple_spinner_item,mandalList);
		MandalAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		mandal_sp.setAdapter(MandalAdapter);
		refreshPendingCount();
		filter = new InputFilter() {
			final int maxDigitsBeforeDecimalPoint=6;
			final int maxDigitsAfterDecimalPoint=2;

			@Override
			public CharSequence filter(CharSequence source, int start, int end,
					Spanned dest, int dstart, int dend) {
				StringBuilder builder = new StringBuilder(dest);
				builder.replace(dstart, dend, source
						.subSequence(start, end).toString());
				if (!builder.toString().matches(
						"(([0-9]{1})([0-9]{0,"+(maxDigitsBeforeDecimalPoint-1)+"})?)?(\\.[0-9]{0,"+maxDigitsAfterDecimalPoint+"})?"

						)) {
					if(source.length()==0)
						return dest.subSequence(dstart, dend);
					return "";
				}

				return null;

			}
		};
		submit_crop_data.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0)
			{
				for (int i = 0; i <crop_table_data.getChildCount(); i++) {
					View child = crop_table_data.getChildAt(i);

					if (child instanceof TableRow) {
						TableRow row = (TableRow) child;
						View view = row.getChildAt(2);
						if(((TextView)view).getText().toString().equalsIgnoreCase(""))		
						{
							((TextView)view).requestFocus();
							((TextView)view).setError("Enter Area");
							return;
						}
						try
						{
							Double.parseDouble(((TextView)view).getText().toString());
						}
						catch(Exception e)
						{
							((TextView)view).requestFocus();
							((TextView)view).setError("Enter Area");
							return;
						}

					}
				}
				
				String formattedDate = df.format(d);
				SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
				db.open();
				String a=db.getSingleValue("select MANDAL_ID from DISTRICT_HQ_MANDAL where MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"'");
				db.close();
				db.open();
				int check=db.getRowCount("select count(*) from CROP_ACTUAL_AREA_MASTER where USER_ID='"+user_id+"' and MANDAL_ID='"+a+"' and D_DATE='"+df1.format(d)+"' ");
				if(check>0)
				{
					AlertDialog(CropDataEntry.this,"Actual Area Already Submitted For "+mandal_sp.getSelectedItem().toString()+" for "+df1.format(d), "exist");
					return;
				}
				else
				{
					ArrayList<ContentValues> normal_data=new ArrayList<ContentValues>();
					for (int i = 0; i <crop_table_data.getChildCount(); i++) 
					{
						View child = crop_table_data.getChildAt(i);

						if (child instanceof TableRow)
						{
							TableRow row = (TableRow) child;
							View view =row.getChildAt(0);
							View view1 = row.getChildAt(2);
							db.open();
							String a1=db.getSingleValue("select CROP_CODE from CROP_MASTER where CROP_NAME='"+((TextView)view).getText().toString()+"'");
							cv=new ContentValues();
							cv.put("USER_ID",user_id);
							cv.put("DISTRICT_ID",district_id);
							cv.put("HEADQUARTER_ID",headquarter_id);
							cv.put("MANDAL_ID",a);
							cv.put("CROP_ID",a1);
							cv.put("CROP_NAME",((TextView)view).getText().toString());
							cv.put("CROP_AREA",((TextView)view1).getText().toString());
							cv.put("DATE",formattedDate);
							cv.put("DEVICE_ID",HomeData.sDeviceId);
							cv.put("MANDAL_NAME",mandal_sp.getSelectedItem().toString());
							cv.put("SEASON",season);
							cv.put("D_DATE",df1.format(d));
							cv.put("ADH",adh);
							cv.put("FIN_YEAR",fin_year);
						}
						normal_data.add(cv);
					}
					db.close();
					if(CheckConnection.isNetworkAvailable(CropDataEntry.this))
					{
						Loaddata("InsertVegitableActualAreaDetails",normal_data,null);
					}
					else
					{
						for (int i = 0; i < normal_data.size(); i++) 
						{
						db.open();
						db.insertTableDate("CROP_ACTUAL_AREA_MASTER",cv);				
						db.close();
						}
						AlertDialog(CropDataEntry.this,"Actual Area SuccessFully Submitted for "+mandal_sp.getSelectedItem().toString(),"");
						MandalAdapter.remove((String)mandal_sp.getSelectedItem());
						MandalAdapter.notifyDataSetChanged();
						mandal_sp.setSelection(0);
						crop_table_data.removeAllViews();
						submit_crop_data.setVisibility(8);
						refreshPendingCount();
						if(mandal_sp.getAdapter().getCount()==1)
						{
							Toast toast = null;
							toast=Toast.makeText(CropDataEntry.this, "Actual Area Entry for Today has been Completed",Toast.LENGTH_SHORT);
							View view = toast.getView();
							toast.setGravity(Gravity.BOTTOM, 0, 0);
							view.setBackgroundResource(R.color.red);
							toast.show();
						}
					}
				}
			}
		});
		mandal_sp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				if(arg3!=0)
				{
					db.open();
					//	db.exportDB();
					crop_data=new ArrayList<String>();
					System.out.println("---"+user_id+"---"+mandal_sp.getSelectedItem().toString()+"---"+season+"---"+fin_year);
					Cursor a=	db.getTableDataCursor("select Distinct CROP_ID from CROP_REGISTRATION_DATA where USER_ID='"+user_id+"' and MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"' and SEASON='"+season+"' and FIN_YEAR='"+fin_year+"'");
					if(a.getCount()>0)
					{
						a.moveToFirst();	
						for (int i = 0; i < a.getCount(); i++) 
						{
							crop_data.add(a.getString(0));
							a.moveToNext();
						}
					}
					load_Crops(crop_data.size());
				}
				else
				{
					TableLayout tl = (TableLayout)findViewById(R.id.crop_table_data);
					tl.removeAllViews();
					submit_crop_data.setVisibility(8);
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {


			}
		});
	}
	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}
	private void load_Crops(int position) 
	{
		submit_crop_data.setVisibility(0);

		TableLayout tl = (TableLayout)findViewById(R.id.crop_table_data);
		tl.removeAllViews();
		for(int i=0;i<position;i++)
		{
			LayoutInflater inflater = getLayoutInflater();
			TableRow tr = (TableRow)inflater.inflate(R.layout.row1, tl, false);

			TextView tvValue = (TextView)tr.findViewById(R.id.column12tv);
			TextView tvValue1 = (TextView)tr.findViewById(R.id.column13tv);
			EditText tvValue2=(EditText)tr.findViewById(R.id.column22tv);
			tvValue2.setFilters(new InputFilter[] { filter });
			String crop_id=crop_data.get(i);
			db.open();
			String crop_name=db.getSingleValue("select CROP_NAME from CROP_MASTER where CROP_CODE='"+crop_id+"'");
			db.close();

			tvValue.setText(crop_name);
			db.open();
			String sum=	db.getSingleValue("select Sum(CROP_AREA) from CROP_ACTUAL_AREA_MASTER where CROP_ID='"+crop_id+"' and USER_ID='"+user_id+"' and MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"' and SEASON='"+season+"' and FIN_YEAR='"+fin_year+"' ");
			db.close();
			if(sum==null)
			{
				tvValue1.setText("0");
			}
			else
			{
				tvValue1.setText(sum);
			}
		

			tl.addView(tr);

		}

	}
	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);

		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	
		TextView msgTv1=(TextView)dialog.findViewById(R.id.textView1);
		if(DialogType.equalsIgnoreCase("exist"))
		{
			msgTv1.setText("Error !!!");
		}
		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				if(DialogType.equalsIgnoreCase("exist"))
				{
					MandalAdapter.remove((String)mandal_sp.getSelectedItem());
					MandalAdapter.notifyDataSetChanged();
					mandal_sp.setSelection(0);
					crop_table_data.removeAllViews();
					submit_crop_data.setVisibility(8);
				}

				dialog.dismiss();				

				return;
			}
		});  
		dialog.setCancelable(false);
		if(!dialog.isShowing())
			dialog.show();
		return;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int id = item.getItemId();
		if (id == R.id.edit_normal_area) 
		{
			Intent i=new Intent(CropDataEntry.this,Edit_Normal_Entry.class);
			startActivity(i);
		}
		if(id==android.R.id.home)
		{
			LogoutAlert("Do You Want To Logout", "logout");
			return true;
		}
		if (id == R.id.upload_of_actual) 
		{
			if(Integer.parseInt(actual_pending) > 0 && CheckConnection.isNetworkAvailable(CropDataEntry.this))
			{
				ContentValues cv=new ContentValues();
				cv.put("SEASON",season);
				cv.put("userid",user_id);

				Loaddata("UploadInsertVegitableActualAreaDetails",new ArrayList<ContentValues>(),cv);
			}
			else
			{
				if(Integer.parseInt(actual_pending)==0)
				{
					Toast toast = null;
					toast=Toast.makeText(CropDataEntry.this, "No Data To Upload",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				else
				{
					boolean a=	CheckConnection.isNetworkAvailable(CropDataEntry.this);
					if(a==false)
					{
						Toast toast = null;
						toast=Toast.makeText(CropDataEntry.this, "Check Internet Connection",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
				}

			}

		}
		if (id == R.id.upload_of_normal) 
		{
			if(Integer.parseInt(normal_pending) > 0 && CheckConnection.isNetworkAvailable(CropDataEntry.this))
			{
				ContentValues cv=new ContentValues();
				cv.put("SEASON",season);
				cv.put("userid",user_id);
				Loaddata("UploadInsertVegitableTotalAreaDetails",new ArrayList<ContentValues>(),cv);
			}
			else
			{
				if(Integer.parseInt(normal_pending)==0)
				{
					Toast toast = null;
					toast=Toast.makeText(CropDataEntry.this, "No Data To Upload",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				else
				{
					boolean a=	CheckConnection.isNetworkAvailable(CropDataEntry.this);
					if(a==false)
					{
						Toast toast = null;
						toast=Toast.makeText(CropDataEntry.this, "Check Internet Connection",Toast.LENGTH_SHORT);
						View view = toast.getView();
						toast.setGravity(Gravity.CENTER, 0, 0);
						view.setBackgroundResource(R.color.red);
						toast.show();
					}
				}

			}
		}
		if (id == R.id.reports) 
		{

			Intent i=new Intent(CropDataEntry.this,Reports.class);
			startActivity(i);


		}
		return super.onOptionsItemSelected(item);
	}

	public void LogoutAlert(String msg1,final String diatype)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Horticulture");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) {

				if(diatype.equalsIgnoreCase("logout")){
					Intent i=new Intent(CropDataEntry.this,Login.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				dialog.cancel();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		//return ;

	}
	public void refreshPendingCount()
	{
		try
		{
			db.open();
			actual_pending=db.getSingleValue("select  Count(AUTO_ID) from CROP_ACTUAL_AREA_MASTER where STATUS='N'  and USER_ID='"+user_id+"' and SEASON='"+season+"'");
			normal_pending=db.getSingleValue("select  Count(AUTO_ID) from CROP_REGISTRATION_DATA where STATUS='N'  and USER_ID='"+user_id+"' and SEASON='"+season+"'");
			actual_pendingUploadCount.setText("Pending Actual Area to be Uploaded   Count :"+actual_pending);
			normal_pendingUploadCount.setText("Pending Normal Area to be Uploaded   Count :"+normal_pending);
			db.close();
		}
		catch(Exception e)
		{                                            

		}
	}
	@Override
	public void onBackPressed() {
		LogoutAlert("Do You Want To Logout", "logout");
	}
}
