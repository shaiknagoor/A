package com.aponline.cropsurvey.adpater;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.cropsurvey.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ReportAdapter extends BaseAdapter
{
	ArrayList<HashMap<String,String>> localArrayList=new ArrayList<HashMap<String,String>>();
	Context mContext;
	private LayoutInflater mInflater;
	private Holder mHolder;
String Report_type;
	public ReportAdapter(Context baseContext,ArrayList<HashMap<String,String>> data,String type)
	{
		this.mContext=baseContext;
		this.localArrayList=data;
		this.mInflater=LayoutInflater.from(baseContext);
		this.Report_type=type;
	}

	@Override
	public int getCount() 
	{
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position)
	{
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(convertView == null)
		{
			convertView=this.mInflater.inflate(R.layout.mandal_wise_row, null);
			if(Report_type.equalsIgnoreCase("MV"))
			{
			
//			convertView = this.mInflater.inflate(R.layout.sell, null);
			this.mHolder= new Holder();
			this.mHolder.district=(TextView) convertView.findViewById(R.id.mv_district_name);
			this.mHolder.mandal=(TextView) convertView.findViewById(R.id.mv_mandal_name);
			this.mHolder.actual_area=(TextView) convertView.findViewById(R.id.mv_actual_area);
			this.mHolder.normal_area=(TextView) convertView.findViewById(R.id.mv_normal_area);
			this.mHolder.crop=(TextView) convertView.findViewById(R.id.mv_crop);
			this.mHolder.crop.setVisibility(View.GONE);
			}
			else
			{
				this.mHolder= new Holder();
				this.mHolder.district=(TextView) convertView.findViewById(R.id.mv_district_name);
				this.mHolder.mandal=(TextView) convertView.findViewById(R.id.mv_mandal_name);
				this.mHolder.actual_area=(TextView) convertView.findViewById(R.id.mv_actual_area);
				this.mHolder.normal_area=(TextView) convertView.findViewById(R.id.mv_normal_area);
				this.mHolder.crop=(TextView) convertView.findViewById(R.id.mv_crop);
				this.mHolder.crop.setVisibility(View.VISIBLE);
			}
									
			convertView.setTag(mHolder);
		}
		else
			this.mHolder=(Holder)convertView.getTag();
		HashMap<String, String> data=this.localArrayList.get(position);
		if(Report_type.equalsIgnoreCase("MV"))
		{
		
		this.mHolder.district.setText(data.get("District"));
		this.mHolder.mandal.setText(data.get("MANDAL"));
		this.mHolder.normal_area.setText(data.get("NORMAL_AREA"));
		this.mHolder.actual_area.setText(data.get("ACTUAL_AREA"));
				
		}
		else
		{
			this.mHolder.district.setText(data.get("District"));
			this.mHolder.mandal.setText(data.get("MANDAL"));
			this.mHolder.crop.setText(data.get("CROP"));
			this.mHolder.normal_area.setText(data.get("NORMAL_AREA"));
			this.mHolder.actual_area.setText(data.get("ACTUAL_AREA"));
		}

		return convertView;

	}
	public class Holder
	{
		TextView district;
		TextView mandal;
		TextView crop;
		TextView actual_area;
		TextView normal_area;
		
	}
}