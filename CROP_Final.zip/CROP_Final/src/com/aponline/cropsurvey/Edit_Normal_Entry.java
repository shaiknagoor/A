package com.aponline.cropsurvey;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.aponline.cropsurvey.database.DBAdapter;
import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Edit_Normal_Entry  extends AppCompatActivity
{
	ActionBar ab;
	Spinner mandal_sp,edit_crops;
	List<String> mandalList,miCropTypelist;
	Button submit_crop_data,edit_add_btn;
	TableLayout crop_table_data;
	DBAdapter db;
	String season_name;
	ArrayList<String> crop_data,crop_area;
	ArrayAdapter<String> MandalAdapter,CropTypeSpAdapter;
	private static final Pattern TAG_REGEX= Pattern.compile("<CROP_NAME>(.+?)</CROP_NAME>") ;
	private static final Pattern TAG_REGEX1= Pattern.compile("<CROP_AREA>(.+?)</CROP_AREA>") ;
	Context context;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	StringBuilder crop_details;
	InputFilter filter;
	ContentValues cv;
	String headquarter_id,district_id,user_id,adh,season,fin_year;
	private void Loaddata(final String methodName,ArrayList<ContentValues> cv)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{

				}
				if(paramMessage.what==22)
				{

				}

				if(paramMessage.what==15)
				{

					
						//AlertDialog(Edit_Normal_Entry.this, "Normal Area SuccessFully Submitted for "+mandal_sp.getSelectedItem().toString(),"");				

						
						AlertDialog(Edit_Normal_Entry.this, "Normal Area SuccessFully Submitted for "+mandal_sp.getSelectedItem().toString(),"");
						//MandalAdapter.remove((String)mandal_sp.getSelectedItem());
						//MandalAdapter.notifyDataSetChanged();
						mandal_sp.setSelection(0);
						crop_table_data.removeAllViews();
						submit_crop_data.setVisibility(8);
						((LinearLayout)findViewById(R.id.edit_add_crop)).setVisibility(8);

					}
					

				
				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(Edit_Normal_Entry.this, "Please Try Agian",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.BOTTOM, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(Edit_Normal_Entry.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==	98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(Edit_Normal_Entry.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(Edit_Normal_Entry.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName,cv);
		this.conn_obj.checkNetworkAvailability();
		return;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{

		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit_normal_area);
		context=this;
		db=new DBAdapter(this);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		this.ab=getSupportActionBar();
		ab.setTitle("Edit Normal Area Entry");
		ab.setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_gradient_shape));
		ab.setHomeButtonEnabled(true);
		ab.setDisplayHomeAsUpEnabled(true);
		SharedPreferences prefs = getSharedPreferences("SEASON",MODE_PRIVATE);		
		season_name = prefs.getString("season","");
		mandal_sp=(Spinner)findViewById(R.id.mandal_crop_edit_data_entry);
		mandalList=new ArrayList<String>();
		submit_crop_data =(Button)findViewById(R.id.submit_edit_Crop_data);
		crop_table_data=(TableLayout)findViewById(R.id.crop_edit_table_data);
		edit_crops=(Spinner)findViewById(R.id.edit_crops);
		edit_add_btn=(Button)findViewById(R.id.edit_add_btn);
		miCropTypelist=new ArrayList<String>();
		final Date d=new Date();
		final SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		db.open();
		SharedPreferences prefs1= getSharedPreferences("Login",MODE_PRIVATE);		
		headquarter_id=	prefs1.getString("headquarter_id","");	
		district_id=	prefs1.getString("district_id","");	
		user_id=prefs1.getString("user_id","");	
		adh=prefs1.getString("adh","");
		SharedPreferences prefs2= getSharedPreferences("SEASON",MODE_PRIVATE);		
		season=	prefs2.getString("season","");	
		SharedPreferences prefs3= getSharedPreferences("fin_year",MODE_PRIVATE);		
		fin_year=	prefs3.getString("fin_year","");
		mandalList=db.getSpinnerData("select MANDAL_NAME from DISTRICT_HQ_MANDAL where DISTRICT_ID='"+district_id+"' and HEADQUARTER_ID='"+headquarter_id+"' and ADH='"+adh+"' order by MANDAL_NAME");


		db.close();

		MandalAdapter = new ArrayAdapter<String>(Edit_Normal_Entry.this,android.R.layout.simple_spinner_item,mandalList);
		MandalAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		mandal_sp.setAdapter(MandalAdapter);
		filter = new InputFilter() {
			final int maxDigitsBeforeDecimalPoint=6;
			final int maxDigitsAfterDecimalPoint=2;

			@Override
			public CharSequence filter(CharSequence source, int start, int end,
					Spanned dest, int dstart, int dend) {
				StringBuilder builder = new StringBuilder(dest);
				builder.replace(dstart, dend, source
						.subSequence(start, end).toString());
				if (!builder.toString().matches(
						"(([0-9]{1})([0-9]{0,"+(maxDigitsBeforeDecimalPoint-1)+"})?)?(\\.[0-9]{0,"+maxDigitsAfterDecimalPoint+"})?"

						)) {
					if(source.length()==0)
						return dest.subSequence(dstart, dend);
					return "";
				}

				return null;

			}
		};
		edit_add_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(mandal_sp.getSelectedItemPosition()==0)
				{
					mandal_sp.requestFocusFromTouch();
					return;
				}

				if(edit_crops.getSelectedItemPosition()==0)
				{
					edit_crops.requestFocusFromTouch();
					return;
				}
				final TableLayout tl = (TableLayout)findViewById(R.id.crop_edit_table_data);
				LayoutInflater inflater = getLayoutInflater();
				TableRow tr = (TableRow)inflater.inflate(R.layout.row2, tl, false);

				TextView tvValue = (TextView)tr.findViewById(R.id.edit_column12tv);
				TextView tvValue1=(EditText)tr.findViewById(R.id.edit_column22tv);
				tvValue1.setFilters(new InputFilter[] { filter });
				//EditText tvValue1 = (EditText)tr.findViewById(R.id.edit_column22tv);
				tvValue.setText(edit_crops.getSelectedItem().toString());
				tl.addView(tr);
				CropTypeSpAdapter.remove((String)edit_crops.getSelectedItem());
				CropTypeSpAdapter.notifyDataSetChanged();
				edit_crops.setSelection(0);
			}
		});
		mandal_sp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				if(arg3!=0)
				{
					((LinearLayout)findViewById(R.id.edit_add_crop)).setVisibility(0);

					crop_data=new ArrayList<String>();
					crop_area=new ArrayList<String>();
					db.open();
					Cursor a=	db.getTableDataCursor("select Distinct CROP_NAME,CROP_AREA from CROP_REGISTRATION_DATA where USER_ID='"+user_id+"' and MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"' and SEASON='"+season+"' and FIN_YEAR='"+fin_year+"'");
					if(a.getCount()>0)
					{
						a.moveToFirst();	
						for (int i = 0; i < a.getCount(); i++) 
						{
							crop_data.add(a.getString(0));
							crop_area.add(a.getString(1));
							a.moveToNext();
						}
					}
				db.close();
					
					CropData();

					for (int i = 0; i < crop_data.size(); i++) {
						CropTypeSpAdapter.remove(crop_data.get(i));
						CropTypeSpAdapter.notifyDataSetChanged();
						edit_crops.setSelection(0);
					}



					load_Crops(crop_data.size());
				}
				else
				{
					TableLayout tl = (TableLayout)findViewById(R.id.crop_edit_table_data);
					tl.removeAllViews();
					submit_crop_data.setVisibility(8);
					((LinearLayout)findViewById(R.id.edit_add_crop)).setVisibility(8);
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {


			}
		});
		submit_crop_data.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) 
			{

				for (int i = 0; i < crop_table_data.getChildCount(); i++) {
					View child = crop_table_data.getChildAt(i);

					if (child instanceof TableRow) {
						TableRow row = (TableRow) child;
						View view = row.getChildAt(1);
						if(((TextView)view).getText().toString().equalsIgnoreCase(""))		
						{
							((TextView)view).requestFocus();
							((TextView)view).setError("Enter Area");
							return;
						}
						try
						{
							Double.parseDouble(((TextView)view).getText().toString());
						}
						catch(Exception e)
						{
							((TextView)view).requestFocus();
							((TextView)view).setError("Enter Area");
							return;
						}

					}
				}


				Date d=new Date();
				SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
				String formattedDate = df.format(d);
				db.open();
				String a=db.getSingleValue("select MANDAL_ID from DISTRICT_HQ_MANDAL where MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"'");
				db.close();
				ArrayList<ContentValues> normal_data=new ArrayList<ContentValues>();
				for (int i = 0; i < crop_table_data.getChildCount(); i++) {
					View child = crop_table_data.getChildAt(i);

					if (child instanceof TableRow) 
					{
						TableRow row = (TableRow) child;
						View view =row.getChildAt(0);
						View view1 = row.getChildAt(1);
						db.open();
						String a1=db.getSingleValue("select CROP_CODE from CROP_MASTER where CROP_NAME='"+((TextView)view).getText().toString()+"'");
						cv=new ContentValues();
						cv.put("USER_ID",user_id);
						cv.put("DISTRICT_ID",district_id);
						cv.put("HEADQUARTER_ID",headquarter_id);
						cv.put("MANDAL_ID",a);
						cv.put("CROP_ID",a1);
						cv.put("CROP_NAME",((TextView)view).getText().toString());
						cv.put("CROP_AREA",((TextView)view1).getText().toString());
						cv.put("DATE",formattedDate);
						cv.put("DEVICE_ID",HomeData.sDeviceId);
						cv.put("MANDAL_NAME",mandal_sp.getSelectedItem().toString());
						cv.put("SEASON",season);
						cv.put("D_DATE",df1.format(d));
						cv.put("ADH",adh);
						cv.put("FIN_YEAR",fin_year);

					}

					normal_data.add(cv);
				}
db.close();
	
				
				
				if(CheckConnection.isNetworkAvailable(Edit_Normal_Entry.this))
				{
					Loaddata("UpdateInsertVegitableTotalAreaDetails",normal_data);
				}
				else
				{
					
					db.open();
			
					db.deleteTableData("CROP_REGISTRATION_DATA","USER_ID='"+user_id+"' and SEASON='"+season+"' and FIN_YEAR='"+fin_year+"' and MANDAL_NAME='"+mandal_sp.getSelectedItem().toString()+"' " );
					db.close();
					for (int i = 0; i < normal_data.size(); i++) {
						
						ContentValues cv=normal_data.get(i);
						db.open();
						db.insertTableDate("CROP_REGISTRATION_DATA",cv);				
						db.close();
					}
					
					
					AlertDialog(Edit_Normal_Entry.this,"Normal Area SuccessFully Submitted for "+mandal_sp.getSelectedItem().toString(),"");					
					mandal_sp.setSelection(0);
					crop_table_data.removeAllViews();
					submit_crop_data.setVisibility(8);
					((LinearLayout)findViewById(R.id.edit_add_crop)).setVisibility(8);
				}

			}
		});

	}

	private void load_Crops(int position) 
	{
		submit_crop_data.setVisibility(0);

		TableLayout tl = (TableLayout)findViewById(R.id.crop_edit_table_data);
		tl.removeAllViews();
		for(int i=0;i<position;i++)
		{
			LayoutInflater inflater = getLayoutInflater();
			TableRow tr = (TableRow)inflater.inflate(R.layout.row2, tl, false);

			TextView tvValue = (TextView)tr.findViewById(R.id.edit_column12tv);
			EditText tvValue1 = (EditText)tr.findViewById(R.id.edit_column22tv);
			tvValue.setText(crop_data.get(i));
			tvValue1.setText(crop_area.get(i));
			tvValue1.setFilters(new InputFilter[] { filter });
			tl.addView(tr);

		}

	}
	public void CropData()
	{
		miCropTypelist.clear();
		CropTypeSpAdapter = new ArrayAdapter<String>(Edit_Normal_Entry.this,android.R.layout.simple_spinner_item,miCropTypelist);
		db.open();
		miCropTypelist=	db.getSpinnerData("select CROP_NAME from CROP_MASTER");
		db.close();
		CropTypeSpAdapter = new ArrayAdapter<String>(Edit_Normal_Entry.this,android.R.layout.simple_spinner_item,miCropTypelist);
		CropTypeSpAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		edit_crops.setAdapter(CropTypeSpAdapter);	
	}
	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{


				dialog.dismiss();
				return;	
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}

	@Override
	public void onBackPressed() {
		Intent i =new Intent(Edit_Normal_Entry.this,CropDataEntry.class);
		startActivity(i);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.reg_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int id = item.getItemId();
		if (id == android.R.id.home) 
		{
			Intent i =new Intent(Edit_Normal_Entry.this,CropDataEntry.class);
			startActivity(i);
		}
		return super.onOptionsItemSelected(item);
	}
}


