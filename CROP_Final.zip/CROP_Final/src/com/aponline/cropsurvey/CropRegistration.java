package com.aponline.cropsurvey;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import com.aponline.cropsurvey.database.DBAdapter;
import com.aponline.cropsurvey.server.CheckConnection;
import com.aponline.cropsurvey.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class CropRegistration extends AppCompatActivity
{
	Spinner crops,mandal;
	List<String> miCropTypelist,mandalList;
	ArrayAdapter<String> CropTypeSpAdapter,MandalAdapter;
	Button add_btn,submit;
	TableLayout table_data;
	DBAdapter db;
	ActionBar ab;
	Calendar c;
	Context context;
	ProgressDialog progressDialog;
	Handler mHandler;
	CheckConnection conn_obj;
	ContentValues cv;
	String season;
	InputFilter filter;
	String headquarter_id,district_id,user_id,adh;
	String fin_year;


	private void Loaddata(final String methodName,ArrayList<ContentValues> a)
	{
		progressDialog=new ProgressDialog(this);
		Handler localHadler=new Handler()
		{
			@SuppressLint("ResourceAsColor")
			public void dispatchMessage(Message paramMessage)
			{
				super.dispatchMessage(paramMessage);
				if(progressDialog.isShowing())
					progressDialog.dismiss();
				if(paramMessage.what==32)
				{
					Toast toast = null;
					toast=Toast.makeText(CropRegistration.this,"Successfully Updated",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.CENTER, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}


				if(paramMessage.what==15)
				{

				//	if(WebserviceCall.serverResponse.equalsIgnoreCase("success"))
				//	{
						AlertDialog(CropRegistration.this, "Normal Area SuccessFully Submitted for "+mandal.getSelectedItem().toString(),"");				

					//	cv.put("STATUS","Y");
					//	db.open();
					//	db.insertTableDate("CROP_REGISTRATION_DATA",cv);	
						//db.exportDB();
					//	db.close();
						MandalAdapter.remove((String)mandal.getSelectedItem());
						MandalAdapter.notifyDataSetChanged();
						mandal.setSelection(0);
						table_data.removeAllViews();
						submit.setVisibility(8);
						CropData();
						if(mandal.getAdapter().getCount()==1)
						{
							SharedPreferences preferences1 = getSharedPreferences("SEASON",MODE_PRIVATE);
							SharedPreferences.Editor editor1 = preferences1.edit();
							editor1.putString("season",season);					
							editor1.apply();


							db.open();
							ContentValues cv=new ContentValues();
							cv.put("USER_ID",user_id);
							cv.put("STATUS","Y");
							cv.put("SEASON",season);
							cv.put("FIN_YEAR",fin_year);
							db.insertTableDate("LOGIN_CHECK_MASTER",cv);
							//db.execSQL("UPDATE LOGIN_CHECK_MASTER SET STATUS='Y' WHERE USER_ID='"+Login.user_id+"' and SEASON='"+season+"' ");
							db.close();
							//							SharedPreferences preferences = getSharedPreferences("MY_PREFS_NAME",MODE_PRIVATE);
							//							SharedPreferences.Editor editor = preferences.edit();
							//							editor.putString("F_STATUS","Y");					
							//							editor.apply();
							Intent i=new Intent(CropRegistration.this,CropDataEntry.class);
							i.putExtra("season",season);
							startActivity(i);
							finish();

						}
					//}
//					else
//					{
//						Toast toast = null;
//						toast=Toast.makeText(CropRegistration.this, "Please Try Agian",Toast.LENGTH_SHORT);
//						View view = toast.getView();
//						toast.setGravity(Gravity.CENTER, 0, 0);
//						view.setBackgroundResource(R.color.red);
//						toast.show();
//					}

				}
				if(paramMessage.what==1)
				{
					System.out.println("********No New Data************");
					Toast toast = null;
					toast=Toast.makeText(CropRegistration.this, "Please Try Again",Toast.LENGTH_SHORT);
					View view = toast.getView();
					toast.setGravity(Gravity.BOTTOM, 0, 0);
					view.setBackgroundResource(R.color.red);
					toast.show();
				}
				if(paramMessage.what==100)
				{
					System.out.println("********Error Occered************");
					//AlertDialogs(DataSynPage.this, "Information!!", WebserviceCall.Error);
					Toast.makeText(CropRegistration.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
					//return;
				}
				if(paramMessage.what==11 || paramMessage.what==	98|| paramMessage.what==21)
				{
					System.out.println("********Soap Fault or xml problem**********"); 
					Toast.makeText(CropRegistration.this,WebserviceCall.Error,Toast.LENGTH_LONG).show();
				}
				if(paramMessage.what==10)
				{
					System.out.println("********No Internet Connection************");
					Toast.makeText(CropRegistration.this,"Timeout",Toast.LENGTH_LONG).show();
					//Dialogs.AlertDialogs(HomePage.mContext, "Information!!", "Timeout");
				}
				while(true)
				{	
					return;
				}
			}
		};
		this.mHandler=localHadler;
		progressDialog.setCancelable(false);
		progressDialog.setMessage("Please Wait.......");
		progressDialog.show();
		this.conn_obj = new CheckConnection(context,this.mHandler,methodName,a);
		this.conn_obj.checkNetworkAvailability();
		return;
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.crop_registration);
		db=new DBAdapter(this);
		context=this;
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		this.ab=getSupportActionBar();
		ab.setTitle("Normal Area Entry");
		ab.setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_gradient_shape));
		ab.setHomeButtonEnabled(true);
		ab.setDisplayHomeAsUpEnabled(true);
		Date d=new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate1 = df.format(d);


		try
		{
			if( d.after( df.parse("01/11/2016")) && d.before(df.parse("28/02/2017")))
			{
				season="RABI";
			}
			else if(d.after(df.parse("01/03/2017")) && d.before(df.parse("30/06/2017")))
			{
				season="SUMMER";
			}
			else if(d.after(df.parse("01/07/2017")) && d.before(df.parse("31/10/2017")))
			{
				season="KHARIF";
			}
			else if(d.after(df.parse("1/11/2017")) &&  d.before(df.parse("28/2/2018")))
			{
				season="RABI";
			}
		}
		catch(Exception e)
		{

		}
		SharedPreferences prefs1= getSharedPreferences("Login",MODE_PRIVATE);		
		headquarter_id=	prefs1.getString("headquarter_id","");	
		district_id=	prefs1.getString("district_id","");	
		user_id=prefs1.getString("user_id","");	
		adh=prefs1.getString("adh","");
		SharedPreferences preferences = getSharedPreferences("SEASON",MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putString("season",season);					
		editor.apply();
		SharedPreferences prefs2= getSharedPreferences("fin_year",MODE_PRIVATE);		
		fin_year=	prefs2.getString("fin_year","");	

		c = Calendar.getInstance();
		crops=(Spinner)findViewById(R.id.crops);
		mandal=(Spinner)findViewById(R.id.mandal);
		miCropTypelist=new ArrayList<String>();
		mandalList=new ArrayList<String>();
		db.open();
		mandalList=db.getSpinnerData("select MANDAL_NAME from DISTRICT_HQ_MANDAL where DISTRICT_ID='"+district_id+"' and HEADQUARTER_ID='"+headquarter_id+"' and ADH='"+adh+"' order by MANDAL_NAME");
		db.close();

		CropData();
		MandalAdapter = new ArrayAdapter<String>(CropRegistration.this,android.R.layout.simple_spinner_item,mandalList);
		MandalAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		mandal.setAdapter(MandalAdapter);
		add_btn=(Button)findViewById(R.id.add_btn);
		submit=(Button)findViewById(R.id.submit_Crop);
		table_data=(TableLayout)findViewById(R.id.table_data);
		filter = new InputFilter() {
			final int maxDigitsBeforeDecimalPoint=6;
			final int maxDigitsAfterDecimalPoint=2;

			@Override
			public CharSequence filter(CharSequence source, int start, int end,
					Spanned dest, int dstart, int dend) {
				StringBuilder builder = new StringBuilder(dest);
				builder.replace(dstart, dend, source
						.subSequence(start, end).toString());
				if (!builder.toString().matches(
						"(([0-9]{1})([0-9]{0,"+(maxDigitsBeforeDecimalPoint-1)+"})?)?(\\.[0-9]{0,"+maxDigitsAfterDecimalPoint+"})?"

						)) {
					if(source.length()==0)
						return dest.subSequence(dstart, dend);
					return "";
				}

				return null;

			}
		};
		mandal.setOnItemSelectedListener(new OnItemSelectedListener()
		{

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) 
			{

				crops.setSelection(0);
				table_data.removeAllViews();
				submit.setVisibility(8);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});
		add_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0)
			{
				if(mandal.getSelectedItemPosition()==0)
				{
					mandal.requestFocusFromTouch();
					return;
				}

				if(crops.getSelectedItemPosition()==0)
				{
					crops.requestFocusFromTouch();
					return;
				}

				final TableLayout tl = (TableLayout)findViewById(R.id.table_data);
				LayoutInflater inflater = getLayoutInflater();
				final TableRow tr = (TableRow)inflater.inflate(R.layout.row, tl, false);
				TextView tvValue1 = (TextView)tr.findViewById(R.id.column1tv);
				EditText tvValue2 = (EditText)tr.findViewById(R.id.column2tv);
				//tvValue2.addTextChangedListener(new CustomTextWatcher(tvValue2));
				Button ck=(Button)tr.findViewById(R.id.check);
				tvValue1.setText(crops.getSelectedItem().toString());
				tvValue2.setFilters(new InputFilter[] { filter });

				submit.setVisibility(0);

				ck.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {

						View row = (View) v.getParent();
						ViewGroup container = ((ViewGroup)row.getParent());
						View view = ((ViewGroup) row).getChildAt(0);
						CropTypeSpAdapter.add(((TextView)view).getText().toString());
						CropTypeSpAdapter.notifyDataSetChanged();
						CropTypeSpAdapter.sort(new Comparator<String>() {
							@Override
							public int compare(String lhs, String rhs) {
								return lhs.compareTo(rhs);
							}
						});
						container.removeView(row);
						container.invalidate();
						if(tl.getChildCount()==0)
						{
							submit.setVisibility(8);
						}
					}
				});
				tl.addView(tr);
				CropTypeSpAdapter.remove((String)crops.getSelectedItem());
				CropTypeSpAdapter.notifyDataSetChanged();
				crops.setSelection(0);

			}


		});


		crops.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});
		submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) 
			{

				for (int i = 0; i < table_data.getChildCount(); i++) {
					View child = table_data.getChildAt(i);

					if (child instanceof TableRow) {
						TableRow row = (TableRow) child;
						View view = row.getChildAt(1);
						if(((TextView)view).getText().toString().equalsIgnoreCase(""))		
						{
							((TextView)view).requestFocus();
							((TextView)view).setError("Enter Area");
							return;
						}
						try
						{
							Double.parseDouble(((TextView)view).getText().toString());
						}
						catch(Exception e)
						{
							((TextView)view).requestFocus();
							((TextView)view).setError("Enter Area");
							return;
						}


					}
				}


				
				Date d=new Date();
				SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
				String formattedDate = df.format(d);
				db.open();
				String a=db.getSingleValue("select MANDAL_ID from DISTRICT_HQ_MANDAL where MANDAL_NAME='"+mandal.getSelectedItem().toString()+"'");
				db.close();
				db.open();
				int check=db.getRowCount("select count(*) from CROP_REGISTRATION_DATA where USER_ID='"+user_id+"' and MANDAL_ID='"+a+"' and SEASON='"+season+"' and FIN_YEAR='"+fin_year+"' ");
				db.close();
				if(check>0)
				{
					AlertDialog(CropRegistration.this,"Normal Area Already Submitted For "+mandal.getSelectedItem().toString(), "exist");
					return;
				}
				else
				{
					ArrayList<ContentValues> normal_data=new ArrayList<ContentValues>();
					//new
					for (int i = 0; i < table_data.getChildCount(); i++) {
						View child = table_data.getChildAt(i);

						if (child instanceof TableRow) 
						{
							TableRow row = (TableRow) child;
							View view =row.getChildAt(0);
							View view1 = row.getChildAt(1);
							db.open();
							String a1=db.getSingleValue("select CROP_CODE from CROP_MASTER where CROP_NAME='"+((TextView)view).getText().toString()+"'");
							cv=new ContentValues();
							cv.put("USER_ID",user_id);
							cv.put("DISTRICT_ID",district_id);
							cv.put("HEADQUARTER_ID",headquarter_id);
							cv.put("MANDAL_ID",a);
							cv.put("CROP_ID",a1);
							cv.put("CROP_NAME",((TextView)view).getText().toString());
							cv.put("CROP_AREA",((TextView)view1).getText().toString());
							cv.put("DATE",formattedDate);
							cv.put("DEVICE_ID",HomeData.sDeviceId);
							cv.put("MANDAL_NAME",mandal.getSelectedItem().toString());
							cv.put("SEASON",season);
							cv.put("D_DATE",df1.format(d));
							cv.put("ADH",adh);
							cv.put("FIN_YEAR",fin_year);

						}

						normal_data.add(cv);
					}
db.close();

					
					if(CheckConnection.isNetworkAvailable(CropRegistration.this))
					{
						Loaddata("InsertVegitableTotalAreaDetails",normal_data);
					}
					else
					{
						for (int i = 0; i < normal_data.size(); i++) {
							
							ContentValues cv=normal_data.get(i);
							db.open();
							db.insertTableDate("CROP_REGISTRATION_DATA",cv);				
							db.close();
						}
						
						AlertDialog(CropRegistration.this, "Normal Area SuccessFully Submitted for "+mandal.getSelectedItem().toString(),"");
						MandalAdapter.remove((String)mandal.getSelectedItem());
						MandalAdapter.notifyDataSetChanged();
						mandal.setSelection(0);
						table_data.removeAllViews();
						submit.setVisibility(8);

						CropData();
						if(mandal.getAdapter().getCount()==1)
						{
							SharedPreferences preferences1 = getSharedPreferences("SEASON",MODE_PRIVATE);
							SharedPreferences.Editor editor1 = preferences1.edit();
							editor1.putString("season",season);					
							editor1.apply();
							db.open();
							ContentValues cv=new ContentValues();
							cv.put("USER_ID",user_id);
							cv.put("STATUS","Y");
							cv.put("SEASON",season);
							cv.put("FIN_YEAR",fin_year);
							db.insertTableDate("LOGIN_CHECK_MASTER", cv);
							//	db.execSQL("UPDATE LOGIN_CHECK_MASTER SET STATUS='Y' WHERE USER_ID='"+Login.user_id+"' and SEASON='"+season+"' ");
							db.close();
							//							SharedPreferences preferences = getSharedPreferences("MY_PREFS_NAME",MODE_PRIVATE);
							//							SharedPreferences.Editor editor = preferences.edit();
							//							editor.putString("F_STATUS","Y");					
							//							editor.apply();
							Intent i=new Intent(CropRegistration.this,CropDataEntry.class);
							i.putExtra("season",season);
							startActivity(i);
							finish();

						}
					}


				}


			}
		});

	}
	public void CropData()
	{
		miCropTypelist.clear();
		CropTypeSpAdapter = new ArrayAdapter<String>(CropRegistration.this,android.R.layout.simple_spinner_item,miCropTypelist);
		db.open();
		miCropTypelist=	db.getSpinnerData("select CROP_NAME from CROP_MASTER");
		db.close();
		CropTypeSpAdapter = new ArrayAdapter<String>(CropRegistration.this,android.R.layout.simple_spinner_item,miCropTypelist);
		CropTypeSpAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		crops.setAdapter(CropTypeSpAdapter);	
	}
	public void LogoutAlert(String msg1,final String diatype)
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Horticulture");
		builder1.setMessage(msg1);
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) {

				if(diatype.equalsIgnoreCase("logout")){
					Intent i=new Intent(CropRegistration.this,Login.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				dialog.cancel();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;

	}
	public  void AlertDialog(Context context,String msg,final String DialogType)
	{
		final Dialog dialog = new Dialog(context);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	
		TextView msgTv1=(TextView)dialog.findViewById(R.id.textView1);
		if(DialogType.equalsIgnoreCase("exist"))
		{
			msgTv1.setText("Error !!!");
		}
		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				if(DialogType.equalsIgnoreCase("exist"))
				{
					MandalAdapter.remove((String)mandal.getSelectedItem());
					MandalAdapter.notifyDataSetChanged();
					mandal.setSelection(0);
					table_data.removeAllViews();
					submit.setVisibility(8);

				}
				dialog.dismiss();				

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.reg_main, menu);
		return true;

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		int id = item.getItemId();
		if(id==R.id.reg_crops)
		{
			boolean a=	CheckConnection.isNetworkAvailable(CropRegistration.this);
			if(a==false)
			{
				Toast toast = null;
				toast=Toast.makeText(CropRegistration.this, "Check Internet Connection",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();

			}
			else
			{
				Loaddata("GetVegitableCropDetails",null);
			}
		}
		if(id==R.id.reg_mandal)
		{
			boolean a=	CheckConnection.isNetworkAvailable(CropRegistration.this);
			if(a==false)
			{
				Toast toast = null;
				toast=Toast.makeText(CropRegistration.this, "Check Internet Connection",Toast.LENGTH_SHORT);
				View view = toast.getView();
				toast.setGravity(Gravity.CENTER, 0, 0);
				view.setBackgroundResource(R.color.red);
				toast.show();
			}
			else
			{
				Loaddata("GetDistrictwiseHQ_MandalDetails",null);
			}
		}
		if(id==android.R.id.home)
		{
			LogoutAlert("Do You Want To Logout", "logout");

			return true;
		}
		return super.onOptionsItemSelected(item);
	}


}
