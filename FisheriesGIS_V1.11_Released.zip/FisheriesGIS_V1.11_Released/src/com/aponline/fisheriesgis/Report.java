package com.aponline.fisheriesgis;



import java.util.ArrayList;




















import com.aponline.fisheriesgis.adapter.Aquacultureadapter;
import com.aponline.fisheriesgis.adapter.Aqualabadapter;
import com.aponline.fisheriesgis.adapter.FishLandAdapter;
import com.aponline.fisheriesgis.adapter.MItankadapter;
import com.aponline.fisheriesgis.adapter.Seedfarmadapter;
import com.aponline.fisheriesgis.database.DBAdapter;

import android.app.ActionBar;
import android.content.res.Resources.NotFoundException;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;

public class Report extends AppCompatActivity implements OnItemSelectedListener{

	ListView Reports_listView;
	HorizontalScrollView maintain;
	ArrayList<String> list;
	android.support.v7.app.ActionBar ab;

	DBAdapter db;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		try {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.report);
			Reports_listView=(ListView) findViewById(R.id.Reports_listView);
			maintain=(HorizontalScrollView) findViewById(R.id.horizontalScrollView_mainTable);
			((Spinner)findViewById(R.id.reporttypespinner)).setOnItemSelectedListener(this);
			db=new DBAdapter(this);
			ab=getSupportActionBar();
			ab.setTitle("Report");

			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 
			ab=getSupportActionBar();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void seedfarmerreport()
	{

		try {

			ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();
			db.open();
			Cursor cursor=db.getTableDataCursor("Select * from SeedFarmCenters_Master where UserId='"+HomeData.userID+"'");


			if(cursor.getCount()>0)
			{
				Reports_listView.setVisibility(View.VISIBLE);
				cursor.moveToFirst();

				//		System.out.println("--"+cursor.getCount());
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
				{

					list=new ArrayList<String>();					
					list.add(cursor.getString(cursor.getColumnIndex("DistrictName")));	
					list.add(cursor.getString(cursor.getColumnIndex("MandalName")));
					list.add(cursor.getString(cursor.getColumnIndex("PanchayatName")));
					list.add(cursor.getString(cursor.getColumnIndex("VillageName")));				
					list.add(cursor.getString(cursor.getColumnIndex("SeedFarmName")));
					list.add(cursor.getString(cursor.getColumnIndex("IsSync")));

					/*	list.add(cursor.getString(cursor.getColumnIndex("Latitude")));
					list.add(cursor.getString(cursor.getColumnIndex("Longitude")));*/

					data.add(list);
				}
				cursor.close();
				db.close();

				Seedfarmadapter seedfarmadapter=new Seedfarmadapter(Report.this,data);
				Reports_listView.setAdapter(seedfarmadapter);
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void aquaculturereport()
	{

		try {


			ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();
			db.open();
			Cursor cursor=db.getTableDataCursor("Select * from AquaCulture_Master where UserId='"+HomeData.userID+"'");

			if(cursor.getCount()>0)
			{
				Reports_listView.setVisibility(View.VISIBLE);
				cursor.moveToFirst();

				//		System.out.println("--"+cursor.getCount());
				for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
				{

					list=new ArrayList<String>();					
					list.add(cursor.getString(cursor.getColumnIndex("DistrictName")));	
					list.add(cursor.getString(cursor.getColumnIndex("MandalName")));
					list.add(cursor.getString(cursor.getColumnIndex("PanchayatName")));
					list.add(cursor.getString(cursor.getColumnIndex("VillageName")));				
					list.add(cursor.getString(cursor.getColumnIndex("AquacultureName")));
					list.add(cursor.getString(cursor.getColumnIndex("IsSync")));

					/*	list.add(cursor.getString(cursor.getColumnIndex("Latitude")));
					list.add(cursor.getString(cursor.getColumnIndex("Longitude")));*/

					data.add(list);
				}
				cursor.close();
				db.close();

				Aquacultureadapter aquaadapter=new Aquacultureadapter(Report.this,data);
				Reports_listView.setAdapter(aquaadapter);
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	public void fishlandreport()
	{

		try {


			ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();
			db.open();
			Cursor cursor=db.getTableDataCursor("Select * from FishLandCenter_Master where UserId='"+HomeData.userID+"'");
			//	System.out.println("--"+cursor.getCount());

			int a=cursor.getCount();
			if(cursor.getCount()>0)
			{
				Reports_listView.setVisibility(View.VISIBLE);
				cursor.moveToFirst();
				//	for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
				do
				{

					list=new ArrayList<String>();


					list.add(cursor.getString(cursor.getColumnIndex("DistrictName")));	
					list.add(cursor.getString(cursor.getColumnIndex("MandalName")));
					list.add(cursor.getString(cursor.getColumnIndex("PanchayatName")));
					list.add(cursor.getString(cursor.getColumnIndex("VillageName")));				
					list.add(cursor.getString(cursor.getColumnIndex("FLC_Name")));
					list.add(cursor.getString(cursor.getColumnIndex("IsSync")));
					/*list.add(cursor.getString(cursor.getColumnIndex("Latitude")));
					list.add(cursor.getString(cursor.getColumnIndex("Longitude")));*/

					data.add(list);
				} while(cursor.moveToNext());
				cursor.close();
				db.close();

				FishLandAdapter fishlandadapter=new FishLandAdapter(Report.this,data);
				Reports_listView.setAdapter(fishlandadapter);
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void mitankreport()
	{

		try {


			ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();
			db.open();
			Cursor cursor=db.getTableDataCursor("Select * from IWBCenters_Master where UserId='"+HomeData.userID+"'");

			if(cursor.getCount()>0)
			{
				Reports_listView.setVisibility(View.VISIBLE);
				cursor.moveToFirst();

				System.out.println("--"+cursor.getCount());
				do
				{

					list=new ArrayList<String>();
					list.add(cursor.getString(cursor.getColumnIndex("DistrictName")));	
					list.add(cursor.getString(cursor.getColumnIndex("MandalName")));
					list.add(cursor.getString(cursor.getColumnIndex("PanchayatName")));
					list.add(cursor.getString(cursor.getColumnIndex("VillageName")));				
					list.add(cursor.getString(cursor.getColumnIndex("MITank_Name")));
					list.add(cursor.getString(cursor.getColumnIndex("IsSync")));
					/*list.add(cursor.getString(cursor.getColumnIndex("Typeofwaterbody")));
					list.add(cursor.getString(cursor.getColumnIndex("Ownership")));
					list.add(cursor.getString(cursor.getColumnIndex("Seasonality")));
					list.add(cursor.getString(cursor.getColumnIndex("Source")));*/

					/*list.add(cursor.getString(cursor.getColumnIndex("Latitude")));
					list.add(cursor.getString(cursor.getColumnIndex("Longitude")));*/




					data.add(list);
				}while(cursor.moveToNext());
				cursor.close();
				db.close();

				MItankadapter mitankadapter=new MItankadapter(Report.this,data);
				Reports_listView.setAdapter(mitankadapter);
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void aqualabreport()
	{

		try {


			ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();
			db.open();
			Cursor cursor=db.getTableDataCursor("Select * from AquaLab_Master where UserId='"+HomeData.userID+"'");

			if(cursor.getCount()>0)
			{
				Reports_listView.setVisibility(View.VISIBLE);
				cursor.moveToFirst();

				System.out.println("--"+cursor.getCount());
				do
				{

					list=new ArrayList<String>();


					list.add(cursor.getString(cursor.getColumnIndex("DistrictName")));	
					list.add(cursor.getString(cursor.getColumnIndex("MandalName")));
					list.add(cursor.getString(cursor.getColumnIndex("PanchayatName")));
					list.add(cursor.getString(cursor.getColumnIndex("VillageName")));				
					list.add(cursor.getString(cursor.getColumnIndex("AquaLab_Name")));
					list.add(cursor.getString(cursor.getColumnIndex("TypeofAqua_Lab")));
					list.add(cursor.getString(cursor.getColumnIndex("Categoryof_Aqualab")));
					list.add(cursor.getString(cursor.getColumnIndex("Categoryof_Analysis")));	
					list.add(cursor.getString(cursor.getColumnIndex("IsSync")));
					/*	list.add(cursor.getString(cursor.getColumnIndex("Latitude")));
					list.add(cursor.getString(cursor.getColumnIndex("Longitude")));*/




					data.add(list);
				}while(cursor.moveToNext());
				cursor.close();
				db.close();

				Aqualabadapter aqualabadapter=new Aqualabadapter(Report.this,data);
				Reports_listView.setAdapter(aqualabadapter);
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) {
		// TODO Auto-generated method stub

		String typename=parent.getSelectedItem().toString().trim();  
		if(typename.equalsIgnoreCase("Seed Farm"))
		{
			Reports_listView.setAdapter(null);
			seedfarmerreport();	
			((LinearLayout)findViewById(R.id.seedFarm_header)).setVisibility(0);
			((LinearLayout)findViewById(R.id.mitankheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aqualabheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aquacultureheader)).setVisibility(View.GONE);

		}

		if(typename.equalsIgnoreCase("Fish Land"))
		{
			Reports_listView.setAdapter(null);
			fishlandreport();
			((LinearLayout)findViewById(R.id.seedFarm_header)).setVisibility(View.VISIBLE);
			((LinearLayout)findViewById(R.id.mitankheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aqualabheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aquacultureheader)).setVisibility(View.GONE);





		}

		if(typename.equalsIgnoreCase("Inland Water Bodies"))
		{
			Reports_listView.setAdapter(null);
			mitankreport();
			((LinearLayout)findViewById(R.id.seedFarm_header)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.mitankheader)).setVisibility(View.VISIBLE);
			((LinearLayout)findViewById(R.id.aqualabheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aquacultureheader)).setVisibility(View.GONE);
		}

		if(typename.equalsIgnoreCase("Aqua lab"))
		{
			((LinearLayout)findViewById(R.id.seedFarm_header)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.mitankheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aqualabheader)).setVisibility(View.VISIBLE);  
			((LinearLayout)findViewById(R.id.aquacultureheader)).setVisibility(View.GONE);

			aqualabreport();

		}

		if(typename.equalsIgnoreCase("Aquaculture"))
		{
			Reports_listView.setAdapter(null);
			aquaculturereport();	
			((LinearLayout)findViewById(R.id.seedFarm_header)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.mitankheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aqualabheader)).setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.aquacultureheader)).setVisibility(View.VISIBLE);

		}
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}




	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}


}
