package com.aponline.fisheriesgis;
import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class Homepage extends AppCompatActivity implements OnClickListener,ServerResponseListener
{
	StringBuilder UserRegXmlDoc;
	ActionBar ab;
	DBAdapter db;
	GPSTracker gps;
	double latitude,longitude;

	public static String UserName,Password;

	ProgressDialog progressDialog;
	Handler mHandler;
	Context context;
	ViewFlipper vf;
	int counter;

	int roleID=5;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{

		super.onCreate(savedInstanceState);
		setContentView(R.layout.homepage);
		vf=(ViewFlipper)findViewById(R.id.view_flipper);
		vf.startFlipping();
		db=new DBAdapter(this);	

		findViewById(R.id.SeedFarm_Tv).setOnClickListener(this);
		findViewById(R.id.FLC_Tv).setOnClickListener(this);
		findViewById(R.id.IWB_Tv).setOnClickListener(this);
		findViewById(R.id.AquaLab_Tv).setOnClickListener(this);
		findViewById(R.id.AquaCulture_Tv).setOnClickListener(this);
		findViewById(R.id.CapativeFish_Tv).setOnClickListener(this);
		findViewById(R.id.AquaCulturePond_Tv).setOnClickListener(this);

		findViewById(R.id.Report_Tv).setOnClickListener(this);
		findViewById(R.id.Download_Tv).setOnClickListener(this);
		findViewById(R.id.Logout_Tv).setOnClickListener(this);
		findViewById(R.id.homepage_help_Btn).setOnClickListener(this);
		findViewById(R.id.Pollution_Tv).setOnClickListener(this);

	}

	Dialog dialog;
	private void showHelp()
	{

		dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation2;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.help);
		dialog.setCancelable(false);
		ImageView cancel =(ImageView)dialog.findViewById(R.id.help_cancel_btn); 
		cancel.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{

				dialog.dismiss();				
				return;
			}
		}); 
		if(!dialog.isShowing())
			dialog.show();
	}

	boolean doubleBackToExitPressedOnce = false;
	@Override
	public void onBackPressed() 
	{
		try 
		{
			if (doubleBackToExitPressedOnce)
			{
				finish();
				return;
			}
			this.doubleBackToExitPressedOnce = true;
			Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

			new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
					doubleBackToExitPressedOnce=false;
				}
			}, 2000);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


	public void downloaddata()
	{
		WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
		request.addParam("VERSIONID",HomeData.sAppVersion);
		request.addParam("USERID", HomeData.userID);
		request.ProccessRequest(Homepage.this, "DOWNLOAD_MASTER_DATA");
	}

	@Override
	public void onResume() 
	{
		super.onResume();

		LoadUserDetails();

	}

	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select UserId,RoleID,DistrictID,MandalID from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				//				HomeData.userRole=cursor.getString(cursor.getColumnIndex("RoleID"));
				//	HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
			}
		}
		else
		{
			AlertDialogsClose("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}

	@Override
	public void Success(String methodName) 
	{
		if(methodName.equalsIgnoreCase("GetFLC"))
		{		
			Intent i= new Intent (Homepage.this,FishLandingCentersPage.class);
			startActivity(i);
		}
		else if(methodName.equalsIgnoreCase("GetSeedFarms"))
		{	
			Intent i= new Intent (Homepage.this,SeedFarmCenterPage.class);
			startActivity(i);
		}
		else if(methodName.equalsIgnoreCase("GetAquaLabs"))
		{
			Intent i= new Intent (Homepage.this,AquaLabPage.class);
			startActivity(i);
		}
		else if(methodName.equalsIgnoreCase("GetMITanks"))
		{
			Intent i= new Intent (Homepage.this,IWBCentersPage.class);
			startActivity(i);

		}
		else if(methodName.equalsIgnoreCase("GetAquaculture"))
		{
			Intent i= new Intent (Homepage.this,AquaCulturePage.class);
			startActivity(i);

		}
		else if(methodName.equalsIgnoreCase("GetCFSRPONDS"))
		{
			Intent i= new Intent (Homepage.this,CapatativeFishPond.class);
			startActivity(i);
		}

		else if(methodName.equalsIgnoreCase("GetAquaCulturePondDetails"))
		{
			Intent i= new Intent (Homepage.this,AquculturePondPage.class);
			startActivity(i);

		}
		if(methodName.equalsIgnoreCase("DOWNLOAD_MASTER_DATA"))
			Dialogs.AlertDialogs(this,"Information!!", "Successfully Downloaded");

	}

	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}

	@Override

	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate()
	{
		startActivity(new Intent(Homepage.this,AppUpdatePage.class));
		finish();
		return;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void AlertDialogsClose(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				finish();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.SeedFarm_Tv:
			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from SeedFarmCenters_Master where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,SeedFarmCenterPage.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetSeedFarms");
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;
		case R.id.FLC_Tv:
			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from FishLandCenter_Master where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,FishLandingCentersPage.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetFLC");
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;
		case R.id.IWB_Tv:
			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from IWBCenters_Master where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,IWBCentersPage.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetMITanks");
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;
		case R.id.AquaLab_Tv:
			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from AquaLab_Master where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,AquaLabPage.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetAquaLabs");
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;
		case R.id.AquaCulture_Tv:
			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from AquaCulture_Master where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,AquaCulturePage.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetAquaculture");
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;
		case R.id.CapativeFish_Tv:
			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from CaptiveFishSeedRearingPonds_Masters where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,CapatativeFishPond.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetCFSRPONDS");
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;

		case R.id.AquaCulturePond_Tv:

			try 
			{
				db.open();
				int count=db.getRowCount("Select count(*) from AquaCulturePondDeatils_Master where UserId='"+HomeData.userID+"'");
				db.close();
				if(count>0)
				{
					Intent i= new Intent (Homepage.this,AquculturePondPage.class);
					startActivity(i);  
				}
				else
				{
					WebserviceCall request=new WebserviceCall(Homepage.this,"GET");
					request.addParam("VERSIONID",HomeData.sAppVersion);
					request.addParam("USERID", HomeData.userID);
					request.ProccessRequest(Homepage.this, "GetAquaCulturePondDetails");//GetAquaCultureFarmDetails
				}
			} 
			catch (Exception e) 
			{
				AlertDialogs("Information!!", " Please Try Again");
				e.printStackTrace();
			}
			break;
		case R.id.Pollution_Tv:
			Intent i1= new Intent (Homepage.this,PollutionAquaPond.class);
			startActivity(i1); 
			break;
		case R.id.Report_Tv:
			Intent i= new Intent (Homepage.this,Report.class);
			startActivity(i);  
			break;	
		case R.id.Download_Tv:
			downloaddata();
			break;
		case R.id.Logout_Tv:
			HomeData.isLogOut(Homepage.this);
			startActivity(new Intent(Homepage.this,Loginpage.class));
			finish();
			break;
		case R.id.homepage_help_Btn:
			showHelp();
			break;
		default:
			break;
		}
	}

}
