package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.JSONParser;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Base64OutputStream;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class AquculturePondPage extends AppCompatActivity implements OnItemSelectedListener, OnClickListener,ServerResponseListener {

	ActionBar ab;
	GPSTracker gps;
	DBAdapter db;

	String strBaseimage="";
	double latitude,longitude;
	String panchayatID="",villageID="",farmername="",adharno="",appno="",pondno="";
	String roleID;
	String distrID,districtName; 
	String mandalID,mandalName;
	int PHOTO_CAPTURE=100;
	LinearLayout childlayout,period_mnth_ll; 
	EditText Enrolment_no;

	String kmlFileName;
	String kmlFileBase64data;
	String selectedFilePath;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		try 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.aquaculture_pond);
			ab=getSupportActionBar();
			ab.setTitle("Aquaculture Pond");
			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 

			db=new DBAdapter(this);	
			Button add;
			childlayout=(LinearLayout) findViewById(R.id.pond_detail_child_layout);
			((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setOnClickListener(this);

			((ImageView)findViewById(R.id.Kml_file_imageview)).setOnClickListener(this);

			add=(Button) findViewById(R.id.add_button);

			add.setOnClickListener(this);
			findViewById(R.id.submit_btn).setOnClickListener(this);
			gps=new GPSTracker(AquculturePondPage.this);
			LoadUserDetails();
			Log.d("User ID", HomeData.userID);

			((Spinner)findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.farmername_sp)).setOnItemSelectedListener(this);

			((Spinner)findViewById(R.id.Pond_No_sp)).setOnItemSelectedListener(this);


			((Spinner)findViewById(R.id.Category_of_Farm_sp)).setOnItemSelectedListener(this);

			((Spinner)findViewById(R.id.status_of_pond_sp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.enrolled_MPEDA_sp)).setOnItemSelectedListener(this);

			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from AquaCulturePondDeatils_Master where UserId ='"+HomeData.userID+"' ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(false);
			}
			else
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);

			}

		} 
		catch (Exception e) 
		{
			CommonFunctions.writeLog("AquaculturePondPage","oncreate",e.getMessage());
			e.printStackTrace();
			AlertDialogsForceBack("Information!!","Please Re-Login once/Try Again!!");
		}

	}
	public void loadSpinnerData(String query, Spinner spinner) 
	{

		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("AquaculturePond", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}

	}

	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));

			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}

	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		
				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);
				ImageView imageView= (ImageView)findViewById(R.id.aqua_lab_center_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}
			catch (Exception e)
			{
				CommonFunctions.writeLog("AquaculturePond", "onCaptureImageResult", e.getMessage());
				e.printStackTrace();
			}

		}
		else if(requestCode==10)
		{
			((ImageView)findViewById(R.id.Kml_file_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.kml_icon_green));

			if(data == null)
			{
				//no data present
				return;
			}

			Uri selectedFileUri = null;
			//			if(Build.VERSION.SDK_INT>=24)
			//			{
			//				if (data.hasExtra("uri")) {
			//					selectedFileUri = (Uri)data.getParcelableExtra("uri");
			//				}
			//			}
			//			else
			selectedFileUri = data.getData();

			if(selectedFileUri!=null)
			{
				if(Build.VERSION.SDK_INT>=24)
				{
					selectedFilePath=getRealPathFromURI(selectedFileUri);
				}
				else
				{
					selectedFilePath = FilePath.getPath(this,selectedFileUri);
				}

				if(selectedFilePath.endsWith(".kml"))
				{
					kmlFileName=new File(selectedFilePath).getName();
					kmlFileBase64data= getStringFile(selectedFilePath);   
					((TextView)findViewById(R.id.Kml_fileName_Tv)).setText(kmlFileName);
				}
				else
				{
					AlertDialogs("Information!!", "Please select .KML file only");
					((TextView)findViewById(R.id.Kml_fileName_Tv)).setText("");
				}
			}

		}
	}
	public String getRealPathFromURI(Uri contentUri) {
		  Cursor cursor = null;
		  try { 
		    String[] proj = { MediaStore.Images.Media.DATA };
		    cursor = getContentResolver().query(contentUri,  proj, null, null, null);
		    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
		    cursor.moveToFirst();
		    return cursor.getString(column_index);
		  } finally {
		    if (cursor != null) {
		      cursor.close();
		    }
		  }
		}

	public String getStringFile(String path) 
	{
		InputStream inputStream = null; 
		String encodedFile= "", lastVal;
		try 
		{
			inputStream = new FileInputStream(path);

			byte[] buffer = new byte[10240];//specify the size to allow
			int bytesRead;
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			Base64OutputStream output64 = new Base64OutputStream(output, Base64.DEFAULT);

			while ((bytesRead = inputStream.read(buffer)) != -1) 
			{
				output64.write(buffer, 0, bytesRead);
			}


			output64.close();


			encodedFile =  output.toString();

		} 
		catch (FileNotFoundException e1 ) 
		{
			e1.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		lastVal = encodedFile;
		return lastVal;
	}
	private void showFileChooser()
	{
		Intent intent = new Intent();
		//sets the select file to all types of files
		intent.setType("application/*");
		//allows to select data and return it
		intent.setAction(Intent.ACTION_GET_CONTENT);
		//starts new activity to select file and return data
		startActivityForResult(Intent.createChooser(intent,"Choose File to Upload.."),10);
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void Success(String response)
	{
		try
		{
			ContentValues seedfarmlist = new ContentValues();
			seedfarmlist.put("Latitude",""+latitude);
			seedfarmlist.put("Longitude",""+longitude);	
			seedfarmlist.put("IsSync","Y");	
			seedfarmlist.put("Image",strBaseimage);	
			seedfarmlist.put("KmlFileName",kmlFileName);	
			seedfarmlist.put("KmlFileData",kmlFileBase64data);	


			//			seedfarmlist.put("PondNo",((EditText)findViewById(R.id.systempond_no)).getText().toString());
			//			seedfarmlist.put("NameoftheFarmer",farmername);
			db.open();

			db.updateTableData("AquaCulturePondDeatils_Master",seedfarmlist,"AQCID='"+appno+"' and PondNo='"+pondno+"'");
			db.close();

			if(!roleID.equalsIgnoreCase("3"))
				((Spinner)findViewById(R.id.mandalSp)).setSelection(0);


			((Spinner)findViewById(R.id.Ownership_Status_sp)).setSelection(0);
			((Spinner)findViewById(R.id.enrolled_MPEDA_sp)).setSelection(0);

			((Spinner)findViewById(R.id.type_of_pond_sp)).setSelection(0);
			((Spinner)findViewById(R.id.registered_with_sp)).setSelection(0);
			((Spinner)findViewById(R.id.status_of_pond_sp)).setSelection(0);
			((Spinner)findViewById(R.id.assistance_sp)).setSelection(0);


			((CheckBox)findViewById(R.id.SourceOfWater_Canal)).setChecked(false);
			((CheckBox)findViewById(R.id.SourceOfWater_Drain)).setChecked(false);
			((CheckBox)findViewById(R.id.SourceOfWater_Rivers)).setChecked(false);
			((CheckBox)findViewById(R.id.SourceOfWater_Creeks)).setChecked(false);
			((CheckBox)findViewById(R.id.SourceOfWater_others)).setChecked(false);


			((EditText)findViewById(R.id.survey_no)).setText("");
			((EditText)findViewById(R.id.Enrolment_no)).setText("");	
			((EditText)findViewById(R.id.reg_no)).setText("");

			((EditText)findViewById(R.id.systempond_no)).setText("");

			((EditText)findViewById(R.id.total_extent_area_in_ha)).setText("");
			((EditText)findViewById(R.id.effectivewaterarea_inha)).setText("");
			((EditText)findViewById(R.id.systempond_no)).setText("");
			((EditText)findViewById(R.id.period_defunct_mnth)).setText("");

			((TextView)findViewById(R.id.Kml_fileName_Tv)).setText("");


			//			((EditText)findViewById(R.id.KMLFIleName)).setText("");
			//		
			//			((EditText)findViewById(R.id.KMLFile)).setText("");
			//			
			//			
			//			

			((EditText)findViewById(R.id.no_crpos_et)).setText("");

			((TextView)findViewById(R.id.latitude)).setText("");
			((TextView)findViewById(R.id.longitude)).setText("");
			((ImageView)findViewById(R.id.Kml_file_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.kml_icon));
			((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.aquaculture));
			//	childlayout.setVisibility(View.GONE);
			strBaseimage="";

			kmlFileBase64data="";
			kmlFileName="";

			Dialogs.AlertDialogs(this,"Information!!", JSONParser.msg);
		}
		catch (Exception e)
		{
			CommonFunctions.writeLog("AquaculturePondPage", "Success", e.getMessage());
			Dialogs.AlertDialogs(this,"Information!!", "Upload Failed, Please Try Again");
			e.printStackTrace();
			return;
		}

	}

	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}

	@Override
	public void NetworkNotAvail() 
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}

	@Override
	public void AppUpdate()
	{
		startActivity(new Intent(AquculturePondPage.this,AppUpdatePage.class));
		finish();
		return;

	}

	@Override
	public void onClick(View v)
	{
		switch (v.getId()) 
		{
		case R.id.Kml_file_imageview:
			//			Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
			//			intent.addCategory(Intent.CATEGORY_OPENABLE);
			//			intent.setType("*/*");
			//			try
			//			{
			//				startActivityForResult(intent, 10);
			//			} 
			//			catch (ActivityNotFoundException e){
			//				Toast.makeText(this, "There are no file explorer clients installed.", Toast.LENGTH_SHORT).show();
			//			}
			//UploadFile();
			showFileChooser();
			break;

		case R.id.aqua_lab_center_imageview:
			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();

				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent1, PHOTO_CAPTURE);
			}

			break;

		case R.id.submit_btn:
			validatedata();
			break;

			/*case R.id.registrationdate:

			showdate(((TextView)findViewById(R.id.registrationdate)));
			break;
			 */
		case R.id.add_button:

			if(childlayout.getVisibility()==View.GONE)
			{
				childlayout.setVisibility(View.VISIBLE);
				((ImageView)findViewById(R.id.Kml_file_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.kml_icon));

				db.open();

				int count=db.getRowCount("select count(*) from AquaCulturePondDeatils_Master where NameoftheFarmer='"+farmername+"' and IsSync='Y'");

				db.close();
				((EditText)findViewById(R.id.systempond_no)).setText(""+(count+1));
				((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setImageBitmap(null);
				((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setBackgroundResource(R.drawable.aquaculture);
			}
			else
			{
				childlayout.setVisibility(View.GONE);
			}

			break;
		default:
			break;
		}
	}


	private void validatedata()
	{


		/*if(((Spinner)findViewById(R.id.districtSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		{
			AlertDialogs("Information!!", " Please Select District");
			((Spinner)findViewById(R.id.districtSp)).requestFocus();
			return;
		}

		if(((Spinner)findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
		{
			AlertDialogs("Information!!", " Please Select Mandal");
			((Spinner)findViewById(R.id.mandalSp)).requestFocus();
			return;
		}*/

		try 
		{
			if(((Spinner)findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner)findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}


			if(((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner)findViewById(R.id.village_spinner)).requestFocus();
				return;
			}

			if(((Spinner)findViewById(R.id.farmername_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Farmer Name");
				((Spinner)findViewById(R.id.farmername_sp)).requestFocus();
				return;
			}


			//			if(((Spinner)findViewById(R.id.typeoffarm_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			//			{
			//				AlertDialogs("Information!!", " Please Select Type of Farm");
			//				((Spinner)findViewById(R.id.typeoffarm_sp)).requestFocus();
			//				return;
			//			}
			//
			//			if(((EditText)findViewById(R.id.landdetail)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.landdetail)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.landdetail)).requestFocus();
			//				return;
			//			}
			//
			//			if(((EditText)findViewById(R.id.adharno_et)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.adharno_et)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.adharno_et)).requestFocus();
			//				return;
			//			}
			//
			//			adharno=((EditText)findViewById(R.id.adharno_et)).getText().toString();
			//
			//
			//			if(Character.isDigit(adharno.charAt(0)))
			//			{
			//				if(!CommonFunctions.validateAadharNumber(adharno))
			//				{
			//					//AlertDialogs("Information!!", " Please Enter Valid Aadhaar Number");
			//					((EditText)findViewById(R.id.adharno_et)).requestFocus();
			//					((EditText)findViewById(R.id.adharno_et)).setError(" Please Enter Valid Aadhaar Number");
			//					return;
			//				}
			//			}
			//
			//			if(((EditText)findViewById(R.id.mobileno_et)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.mobileno_et)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.mobileno_et)).requestFocus();
			//				return;
			//			}
			//
			//			if(((EditText)findViewById(R.id.farm_name)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.farm_name)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.farm_name)).requestFocus();
			//				return;
			//			}
			//
			//			if(((Spinner)findViewById(R.id.farmstatus)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			//			{
			//				AlertDialogs("Information!!", " Please Select Farm Status");
			//				((Spinner)findViewById(R.id.farmstatus)).requestFocus();
			//				return;
			//			}
			//
			//			if(((Spinner)findViewById(R.id.registeredwith)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			//			{
			//				AlertDialogs("Information!!", " Please Select registered with");
			//				((Spinner)findViewById(R.id.registeredwith)).requestFocus();
			//				return;
			//			}
			//
			//			if(((EditText)findViewById(R.id.registrationno_et)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.registrationno_et)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.registrationno_et)).requestFocus();
			//				return;
			//			}
			//
			//			if(((EditText)findViewById(R.id.totalwater_txt)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.totalwater_txt)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.totalwater_txt)).requestFocus();
			//				return;
			//			}
			//
			//
			//			if(((EditText)findViewById(R.id.effectviewater_txt)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.effectviewater_txt)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.effectviewater_txt)).requestFocus();
			//				return;
			//			}
			//
			//			if(((CheckBox)findViewById(R.id.fish)).isChecked()==false&&((CheckBox)findViewById(R.id.prwan)).isChecked()==false&&((CheckBox)findViewById(R.id.bwfish)).isChecked()==false&&((CheckBox)findViewById(R.id.bwshrimp)).isChecked()==false&&((CheckBox)findViewById(R.id.crab)).isChecked()==false&&((CheckBox)findViewById(R.id.other)).isChecked()==false)
			//			{
			//
			//
			//				AlertDialogs("Information!!", " Please Select Type of Culture");
			//
			//				return;
			//			}
			//
			//			if(((CheckBox)findViewById(R.id.pattaland)).isChecked()==false&&((CheckBox)findViewById(R.id.dkt)).isChecked()==false&&((CheckBox)findViewById(R.id.lease)).isChecked()==false&&((CheckBox)findViewById(R.id.others)).isChecked()==false)
			//			{
			//
			//				AlertDialogs("Information!!", " Please Select Type of Land");
			//
			//				return;
			//			}
			//
			//			if(((EditText)findViewById(R.id.surveyno_et)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.surveyno_et)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.surveyno_et)).requestFocus();
			//				return;
			//			}


			String toatalExtent=((EditText)findViewById(R.id.total_extent_area_in_ha)).getText().toString();

			if(toatalExtent.equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.total_extent_area_in_ha)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.total_extent_area_in_ha)).requestFocus();
				return;
			}

			String effictiveWaterSpreadArea=((EditText)findViewById(R.id.effectivewaterarea_inha)).getText().toString();
			if(effictiveWaterSpreadArea.equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.effectivewaterarea_inha)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.effectivewaterarea_inha)).requestFocus();

				return;
			}

			if(Float.parseFloat(effictiveWaterSpreadArea) > Float.parseFloat(toatalExtent))
			{

				((EditText)findViewById(R.id.effectivewaterarea_inha)).setError("Enter Valid Area");
				((EditText)findViewById(R.id.effectivewaterarea_inha)).requestFocus();
				return;
			}



			//			if(((EditText)findViewById(R.id.no_of_ponds)).getText().toString().equalsIgnoreCase(""))
			//			{
			//				((EditText)findViewById(R.id.no_of_ponds)).setError("field cannot left Empty");
			//				((EditText)findViewById(R.id.no_of_ponds)).requestFocus();
			//				return;
			//			}
			//			 


			if(strBaseimage.equalsIgnoreCase(""))
			{
				AlertDialogs("Information!!", " Please Capture  Seed Farm Center Photo");
				return;
			}
			if(latitude== 0 || longitude== 0)
			{
				AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
				return;

			}


			String DefunctPeriod;
			if(((Spinner)findViewById(R.id.status_of_pond_sp)).getSelectedItemPosition()==0)
			{
				AlertDialogs("Information!!", "Please select Status of Pond");
				return;
			}
			else if(((Spinner)findViewById(R.id.status_of_pond_sp)).getSelectedItemPosition()==2)
			{
				DefunctPeriod=((EditText)findViewById(R.id.period_defunct_mnth)).getText().toString();
				if(DefunctPeriod==null||DefunctPeriod.equalsIgnoreCase(""))
				{
					AlertDialogs("Information!!", "Please enter Defunct in Months");
					return;
				}
			}
			else
			{
				DefunctPeriod="0";
			}


			String IsEnroledID,EnrolmentNo;
			if(((Spinner)findViewById(R.id.enrolled_MPEDA_sp)).getSelectedItemPosition()==0)
			{
				AlertDialogs("Information!!", "Please select enrollment MPEDA ");
				return;
			}
			else if(((Spinner)findViewById(R.id.enrolled_MPEDA_sp)).getSelectedItemPosition()==1)
			{
				IsEnroledID="1";
				EnrolmentNo=((EditText)findViewById(R.id.Enrolment_no)).getText().toString();
				if(EnrolmentNo==null||EnrolmentNo.equalsIgnoreCase(""))
				{
					AlertDialogs("Information!!", "Please enter enrollment No");
					return;
				}
			}
			else 
			{
				IsEnroledID="2";
				EnrolmentNo="";
			}


			if(((EditText)findViewById(R.id.no_crpos_et)).getText().toString()==null||((EditText)findViewById(R.id.no_crpos_et)).getText().toString().equalsIgnoreCase(""))
			{
				AlertDialogs("Information!!", "Please enter Defunct in Months");
				return;
			}

			StringBuilder SourceOfWater= new StringBuilder();
			if(((CheckBox)findViewById(R.id.SourceOfWater_Canal)).isChecked()==true)
			{
				SourceOfWater.append("1");
			}
			if(((CheckBox)findViewById(R.id.SourceOfWater_Drain)).isChecked()==true)
			{
				if(SourceOfWater.toString().equalsIgnoreCase(""))
					SourceOfWater.append("2");
				else
					SourceOfWater.append(",2");
			}
			if(((CheckBox)findViewById(R.id.SourceOfWater_Rivers)).isChecked()==true)
			{
				if(SourceOfWater.toString().equalsIgnoreCase(""))
					SourceOfWater.append("3");
				else
					SourceOfWater.append(",3");
			}
			if(((CheckBox)findViewById(R.id.SourceOfWater_Creeks)).isChecked()==true)
			{
				if(SourceOfWater.toString().equalsIgnoreCase(""))
					SourceOfWater.append("4");
				else
					SourceOfWater.append(",4");
			}
			if(((CheckBox)findViewById(R.id.SourceOfWater_others)).isChecked()==true)
			{
				if(SourceOfWater.toString().equalsIgnoreCase(""))
					SourceOfWater.append("5");
				else
					SourceOfWater.append(",5");
			}


			if(SourceOfWater.toString().equalsIgnoreCase(""))
			{
				AlertDialogs("INformation!!", "Please select Source of Water");
				return;
			}

			JSONObject seedData=new JSONObject();			
			seedData.put("AppNo",appno);
			seedData.put("PondNO",((Spinner)findViewById(R.id.Pond_No_sp)).getSelectedItemPosition());	
			seedData.put("PondTypeID",((Spinner)findViewById(R.id.type_of_pond_sp)).getSelectedItemPosition());	
			seedData.put("SurveyNo",((EditText)findViewById(R.id.survey_no)).getText().toString());
			seedData.put("RegisteredWithID",((Spinner)findViewById(R.id.registered_with_sp)).getSelectedItemPosition());
			seedData.put("RegNo",((EditText)findViewById(R.id.reg_no)).getText().toString());
			seedData.put("StatusOfPondID",((Spinner)findViewById(R.id.status_of_pond_sp)).getSelectedItemPosition());	
			seedData.put("NoofCrops",((EditText)findViewById(R.id.no_crpos_et)).getText().toString());
			seedData.put("DefunctPeriod",DefunctPeriod);
			seedData.put("TotalExtentArea",((EditText)findViewById(R.id.total_extent_area_in_ha)).getText().toString());
			seedData.put("EffectiveWaterArea",((EditText)findViewById(R.id.effectivewaterarea_inha)).getText().toString());		
			seedData.put("AssistanceReqID",((Spinner)findViewById(R.id.assistance_sp)).getSelectedItemPosition());
			seedData.put("OwnerShipID",((Spinner)findViewById(R.id.Ownership_Status_sp)).getSelectedItemPosition());
			seedData.put("IsEnrolledID",IsEnroledID);
			seedData.put("EnrolmentNo",EnrolmentNo);		
			seedData.put("SourceofWarterID",SourceOfWater.toString());
			seedData.put("Longitude", longitude);
			seedData.put("Lattitude", latitude);
			seedData.put("BASE64PHOTO",strBaseimage);
			seedData.put("KMLFIleName", kmlFileName);
			seedData.put("KMLFile", kmlFileBase64data); 
			seedData.put("UserID", HomeData.userID);
			seedData.put("DeviceID", HomeData.sDeviceId);					

			JSONObject data=new JSONObject();
			data.put("Version", HomeData.sAppVersion);
			data.put("UserID", HomeData.userID);				
			data.put("AquaculturePonds",seedData);
			WebserviceCall request=new WebserviceCall(AquculturePondPage.this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "AQUA_ADDPONDDETAILS");
			return;

		} 
		catch (JSONException e)
		{
			CommonFunctions.writeLog("Aquculture_Pond", "AQUACULTUREGEOTAGGING", e.getMessage());

			e.printStackTrace();
		}

	}


	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}


	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) 
	{

		try 
		{
			switch (parent.getId()) 
			{

			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(AquculturePondPage.this, "select distinct MandalName from AquaCulturePondDeatils_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);

					}
					else
					{
						loadSpinnerData("select distinct MandalName from AquaCulturePondDeatils_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;

			case R.id.mandalSp:

				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);

				String mandalname=parent.getSelectedItem().toString().trim();  
				if(!mandalname.equalsIgnoreCase("--Select--"))
				{
					if(!roleID.equalsIgnoreCase("3"))
					{
						db.open();
						mandalID=db.getSingleValue("select MandalID from AquaCulturePondDeatils_Master where MandalName='"+mandalname +"' and DistrictID='"+distrID+"'");															
						db.close();
					}				
					loadSpinnerData("select distinct PanchayatName from AquaCulturePondDeatils_Master where DistrictID='"+distrID+"'and MandalID='"+mandalID+"' order by PanchayatName ",((Spinner)findViewById(R.id.panchayat_spinner)));
				}
				break;
			case R.id.panchayat_spinner:

				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);

				String panchayatname=parent.getSelectedItem().toString().trim(); 
				if(!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID=db.getSingleValue("select PanchayatID from AquaCulturePondDeatils_Master where PanchayatName='"+panchayatname+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"'");
					db.close();
					loadSpinnerData("select distinct VillageName from AquaCulturePondDeatils_Master where PanchayatID='"+panchayatID +"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'",((Spinner)findViewById(R.id.village_spinner)));
				}
				break;

			case R.id.village_spinner:
				((Spinner)findViewById(R.id.Category_of_Farm_sp)).setSelection(0);

				((Spinner)findViewById(R.id.status_of_pond_sp)).setSelection(0);
				String villagename=parent.getSelectedItem().toString();
				if(!villagename.equalsIgnoreCase("--Select--"))
				{
					db.open();
					villageID=db.getSingleValue("select VillageID from AquaCulturePondDeatils_Master where VillageName='"+villagename+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");
					db.close();
					//loadSpinnerData("select FarmerName from AquaCulturePondDeatils_Master where MandalID='"+mandalID +"' and PanchayatID='"+panchayatID+"'and VillageID='"+villageID+"'and DistrictID='"+distrID+"' order by FarmerName ",((Spinner)findViewById(R.id.farmername_sp)));
				}
				break;



			case R.id.Category_of_Farm_sp:

				((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
				String category=parent.getSelectedItem().toString();
				if(!category.equalsIgnoreCase("--Select--"))
				{
					if(category.equalsIgnoreCase("Individual"))
					{
						((TextView)findViewById(R.id.farmer_Firm_selection_Tv)).setText("Farmer Name");
						((TextView)findViewById(R.id.farmer_FatherName_Tv)).setText("Father/Husband Name");
						((TextView)findViewById(R.id.FarmerAddress_Tv)).setText("Farmer Address");


						findViewById(R.id.farmName_ll).setVisibility(0);
						findViewById(R.id.AddhaarNo_ll).setVisibility(0);
						findViewById(R.id.MobileNo_ll).setVisibility(0);
					}
					else
					{
						((TextView)findViewById(R.id.farmer_Firm_selection_Tv)).setText("Firm Name");
						((TextView)findViewById(R.id.farmer_FatherName_Tv)).setText("Auth. Contact Person");
						((TextView)findViewById(R.id.FarmerAddress_Tv)).setText("Firm Address");

						findViewById(R.id.farmName_ll).setVisibility(8);
						findViewById(R.id.AddhaarNo_ll).setVisibility(8);
						findViewById(R.id.MobileNo_ll).setVisibility(8);

					}


					String village=((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString();
					loadSpinnerData("select NameoftheFarmer from AquaCulturePondDeatils_Master where MandalID='"+mandalID +"' and PanchayatID='"+panchayatID+"'and VillageID='"+villageID+"'and DistrictID='"+distrID+"' order by NameoftheFarmer ",((Spinner)findViewById(R.id.farmername_sp)));

				}
				break;


			case R.id.status_of_pond_sp:

				//((Spinner)findViewById(R.id.status_of_pond_sp)).setSelection(0);

				String status=parent.getSelectedItem().toString();
				if(!status.equalsIgnoreCase("--Select--"))
				{
					if(status.equalsIgnoreCase("Defunct"))
					{
						findViewById(R.id.period_mnth_ll).setVisibility(0);
					}
					else 
					{
						findViewById(R.id.period_mnth_ll).setVisibility(8);

					}

				}

				break;


			case R.id.farmername_sp:

				farmername=parent.getSelectedItem().toString();

				if(!farmername.equalsIgnoreCase("--Select--"))
				{
					String categoryForm=((Spinner)findViewById(R.id.Category_of_Farm_sp)).getSelectedItem().toString();
					//					if(categoryForm.equalsIgnoreCase("Individual"))
					//					{
					db.open();
					Cursor cursor=db.getTableDataCursor("select distinct(AQCID),FatherOrHusbandName,AquaFarmName,AadharNumber,MobileNO,FarmerAddress,FarmAddress,NoOfPonds,FarmTypeID from AquaCulturePondDeatils_Master"
							+ " where  trim(VillageID)='"+villageID+"' and PanchayatID='"+panchayatID+"' "
							+ "and trim(MandalID)='"+mandalID+"' and DistrictID='"+distrID+"' and trim(NameoftheFarmer)='"+farmername+"'");
					if(cursor.getCount()>0)
					{
						cursor.moveToFirst();
						appno=cursor.getString(cursor.getColumnIndex("AQCID"));
						((TextView)findViewById(R.id.father_name_txt)).setText(cursor.getString(cursor.getColumnIndex("FatherorHusbandName")));
						((EditText)findViewById(R.id.farmname_edt)).setText(cursor.getString(cursor.getColumnIndex("AquaFarmName")));
						((EditText)findViewById(R.id.adhar_no_edt)).setText(cursor.getString(cursor.getColumnIndex("AadharNumber")));
						((EditText)findViewById(R.id.mobile_no_edt)).setText(cursor.getString(cursor.getColumnIndex("MobileNO")));
						((TextView)findViewById(R.id.farm_address_txt)).setText(cursor.getString(cursor.getColumnIndex("FarmerAddress")));
						((TextView)findViewById(R.id.no_of_ponds)).setText(cursor.getString(cursor.getColumnIndex("NoOfPonds")));


						String farmTypeID= cursor.getString(cursor.getColumnIndex("FarmTypeID"));
						if(farmTypeID==null||farmTypeID.equalsIgnoreCase("")||farmTypeID.equalsIgnoreCase("null"))
							farmTypeID="0";
						((Spinner)findViewById(R.id.farm_type)).setSelection(Integer.parseInt(farmTypeID));


					}
					else
					{
						cursor.close();
						db.close();
						AlertDialogs("Information!!", "Data Not Available");
						return;
					}
					cursor.close();
					db.close();
					//					}
					//					else
					//					{
					//
					//						db.open();
					//						Cursor cursor=db.getTableDataCursor("select distinct(AQCID),FatherOrHusbandName,AquaFarmName,AadharNumber,MobileNO,FarmerAddress,FarmAddress,NoOfPonds,FarmTypeID from AquaCulturePondDeatils_Master"
					//								+ " where  trim(VillageID)='"+villageID+"' and PanchayatID='"+panchayatID+"' "
					//								+ "and trim(MandalID)='"+mandalID+"' and DistrictID='"+distrID+"' and trim(NameoftheFarmer)='"+farmername+"'");
					//						if(cursor.getCount()>0&&cursor.moveToFirst())
					//						{
					//							((TextView)findViewById(R.id.father_name_txt)).setText(cursor.getString(cursor.getColumnIndex("FatherOrHusbandName")));
					//							((EditText)findViewById(R.id.farmname_edt)).setText(cursor.getString(cursor.getColumnIndex("AquaFarmName")));
					//							((EditText)findViewById(R.id.adhar_no_edt)).setText(cursor.getString(cursor.getColumnIndex("AadharNumber")));
					//							((EditText)findViewById(R.id.mobile_no_edt)).setText(cursor.getString(cursor.getColumnIndex("MobileNO")));
					//							((TextView)findViewById(R.id.farm_address_txt)).setText(cursor.getString(cursor.getColumnIndex("FarmAddress")));
					//							((TextView)findViewById(R.id.no_of_ponds)).setText(cursor.getString(cursor.getColumnIndex("NoOfPonds")));
					//							appno=cursor.getString(cursor.getColumnIndex("AQCID"));
					//
					//							String farmTypeID= cursor.getString(cursor.getColumnIndex("FarmTypeID"));
					//							if(farmTypeID==null||farmTypeID.equalsIgnoreCase("")||farmTypeID.equalsIgnoreCase("null"))
					//								farmTypeID="0";
					//							((Spinner)findViewById(R.id.farm_type)).setSelection(Integer.parseInt(farmTypeID));
					//
					//						}
					//						else
					//						{
					//							cursor.close();
					//							db.close();
					//							AlertDialogs("Information!!", "Data Not Available");
					//							return;
					//						}
					//						cursor.close();
					//						db.close();
					//					}


					loadSpinnerData("select distinct(PondNo) from AquaCulturePondDeatils_Master"
							+ " where  trim(VillageID)='"+villageID+"' and PanchayatID='"+panchayatID+"' "
							+ "and trim(MandalID)='"+mandalID+"' and DistrictID='"+distrID+"' and trim(NameoftheFarmer)='"+farmername+"'",((Spinner)findViewById(R.id.Pond_No_sp)));

				}
				break;

			case R.id.enrolled_MPEDA_sp:
				String statusMPEDA=parent.getSelectedItem().toString();
				if(!statusMPEDA.equalsIgnoreCase("--Select--"))
				{
					if(statusMPEDA.equalsIgnoreCase("Yes"))
					{
						findViewById(R.id.Enrolment_no_ll).setVisibility(0);
					}
					else 
					{
						findViewById(R.id.Enrolment_no_ll).setVisibility(8);
					}
				}
				break;
			case R.id.Pond_No_sp:
				pondno=parent.getSelectedItem().toString();
				if(!pondno.equalsIgnoreCase("--Select--"))
				{
					//childlayout.setVisibility(View.VISIBLE);
					db.open();
					Cursor cursor=db.getTableDataCursor("select * from AquaCulturePondDeatils_Master where AQCID='"+appno+"' and PondNo='"+pondno+"'");
					if(cursor.getCount()>0&&cursor.moveToFirst())
					{


						try
						{
							String sourceOfWater=cursor.getString(cursor.getColumnIndex("WaterSourceId"));

							if(sourceOfWater!=null&&!sourceOfWater.contains(","))
							{
								if(sourceOfWater.equalsIgnoreCase("1"))
								{
									((CheckBox)findViewById(R.id.SourceOfWater_Canal)).setChecked(true);
								}
								else if(sourceOfWater.equalsIgnoreCase("2"))
								{
									((CheckBox)findViewById(R.id.SourceOfWater_Drain)).setChecked(true);
								}
								else if(sourceOfWater.equalsIgnoreCase("3"))
								{
									((CheckBox)findViewById(R.id.SourceOfWater_Rivers)).setChecked(true);
								}
								else if(sourceOfWater.equalsIgnoreCase("4"))
								{
									((CheckBox)findViewById(R.id.SourceOfWater_Creeks)).setChecked(true);
								}
								else if(sourceOfWater.equalsIgnoreCase("5"))
								{
									((CheckBox)findViewById(R.id.SourceOfWater_others)).setChecked(true);
								}
							}
							else if(sourceOfWater!=null&&sourceOfWater.contains(","))
							{
								String[] data=sourceOfWater.split(",");
								for(String sourceOfWaterID:data)
								{
									if(sourceOfWaterID.equalsIgnoreCase("1"))
									{
										((CheckBox)findViewById(R.id.SourceOfWater_Canal)).setChecked(true);
									}
									else if(sourceOfWaterID.equalsIgnoreCase("2"))
									{
										((CheckBox)findViewById(R.id.SourceOfWater_Drain)).setChecked(true);
									}
									else if(sourceOfWaterID.equalsIgnoreCase("3"))
									{
										((CheckBox)findViewById(R.id.SourceOfWater_Rivers)).setChecked(true);
									}
									else if(sourceOfWaterID.equalsIgnoreCase("4"))
									{
										((CheckBox)findViewById(R.id.SourceOfWater_Creeks)).setChecked(true);
									}
									else if(sourceOfWaterID.equalsIgnoreCase("5"))
									{
										((CheckBox)findViewById(R.id.SourceOfWater_others)).setChecked(true);
									}
								}
							}
							String OwnerShipID=cursor.getString(cursor.getColumnIndex("OwnerShipID"));
							if(OwnerShipID==null||OwnerShipID.equalsIgnoreCase(""))
								OwnerShipID="0";
							((Spinner)findViewById(R.id.Ownership_Status_sp)).setSelection(Integer.parseInt(OwnerShipID));
							String EnrolledMPEDA=cursor.getString(cursor.getColumnIndex("EnrolledMPEDA"));
							if(EnrolledMPEDA==null||EnrolledMPEDA.equalsIgnoreCase(""))
								EnrolledMPEDA="0";
							((Spinner)findViewById(R.id.enrolled_MPEDA_sp)).setSelection(Integer.parseInt(EnrolledMPEDA));
							String PondTypeID=cursor.getString(cursor.getColumnIndex("PondTypeID"));
							if(PondTypeID==null||PondTypeID.equalsIgnoreCase(""))
								PondTypeID="0";
							((Spinner)findViewById(R.id.type_of_pond_sp)).setSelection(Integer.parseInt(PondTypeID));
							String RegisteredWithId=cursor.getString(cursor.getColumnIndex("RegisteredWithId"));
							if(RegisteredWithId==null||RegisteredWithId.equalsIgnoreCase(""))
								RegisteredWithId="0";
							((Spinner)findViewById(R.id.registered_with_sp)).setSelection(Integer.parseInt(RegisteredWithId));

							String PondStatusId=cursor.getString(cursor.getColumnIndex("PondStatusId"));
							if(PondStatusId==null||PondStatusId.equalsIgnoreCase(""))
								PondStatusId="0";
							((Spinner)findViewById(R.id.status_of_pond_sp)).setSelection(Integer.parseInt(PondStatusId));
							String AssistanceRegID=cursor.getString(cursor.getColumnIndex("AssistanceRegID"));
							if(AssistanceRegID==null||AssistanceRegID.equalsIgnoreCase(""))
								AssistanceRegID="0";
							((Spinner)findViewById(R.id.assistance_sp)).setSelection(Integer.parseInt(AssistanceRegID));


							((EditText)findViewById(R.id.survey_no)).setText(cursor.getString(cursor.getColumnIndex("SurveyNo")));
							((EditText)findViewById(R.id.Enrolment_no)).setText(cursor.getString(cursor.getColumnIndex("EnrollmentNO")));	
							((EditText)findViewById(R.id.reg_no)).setText(cursor.getString(cursor.getColumnIndex("RegistrationNo")));

							//	((EditText)findViewById(R.id.systempond_no)).setText("");
							((EditText)findViewById(R.id.total_extent_area_in_ha)).setText(cursor.getString(cursor.getColumnIndex("TotalExtentAreaOfPond")));
							((EditText)findViewById(R.id.effectivewaterarea_inha)).setText(cursor.getString(cursor.getColumnIndex("EffectiveWaterSpreadArea")));
							//((EditText)findViewById(R.id.systempond_no)).setText(cursor.getString(cursor.getColumnIndex("RegistrationNo")));
							((EditText)findViewById(R.id.period_defunct_mnth)).setText(cursor.getString(cursor.getColumnIndex("DefunctPeriod")));
						} 
						catch (Exception e) 
						{
							e.printStackTrace();
						}

					}
					else
					{
						cursor.close();
						db.close();
						AlertDialogs("Information!!", "Data Not Available");
						return;
					}
					cursor.close();
					db.close();


				}
				break;

			default:
				break;
			}
		} 
		catch (Exception e) 
		{
			CommonFunctions.writeLog("Aquaculture", "onItemSelected", e.getMessage());
			e.printStackTrace();
		} 
	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}


}
