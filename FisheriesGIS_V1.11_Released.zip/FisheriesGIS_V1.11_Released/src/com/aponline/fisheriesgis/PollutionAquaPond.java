package com.aponline.fisheriesgis;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.json.JSONObject;

import com.aponline.fisheriesgis.database.DBAdapter;
import com.aponline.fisheriesgis.server.JSONParser;
import com.aponline.fisheriesgis.server.ServerResponseListener;
import com.aponline.fisheriesgis.server.WebserviceCall;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class PollutionAquaPond extends AppCompatActivity implements OnItemSelectedListener, OnClickListener,ServerResponseListener 
{
	ActionBar ab;
	GPSTracker gps;
	DBAdapter db;
	Button add;
	Spinner ponds_ID;
	String strBaseimage="",strBaseimage2="";
	String distrID,districtName; 
	String mandalID,mandalName;
	String roleID;
	LinearLayout childlayout; 
	String panchayatID="",villageID="",AqaLabID="",farmername="",Typeof_framID="",FramerNameID="",Farm_FirmID="";
	double latitude,longitude,latitude2,longitude2;
	int PHOTO_CAPTURE=100,PHOTO_CAPTURE2=102;
	protected void onCreate(Bundle savedInstanceState) 
	{
		try
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.pollution_aquafarm);

			ab=getSupportActionBar();
			ab.setTitle("Aqua Pollution");
			ab.setHomeButtonEnabled(true);
			ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
			ab.setDisplayHomeAsUpEnabled(true); 

			db=new DBAdapter(this);	

			gps=new GPSTracker(this);
			LoadUserDetails();
			Log.d("User ID", HomeData.userID);

			((Spinner)findViewById(R.id.districtSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.mandalSp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.panchayat_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.typeoffarm_sp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.village_spinner)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.farmername_sp)).setOnItemSelectedListener(this);
			((Spinner)findViewById(R.id.Name_of_the_Farmer_Firm_SP)).setOnItemSelectedListener(this);

			((Spinner)findViewById(R.id.ponds_ID)).setOnItemSelectedListener(this);


			childlayout=(LinearLayout)findViewById(R.id.pollution_child_layout);


			CommonFunctions.loadSpinnerSetSelectedItem(this,"select distinct DistrictName from Aqua_pollution where UserId ='"+HomeData.userID+"' ORDER BY DistrictName", (Spinner) findViewById(R.id.districtSp), districtName);
			if(roleID.equalsIgnoreCase("3"))
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(true);
				((Spinner)findViewById(R.id.mandalSp)).setEnabled(true);
			}
			else
			{
				((Spinner)findViewById(R.id.districtSp)).setEnabled(false);

			}

			((ImageView)findViewById(R.id.pollustion_aqua_imageview)).setOnClickListener(this);
			findViewById(R.id.submit_btn).setOnClickListener(this);
			((ImageView)findViewById(R.id.Pollution_WaterDischarges_imageview)).setOnClickListener(this);
			findViewById(R.id.submit_btn).setOnClickListener(this);
		}
		catch (Exception e) 
		{
			CommonFunctions.writeLog("Aqua_Polustion", "oncreate", e.getMessage());
			e.printStackTrace();
			AlertDialogsForceBack("Information!!", "Please Re-Login once/Try Again!!");
		}
	}

	private void LoadUserDetails() 
	{
		db.open();
		Cursor cursor=db.getTableDataCursor("select * from UserDetailsMaster");
		if(cursor.getCount()>0)
		{
			if(cursor.moveToFirst())
			{
				HomeData.userID=cursor.getString(cursor.getColumnIndex("UserId"));
				roleID=cursor.getString(cursor.getColumnIndex("RoleID"));
				distrID=cursor.getString(cursor.getColumnIndex("DistrictID"));
				mandalID=cursor.getString(cursor.getColumnIndex("MandalID"));
				districtName=cursor.getString(cursor.getColumnIndex("DistrictName"));
				mandalName=cursor.getString(cursor.getColumnIndex("MandalName"));

			}
		}
		else
		{
			AlertDialogsForceBack("Information!!", "Please Relogin!!");
		}
		cursor.close();
		db.close();
	}
	public void AlertDialogsForceBack(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				onBackPressed();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void loadSpinnerData(String query, Spinner spinner) 
	{
		try
		{
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();

			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			CommonFunctions.writeLog("Mapping", "loadSpinnerData", e.getMessage());
			e.printStackTrace();
		}
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==PHOTO_CAPTURE && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.pollustion_aqua_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}

			catch (Exception e)
			{
				CommonFunctions.writeLog("MappingSeedFarm", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}
		else if(requestCode==PHOTO_CAPTURE2 && resultCode == RESULT_OK)
		{
			try
			{

				Bitmap photo = (Bitmap) data.getExtras().get("data");
				Bitmap scaled = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);		

				Canvas canvas = new Canvas(scaled);
				Paint paint = new Paint();  
				paint.setColor(Color.RED);
				paint.setTextSize(14);  
				paint.setFlags(Paint.ANTI_ALIAS_FLAG);
				canvas.drawBitmap(photo, 0, 0, null);
				float fKoordX = 3f, fKoordY = 5f;
				canvas.drawPoint(fKoordX, fKoordY, paint);
				canvas.drawText("Lat    : "+latitude2, fKoordX + 3, fKoordY + 10, paint);
				canvas.drawText("Long: "+longitude2, fKoordX + 3, fKoordY + 30, paint);

				ImageView imageView= (ImageView)findViewById(R.id.Pollution_WaterDischarges_imageview);
				imageView.setImageBitmap(scaled);
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				scaled.compress(Bitmap.CompressFormat.PNG, 100, stream);
				byte[] byteArray = stream.toByteArray();
				strBaseimage2= Base64.encodeToString(byteArray,Base64.DEFAULT);

			}

			catch (Exception e)
			{
				CommonFunctions.writeLog("Discharge Water", "onCaptureImageResult", e.getMessage());

				e.printStackTrace();
			}

		}

	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.pollustion_aqua_imageview:
			if(gps.canGetLocation())
			{
				latitude=gps.getLatitude();
				longitude=gps.getLongitude();

				if(latitude==0 || longitude==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude)).setText(""+latitude);
				((TextView)findViewById(R.id.longitude)).setText(""+longitude);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE);			}

			break;
		case R.id.submit_btn:
			validatedata();
			break;


		case R.id.Pollution_WaterDischarges_imageview:
			if(gps.canGetLocation())
			{
				latitude2=gps.getLatitude();
				longitude2=gps.getLongitude();

				if(latitude2==0 || longitude2==0)
				{
					AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
					return;
				}

				((TextView)findViewById(R.id.latitude2)).setText(""+latitude2);
				((TextView)findViewById(R.id.longitude2)).setText(""+longitude2);
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(intent, PHOTO_CAPTURE2);			}

			break;

		case R.id.ponds_ID:

			if(childlayout.getVisibility()==View.GONE)
			{
				childlayout.setVisibility(View.VISIBLE);

				db.open();


				int count=db.getRowCount("select count(*) from Aqua_Pollustion_Master where FarmerName='"+farmername+"' and IsSync='Y'");

				db.close();
				((EditText)findViewById(R.id.effectviewater_txt)).setText(""+(count+1));
				((ImageView)findViewById(R.id.pollustion_aqua_imageview)).setImageBitmap(null);
				//((ImageView)findViewById(R.id.aqua_lab_center_imageview)).setBackgroundResource(R.drawable.aquaculture);
				((ImageView)findViewById(R.id.Pollution_WaterDischarges_imageview)).setBackgroundResource(R.drawable.aquaculture);
			}
			else
			{
				childlayout.setVisibility(View.GONE);
			}

			break;

		default:
			break;
		}
	}
	private void validatedata()
	{

		try 
		{
			if(((Spinner)findViewById(R.id.mandalSp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Mandal");
				((Spinner)findViewById(R.id.mandalSp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.panchayat_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Panchayat");
				((Spinner)findViewById(R.id.panchayat_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.village_spinner)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Village");
				((Spinner)findViewById(R.id.village_spinner)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.typeoffarm_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Type of farm  Name");
				((Spinner)findViewById(R.id.typeoffarm_sp)).requestFocus();
				return;
			}

			if(((Spinner)findViewById(R.id.farmername_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select Farmer Name");
				((Spinner)findViewById(R.id.farmername_sp)).requestFocus();
				return;
			}

			if(((Spinner)findViewById(R.id.Name_of_the_Farmer_Firm_SP)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select FRAM FIRMS  Name");
				((Spinner)findViewById(R.id.Name_of_the_Farmer_Firm_SP)).requestFocus();
				return;
			}


			if(((Spinner)findViewById(R.id.Availability_Effluent_Treatment_System_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select FRAM FIRMS  Name");
				((Spinner)findViewById(R.id.Availability_Effluent_Treatment_System_sp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.Salinity_Fresh_Drinking_watersource_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select FRAM FIRMS  Name");
				((Spinner)findViewById(R.id.Salinity_Fresh_Drinking_watersource_sp)).requestFocus();
				return;
			}
			if(((Spinner)findViewById(R.id.Salinity_Borewell_sp)).getSelectedItem().toString().equalsIgnoreCase("--Select--"))
			{
				AlertDialogs("Information!!", " Please Select FRAM FIRMS  Name");
				((Spinner)findViewById(R.id.Salinity_Borewell_sp)).requestFocus();
				return;
			}


			if(((EditText)findViewById(R.id.ponds_ID)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.ponds_ID)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.ponds_ID)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.effectviewater_txt)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.effectviewater_txt)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.effectviewater_txt)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.Source_of_Water)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Source_of_Water)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Source_of_Water)).requestFocus();
				return;
			}
			if(((EditText)findViewById(R.id.Name_of_Source_of_Water)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Name_of_Source_of_Water)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Name_of_Source_of_Water)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.Salinity_Feeder_Channel)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Salinity_Feeder_Channel)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Salinity_Feeder_Channel)).requestFocus();
				return;
			}


			if(((EditText)findViewById(R.id.Salinity_Pond_Inlet)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Salinity_Pond_Inlet)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Salinity_Pond_Inlet)).requestFocus();
				return;
			}


			if(((EditText)findViewById(R.id.Salinity_Pond_OutletWater_exit_Channel)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Salinity_Pond_OutletWater_exit_Channel)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Salinity_Pond_OutletWater_exit_Channel)).requestFocus();
				return;
			}

			if(((EditText)findViewById(R.id.Creek_Drain_waterdrained_pond)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Creek_Drain_waterdrained_pond)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Creek_Drain_waterdrained_pond)).requestFocus();
				return;
			}


			if(((EditText)findViewById(R.id.Sailinty_Water_Discharge_point_Drain_Creek)).getText().toString().equalsIgnoreCase(""))
			{
				((EditText)findViewById(R.id.Sailinty_Water_Discharge_point_Drain_Creek)).setError("field cannot left Empty");
				((EditText)findViewById(R.id.Sailinty_Water_Discharge_point_Drain_Creek)).requestFocus();
				return;
			}




			//				
			//				String adharno=((EditText)findViewById(R.id.adharno_et)).getText().toString();
			//				if(adharno.equalsIgnoreCase(""))
			//				{
			//					((EditText)findViewById(R.id.adharno_et)).setError("field cannot left Empty");
			//					((EditText)findViewById(R.id.adharno_et)).requestFocus();
			//					return;
			//				}
			//
			//				if(!CommonFunctions.validateAadharNumber(adharno))
			//				{
			//					((EditText)findViewById(R.id.adharno_et)).requestFocus();
			//					((EditText)findViewById(R.id.adharno_et)).setError(" Please Enter Valid Aadhaar Number");
			//					return;
			//				}
			//
			//			String NoofPonds=((EditText)findViewById(R.id.no_of_ponds)).getText().toString();
			//			String Pond_ID=((EditText)findViewById(R.id.ponds_ID)).getText().toString();
			//				String noofperson=((EditText)findViewById(R.id.noofperson_et)).getText().toString();
			//				String emailid=((EditText)findViewById(R.id.websitename_et)).getText().toString();

			if(strBaseimage.equalsIgnoreCase(""))
			{
				AlertDialogs("Information!!", " Please Capture  Seed Farm Center Photo");
				return;
			}
			if(latitude== 0 || longitude== 0)
			{
				AlertDialogs("Information!!", "Failed to capture the GPS Co-ordinates, Please check your gps settings and try again!!");
				return;

			}
			if(AqaLabID == null || AqaLabID.equalsIgnoreCase("null") || AqaLabID.equalsIgnoreCase("0")|| AqaLabID.equalsIgnoreCase(""))
			{
				//	((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
				AlertDialogs("Information!!", "AqaLab ID Not found, Please try again!!");
				return;
			}

			//				
			//				if(AqaLabID == null || AqaLabID.equalsIgnoreCase("null") || AqaLabID.equalsIgnoreCase("0")|| AqaLabID.equalsIgnoreCase(""))
			//				{
			//					//	((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
			//					AlertDialogs("Information!!", "AqaLab ID Not found, Please try again!!");
			//					return;
			//				}
			//				
			//				
			//				if(AqaLabID == null || AqaLabID.equalsIgnoreCase("null") || AqaLabID.equalsIgnoreCase("0")|| AqaLabID.equalsIgnoreCase(""))
			//				{
			//					//	((Spinner)findViewById(R.id.marinename_sp)).setSelection(0);
			//					AlertDialogs("Information!!", "AqaLab ID Not found, Please try again!!");
			//					return;
			//				}
			//				
			//			

			//
			//				JSONObject seedData=new JSONObject();
			//				seedData.put("USERID", HomeData.userID);
			//				seedData.put("DEVICEID", HomeData.sDeviceId);
			//				seedData.put("ALID",AqaLabID);		
			//				seedData.put("BASE64PHOTO",strBaseimage);
			//				seedData.put("LONGITUDE", longitude);
			//				seedData.put("LATITUDE", latitude);
			//				seedData.put("Pond NO", NoofPonds);
			//				seedData.put("Mobile", Pond_ID);
			//				seedData.put("NoofTechinalPersons", noofperson);
			//				seedData.put("Email", emailid);
			//				seedData.put("AadharNo", adharno);
			//
			//				seedData.put("NoofTechinalPersons", noofperson);
			//				seedData.put("Email", emailid);
			//				seedData.put("AadharNo", adharno);
			//
			//				seedData.put("NoofTechinalPersons", noofperson);
			//				seedData.put("Email", emailid);
			//				seedData.put("AadharNo", adharno);
			//
			//				seedData.put("NoofTechinalPersons", noofperson);
			//				seedData.put("Email", emailid);
			//				seedData.put("AadharNo", adharno);
			//
			//				
			//				
			//				


			childlayout.setVisibility(View.GONE);



			JSONObject data=new JSONObject();
			data.put("Version", HomeData.sAppVersion);
			//data.put("ALGEOTAGGING", seedData);

			WebserviceCall request=new WebserviceCall(this,"POST");
			request.addParam("JSON", data.toString());
			request.ProccessRequest(this, "UPDATELOCATIONDETAILS_AL");

			return;
		} 
		catch (Exception e) 
		{
			CommonFunctions.writeLog("Aqua_Polustion", "validatedata", e.getMessage());
			e.printStackTrace();
			AlertDialogs("Information!!", "Somethimg went wrong, Please try again!!");
		}
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			super.onBackPressed();
			return true; 
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	@Override
	public void Success(String response) 
	{
		try 
		{
			ContentValues seedfarmlist = new ContentValues();
			seedfarmlist.put("Image", strBaseimage);
			seedfarmlist.put("Latitude",""+latitude);
			seedfarmlist.put("Longitude",""+longitude);	
			seedfarmlist.put("IsSync","Y");
			db.open();
			db.updateTableData("AquaLab_Master", seedfarmlist,"UserId='"+HomeData.userID +"' and Aqualab_id='"+AqaLabID+"' and VillageID='"+villageID+"' and DistrictID='"+distrID+"' and MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'");
			db.close();


			if(!roleID.equalsIgnoreCase("3"))
				((Spinner)findViewById(R.id.mandalSp)).setSelection(0);

			((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.aqualab_sp)).setSelection(0);
			((Spinner)findViewById(R.id.village_spinner)).setSelection(0);

			((Spinner)findViewById(R.id.typeoffarm_sp)).setSelection(0);
			((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
			((Spinner)findViewById(R.id.farmername_sp)).setSelection(0);
			((Spinner)findViewById(R.id.Name_of_the_Farmer_Firm_SP)).setSelection(0);


			((Spinner)findViewById(R.id.Availability_Effluent_Treatment_System_sp)).setSelection(0);
			((Spinner)findViewById(R.id.Salinity_Fresh_Drinking_watersource_sp)).setSelection(0);
			((Spinner)findViewById(R.id.Salinity_Borewell_sp)).setSelection(0);
			//((Spinner)findViewById(R.id.Name_of_the_Farmer_Firm_SP)).setSelection(0);


			((ImageView) findViewById(R.id.aqua_lab_center_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.aqualab));

			((ImageView) findViewById(R.id.pollustion_aqua_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.aqualab));


			((TextView)findViewById(R.id.latitude)).setText("");

			((TextView)findViewById(R.id.longitude)).setText("");


			((TextView)findViewById(R.id.latitude2)).setText("");

			((TextView)findViewById(R.id.longitude2)).setText("");


			((TextView)findViewById(R.id.no_of_ponds)).setText("");
			((TextView)findViewById(R.id.ponds_ID)).setText("");
			((TextView)findViewById(R.id.categoryofanalysis_txt)).setText("");
			((EditText)findViewById(R.id.effectviewater_txt)).setText("");
			((EditText)findViewById(R.id.Source_of_Water)).setText("");
			((TextView)findViewById(R.id.Name_of_Source_of_Water)).setText("");
			((EditText)findViewById(R.id.Salinity_Feeder_Channel)).setText("");
			((EditText)findViewById(R.id.Salinity_Pond_Inlet)).setText("");
			((EditText)findViewById(R.id.Salinity_Pond_OutletWater_exit_Channel)).setText("");

			((EditText)findViewById(R.id.Creek_Drain_waterdrained_pond)).setText("");
			((EditText)findViewById(R.id.Sailinty_Water_Discharge_point_Drain_Creek)).setText("");


			strBaseimage="";
			Dialogs.AlertDialogs(this,"Information!!", JSONParser.msg);


		}  
		catch (Exception e)
		{
			CommonFunctions.writeLog("Aqua_Polustion", "Success", e.getMessage());
			e.printStackTrace();
			Dialogs.AlertDialogs(this,"Information!!", "Upload Failed, Please Try Again");
		}

	}


	@Override
	public void Fail(String response) 
	{
		Dialogs.AlertDialogs(this,"Information!!", response);
	}


	@Override
	public void NetworkNotAvail()
	{
		Dialogs.AlertDialogs(this,"Information!!", "Network not available, Please try again!!");
	}


	@Override
	public void AppUpdate() 
	{
		startActivity(new Intent(PollutionAquaPond.this,AppUpdatePage.class));
		finish();
		return;
	}


	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void onItemSelected(AdapterView<?> parent, View view, int position,long id) 
	{

		try 
		{
			strBaseimage="";
			((ImageView) findViewById(R.id.pollustion_aqua_imageview)).setImageDrawable(getResources().getDrawable(R.drawable.pic4));
			((TextView)findViewById(R.id.latitude)).setText("");
			((TextView)findViewById(R.id.longitude)).setText("");
			((TextView)findViewById(R.id.Salinity_Feeder_Channel)).setText("");
			((TextView)findViewById(R.id.Salinity_Pond_Inlet)).setText("");
			((TextView)findViewById(R.id.Salinity_Pond_OutletWater_exit_Channel)).setText("");
			((EditText)findViewById(R.id.Creek_Drain_waterdrained_pond)).setText("");
			((EditText)findViewById(R.id.Sailinty_Water_Discharge_point_Drain_Creek)).setText("");
			((TextView)findViewById(R.id.Name_of_Source_of_Water)).setText("");
			((TextView)findViewById(R.id.Source_of_Water)).setText("");
			((EditText)findViewById(R.id.effectviewater_txt)).setText("");
			((EditText)findViewById(R.id.ponds_ID)).setText("");
			((EditText)findViewById(R.id.no_of_ponds)).setText("");

			switch (parent.getId()) 
			{
			case R.id.districtSp:
				String distrctName=parent.getSelectedItem().toString().trim();  
				if(!distrctName.equalsIgnoreCase("--Select--"))
				{
					if(roleID.equalsIgnoreCase("3"))
					{
						CommonFunctions.loadSpinnerSetSelectedItem(PollutionAquaPond.this, "select distinct MandalName from AquaLab_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp), mandalName);
					}
					else
					{
						loadSpinnerData("select distinct MandalName from Aqua_Polustion_Master where DistrictID='"+distrID+"' ORDER BY MandalName", (Spinner)findViewById(R.id.mandalSp));
					}
				}
				break;
			case R.id.mandalSp:
				String mandalname=parent.getSelectedItem().toString().trim();  
				((Spinner)findViewById(R.id.panchayat_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.aqualab_sp)).setSelection(0);
				if(!mandalname.equalsIgnoreCase("--Select--"))
				{
					if(!roleID.equalsIgnoreCase("3"))
					{
						db.open();
						mandalID=db.getSingleValue("select MandalID from Aqua_Polustion_Master where MandalName='"+mandalname +"' and DistrictID='"+distrID+"'");															
						db.close();
					}
					loadSpinnerData("select distinct PanchayatName from Aqua_Polustion_Master where MandalID='"+mandalID+"' and DistrictID='"+distrID+"' order by PanchayatName",((Spinner)findViewById(R.id.panchayat_spinner)));
				}

				break;
			case R.id.panchayat_spinner:
				String panchayatname=parent.getSelectedItem().toString().trim(); 
				((Spinner)findViewById(R.id.village_spinner)).setSelection(0);
				((Spinner)findViewById(R.id.aqualab_sp)).setSelection(0);
				if(!panchayatname.equalsIgnoreCase("--Select--"))
				{
					db.open();
					panchayatID=db.getSingleValue("select distinct PanchayatID from AquaLab_Master where PanchayatName='"+panchayatname+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'");
					db.close();
					loadSpinnerData("select distinct VillageName from Aqua_Polustion_Master where PanchayatID='"+panchayatID+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"' order by VillageName",((Spinner)findViewById(R.id.village_spinner)));
				}
				break;

			case R.id.village_spinner:
				String villagename=parent.getSelectedItem().toString();
				((Spinner)findViewById(R.id.aqualab_sp)).setSelection(0);
				if(!villagename.equalsIgnoreCase("--Select--"))
				{
					db.open();
					villageID=db.getSingleValue("select distinct VillageID from AquaLab_Master where VillageName='"+villagename+"' and PanchayatID='"+panchayatID+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'");
					db.close();
					loadSpinnerData("select distinct Aqua_Polustion from AquaLab_Master where MandalID='"+mandalID+"' and PanchayatID='"+panchayatID+"'and VillageID='"+villageID+"' and DistrictID='"+distrID+"' order by AquaLab_Name ",((Spinner)findViewById(R.id.aqualab_sp)));
				}

				break;


			case R.id.farmername_sp:

				String aqualab_name=parent.getSelectedItem().toString();
				if(!aqualab_name.equalsIgnoreCase("--Select--"))
				{

					db.open();
					Cursor cursor=db.getTableDataCursor("select Aqualab_id,TypeofAqua_Lab,Categoryof_Aqualab,Categoryof_Analysis,Nameofofficer,Mobile_no,Address,NoOfTechnical_Person,Adhar_No from AquaLab_Master "
							+ "where AquaLab_Name='"+aqualab_name+"' and VillageID='"+villageID+"' and PanchayatID='"+panchayatID+"' and MandalID='"+mandalID+"' and DistrictID='"+distrID+"'");
					if(cursor.getCount()>0)
					{
						cursor.moveToFirst();
						AqaLabID=cursor.getString(cursor.getColumnIndex("Aqualab_id"));
						((TextView)findViewById(R.id.typeoflab_txt)).setText(cursor.getString(cursor.getColumnIndex("TypeofAqua_Lab")));
						((TextView)findViewById(R.id.categoryoflab_txt)).setText(cursor.getString(cursor.getColumnIndex("Categoryof_Aqualab")));
						((TextView)findViewById(R.id.categoryofanalysis_txt)).setText(cursor.getString(cursor.getColumnIndex("Categoryof_Analysis")));
						((EditText)findViewById(R.id.nameofofficer_et)).setText(cursor.getString(cursor.getColumnIndex("Nameofofficer")));
						//						((EditText)findViewById(R.id.mobileno_et)).setText(cursor.getString(cursor.getColumnIndex("Mobile_no")));
						//						((TextView)findViewById(R.id.address_et)).setText(cursor.getString(cursor.getColumnIndex("Address")));
						//						((EditText)findViewById(R.id.noofperson_et)).setText(cursor.getString(cursor.getColumnIndex("NoOfTechnical_Person")));
						//						((EditText)findViewById(R.id.adharno_et)).setText(cursor.getString(cursor.getColumnIndex("Adhar_No")));

					}
					else
					{
						AlertDialogs("Information!!", "Details not found, Please contact APOnline");
						cursor.close();
						db.close();
						((Spinner)findViewById(R.id.aqualab_sp)).setSelection(0);
						return;
					}
					cursor.close();
					db.close();

					if(AqaLabID == null || AqaLabID.equalsIgnoreCase("null") || AqaLabID.equalsIgnoreCase("0")|| AqaLabID.equalsIgnoreCase(""))
					{
						((Spinner)findViewById(R.id.seedfarm_sp)).setSelection(0);
						AlertDialogs("Information!!", "Aqua Polustion details not found, Please contact APOnline");
					}
					latitude=gps.getLatitude();
					longitude=gps.getLongitude();
				}
				break;
			default:
				break;
			}
		}
		catch (Exception e)
		{
			CommonFunctions.writeLog("Mapping", "onItemSelected", e.getMessage());
			e.printStackTrace();
		}
	}


	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}


}
