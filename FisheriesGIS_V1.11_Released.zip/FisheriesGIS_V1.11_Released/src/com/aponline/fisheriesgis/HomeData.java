package com.aponline.fisheriesgis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

public class HomeData 
{
//	//Staging 		public static String url ="http://ahd.aponline.gov.in/ahs/animalhusbandryservice.asmx"; 
//	//Live 		//			
//	public static String url ="http://ahd.aponline.gov.in/ahs/animalhusbandryservice.asmx"; 

	public static int sApiLevel = 0; 
	public static String sAppVersion,sAppVersionName;    
	public static Boolean sCheckMeEnable;    
	public static String sCountry;
	public static String sCountrySortName; 
	public static String sDeviceId;  
	public static String sModel;
	public static String sOSVersion;
	public static String current_date;
	public static String smUpgrade_Content;
	public static int smUpgrade_count;
	public static boolean smUpgrade_displayflag=true;
	public static String smUpgrade_header;                
	public static String smAppSettingVersion;

	public static String userID;
	public static String Password;
	public static Boolean isServiceRunning=false;
	public static int Task=1;
	public static void readDeviceDetails(Context paramContext) 
	{
		String str1 = ((TelephonyManager)paramContext.getApplicationContext().getSystemService("phone")).getDeviceId();
		if (str1 == null)
			str1 = Settings.Secure.getString(paramContext.getApplicationContext().getContentResolver(), "android_id");
		if (str1 == null)
			str1 = "NODeviceID";
		String str2 = Build.VERSION.RELEASE;
		String str3 = Build.MODEL;
		int i = Integer.parseInt(Build.VERSION.SDK);
		SharedPreferences localSharedPreferences = paramContext.getApplicationContext().getSharedPreferences("user_settings", 0);
		String str4 = localSharedPreferences.getString("UserLocation", "");
		String str5 = localSharedPreferences.getString("UserLocationSortName", "");
		//	    if ((str4.equalsIgnoreCase("")) && (smLocationUrl != null) && (smLocationUrl.length() > 0))
		//	      getCountry_LocationUrl(paramContext, smLocationUrl);
		PackageManager localPackageManager = paramContext.getApplicationContext().getPackageManager();
		String str6 = "";
		try
		{
			str6 = ""+localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 128).versionCode;
			sAppVersionName = localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 128).versionName;
			sApiLevel = i;
			Log.d("API LEVEL", Integer.toString(sApiLevel));
			sAppVersion = str6;
			Log.d("APP VERSION",sAppVersion);
			sDeviceId =str1; 
			Log.d("Device ID",sDeviceId);   
			sOSVersion = str2;
			Log.d("OS Version",sOSVersion); 
			sModel = str3; 
			Log.d("MODEL",sModel);
			sCountry = str4;
			Log.d("COUNTRY",sCountry);  
			sCountrySortName = str5;                  
			Log.d("COUNTRY SORT", sCountrySortName);               
			return;
		}
		catch (Exception localException)   
		{
			while (true)
				localException.printStackTrace();
		}
	}
	public static Boolean isLogin(Context mContext) 
	{
		SharedPreferences pref = mContext.getSharedPreferences("AH_MyPref", Context.MODE_PRIVATE);     
		if(pref.contains("AppInstalled"))
		{
			if(pref.getBoolean("IsLogin", false))
			{
				userID=pref.getString("UserName", null);
				Password=pref.getString("Password", null);
				return true;
			}
		}
		return false;
	}
	public static void isLogOut(Context mContext) 
	{
		SharedPreferences pref = mContext.getSharedPreferences("AH_MyPref", Context.MODE_PRIVATE);     
		if(pref.contains("AppInstalled"))
		{
			Editor editor = pref.edit();   
			editor.putBoolean("IsLogin", false); 
			editor.commit();
		}
		return;
	}

	public static void SaveCreadentials(Context mContext, String userName, String password)
	{
		userID=userName;
		Password=password;
		SharedPreferences pref = mContext.getSharedPreferences("AH_MyPref", Context.MODE_PRIVATE);    
		if(!pref.contains("AppInstalled"))
		{
			Editor editor = pref.edit();   
			editor.putBoolean("AppInstalled", true);  
			editor.putString("AppLaunchDate",HomeData.current_date);    
 			editor.putString("Version", ""+HomeData.sAppVersion); 
			editor.putString("UserName", userName); 
			editor.putString("Password", password); 
			editor.putBoolean("IsLogin", true); 
			editor.commit(); 
		}
		else
		{}
	}
	public static ArrayList<String> getDistrictList(ArrayList<HashMap<String, String>> listMap)
	{
		ArrayList<String> list = new ArrayList<String>();

		for(int i=0; i<listMap.size(); i++)
		{ 
			list.add(listMap.get(i).get("District_description").trim());
		} 
		HashSet<String> hashSet_district = new HashSet<String>(list);
		
		ArrayList<String> District_ArrayList = new ArrayList<String>();
		District_ArrayList.add("--Select--");
		District_ArrayList.addAll(hashSet_district);
		Collections.sort(District_ArrayList);
		return District_ArrayList;
	}
	public static ArrayList<String> getMandalList(ArrayList<HashMap<String, String>> listMap,String district)
	{
		ArrayList<String> list = new ArrayList<String>();

		for(int i=0; i<listMap.size(); i++)
		{
			
			if(listMap.get(i).get("District_description").trim().equalsIgnoreCase(district))
			{
				list.add(listMap.get(i).get("Mandal_Description").trim());
			}
		} 
		HashSet<String> hashSet_district = new HashSet<String>(list);
		
		ArrayList<String> data = new ArrayList<String>();
		data.add("--Select--");
		data.addAll(hashSet_district);
		Collections.sort(data);
		return data;
	}
	public static ArrayList<String> getPanchayathList(ArrayList<HashMap<String, String>> listMap,String district,String mandal)
	{
		ArrayList<String> list = new ArrayList<String>();

		for(int i=0; i<listMap.size(); i++)
		{
			
			if(listMap.get(i).get("District_description").trim().equalsIgnoreCase(district)&&listMap.get(i).get("Mandal_Description").trim().equalsIgnoreCase(mandal))
			{
				list.add(listMap.get(i).get("PANCHAYAT_NAME").trim());
			}
		} 
		HashSet<String> hashSet_district = new HashSet<String>(list);
		
		ArrayList<String> data = new ArrayList<String>();
		data.add("--Select--");
		data.addAll(hashSet_district);
		Collections.sort(data);
		return data;
	}
	
	public static ArrayList<String> getVillageList(ArrayList<HashMap<String, String>> listMap,String district,String mandal,String panchayath)
	{
		ArrayList<String> list = new ArrayList<String>();

		for(int i=0; i<listMap.size(); i++)
		{
			
			if(listMap.get(i).get("District_description").trim().equalsIgnoreCase(district)&&listMap.get(i).get("Mandal_Description").trim().equalsIgnoreCase(mandal)&&listMap.get(i).get("PANCHAYAT_NAME").trim().equalsIgnoreCase(panchayath))
			{
				list.add(listMap.get(i).get("VILLAGE_NAME"));
			}
		} 
		HashSet<String> hashSet_district = new HashSet<String>(list);
		
		ArrayList<String> data = new ArrayList<String>();
		data.add("--Select--");
		data.addAll(hashSet_district);
		Collections.sort(data);
		return data;
	}
}
