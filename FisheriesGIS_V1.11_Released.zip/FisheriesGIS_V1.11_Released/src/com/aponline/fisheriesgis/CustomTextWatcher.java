package com.aponline.fisheriesgis;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public  class  CustomTextWatcher implements TextWatcher
{
	EditText e;
	TextView t;
	public static int no1=0;
	public static int no2=0;
	public static int no3=0;
	public static double effectivewater=0.0;

	private View view;
	public CustomTextWatcher(EditText e) 
	{
		this.e = e;
	}

	public CustomTextWatcher(EditText e,TextView t) 
	{
		this.e = e;
		this.t=t;
	}

	public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
	public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub

		if(e.getId()==R.id.mechanised_et)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no1=0;
				int total=no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no1=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.motarised_et)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no2=0;
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no2=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.tradestional_et)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no3=0;
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no3=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.male_txt)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no1=0;
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no1=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.female_txt)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no2=0;
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no2=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.children_txt)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no3=0;
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no3=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.children_txt)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				no3=0;
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;

			}
			else 
			{
				no3=Integer.parseInt(e.getText().toString()); 
				int total= no1+no2+no3;

				t.setText(String.valueOf(total));
				total=0;
			}

		}

		if(e.getId()==R.id.totalwater_txt)
		{

			if(e.getText().toString().equalsIgnoreCase(""))
			{
				effectivewater=0.0;
				t.setText(String.valueOf(effectivewater));

			}
			else
			{

				if(IWBCentersPage.percentage==75)
				{			
					effectivewater=Double.parseDouble(e.getText().toString())*75/100;
					t.setText(String.valueOf(effectivewater));
				}

				if(IWBCentersPage.percentage==50)
				{						
					effectivewater=Double.parseDouble(e.getText().toString())*50/100;
					t.setText(String.valueOf(effectivewater));
				}
				if(IWBCentersPage.percentage==25)
				{						
					effectivewater=Double.parseDouble(e.getText().toString())*25/100;
					t.setText(String.valueOf(effectivewater));
				}
			}

		}


	}


}
