package com.aponline.fisheriesgis.database;

public class CreateTablesData {

	public static final String Aqua_lab_table = "CREATE TABLE Aqua_Lab(" + "DISTRICT_NAME varchar(50)," + "MANDAL_ID varchar(5),"+ "MANDAL_NAME varchar(50),"+ "PANCHAYAT_ID varchar(5),"+ "PANCHAYAT_NAME varchar(50),"+ "VILLAGE_ID varchar(5),"+ "VILLAGE_NAME varchar(50),"+ "AquaLab_Name varchar(50),"+ "TypeofAqua_Lab varchar(50),"+ "Categoryof_Aqualab varchar(50),"+ "Categoryof_Analysis varchar(50),"+ "District_ID varchar(5),"+ "District_ID varchar(5),"+ "Aqualab_id varchar(50),"+ "Nameofofficer varchar(50),"+ "Mobile_no varchar(50),"+ "websiteoremail varchar(50),"+ "Address varchar(50),"+ "NoOfTechnical_Person varchar(50),"+ "Adhar_No varchar(50),"+ "Latitude varchar(50),"+ "Longitude varchar(50),"+ "UPLOAD_STATUS varchar(5),"+ "User_Id varchar(50),";

	public static final String Aquaculture_table = "CREATE TABLE Aquaculture(" + "District_ID varchar(5)," + "DISTRICT_NAME varchar(50), "+ "MANDAL_ID varchar(50),"+ "MANDAL_NAME varchar(50),"+ "PANCHAYAT_ID varchar(50),"+ "PANCHAYAT_NAME varchar(50),"+ "VILLAGE_ID varchar(50),"+ "VILLAGE_NAME varchar(50),"+ "Aquaculture_id varchar(50),"+ "Aquaculture_name varchar(50),"+ "Typeofthefarm varchar(50),"+ "Surveyno varchar(50),"+ "Landownership varchar(50),"+ "Adharno varchar(50),"+ "mobileno varchar(50),"+ "Farmstatus varchar(50),"+ "Farmregistered varchar(50),"+ "Registeredwith varchar(50),"+ "Regirstraionno varchar(50),"+ "Registrationdate varchar(50),"+ "waterspreadinha varchar(50),"+ "totalareaoffarm varchar(50),"+ "Typeofcuture varchar(50),"+ "User_Id varchar(50),"+ "UPLOAD_STATUS varchar(50),"+ "Farmer_Name varchar(50),;";

	public static final String Fishland_table = "CREATE TABLE FISHLAND_CENTRE_MASTER(" + "DISTRICT_NAME varchar(50),"+ "MANDAL_ID varchar(50)," + "MANDAL_NAME varchar(50),"+ "PANCHAYAT_ID varchar(50),"+ "PANCHAYAT_NAME varchar(50),"+ "VILLAGE_ID varchar(50),"+ "VILLAGE_NAME varchar(50),"+ "FISHING_CENTRE varchar(50),"+ "DISTRICT_ID varchar(50),"+ "FLCENTER_ID varchar(50),"+ "Mechanised_Boat varchar(50),"+ "Motarised_Boat varchar(50),"+ "Traditional_Boats varchar(50),"+ "Total varchar(50),"+ "Castnets varchar(50),"+ "Gilnet varchar(50),"+ "Tramelnet varchar(50),"+ "Latitude varchar(50),"+ "Longitude varchar(50),"+ "UPLOAD_STATUS varchar(50),"+ "Male varchar(50),"+ "Female varchar(50),"+ "Children varchar(50),"+ "Total_Population varchar(50),"+ "User_Id varchar(50),;";

	public static final String Mitank_table = "CREATE TABLE Mi_Tank(" + "District_ID varchar(50),"
			+ "DISTRICT_NAME varchar(50)," + "MANDAL_ID varchar(50)," + "MANDAL_NAME varchar(50),"
			+ "PANCHAYAT_ID varchar(50)," + "PANCHAYAT_NAME varchar(50)," + "VILLAGE_ID varchar(50),"
			+ "VILLAGE_NAME varchar(50)," + "MITank_id varchar(50)," + "MITank_Name varchar(50)," + "Typeofwaterbody varchar(50)),"
			+ "Ownership varchar(50)," + "Seasonality varchar(50)," + "TotalWater varchar(50)," + "Effective_Water varchar(50),"
			+ "Disposing_Mode varchar(50)," + "Latitude varchar(50)," + "Longitude varchar(50)," + "UPLOAD_STATUS varchar(50),"
			+ "Source varchar(50)," + "Nameoftheofficer varchar(100)," + "MobileNo varchar(100)," + "User_Id varchar(50)," + "Designation varchar(50),;";

	public static final String seedfarm_table = "CREATE TABLE SeedFarm_Center(" + "District varchar(50),"
			+ "District_ID varchar(50)," + "Mandal varchar(50)," + "Mandal_ID varchar(50),"
			+ "Panchayat varchar(50)," + "Panchayat_ID varchar(50)," + "Village varchar(50)," + "Village_ID varchar(50)," + "Nameoftheseedfarm varchar(50)," + "Categoryofseedfarm varchar(50)," + "IndicatorType varchar(50)," + "Ownership varchar(50)," + "SeedRegId varchar(50)," + "Latitude varchar(50)," + "Longitude varchar(50)," + "UPLOAD_STATUS varchar(50)," + "User_Id varchar(50),;";

	public static final String landownership_table = "CREATE TABLE LandOwnership_Master(" + "Id varchar(50),"+ "LandType varchar(50),;";
	
	public static final String Ownership_Detail_table = "CREATE TABLE Ownership_Detail(" + "Id varchar(50),"+ "Name varchar(50),;";
	
	
	public static final String registeredwith_table = "CREATE TABLE Registered_With(" + "Id varchar(50),"+ "Name varchar(50),;";


	public static final String AquaCulturePondDeatils_Master="CREATE TABLE if not exists [AquaCulturePondDeatils_Master] ("
			+ "[AQCID] VARCHAR(15)  NULL,"
			+ "[DistrictID] VARCHAR(5)  NULL,"
			+ "[DistrictName] VARCHAR(50)  NULL,"
			+ "[MandalID] VARCHAR(5)  NULL,"
			+ "[MandalName] VARCHAR(50)  NULL,"
			+ "[PanchayatID] VARCHAR(5)  NULL,"
			+ "[PanchayatName] VARCHAR(50)  NULL,"
			+ "[VillageID] VARCHAR(5)  NULL,"
			+ "[VillageName] VARCHAR(50)  NULL,"
			+ "[NameoftheFarmer] VARCHAR(50)  NULL,"
			+ "[FatherorHusbandName] VARCHAR(50)  NULL,"
			+ "[AadharNumber] VARCHAR(15)  NULL,"
			+ "[MobileNO] VARCHAR(12)  NULL,"
			+ "[FarmerAddress] VARCHAR(100)  NULL,"
			+ "[AquaFarmName] VARCHAR(50)  NULL,"
			+ "[FarmType] VARCHAR(50)  NULL,"
			+ "[FarmTypeID] VARCHAR(50)  NULL,"
			+ "[FarmAddress] VARCHAR(50)  NULL,"
			+ "[NoOfPonds] VARCHAR(15)  NULL,"
			+ "[PondNo] VARCHAR(50)  NULL,"
			+ "[WaterSourceId] VARCHAR(10)  NULL,"
			+ "[OwnerShipID] VARCHAR(50)  NULL,"
			+ "[PondTypeID] VARCHAR(50)  NULL,"
			+ "[SurveyNo] VARCHAR(15)  NULL,"
			+ "[RegisteredWithId] VARCHAR(15)  NULL,"
			+ "[EnrolledMPEDA] VARCHAR(50)  NULL,"
			+ "[EnrollmentNO] VARCHAR(50)  NULL,"
			+ "[RegistrationNo] VARCHAR(50)  NULL,"
			+ "[PondStatusId] VARCHAR(50)  NULL,"
			+ "[NoofCrops] VARCHAR(50)  NULL,"
			+ "[DefunctPeriod] VARCHAR(50)  NULL,"
			+ "[TotalExtentAreaOfPond] VARCHAR(50)  NULL,"
			+ "[EffectiveWaterSpreadArea] VARCHAR(50)  NULL,"
			+ "[AssistanceRegID] VARCHAR(50)  NULL,"
			+ "[Image] TEXT  NULL,"
			+ "[KmlFileName] TEXT  NULL,"
			+ "[KmlFileData] TEXT  NULL,"
			+ "[Latitude] VARCHAR(15)  NULL,"
			+ "[Longitude] VARCHAR(15)  NULL,"
			+ "[IsSync] VARCHAR(5) DEFAULT 'N' NULL,"
			+ "[UserId] VARCHAR(20)  NULL,"
			+ "[CreatedBy] VARCHAR(50)  NULL,"
			+ "[CreatedDate] TIMESTAMP DEFAULT CURRENT_TIME NULL,"
			+ "PRIMARY KEY ([AQCID],[PondNo]))";

	
	
	
}
