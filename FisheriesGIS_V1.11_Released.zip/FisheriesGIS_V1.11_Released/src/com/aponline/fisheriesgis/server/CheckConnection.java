package com.aponline.fisheriesgis.server;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.widget.ProgressBar;


public class CheckConnection
{
	Display Disp;
	AlertDialog.Builder builder;
	Handler mHandler;
	ProgressBar mInProgress;
	String mParseMethod;
	Context mcontext;
	Object obj;
	int position = 0;
	Message localMessage;
	String MethodName,UserName,Password;
	String paramString1,paramString2;
	public CheckConnection(Context paramContext, Handler paramHandler,String methodName)
	{
		this.mcontext = paramContext;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = paramHandler;
		this.MethodName=methodName;
	}
	public CheckConnection(Context paramContext, Handler paramHandler,String MethodName,String paramString1,String paramString2)
	{
		this.mcontext = paramContext;
		this.builder = new AlertDialog.Builder(this.mcontext);
		this.mHandler = paramHandler;
		this.MethodName=MethodName;
		this.paramString1=paramString1;
		this.paramString2=paramString2;
	}
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}

	public boolean checkNetworkAvailability(String methodType)
	{
		if (!isNetworkAvailable(this.mcontext))
		{
			showdialog("no_connection");
			return false;
		}
		return true;
	}
	public void showdialog(String paramString)
	{
		if (paramString.equals("no_connection"))
		{
			this.builder.setTitle("No Internet");
			this.builder.setMessage("No Internet Connection Available. Do you want to Continue?");
		}
		else
		{
			this.builder.setTitle("Server unavailable");
			this.builder.setMessage("Oops! Could not communicate with APONLINE Servers. Do you wish to retry?");
		}
		while (true)
		{

			this.builder.setPositiveButton("YES", new DialogInterface.OnClickListener(/*paramString*/)
			{
				public void onClick(DialogInterface paramDialogInterface, int paramInt)
				{
					localMessage=new Message();
					localMessage.what = 2;
					mHandler.sendMessage(localMessage);

					return;
				}
			});
			this.builder.setNegativeButton("NO", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface paramDialogInterface, int paramInt)
				{
					CheckConnection.this.builder.create().dismiss();
					((Activity)CheckConnection.this.mcontext).finish();
					return;
				}
			});
			this.builder.setCancelable(false);
			this.builder.show();
			return;
		}
	}
}
