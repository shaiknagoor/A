package com.aponline.fisheriesgis.server;

import java.net.SocketTimeoutException;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aponline.fisheriesgis.R;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.conn.ConnectTimeoutException;
import cz.msebera.android.httpclient.entity.StringEntity;

public class RequestServer implements ErrorCodes
{

	Boolean isMasterDownload=false;

	ServerResponseListener listener;
	Handler mUIHandler;
	Context mContext;
	HashMap<String, String> paramList;
	public static String methodName;
	ProgressDialog progressDialog;
	String proccessMsg="Proccessing,Please wait.................";

	String error;
	private static AsyncHttpClient client;
	RequestParams params;
	//Stagin  
	//	
	//String baseUrl="http://125.16.9.138:8090/fisheriesws/api/mobile/";

	//LIVE 
	//	
	String baseUrl="http://apfisheries.aponline.gov.in/fisheriesws/api/mobile/";

	//RequestQueue requestQueue ;
	public RequestServer(Context context)
	{
		this.mContext=context;
		this.paramList=new HashMap<String, String>();
	}
	public void addParam(String key, String value)
	{
		paramList.put(key, value);
	}
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "chec"
				+ "king if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}

	public void ProccessRequest(ServerResponseListener listener,String method)
	{
		this.listener=listener;
		methodName=method;
		if(isNetworkAvailable(mContext))
		{
			Loaddata();
		}
		else
		{
			this.listener.NetworkNotAvail();
		}
	}
	private void Loaddata()
	{
		progressDialog=new ProgressDialog(mContext);
		try 
		{
			Handler localHadler=new Handler()
			{
				public void dispatchMessage(Message paramMessage)
				{
					super.dispatchMessage(paramMessage);

					if(progressDialog.isShowing())
						progressDialog.dismiss();
					if(paramMessage.what==mSuccess)
					{
						if(isMasterDownload)
						{
							if(methodName.equalsIgnoreCase("GetSeedFarms"))
							{
								proccessMsg="FLC Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetFLC");
							}
							else if(methodName.equalsIgnoreCase("GetFLC"))
							{
								proccessMsg="MI Tanks Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetMITanks");
							}
							else if(methodName.equalsIgnoreCase("GetMITanks"))
							{
								proccessMsg="Aqua Labs Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetAquaLabs");
							}
							else if(methodName.equalsIgnoreCase("GetAquaLabs"))
							{
								proccessMsg="Aquaculture Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetAquaculture");
							}
							else if(methodName.equalsIgnoreCase("GetAquaculture"))
							{
								proccessMsg="Aquaculture Pond Data Downloading, Please wait.................";
								ProccessRequest(listener, "GetAquaCultureFarmDetails");
							}
							else
							{
								isMasterDownload=false;
								listener.Success("DOWNLOAD_MASTER_DATA");
							}
						}
						else
						{
							listener.Success(methodName);
						}
					}
					else if(paramMessage.what==mErrorResFromWebServices)
					{
						listener.Fail(JSONParser.Error);
					}
					else if(paramMessage.what==mFailure)
					{
						listener.Fail("Failed to transfer the data to server");
					}
					else if(paramMessage.what==mXmlPullParserException)
					{
						listener.Fail("Data parsing error, Please try again!!");
					}
					else if(paramMessage.what==mHandlerFailure||paramMessage.what==mSocketTimeoutException)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					else if(paramMessage.what==mException||paramMessage.what==mIOException)
					{
						listener.Fail("Failed to connect to the server");
					}
					else if(paramMessage.what==mJSONException)
					{
						listener.Fail("Data not found");
					}
					else if(paramMessage.what==mUpdateVersion)
					{
						listener.AppUpdate();
					}
					else if(paramMessage.what==5)
					{
						listener.Fail("Connection Time out, Please try again!!");
					}
					while(true)
					{
						return;
					}
				}
			};
			this.mUIHandler=localHadler;
			progressDialog.setCancelable(false);
			progressDialog.setMessage(proccessMsg);
			if(!progressDialog.isShowing())
				progressDialog.show();
			//			progressDialog.setContentView(setCustomeLayout());
			//new ParseThread("").start();
			if(methodName.equalsIgnoreCase("SeedFarm_UpdateGeoTagging")||methodName.equalsIgnoreCase("UpdateFLCLocationDetails")||methodName.equalsIgnoreCase("UPDATELOCATIONDETAILS_AL")||methodName.equalsIgnoreCase("MITANK_UPDATELOCATIONDETAILS")||methodName.equalsIgnoreCase("AQUACULTURE_UPDATELOCATIONDETAILS")||methodName.equalsIgnoreCase("AQUA_ADDPONDDETAILS"))
				postFetch(1);//uploadImage();//
			else
				postFetch();
			return;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			mUIHandler.sendEmptyMessage(mFailure);
		}
	}


	public View setCustomeLayout()
	{
		LayoutInflater mInflater = LayoutInflater.from(mContext);
		View layout = mInflater.inflate(R.layout.my_progress, null);
		return layout;
	}

	private void postFetch()
	{
		try 
		{
			if(methodName.equalsIgnoreCase("DOWNLOAD_MASTER_DATA"))
			{
				isMasterDownload=true;
				methodName="GetSeedFarms";
			}
			//	
			//String url="http://125.16.9.138:8090//fisheriesws/api/mobile/GetSeedFarms?";//VERSIONID=1&USERID=EGD-DFO
			client = new AsyncHttpClient();
			client.setConnectTimeout(180000);

			client.get(mContext,getAbsoluteURL(),createRequest(),new JsonHttpResponseHandler()
			{

				@Override
				public void onFailure(int statusCode, Header[] headers, String responseString,Throwable throwable) 
				{
					super.onFailure(statusCode, headers, responseString, throwable);
					checkError(statusCode,throwable);
				}
				@Override
				public void onFailure(int statusCode,Header[] headers, Throwable throwable,JSONArray errorResponse)
				{
					super.onFailure(statusCode, headers, throwable, errorResponse);
					checkError(statusCode,throwable);
				}
				@Override
				public void onFailure(int statusCode,Header[] headers, Throwable throwable,JSONObject errorResponse) 
				{
					super.onFailure(statusCode, headers, throwable, errorResponse);
					checkError(statusCode,throwable);
				}
				@Override
				public void onSuccess(int statusCode,Header[] headers, JSONArray response) 
				{
					super.onSuccess(statusCode, headers, response);
					new ParseThread(response).start();
				}

				@Override
				public void onSuccess(int statusCode,Header[] headers, JSONObject response) 
				{
					super.onSuccess(statusCode, headers, response);
					new ParseThread(response).start();
				}

				@Override
				public void onSuccess(int statusCode,Header[] headers, String response)
				{
					super.onSuccess(statusCode, headers, response);
					new ParseThread(response).start();
				}

			});
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			this.mUIHandler.sendEmptyMessage(5);
		}

	}


	@SuppressLint("NewApi")
	private void postFetch(int id)
	{
		client = new AsyncHttpClient();
		client.setConnectTimeout(180000);
		client.addHeader("Content-Type","application/json");
		try 
		{
			StringEntity se = new StringEntity(paramList.get("JSON"));
			client.post(mContext, getAbsoluteURL(),se, "application/json", new JsonHttpResponseHandler()
			{

				@Override
				public void onFailure(int statusCode,Header[] headers, String responseString,Throwable throwable) 
				{
					super.onFailure(statusCode, headers, responseString, throwable);
					checkError(statusCode,throwable);
				}
				@Override
				public void onFailure(int statusCode, Header[] headers, Throwable throwable,JSONArray errorResponse)
				{
					super.onFailure(statusCode, headers, throwable, errorResponse);
					checkError(statusCode,throwable);
				}
				@Override
				public void onFailure(int statusCode, Header[] headers, Throwable throwable,JSONObject errorResponse) 
				{
					super.onFailure(statusCode, headers, throwable, errorResponse);
					checkError(statusCode,throwable);
				}
				@Override
				public void onSuccess(int statusCode, Header[] headers, JSONArray response) 
				{
					super.onSuccess(statusCode, headers, response);
					new ParseThread(response).start();
				}
				@Override
				public void onSuccess(int statusCode,Header[] headers, JSONObject response) 
				{
					super.onSuccess(statusCode, headers, response);//{"STATUS":true,"MESSAGE":"SUCCESSFULLY UPDATED"}
					new ParseThread(response).start();
				}

				@Override
				public void onSuccess(int statusCode,Header[] headers, String response)
				{
					super.onSuccess(statusCode, headers, response);
					new ParseThread(response).start();
				}

			});

		} 
		catch (Exception e)
		{
			e.printStackTrace();
			this.mUIHandler.sendEmptyMessage(5);
		}
	}
	//	private void uploadImage()
	//	{
	//		methodName="SeedFarm_UpdateGeoTagging";
	//
	//		JSONObject jObject = null;
	//		try {
	//			jObject=new JSONObject(paramList.get("JSON"));
	//		} catch (JSONException e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//		}
	//
	//
	//		requestQueue=Volley.newRequestQueue(mContext);
	//		String url =getAbsoluteURL();
	//		JsonObjectRequest jsonRequet = new JsonObjectRequest(Method.POST, url,
	//				jObject, new Listener<JSONObject>() 
	//				{
	//			public void onResponse(JSONObject result) 
	//			{
	//				new ParseThread(result).start();
	//			}
	//				}, new Response.ErrorListener() {
	//					public void onErrorResponse(VolleyError error) 
	//					{
	//						readUIError(error);
	//					}
	//				});
	//
	//
	//
	//		jsonRequet.setTag(TAG);
	//		requestQueue.add(jsonRequet);
	//
	//	}


	//	protected void readUIError(VolleyError volleyError) 
	//	{
	//		Throwable error=volleyError.fillInStackTrace();
	//		Message localMessage = new Message();
	//		if (error instanceof ConnectTimeoutException || error instanceof SocketTimeoutException)
	//		{
	//			localMessage.what = mSocketTimeoutException;
	//		} 
	//		else 
	//		{
	//			localMessage.what = mException;
	//		}
	//
	//		mUIHandler.sendMessage(localMessage);
	//	}
	protected void checkError(int statusCode, Throwable error) 
	{

		try
		{
			Message localMessage = new Message();
			if (error instanceof ConnectTimeoutException || error instanceof SocketTimeoutException)
			{
				localMessage.what = mSocketTimeoutException;
			} 
			else 
			{
				localMessage.what = mException;
			}
			if(isMasterDownload)
			{
				if(methodName.equalsIgnoreCase("GetSeedFarms"))
				{
					ProccessRequest(listener, "GetFLC");
				}
				else if(methodName.equalsIgnoreCase("GetFLC"))
				{
					ProccessRequest(listener, "GetMITanks");
				}
				else if(methodName.equalsIgnoreCase("GetMITanks"))
				{
					ProccessRequest(listener, "GetAquaLabs");
				}
				else if(methodName.equalsIgnoreCase("GetAquaLabs"))
				{
					ProccessRequest(listener, "GetAquaculture");
				}

				else if(methodName.equalsIgnoreCase("GetAquaculture"))
				{
					ProccessRequest(listener, "GetAquaCultureFarmDetails");
				}
				else
				{
					isMasterDownload=false;
					mUIHandler.sendMessage(localMessage);
				}
			}
			else
			{
				mUIHandler.sendMessage(localMessage);
			}
		} 
		catch (Exception e) 
		{
			mUIHandler.sendEmptyMessage(5);
			e.printStackTrace();
		}
	}
	private String getAbsoluteURL() 
	{
		StringBuilder builder=new StringBuilder();
		builder.append(baseUrl);
		builder.append(methodName+"?");//http://125.16.9.138:8090/fisheriesws/api/mobile/UpdateSeedFarmLocationDetails?VERSIONID=1&JSON={"SEEDFARMID":"EGD\/2016\/48\/M","DEVICEID":"868159026563622","BASE64PHOTO":"iVBORw0KGgoAAAANSUhEUgAAAJYAAADICAIAAACF548yAAAAA3NCSVQICAjb","USERID":"EGD-DFO","LONGITUDE":"17.5555544","LATITUDE":"78.5544444"}
		return builder.toString();
	}
	private RequestParams createRequest() 
	{
		RequestParams params=new RequestParams();
		for ( String key : paramList.keySet())
		{		
			params.put(key, paramList.get(key));
		}
		//VERSION=1&JSON={"DEVICEID":"865770025033137","SEEDFARMID":"EGD\/2016\/00120\/M","LONGITUDE":78.3680899,"BASE64PHOTO":"iVBORw0KGgoAAAANSUhEUgAAAJYAAADICAIAAACF548yAAAAA3NCSVQICAjb","LATITUDE":17.4591679,"USERID":"EGD-DFO"}
		//	params.setUseJsonStreamer(false);
		return params;
	}

	public class ParseThread extends Thread
	{
		Object response;
		public ParseThread(String response)
		{
			this.response=response;
		}
		public ParseThread(JSONObject response)
		{
			this.response=response;
		}
		public ParseThread(JSONArray response)
		{
			this.response=response;
		}
		public void run()
		{
			Message localMessage = new Message();
			try 
			{
				System.out.println("***********Inside Parsethread**********");
				JSONParser parser = new JSONParser(mContext);
				int i = mFailure;

				if(response instanceof JSONObject)
				{
					i = parser.checkForError((JSONObject) response);
					if(i != 10)
					{
						localMessage.what = i;
						mUIHandler.sendMessage(localMessage);
						return;
					}
				}
				if (methodName.equalsIgnoreCase("UpdateFLCLocationDetails")) 
				{
					i = parser.UpdateFLCLocationDetails((JSONObject)response);              
				}
				else if (methodName.equalsIgnoreCase("AQUACULTURE_UPDATELOCATIONDETAILS")) 
				{
					i = parser.UpdateFLCLocationDetails((JSONObject)response);             
				}
				else if (methodName.equalsIgnoreCase("GetFLC")) 
				{
					i = parser.GetFLC((JSONArray) response);
				}
				else if (methodName.equalsIgnoreCase("GetSeedFarms")) 
				{
					i = parser.GetSeedFarms((JSONArray)response);
				}
				else if (methodName.equalsIgnoreCase("GetUserDetails")) 
				{
					i = parser.GetUserDetails((JSONObject)response);
				}
				else if (methodName.equalsIgnoreCase("GetMITanks")) 
				{
					i = parser.GetMITank((JSONArray)response);
				}
				else if (methodName.equalsIgnoreCase("GetAquaCultureFarmDetails")) 
				{
					i = parser.GetAquaCultureFarmDetails((JSONArray)response);
				}
				else if (methodName.equalsIgnoreCase("SeedFarm_UpdateGeoTagging")) 
				{
					i = parser.UpdateSeedFarmLocationDetails((JSONObject)response);
				}
				else if (methodName.equalsIgnoreCase("GetAquaLabs"))
				{
					i = parser.GetAquaLabs((JSONArray)response);
				}
				else if (methodName.equalsIgnoreCase("GetAquaculture"))
				{
					i = parser.GetAquaculture((JSONArray)response);
				}
				else if (methodName.equalsIgnoreCase("DownloadData"))
				{
					i = parser.GetAquaLabs((JSONArray)response);
					i = parser.GetFLC((JSONArray) response);
					i = parser.GetSeedFarms((JSONArray)response);
					i = parser.GetMITank((JSONArray)response);
					i = parser.GetAquaculture((JSONArray)response);
					i = parser.GetAquaCultureFarmDetails((JSONArray)response);
				}
				else if (methodName.equalsIgnoreCase("UPDATELOCATIONDETAILS_AL")) 
				{
					i = parser.UpdateaqualabLocationDetails((JSONObject) response);
				}
				else if (methodName.equalsIgnoreCase("UPDATECFSRPONDSDETAILS")) 
				{
					i = parser.UPDATECFSRPONDSDETAILS((JSONObject)response);              
				}
				else if (methodName.equalsIgnoreCase("MITANK_UPDATELOCATIONDETAILS")) 
				{
					i = parser.UpdateMITankLocationDetails((JSONObject) response);
				}

				else if (methodName.equalsIgnoreCase("AQUA_ADDPONDDETAILS")) 
				{
					i = parser.AQUA_ADDPONDDETAILS((JSONObject) response);
				}

				localMessage.what = i;

				mUIHandler.sendMessage(localMessage);

				return;
			}
			catch (JSONException e) 
			{
				e.printStackTrace();
				localMessage.what = mJSONException;
				mUIHandler.sendMessage(localMessage);
				return;
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				localMessage.what = mException;
				mUIHandler.sendMessage(localMessage);
			}
		}
	}
}
