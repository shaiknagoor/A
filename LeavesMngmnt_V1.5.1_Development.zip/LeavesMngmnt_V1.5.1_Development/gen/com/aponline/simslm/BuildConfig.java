/** Automatically generated file. DO NOT MODIFY */
package com.aponline.simslm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}