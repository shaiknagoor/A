package com.aponline.simslm;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import com.aponline.simslm.database.DBAdapter;

import android.content.Context;
import android.os.Environment;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class CommonFunctions 
{
	static DBAdapter db;

	public static void loadSpinnerData(Context context,String query, Spinner spinner)
	{
		try
		{
			db=new DBAdapter(context);
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void loadSpinnerSetSelectedItem(Context context,String query, Spinner spinner)
	{
		try
		{
			db=new DBAdapter(context);
			db.open(); 
			ArrayList<String> lables =db.getSpinnerData(query);
			db.close();
			ArrayAdapter<String> spinnerArrayAdapter= new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item,lables); 
			spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(spinnerArrayAdapter);
			//spinner.setSelection(spinnerArrayAdapter.getPosition(selection));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void writeLog(String className,String methodName,String strLog) 
	{

		try 
		{
			boolean isNewFile = false;
			String Dir = Environment.getExternalStorageDirectory().getPath()+ "/PPS/ErrorLog/"+className+"/";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHH");
			String FileNameFormate = dateFormat.format(new Date());
			String FileName = Dir + "/"+methodName+"_" + FileNameFormate +".txt";

			SimpleDateFormat logTimeFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
			String logTime = logTimeFormat.format(new Date());
			File dir = new File(Dir);
			if (!dir.exists()) 
			{
				dir.mkdirs();
			}
			File logFile = new File(FileName);
			if (!logFile.exists())
			{
				isNewFile = true;
				logFile.createNewFile();
			}
			FileOutputStream fOut;
			OutputStreamWriter myOutWriter;
			fOut = new FileOutputStream(logFile, true);
			myOutWriter = new OutputStreamWriter(fOut);
			if (isNewFile)
			{
				myOutWriter.append(logTime + "\n" + strLog);
			} 
			else 
			{
				myOutWriter.append("\n" + logTime + "\n" + strLog);
			}
			myOutWriter.flush();
			myOutWriter.close();
		} 
		catch (Exception ex)
		{

		}
	}
//	public static boolean validateAadharNumber(String aadharNumber)
//	{
//		Pattern aadharPattern = Pattern.compile("\\d{12}");
//		boolean isValidAadhar = aadharPattern.matcher(aadharNumber).matches();
//		if(isValidAadhar)
//		{
//			isValidAadhar = VerhoeffAlgorithm.validateVerhoeff(aadharNumber);
//		}
//		return isValidAadhar;
//	} 
}
