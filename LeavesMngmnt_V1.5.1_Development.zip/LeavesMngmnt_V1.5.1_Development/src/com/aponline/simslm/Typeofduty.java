package com.aponline.simslm;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class Typeofduty extends Activity implements OnItemSelectedListener,ServerResponseListener,SmsListener
{
	Spinner dutysp;
	LinearLayout ll_opt,schoolcodell,ll_fromdate,ll_todate,ll_noofdays,venuell;
	private int mYear;
	private int mMonth;
	private int mDay;
	ImageView fromdatepickduty,datepicktoduty;
	TextView fromdatedutytv,todatedutytv,noofdaysdutytv,Teachernametv,resendotp,mobtv;
	Button submit_btn_duty,user_submit_btn_otp,logoutbtnduty;
	ArrayList<String> holidaylist;
	EditText reasondutyet,venueet,schoolcode,otpet;
	StringBuilder TypeofLleaveData;
	String otpcheck,treasuryIdstr,LeaveApplyFromDatestr,LeaveApplyToDatestr,Noofdaysstr,resonForLeavestr,LeaveTypestr,SubTypeLeavestr,venuestr,deputationCodestr;
	SmsReceiver receiver=new SmsReceiver();
	HashMap<String,String> dutyhm;
	String temp ="";


	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.typeduty);

		try
		{


			dutysp=(Spinner)findViewById(R.id.dutysp);
			schoolcodell=(LinearLayout)findViewById(R.id.schoolcodell);
			((Spinner)findViewById(R.id.dutysp)).setOnItemSelectedListener(this);			Teachernametv=(TextView)findViewById(R.id.Teachernametv);
			resendotp=(TextView)findViewById(R.id.resendotp);
			Teachernametv.setText(WebserviceCall.Schoolinfolist.get("TEACHERNAME").toString());
			ll_opt=(LinearLayout)findViewById(R.id.ll_opt);
			final Calendar c = Calendar.getInstance();
			mYear = c.get(Calendar.YEAR);
			mMonth = c.get(Calendar.MONTH);
			mDay = c.get(Calendar.DAY_OF_MONTH);
			fromdatedutytv=(TextView)findViewById(R.id.fromdatedutytv);
			todatedutytv=(TextView)findViewById(R.id.todatedutytv);
			fromdatepickduty=(ImageView)findViewById(R.id.fromdatepickduty);
			datepicktoduty=(ImageView)findViewById(R.id.datepicktoduty);
			noofdaysdutytv=(TextView)findViewById(R.id.noofdaysdutytv);
			submit_btn_duty=(Button)findViewById(R.id.submit_btn_duty);
			user_submit_btn_otp=(Button)findViewById(R.id.user_submit_btn_otp);
			ll_fromdate=(LinearLayout)findViewById(R.id.ll_fromdate);
			ll_todate=(LinearLayout)findViewById(R.id.ll_todate);
			ll_noofdays=(LinearLayout)findViewById(R.id.ll_noofdays);
			venuell=(LinearLayout)findViewById(R.id.venuell);
			reasondutyet=(EditText)findViewById(R.id.reasondutyet);
			otpet=(EditText)findViewById(R.id.otpet);
			venueet=(EditText)findViewById(R.id.venueet);
			schoolcode=(EditText)findViewById(R.id.schoolcode);

			mobtv = (TextView)findViewById(R.id.mob_tv);		


			TextView scroll = (TextView) this.findViewById(R.id.marque_scrolling_text);
			scroll.setSelected(true);			Initialviews();
			//	todate.setText(new StringBuilder().append(mDay).append("/").append(mMonth+ 1).append("/").append(mYear));
			//		holidaylist=new ArrayList<String>();
			//		holidaylist.add("11/11/2017");
			//		holidaylist.add("12/11/2017");
			//		holidaylist.add("19/11/2017");
			//		holidaylist.add("26/11/2017");
			//		holidaylist.add("03/12/2017");
			//		holidaylist.add("09/12/2017");
			//		holidaylist.add("10/12/2017");
			//		holidaylist.add("17/12/2017");
			//		holidaylist.add("24/12/2017");
			//		holidaylist.add("25/12/2017");
			//		holidaylist.add("31/12/2017");
			//		holidaylist.add("07/01/2018");
			//		holidaylist.add("13/01/2018");
			//		holidaylist.add("14/01/2018");
			//		holidaylist.add("15/01/2018");
			//		holidaylist.add("21/01/2018");
			//		holidaylist.add("26/01/2018");
			//		holidaylist.add("28/01/2018");
			//		holidaylist.add("10/02/2018");
			//		holidaylist.add("11/02/2018");
			//		holidaylist.add("18/02/2018");
			//		holidaylist.add("25/02/2018");

			logoutbtnduty=(Button)findViewById(R.id.logoutbtnduty);
			logoutbtnduty.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{
					logoutFunction();

				}
			});
			fromdatepickduty.setOnClickListener(new OnClickListener() 
			{

				@TargetApi(Build.VERSION_CODES.HONEYCOMB)
				@SuppressLint("NewApi")
				@Override
				public void onClick(View v) 
				{
					DatePickerDialog fromDatePicker=new DatePickerDialog(Typeofduty.this, new OnDateSetListener() 
					{

						@Override
						public void onDateSet(DatePicker view, int year, int monthOfYear,
								int dayOfMonth) 
						{

							todatedutytv.setText("");
							noofdaysdutytv.setText("");

							if((monthOfYear+1)<10)
							{
								if(dayOfMonth>=10)
								{
									fromdatedutytv.setText(dayOfMonth+"/"+"0"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(fromdatedutytv.getText().toString()))
									{
										fromdatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
								else
								{
									fromdatedutytv.setText("0"+dayOfMonth+"/"+"0"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(fromdatedutytv.getText().toString()))
									{
										fromdatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
							}
							else {
								if(dayOfMonth>=10)
								{
									fromdatedutytv.setText(dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(fromdatedutytv.getText().toString()))
									{
										fromdatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
								else
								{
									fromdatedutytv.setText("0"+dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(fromdatedutytv.getText().toString()))
									{
										fromdatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
							}
						}
					}, mYear,mMonth,mDay);
					fromDatePicker.show();
					Calendar a=Calendar.getInstance();
					a.add(Calendar.MONTH,-1);
					Date d=a.getTime();
					fromDatePicker.getDatePicker().setMinDate(d.getTime());
					//fromDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());

				}
			});


			datepicktoduty.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{
					DatePickerDialog fromDatePicker=new DatePickerDialog(Typeofduty.this, new OnDateSetListener() {

						@Override
						public void onDateSet(DatePicker view, int year, int monthOfYear,
								int dayOfMonth) 
						{

							if((monthOfYear+1)<10)
							{
								if(dayOfMonth>=10)
								{
									if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
									{
										AlertDialogs("Information!!", "Select From Date");
										return;
									}

									todatedutytv.setText(dayOfMonth+"/"+"0"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(todatedutytv.getText().toString()))
									{
										todatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
									check(fromdatedutytv.getText().toString(),todatedutytv.getText().toString());
								}
								else
								{

									if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
									{
										AlertDialogs("Information!!", "Select From Date");
										return;
									}
									todatedutytv.setText("0"+dayOfMonth+"/"+"0"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(todatedutytv.getText().toString()))
									{
										todatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
									check(fromdatedutytv.getText().toString(),todatedutytv.getText().toString());
								}
							}
							else {
								if(dayOfMonth>=10)
								{
									if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
									{
										AlertDialogs("Information!!", "Select From Date");
										return;
									}
									todatedutytv.setText(dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(todatedutytv.getText().toString()))
									{
										todatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
									check(fromdatedutytv.getText().toString(),todatedutytv.getText().toString());
								}
								else
								{
									if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
									{
										AlertDialogs("Information!!", "Select From Date");
										return;
									}
									todatedutytv.setText("0"+dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(todatedutytv.getText().toString()))
									{
										todatedutytv.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
									check(fromdatedutytv.getText().toString(),todatedutytv.getText().toString());
								}
							}
						}


					}, mYear,mMonth,mDay);
					fromDatePicker.show();
					Calendar a=Calendar.getInstance();
					a.add(Calendar.MONTH,-1);
					Date d=a.getTime();
					fromDatePicker.getDatePicker().setMinDate(d.getTime());
					//fromDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());

				}
			});

			submit_btn_duty.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{
					if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("--SELECT--"))
					{
						AlertDialogs("Information!!", " Please Select Duty Type");
						((Spinner)findViewById(R.id.dutysp)).requestFocus();
						return;
					}
					if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("On Duty"))
					{
						if(reasondutyet.getText().toString().trim().equalsIgnoreCase(""))
						{
							//AlertDialogs("", "Enter Reason");
							reasondutyet.setError("Enter Reason");
							reasondutyet.requestFocus();
							return;
						}
						if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Select From Date");

							//	fromdatepick.setError("Select From Date");
							fromdatepickduty.requestFocus();
							return;
						}
						if(todatedutytv.getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Select To Date");

							//	fromdatepick.setError("Select From Date");
							datepicktoduty.requestFocus();
							return;
						}
						else
						{
							LeaveApplyFromDatestr=fromdatedutytv.getText().toString();
							LeaveApplyToDatestr=todatedutytv.getText().toString();
							Noofdaysstr=noofdaysdutytv.getText().toString();
							venuestr="0";
							deputationCodestr="0";
							SubTypeLeavestr=dutyhm.get(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString());

						}

					}
					if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("Training"))
					{
						if(venueet.getText().toString().equalsIgnoreCase(""))
						{


							venueet.setError("Enter Venue Details");
							venueet.requestFocus();
							return;
						}
						if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Select From Date");

							//	fromdatepick.setError("Select From Date");
							fromdatepickduty.requestFocus();
							return;
						}
						if(todatedutytv.getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Select To Date");

							//	fromdatepick.setError("Select From Date");
							datepicktoduty.requestFocus();
							return;
						}
						if(reasondutyet.getText().toString().trim().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Enter Reason");
							reasondutyet.requestFocus();
							return;
						}

						else
						{
							Noofdaysstr=noofdaysdutytv.getText().toString();
							LeaveApplyFromDatestr=fromdatedutytv.getText().toString();
							LeaveApplyToDatestr=todatedutytv.getText().toString();
							venuestr=venueet.getText().toString().trim();
							deputationCodestr="0";
							SubTypeLeavestr=dutyhm.get(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString());			
						}
					}
					if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("Deputation"))
					{
						if(schoolcode.getText().toString().equalsIgnoreCase(""))
						{
							schoolcode.setError("Enter Deputation School Code");
							schoolcode.requestFocus();
							return;
						}
						if(schoolcode.getText().toString().length()<11)
						{
							schoolcode.setError("Enter Deputation School Code Correctly");
							schoolcode.requestFocus();
							return;
						}
						if(fromdatedutytv.getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Select From Date");

							//	fromdatepick.setError("Select From Date");
							fromdatepickduty.requestFocus();
							return;
						}
						if(todatedutytv.getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Select To Date");

							//	fromdatepick.setError("Select From Date");
							datepicktoduty.requestFocus();
							return;
						}



						if(reasondutyet.getText().toString().trim().equalsIgnoreCase(""))
						{
							AlertDialogs("", "Enter Reason");
							reasondutyet.requestFocus();
							return;
						}
						else
						{
							Noofdaysstr=noofdaysdutytv.getText().toString();
							LeaveApplyFromDatestr=fromdatedutytv.getText().toString();
							LeaveApplyToDatestr=todatedutytv.getText().toString();
							venuestr="0";
							deputationCodestr=schoolcode.getText().toString().trim();
							SubTypeLeavestr=dutyhm.get(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString());
						}
					}
					//				if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("OD"))
					//				{
					//					AlertDialogs1("Information", "Successfully Submitted");
					//					return;
					//
					//				}
					if(schoolcodell.getVisibility()==View.VISIBLE)
					{
						if (isNetworkAvailable(Typeofduty.this)) 
						{
							RequestServer request=new RequestServer(Typeofduty.this);
							request.addParam("SchoolCode", deputationCodestr);
							request.addParam("deviceVersion", HomeData.sAppVersion);
							request.ProccessRequest(Typeofduty.this, "deputationSchools");

						}
						else
						{
							AlertDialogs("Information!!","Check The Internet Connection");
							return;
						}
					}
					else if(isNetworkAvailable(Typeofduty.this))
					{
						final Dialog dialog = new Dialog(Typeofduty.this);
						dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
						dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
						dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
						Animation shake = AnimationUtils.loadAnimation(Typeofduty.this, R.anim.zoom_out);
						//					if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("OD"))
						//					{
						//						dialog.setContentView(R.layout.alert_dialog_details2);
						//						dialog.setCancelable(false);
						//						//	Animation shake = AnimationUtils.loadAnimation(Typeofduty.this, R.anim.zoom_out);
						//						TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
						//						msgTv.setText("Do you want to submit ??");
						//
						//					}
						//					else
						//					{
						dialog.setContentView(R.layout.alert_dialog_details);
						dialog.setCancelable(false);

						TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
						TextView msgTv1=(TextView)dialog.findViewById(R.id.message_textView1);
						TextView msgTv2=(TextView)dialog.findViewById(R.id.message_textView2);
						msgTv.setText(fromdatedutytv.getText().toString());
						msgTv1.setText(todatedutytv.getText().toString());
						msgTv2.setText(noofdaysdutytv.getText().toString());
						//			}
						//msgTv.setText(fromdatedutytv.getText().toString()+" to "+todatedutytv.getText().toString()+"."+" Total "+noofdaysdutytv.getText().toString()+"days");
						Button yes =(Button)dialog.findViewById(R.id.ok_button); 
						Button no =(Button)dialog.findViewById(R.id.cancel_button); 
						yes.startAnimation(shake);
						no.startAnimation(shake);

						yes.setOnClickListener(new View.OnClickListener() 
						{
							@Override
							public void onClick(View v)
							{
								dialog.dismiss();

								RequestServer request=new RequestServer(Typeofduty.this);
								request.addParam("teacherCode", Login.UserName);
								request.ProccessRequest(Typeofduty.this, "getOtp");
								//					
								return;
							}
						}); 
						no.setOnClickListener(new View.OnClickListener()
						{

							@Override
							public void onClick(View v) 
							{
								dialog.dismiss();
								return;

							}
						});
						if(!dialog.isShowing())
							dialog.show();

					}
					else
					{
						AlertDialogs("Information!!","Check The Internet Connection");
						return;
					}
					
					
				

					//				if(isNetworkAvailable(Typeofduty.this))
					//				{
					//
					//
					//				}
					//				else
					//				{
					//					AlertDialogs("Information!!","Check The Internet Connection");
					//					return;
					//				}



					//	AlertDialogs("Leave Details", fromdate.getText().toString()+" to "+todate.getText().toString()+"."+" Total "+noofdaystv.getText().toString()+"days");

				}
				
			});

			user_submit_btn_otp.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					if(otpet.getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("", "Enter OTP");
						otpet.requestFocus();
						return;
					}
					if(!(otpet.getText().toString().trim().equalsIgnoreCase(otpcheck)))
					{
						AlertDialogs("", "OTP is Invalid");
						otpet.requestFocus();
						return;
					}

					if(isNetworkAvailable(Typeofduty.this))
					{

						RequestServer request=new RequestServer(Typeofduty.this);
						request.addParam("treasuryId", Login.UserName);
						request.addParam("LeaveApplyFromDate", LeaveApplyFromDatestr);
						request.addParam("LeaveApplyToDate", LeaveApplyToDatestr);
						request.addParam("Noofdays", Noofdaysstr);
						request.addParam("resonForLeave", reasondutyet.getText().toString().trim());
						request.addParam("LeaveType", "2");
						request.addParam("SubTypeLeave", SubTypeLeavestr);
						request.addParam("venue", venuestr);
						request.addParam("deputationCode", deputationCodestr);
						request.addParam("deviceVersion", HomeData.sAppVersion);
						request.ProccessRequest(Typeofduty.this, "ApplyLeave");
						//AlertDialogs1("Information", "Successfully Submitted");


						return;



					}




					//	AlertDialogs("Leave Details", fromdate.getText().toString()+" to "+todate.getText().toString()+"."+" Total "+noofdaystv.getText().toString()+"days");

				}
			});

			resendotp.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{

					if(isNetworkAvailable(Typeofduty.this))
					{
						otpet.setText("");
						RequestServer request=new RequestServer(Typeofduty.this);
						request.addParam("teacherCode", Login.UserName);
						request.ProccessRequest(Typeofduty.this, "getOtp");
					}
				}
			});

		}
		catch(Exception e)
		{

		}



	}
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,long id)
	{

		try 
		{
			switch (parent.getId()) 
			{
			case R.id.dutysp:
				String dp=parent.getSelectedItem().toString().trim();  
				if(!dp.equalsIgnoreCase("--SELECT--"))
				{
					if(dp.equalsIgnoreCase("Deputation"))
					{
						schoolcodell.setVisibility(0);
						ll_fromdate.setVisibility(0);
						ll_todate.setVisibility(0);
						ll_noofdays.setVisibility(0);
						venuell.setVisibility(8);

					}
					if(dp.equalsIgnoreCase("On Duty"))
					{
						schoolcodell.setVisibility(8);
						ll_fromdate.setVisibility(0);
						ll_todate.setVisibility(0);
						ll_noofdays.setVisibility(0);
						venuell.setVisibility(8);
					}
					if(dp.equalsIgnoreCase("Training"))
					{
						schoolcodell.setVisibility(8);
						ll_fromdate.setVisibility(0);
						ll_todate.setVisibility(0);
						ll_noofdays.setVisibility(0);
						venuell.setVisibility(0);
					}

				}

				break;

			default:
				break;
			}
		}
		catch (Exception e) 
		{
			//	CommonFunctions.writeLog("MappingSeedFarm", "onItemSelected", e.getMessage());
			e.printStackTrace();
		}
	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) 
	{

	}
	SimpleDateFormat dfDate  = new SimpleDateFormat("dd/MM/yyyy");
	private  void check(String fromdate,String todate) 
	{
		String result = "NO";

		try 
		{
			if(dfDate.parse(fromdate).before(dfDate.parse(todate)))
			{
				daysBetween();
			}
			else if(dfDate.parse(fromdate).equals(dfDate.parse(todate)))
			{
				//numofdays="1";
				noofdaysdutytv.setText("1");
			}
			else
			{
				AlertDialogs("Information!!","To-Date must be greater than From-Date");
				this.todatedutytv.setText("");
				//result = "GREATER"; //If start date is after the end date
				return;
			}
		}
		catch (java.text.ParseException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return ;

	}

	public  void daysBetween() 
	{
		String fromd =fromdatedutytv.getText().toString();
		String tod =todatedutytv.getText().toString();
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date fdate=null;
		try 
		{
			fdate = format.parse(fromd);
		} 
		catch (java.text.ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar fromdc = Calendar.getInstance();
		fromdc.setTime(fdate);
		Date tdate=null;
		try 
		{
			tdate = format.parse(tod);
		} 
		catch (java.text.ParseException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar todc = Calendar.getInstance();
		todc.setTime(tdate);
		Calendar sDate = fromdc;
		Calendar eDate = todc;

		long daysBetween = 0;
		while (sDate.before(eDate))
		{

			sDate.add(Calendar.DAY_OF_MONTH, 1);
			daysBetween++;


		}

		int holidayscount = 0;          // the date in question
		for (int i = 0; i <WebserviceCall.holidaylist.size(); i++)
		{
			try 
			{
				if(format.parse(WebserviceCall.holidaylist.get(i)).after(fdate) && format.parse(WebserviceCall.holidaylist.get(i)).before(tdate))
				{
					holidayscount++;
				}
				int fromdateholiday=format.parse(WebserviceCall.holidaylist.get(i)).compareTo(fdate);
				int todateholiday=format.parse(WebserviceCall.holidaylist.get(i)).compareTo(tdate);
				if(fromdateholiday==0||todateholiday==0)
				{
					holidayscount++;
				}
			} 
			catch (java.text.ParseException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		noofdaysdutytv.setText(String.valueOf(daysBetween+1-holidayscount));
		return;
	}


	public void Initialviews()
	{
		ArrayList<String> dutysplist=new ArrayList<String>();
		dutyhm = new HashMap<String,String>();
		//	hashSet.addAll(WebserviceCall.userList);
		dutysplist.clear();
		dutysplist.add("--SELECT--");
		for(int i=0;i<WebserviceCall.spduty.size();i++)
		{
			HashMap<String,String> temp=WebserviceCall.spduty.get(i);
			String a=temp.get("SUBLEAVETYPENAME");
			dutysplist.add(a);
			dutyhm.put(temp.get("SUBLEAVETYPENAME"),temp.get("SUBLEAVETYPEID"));

		}


		ArrayAdapter<String> dutyAdapter = new ArrayAdapter<String>(Typeofduty.this,android.R.layout.simple_spinner_item,dutysplist);
		dutyAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		((Spinner)findViewById(R.id.dutysp)).setAdapter(dutyAdapter);
	}

	public Boolean holidayselectcheck(String date)
	{
		for (int i = 0; i <WebserviceCall.holidaylist.size(); i++)
		{
			if(date.equalsIgnoreCase(WebserviceCall.holidaylist.get(i)) )
			{
				return true;
			}

		}
		return false;

	}

	private void logoutFunction() 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				Intent i=	new Intent(Typeofduty.this,Login.class);
				startActivity(i);
				Typeofduty.this.finish();
				finishAffinity();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}

	@SuppressLint("NewApi")
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void AlertDialogs1(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				Typeofduty.this.finish();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void Success(String response, String methodName) 
	{
		if(methodName.equalsIgnoreCase("getOtp"))
		{
			submit_btn_duty.setVisibility(8);
			ll_opt.setVisibility(0);
			temp= WebserviceCall.Schoolinfolist.get("MOBILENO").toString().substring(6, 10);
			mobtv.setText("Registered Mobile Number :  "+"******"+temp);
			user_submit_btn_otp.setVisibility(0);
			((Spinner)findViewById(R.id.dutysp)).setEnabled(false);
			fromdatepickduty.setClickable(false);
			datepicktoduty.setClickable(false);
			reasondutyet.setEnabled(false);
			schoolcode.setEnabled(false);
			venueet.setEnabled(false);
			resendotp.setVisibility(0);
			otpcheck=response;
			IntentFilter filter = new IntentFilter();
			filter.addAction("android.provider.Telephony.SMS_RECEIVED");
			registerReceiver(receiver, filter); 

			SmsReceiver.bindListener(Typeofduty.this,"");

		}
		else if(methodName.equalsIgnoreCase("deputationSchools"))
		{
			if(isNetworkAvailable(Typeofduty.this))
			{
				final Dialog dialog = new Dialog(Typeofduty.this);
				dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
				dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
				dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
				Animation shake = AnimationUtils.loadAnimation(Typeofduty.this, R.anim.zoom_out);
				//					if(((Spinner)findViewById(R.id.dutysp)).getSelectedItem().toString().equalsIgnoreCase("OD"))
				//					{
				//						dialog.setContentView(R.layout.alert_dialog_details2);
				//						dialog.setCancelable(false);
				//						//	Animation shake = AnimationUtils.loadAnimation(Typeofduty.this, R.anim.zoom_out);
				//						TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
				//						msgTv.setText("Do you want to submit ??");
				//
				//					}
				//					else
				//					{
				dialog.setContentView(R.layout.alert_dialog_details);
				dialog.setCancelable(false);

				TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
				TextView msgTv1=(TextView)dialog.findViewById(R.id.message_textView1);
				TextView msgTv2=(TextView)dialog.findViewById(R.id.message_textView2);
				msgTv.setText(fromdatedutytv.getText().toString());
				msgTv1.setText(todatedutytv.getText().toString());
				msgTv2.setText(noofdaysdutytv.getText().toString());
				//			}
				//msgTv.setText(fromdatedutytv.getText().toString()+" to "+todatedutytv.getText().toString()+"."+" Total "+noofdaysdutytv.getText().toString()+"days");
				Button yes =(Button)dialog.findViewById(R.id.ok_button); 
				Button no =(Button)dialog.findViewById(R.id.cancel_button); 
				yes.startAnimation(shake);
				no.startAnimation(shake);

				yes.setOnClickListener(new View.OnClickListener() 
				{
					@Override
					public void onClick(View v)
					{
						dialog.dismiss();

						RequestServer request=new RequestServer(Typeofduty.this);
						request.addParam("teacherCode", Login.UserName);
						request.ProccessRequest(Typeofduty.this, "getOtp");
						//					
						return;
					}
				}); 
				no.setOnClickListener(new View.OnClickListener()
				{

					@Override
					public void onClick(View v) 
					{
						dialog.dismiss();
						return;

					}
				});
				if(!dialog.isShowing())
					dialog.show();

			}
			else
			{
				AlertDialogs("Information!!","Check The Internet Connection");
				return;
			}
		}
		else
		{
			AlertDialogs1("Information", response);
		}

	}
	@Override
	public void Fail(String response, String methodName) 
	{
		if(methodName.equalsIgnoreCase("getOtp"))
		{
			AlertDialogs("Information!!",response);
		}
		else
		{
			submit_btn_duty.setVisibility(0);
			ll_opt.setVisibility(8);
			user_submit_btn_otp.setVisibility(8);
			((Spinner)findViewById(R.id.dutysp)).setEnabled(true);
			fromdatepickduty.setClickable(true);
			datepicktoduty.setClickable(true);
			reasondutyet.setEnabled(true);
			schoolcode.setEnabled(true);
			venueet.setEnabled(true);
			resendotp.setVisibility(8);
			otpet.setText("");
			noofdaysdutytv.setText("");
			AlertDialogs("Information!!",response);
		}

	}
	@Override
	public void NetworkNotAvail()
	{
		AlertDialogs("Information!!","Network not Available, Please check and try again!!");

	}
	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(Typeofduty.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					Typeofduty.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;

	}
	@Override
	public void messageReceived(String messageText)
	{
		Typeofduty.this.unregisterReceiver(receiver);
		String msg=messageText;
		msg=msg.replaceAll("[^\\d.]", "");
		otpet.setText(msg);

	}





}
