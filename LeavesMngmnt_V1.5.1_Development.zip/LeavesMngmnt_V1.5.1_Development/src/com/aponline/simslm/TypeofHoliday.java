package com.aponline.simslm;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.logging.Handler;

import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.net.Uri;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class TypeofHoliday extends Activity implements ServerResponseListener,SmsListener
{

	ProgressDialog progressDialog;
	Handler mHandler;
	private int mYear;
	private int mMonth;
	private int mDay;
	String numofdays,otpcheck;
	Button user_submit_btn,user_submit_btn_otp,logoutbtnleave;
	TextView date,fromdate,noofdaystv,Teachernametv,resendotp,mobtv;
	ImageView datepick,datepickto;
	ArrayList<String> holidaylist;
	EditText reasonholiday,otpet;
	LinearLayout ll_opt;
	SmsReceiver receiver=new SmsReceiver();
	HashMap<String,String> holidayhm;
	String temp ="";

	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.typeholiday);

		try
		{


			final Calendar c = Calendar.getInstance();
			mYear = c.get(Calendar.YEAR);
			mMonth = c.get(Calendar.MONTH);
			mDay = c.get(Calendar.DAY_OF_MONTH);
			date=(TextView)findViewById(R.id.date);
			ll_opt=(LinearLayout)findViewById(R.id.ll_opt);
			user_submit_btn_otp=(Button)findViewById(R.id.user_submit_btn_otp);
			otpet=(EditText)findViewById(R.id.otpet);
			datepick=(ImageView)findViewById(R.id.datepick);
			reasonholiday=(EditText)findViewById(R.id.reasonholiday);
			user_submit_btn=(Button)findViewById(R.id.user_submit_btn);
			resendotp=(TextView)findViewById(R.id.resendotp);
			Teachernametv=(TextView)findViewById(R.id.Teachernametv);

			mobtv = (TextView)findViewById(R.id.mob_tv);		

			Teachernametv.setText(WebserviceCall.Schoolinfolist.get("TEACHERNAME").toString());
			TextView scroll = (TextView) this.findViewById(R.id.marque_scrolling_text);
			scroll.setSelected(true);
			Initialviews();

			//	todate.setText(new StringBuilder().append(mDay).append("/").append(mMonth+ 1).append("/").append(mYear));
			date.setText(new StringBuilder().append(mDay).append("/").append(mMonth+ 1).append("/").append(mYear));
			//	StringBuilder holicheck=new StringBuilder().append(mDay).append("/").append(mMonth+ 1).append("/").append(mYear);
			if(holidayselectcheck(date.getText().toString()))
			{
				date.setText("");
				AlertDialogs("Information!!", "Today is Holiday. You don't need to Apply for Today");
				//return;
			}

			logoutbtnleave=(Button)findViewById(R.id.logoutbtnleave);
			logoutbtnleave.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{
					logoutFunction();

				}
			});

			datepick.setOnClickListener(new OnClickListener() 
			{

				@TargetApi(Build.VERSION_CODES.HONEYCOMB)
				@SuppressLint("NewApi")
				@Override
				public void onClick(View v) 
				{
					DatePickerDialog fromDatePicker=new DatePickerDialog(TypeofHoliday.this, new OnDateSetListener() 
					{

						@Override
						public void onDateSet(DatePicker view, int year, int monthOfYear,
								int dayOfMonth) 
						{
							//						todate.setText("");
							//						noofdaystv.setText("");

							if((monthOfYear+1)<10)
							{
								if(dayOfMonth>=10)
								{
									date.setText(dayOfMonth+"/"+"0"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(date.getText().toString()))
									{
										date.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
								else
								{
									date.setText("0"+dayOfMonth+"/"+"0"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(date.getText().toString()))
									{
										date.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
							}
							else {
								if(dayOfMonth>=10)
								{
									date.setText(dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(date.getText().toString()))
									{
										date.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
								else
								{
									date.setText("0"+dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
									if(holidayselectcheck(date.getText().toString()))
									{
										date.setText("");
										AlertDialogs("Information!!", "Selected Date is Holiday");
										return;
									}
								}
							}
						}
					}, mYear,mMonth,mDay);
					fromDatePicker.show();
					fromDatePicker.getDatePicker().setMinDate(System.currentTimeMillis());

				}
			});



			user_submit_btn.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{
					if(((Spinner)findViewById(R.id.leavesp)).getSelectedItem().toString().equalsIgnoreCase("--SELECT--"))
					{
						AlertDialogs("Information!!", " Please Select Holiday Type");
						((Spinner)findViewById(R.id.leavesp)).requestFocus();
						return;
					}
					if(date.getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("", "Select Date");

						//	fromdatepick.setError("Select From Date");
						date.requestFocus();
						return;
					}
					if(reasonholiday.getText().toString().trim().equalsIgnoreCase(""))
					{
						AlertDialogs("", "Enter Reason");
						reasonholiday.requestFocus();
						return;
					}


					if(isNetworkAvailable(TypeofHoliday.this))
					{
						final Dialog dialog = new Dialog(TypeofHoliday.this);
						dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
						dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
						dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
						dialog.setContentView(R.layout.alert_dialog_details2);
						dialog.setCancelable(false);
						Animation shake = AnimationUtils.loadAnimation(TypeofHoliday.this, R.anim.zoom_out);
						TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
						//				TextView msgTv1=(TextView)dialog.findViewById(R.id.message_textView1);
						//				TextView msgTv2=(TextView)dialog.findViewById(R.id.message_textView2);
						msgTv.setText("Do you want to Submit ??");
						//				msgTv1.setText(todate.getText().toString());
						//				msgTv2.setText(noofdaystv.getText().toString());
						//msgTv.setText(fromdate.getText().toString()+" to "+todate.getText().toString()+"."+" Total "+noofdaystv.getText().toString()+"days");
						Button yes =(Button)dialog.findViewById(R.id.ok_button); 
						Button no =(Button)dialog.findViewById(R.id.cancel_button); 
						yes.startAnimation(shake);
						no.startAnimation(shake);

						yes.setOnClickListener(new View.OnClickListener() 
						{
							@Override
							public void onClick(View v)
							{
								dialog.dismiss();

								RequestServer request=new RequestServer(TypeofHoliday.this);
								request.addParam("teacherCode", Login.UserName);

								request.ProccessRequest(TypeofHoliday.this, "getOtp");
								//AlertDialogs1("Information", "Successfully Submitted");
								return;
							}
						});   
						no.setOnClickListener(new View.OnClickListener()
						{

							@Override
							public void onClick(View v) 
							{
								dialog.dismiss();
								return;

							}
						});
						if(!dialog.isShowing())
							dialog.show();
					}
					else
					{
						AlertDialogs("Information!!","Check The Internet Connection");
						return;
					}




					//	AlertDialogs("Leave Details", fromdate.getText().toString()+" to "+todate.getText().toString()+"."+" Total "+noofdaystv.getText().toString()+"days");

				}
			});

			user_submit_btn_otp.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					if(otpet.getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("", "Enter OTP");
						otpet.requestFocus();
						return;
					}
					if(!(otpet.getText().toString().trim().equalsIgnoreCase(otpcheck)))
					{
						AlertDialogs("", "OTP is Invalid");
						otpet.requestFocus();
						return;
					}

					if(isNetworkAvailable(TypeofHoliday.this))
					{
						RequestServer request=new RequestServer(TypeofHoliday.this);
						request.addParam("treasuryId", Login.UserName);
						request.addParam("LeaveApplyFromDate", date.getText().toString());
						request.addParam("LeaveApplyToDate", date.getText().toString());
						request.addParam("Noofdays", "1");
						request.addParam("resonForLeave", reasonholiday.getText().toString().trim());
						request.addParam("LeaveType", "3");
						request.addParam("SubTypeLeave", holidayhm.get(((Spinner)findViewById(R.id.leavesp)).getSelectedItem().toString()));
						request.addParam("venue", "0");
						request.addParam("deputationCode", "0");
						request.addParam("deviceVersion", HomeData.sAppVersion);
						request.ProccessRequest(TypeofHoliday.this, "ApplyLeave");
						return;



					}
					else
					{
						AlertDialogs("Information!!","Check The Internet Connection");
						return;
					}

				}
			});

			resendotp.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{

					if(isNetworkAvailable(TypeofHoliday.this))
					{
						otpet.setText("");
						RequestServer request=new RequestServer(TypeofHoliday.this);
						request.addParam("teacherCode", Login.UserName);
						request.ProccessRequest(TypeofHoliday.this, "getOtp");
					}
				}
			});

		}
		catch(Exception e)
		{

		}



	}

	public void Initialviews()
	{
		ArrayList<String> holisplist=new ArrayList<String>();
		holidayhm = new HashMap<String,String>();
		//	hashSet.addAll(WebserviceCall.userList);
		holisplist.clear();
		holisplist.add("--SELECT--");
		for(int i=0;i<WebserviceCall.spholiday.size();i++)
		{
			HashMap<String,String> temp=WebserviceCall.spholiday.get(i);
			String a=temp.get("SUBLEAVETYPENAME");
			holisplist.add(a);
			holidayhm.put(temp.get("SUBLEAVETYPENAME"),temp.get("SUBLEAVETYPEID"));

		}

		ArrayAdapter<String> holiAdapter = new ArrayAdapter<String>(TypeofHoliday.this,android.R.layout.simple_spinner_item,holisplist);
		holiAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
		((Spinner)findViewById(R.id.leavesp)).setAdapter(holiAdapter);
	}

	public Boolean holidayselectcheck(String date)
	{
		for (int i = 0; i <WebserviceCall.holidaylist.size(); i++)
		{
			if(date.equalsIgnoreCase(WebserviceCall.holidaylist.get(i)) )
			{
				return true;
			}

		}
		return false;

	}
	@SuppressLint("NewApi")
	private void logoutFunction() 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				Intent i=	new Intent(TypeofHoliday.this,Login.class);
				startActivity(i);
				TypeofHoliday.this.finish();
				finishAffinity();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	public void AlertDialogs1(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				TypeofHoliday.this.finish();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void Success(String response, String methodName) 
	{
		if(methodName.equalsIgnoreCase("getOtp"))
		{
			user_submit_btn.setVisibility(8);
			ll_opt.setVisibility(0);
			temp= WebserviceCall.Schoolinfolist.get("MOBILENO").toString().substring(6, 10);
			mobtv.setText("Registered Mobile Number :  "+"******"+temp);
			user_submit_btn_otp.setVisibility(0);
			((Spinner)findViewById(R.id.leavesp)).setEnabled(false);
			datepick.setClickable(false);
			reasonholiday.setEnabled(false);
			resendotp.setVisibility(0);
			otpcheck=response;
			IntentFilter filter = new IntentFilter();
			filter.addAction("android.provider.Telephony.SMS_RECEIVED");
			registerReceiver(receiver, filter); 

			SmsReceiver.bindListener(TypeofHoliday.this,"");
		}
		else
		{
			AlertDialogs1("Information", response);
		}

	}
	@Override
	public void Fail(String response, String methodName) 
	{
		if(methodName.equalsIgnoreCase("getOtp"))
		{
			AlertDialogs("Information!!",response);
		}
		else
		{
			user_submit_btn.setVisibility(0);
			ll_opt.setVisibility(8);
			user_submit_btn_otp.setVisibility(8);
			((Spinner)findViewById(R.id.leavesp)).setEnabled(true);
			datepick.setClickable(true);
			reasonholiday.setEnabled(true);
			resendotp.setVisibility(8);
			//otpcheck=response;
			otpet.setText("");
			AlertDialogs("Information!!",response);
		}

	}
	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information!!","Network not Available, Please check and try again!!");


	}
	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(TypeofHoliday.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					TypeofHoliday.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;

	}
	@Override
	public void messageReceived(String messageText)
	{
		TypeofHoliday.this.unregisterReceiver(receiver);
		String msg=messageText;
		msg=msg.replaceAll("[^\\d.]", "");
		otpet.setText(msg);

	}



}
