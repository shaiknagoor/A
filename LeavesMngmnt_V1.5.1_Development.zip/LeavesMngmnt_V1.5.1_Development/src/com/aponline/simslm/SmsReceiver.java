package com.aponline.simslm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.text.TextUtils;

public class SmsReceiver extends BroadcastReceiver {
    
    private static SmsListener mListener;
    private static String receiverString;
    
    public SmsReceiver() {
		super();
		
	}

	@Override
    public void onReceive(Context context, Intent intent) 
	{
        Bundle data  = intent.getExtras();
      
        if (data != null) 
        {
        	

            final Object[] pdusArr = (Object[]) data.get("pdus");

            for (int i = 0; i < pdusArr.length; i++) 
            {

                SmsMessage currentMessage = SmsMessage.createFromPdu((byte[]) pdusArr[i]);
                String senderNum = currentMessage.getDisplayOriginatingAddress();
                String message = currentMessage.getDisplayMessageBody();
               

                if (!TextUtils.isEmpty(message) && senderNum.contains("VM-APONLN")) 
                { //If message received is from required number.
                    //If bound a listener interface, callback the overriden method.
                    if (mListener != null)
                    {
                        mListener.messageReceived(message);
                    }
                }
            }
        }

    }

    public static void bindListener(SmsListener listener, String sender) {
        mListener = listener;
        receiverString = sender;
    }
}
