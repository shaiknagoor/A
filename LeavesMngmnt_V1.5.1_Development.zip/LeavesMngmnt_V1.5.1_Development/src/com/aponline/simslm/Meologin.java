package com.aponline.simslm;

import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;import android.os.storage.OnObbStateChangeListener;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class Meologin extends AppCompatActivity implements ServerResponseListener
{
	
	EditText username,password;
	String userstr,passstr;
	Button submit;
	public static String meouserid;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.meologin);
		try
		{
		username = (EditText)findViewById(R.id.usernameEt);
		password = (EditText)findViewById(R.id.passwordEt);
		
		submit = (Button)findViewById(R.id.submit_btn);
		
		
		submit.setOnClickListener(new OnClickListener() 
		{
			
			@Override
			public void onClick(View v) 
			{
				
				userstr = username.getText().toString();
				passstr = password.getText().toString();
				
				
				if (userstr.equalsIgnoreCase("")) 
				{
					username.setError("Enter Username");
					username.requestFocus();
					return;
				}
				
				if (userstr.length()<9) 
				{
					username.setError("Enter Correct Username");
					username.requestFocus();
					return;
				}
			
				
				if (passstr.equalsIgnoreCase("")) 
				{
					password.setError("Enter Passsword");
					password.requestFocus();
					return;
					
				}
				RequestServer request=new RequestServer(Meologin.this);
				meouserid=userstr;
				request.addParam("userName",userstr);
				request.addParam("passWord",passstr);
				request.addParam("deviceVersion", HomeData.sAppVersion);
				//	request.addParam("deviceVersion", HomeData.sAppVersion);
				request.ProccessRequest(Meologin.this, "loginService");
//				
				
				
				
				
			}
		});
		
		
		}
		catch(Exception e)
		{
			
		}
		
		
	}

	@Override
	public void Success(String response, String methodName) 
	{
		Intent i =  new Intent(Meologin.this,Meodashboard.class);
		startActivity(i);
		finish();
	}

	@Override
	public void Fail(String response, String methodName) {
		
		AlertDialogs("Information!!",response);
	}

	@Override
	public void NetworkNotAvail() {
		
		AlertDialogs("Information!!","Network not Available, Please check and try again!!");
	}

	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(Meologin.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					Meologin.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;
		
	}
	
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

}
