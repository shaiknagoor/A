package com.aponline.simslm;

public interface SmsListener {
	 public void messageReceived(String messageText);
}
