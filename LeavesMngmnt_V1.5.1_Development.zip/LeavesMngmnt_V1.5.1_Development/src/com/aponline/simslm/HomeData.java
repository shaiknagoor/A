package com.aponline.simslm;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

public class HomeData 
{

	public static String DeviceID;
	public static int sApiLevel = 0;
	public static String sAppVersion;
	public static String sAppVersionName;
	public static Boolean sCheckMeEnable;
	public static String sCountry;
	public static String sCountrySortName;
	public static String sDeviceId;
	public static String sModel;
	public static String url;
	public static String sOSVersion;
	public static String current_date;
	public static String UserID;
	public static String Password;
	public static String smUpgrade_Content;
	public static int smUpgrade_count;
	public static boolean smUpgrade_displayflag;
	public static String smUpgrade_header;
	public static String smAppSettingVersion;
	public static HashMap<String, String> mDashBoardData;
	
	public static String rErrorMsgFromServer="";
	public static String rSuccessMsgFromServer="";
	public static Boolean isServiceRunning=false;
	public static boolean isSamsung=false;
	public static int Task=1;
	public static ArrayList<HashMap<String, String>> studentAttendanceList=new ArrayList<HashMap<String,String>>();
	public static ArrayList<HashMap<String, String>> teacherAttendanceList=new ArrayList<HashMap<String,String>>();

	
	static
	{
		mDashBoardData=new HashMap<String, String>();

		current_date="";
		smUpgrade_displayflag = false;
	}

	public static void readDeviceDetails(Context paramContext)
	{
		String str1 = ((TelephonyManager)paramContext.getApplicationContext().getSystemService("phone")).getDeviceId();
		if (str1 == null)
			str1 = Settings.Secure.getString(paramContext.getApplicationContext().getContentResolver(), "android_id");
		if (str1 == null)
			str1 = "NODeviceID";
		String str2 = Build.VERSION.RELEASE;
		String str3 = Build.MODEL;
		int i = Integer.parseInt(Build.VERSION.SDK);
		SharedPreferences localSharedPreferences = paramContext.getApplicationContext().getSharedPreferences("user_settings", 0);
		String str4 = localSharedPreferences.getString("UserLocation", "");
		String str5 = localSharedPreferences.getString("UserLocationSortName", "");
		//	    if ((str4.equalsIgnoreCase("")) && (smLocationUrl != null) && (smLocationUrl.length() > 0))
		//	      getCountry_LocationUrl(paramContext, smLocationUrl);
		PackageManager localPackageManager = paramContext.getApplicationContext().getPackageManager();
		String str6 = "";
		try
		{
			str6 = ""+localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 128).versionCode;
			sAppVersionName =localPackageManager.getPackageInfo(paramContext.getApplicationContext().getPackageName(), 128).versionName;
			sApiLevel = i;
			Log.d("API LEVEL", Integer.toString(sApiLevel));
			sAppVersion = str6;
			Log.d("APP VERSION",sAppVersion);
			sDeviceId =str1;////"355102031349991";//"355102031292092";/
			Log.d("Device ID",sDeviceId);           
			sOSVersion = str2;  
			Log.d("OS Version",sOSVersion);    
			sModel = str3;
			Log.d("MODEL",sModel);
			if(sModel.equalsIgnoreCase("SM-T116IR"))
			{
				isSamsung=true;
			}
			sCountry = str4;
			Log.d("COUNTRY",sCountry);
			sCountrySortName = str5;
			Log.d("COUNTRY SORT", sCountrySortName);   
			
			return;
		}
		catch (Exception localException)
		{
			while (true)
				localException.printStackTrace();
		}
	}
}
