package com.aponline.simslm;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Dialogs1 
{
	public static void AlertDialogs(Context context, String title, String msg)
    {
			AlertDialog.Builder adb = new AlertDialog.Builder(context);
			adb.setTitle(title);
			adb.setMessage(msg);			
			adb.setPositiveButton("Ok", 
				new DialogInterface.OnClickListener()
				{				
					public void onClick(DialogInterface dialog, int which) 
					{	
						return;
					}
			    });
			adb.show();
    }


}
