package com.aponline.simslm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.aponline.simslm.adapter.EmployeeListAdpter2;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;

public class Balanceleave extends AppCompatActivity 
{
	TextView cltv,eltv,hpltv,mltv,pltv,ccltv,copmtv;
	ArrayList<HashMap<String,String>> data;
	ListView list;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.leavebalance);


		list=(ListView)findViewById(R.id.balancelistview);



		data=new ArrayList<HashMap<String,String>>();

		HashMap<String ,String> temp1 = null;
		for(int i=0;i<WebserviceCall.spleavedata.size();i++)
		{
			temp1=new HashMap<String, String>();
			HashMap<String,String> temp=WebserviceCall.spleavedata.get(i);
			String a=temp.get("SUBLEAVETYPENAME");

			String b=temp.get("SUBLEAVETYPEID");
			for(Map.Entry<String,String> entry : WebserviceCall.BalanceLeave.entrySet()) 
			{
				if(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M"))
				{


					if(!(b.equalsIgnoreCase("7") || b.equalsIgnoreCase("9") || b.equalsIgnoreCase("16") || b.equalsIgnoreCase("17") || b.equalsIgnoreCase("21") )  )
					{
						if(b.equalsIgnoreCase(entry.getKey()))
						{
							temp1.put("name",a);
							temp1.put("balance",entry.getValue());

						}
					}
				}
				else
				{
					if(!(b.equalsIgnoreCase("8") || b.equalsIgnoreCase("19")|| b.equalsIgnoreCase("18"))  )
					{
						if(b.equalsIgnoreCase(entry.getKey()))
						{
							temp1.put("name",a);
							temp1.put("balance",entry.getValue());

						}
					}


				}


			}
			if(temp1.size()>0)
			{
				data.add(temp1);
			}
		}



		EmployeeListAdpter2 adapter=new EmployeeListAdpter2(getBaseContext(), data);
		list.setAdapter(adapter);



	}

	@SuppressLint("NewApi")
	@Override
	public void onBackPressed()
	{
		Intent i=new Intent(Balanceleave.this,HomePage.class);

		startActivity(i);
		finish();
		
	}


}
