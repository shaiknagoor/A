package com.aponline.simslm;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aponline.simslm.database.DBAdapter;
import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;


@SuppressLint("NewApi")
public class Login extends AppCompatActivity implements ServerResponseListener
{
	ProgressDialog progressDialog;
//	Handler mHandler;
	EditText userNameET,passwordET;
	TextView resendotp,meologin,login_versionTv;
	Button getoptbtn,submitbtn;
	String checkotp;
	public static String UserName,Password;
//	int count=0;
	//	CheckConnection conn_obj;
	View paramView;
	DBAdapter db;
	ViewFlipper vf;


	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.login);


		if (Build.VERSION.SDK_INT >= 23)
		{
			requestPermissions();

		}
		else
		{

			HomeData.readDeviceDetails(this);
			userNameET=(EditText)findViewById(R.id.usernameEt);
			passwordET=(EditText)findViewById(R.id.password);
			getoptbtn=(Button)findViewById(R.id.getoptbtn);
			submitbtn=(Button)findViewById(R.id.submitbtn);
			resendotp=(TextView)findViewById(R.id.resendotp);
			meologin = (TextView)findViewById(R.id.meotextview);
			login_versionTv= (TextView)findViewById(R.id.login_versionTv);
			
			login_versionTv.setText("V : " + HomeData.sAppVersionName);

			//		vf=(ViewFlipper) findViewById(R.id.view_flipper);
			//		vf.startFlipping();
			
			meologin.setOnClickListener(new OnClickListener() 
			{
				
				@Override
				public void onClick(View v) 
				{
					Intent i = new Intent(Login.this,Meologin.class);
					startActivity(i);
					
					
				}
			});
			
			getoptbtn.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{
					//								if(isNetworkAvailable(Login.this))
					//								{
					//									RequestServer request=new RequestServer(Login.this);
					//				//					request.addParam("teacherCode", UserName);
					//				//					request.addParam("deviceVersion", HomeData.sAppVersion);
					//									//	request.addParam("deviceVersion", HomeData.sAppVersion);
					//									request.ProccessRequest(Login.this, "leaveMaster");
					//								}


					UserName=userNameET.getText().toString();

					HomeData.UserID=UserName;

					if(UserName.equalsIgnoreCase(""))
					{

						userNameET.setError("Enter Treasury Id");
						userNameET.requestFocus();
						return;
					}
					if(UserName.length()<7)
					{
						userNameET.setError("Enter Correct Treasury ID");
						userNameET.requestFocus();
						return;
					}
					if(isNetworkAvailable(Login.this))
					{
						RequestServer request=new RequestServer(Login.this);
						request.addParam("teacherCode", UserName);
						request.addParam("deviceVersion", HomeData.sAppVersion);
						//	request.addParam("deviceVersion", HomeData.sAppVersion);
						request.ProccessRequest(Login.this, "getTeacherInfo");
					}
					else
					{
						AlertDialogs("Information!!","Check The Internet Connection");
						return;
					}

				}
			});

			submitbtn.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{


					UserName=userNameET.getText().toString();
					Password=passwordET.getText().toString();
					HomeData.UserID=UserName;
					HomeData.Password=Password;


					if(Password.equalsIgnoreCase(""))
					{

						passwordET.setError("Enter OTP");
						passwordET.requestFocus();
						return;
					}

					if(Password.equalsIgnoreCase(checkotp))
					{
						if(WebserviceCall.Schoolinfolist.get("ISLEAVE").equalsIgnoreCase("N"))
						{
							Intent i=new Intent(Login.this,LeaveAccount.class);
							startActivity(i);
							Login.this.finish();
						}
						else
						{
							Intent i=new Intent(Login.this,HomePage.class);
							startActivity(i);
							Login.this.finish();
						}


					}
					else
					{
						AlertDialogs("Information!!","Invalid OTP");
					}





				}
			});
		}

		


	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}

	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
	private void requestPermissions()
	{
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.INTERNET))
			permissionsNeeded.add("InterNet");
		if (!addPermission(permissionsList, Manifest.permission.READ_PHONE_STATE))
			permissionsNeeded.add("Read State");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
			permissionsNeeded.add("Access network state");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_WIFI_STATE))
			permissionsNeeded.add("Access wifi state");
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("Write enternal Contacts");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("camera");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
			permissionsNeeded.add("Access Fine Location");
		if (!addPermission(permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
			permissionsNeeded.add("Access Coarse Location");
		if (!addPermission(permissionsList, Manifest.permission.READ_SMS))
			permissionsNeeded.add("Access Read SMS");
		if (!addPermission(permissionsList, Manifest.permission.SEND_SMS))
			permissionsNeeded.add("Access send SMS");
		if (!addPermission(permissionsList, Manifest.permission.RECEIVE_SMS))
			permissionsNeeded.add("Access Receive SMS");


		if (permissionsList.size() > 0)
		{
			if (permissionsNeeded.size() > 0)
			{
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				try
				{

					ActivityCompat.requestPermissions(Login.this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
					return;

				} catch (Resources.NotFoundException e) {
					e.printStackTrace();
				}

				return;
			}
			ActivityCompat.requestPermissions(this,permissionsList.toArray(new String[permissionsList.size()]),REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
			return;
		}

		//HomeData.readDeviceDetails(this);
		//		db=new DBAdapter(this);
		//		try 
		//		{
		//			db.createDataBase();
		//			db.close();
		//		} 
		//		catch (IOException e) 
		//		{
		//			e.printStackTrace();
		//			db.close();
		//		}
		//		db.close();

	}
	@SuppressLint("Override")
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		switch (requestCode)
		{
		case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
		{
			Map<String, Integer> perms = new HashMap<String, Integer>();
			// Initial
			perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.READ_SMS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.SEND_SMS, PackageManager.PERMISSION_GRANTED);
			perms.put(Manifest.permission.RECEIVE_SMS, PackageManager.PERMISSION_GRANTED);
			// Fill with results
			for (int i = 0; i < permissions.length; i++)
				perms.put(permissions[i], grantResults[i]);
			// Check for ACCESS_FINE_LOCATION
			if (perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
					&& perms.get(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED)



			{
				// All Permissions Granted
				//				db=new DBAdapter(this);
				//				try 
				//				{
				//					db.createDataBase();
				//
				//
				//					db.close();
				//				} 
				//				catch (IOException e) 
				//				{
				//
				//					e.printStackTrace();
				//					db.close();
				//				}
				HomeData.readDeviceDetails(this);
				userNameET=(EditText)findViewById(R.id.usernameEt);
				passwordET=(EditText)findViewById(R.id.password);
				getoptbtn=(Button)findViewById(R.id.getoptbtn);
				submitbtn=(Button)findViewById(R.id.submitbtn);
				resendotp=(TextView)findViewById(R.id.resendotp);
				meologin = (TextView)findViewById(R.id.meotextview);
				login_versionTv= (TextView)findViewById(R.id.login_versionTv);
				
				login_versionTv.setText("V : " + HomeData.sAppVersionName);

				//		vf=(ViewFlipper) findViewById(R.id.view_flipper);
				//		vf.startFlipping();
				
				meologin.setOnClickListener(new OnClickListener() 
				{
					
					@Override
					public void onClick(View v) 
					{
						Intent i = new Intent(Login.this,Meologin.class);
						startActivity(i);
						
					}
				});
				
				getoptbtn.setOnClickListener(new OnClickListener() 
				{

					@Override
					public void onClick(View v)
					{
						//								if(isNetworkAvailable(Login.this))
						//								{
						//									RequestServer request=new RequestServer(Login.this);
						//				//					request.addParam("teacherCode", UserName);
						//				//					request.addParam("deviceVersion", HomeData.sAppVersion);
						//									//	request.addParam("deviceVersion", HomeData.sAppVersion);
						//									request.ProccessRequest(Login.this, "leaveMaster");
						//								}


						UserName=userNameET.getText().toString();

						HomeData.UserID=UserName;

						if(UserName.equalsIgnoreCase(""))
						{

							userNameET.setError("Enter Treasury Id");
							userNameET.requestFocus();
							return;
						}
						if(UserName.length()<7)
						{
							userNameET.setError("Enter Correct Treasury ID");
							userNameET.requestFocus();
							return;
						}
						if(isNetworkAvailable(Login.this))
						{
							RequestServer request=new RequestServer(Login.this);
							request.addParam("teacherCode", UserName);
							request.addParam("deviceVersion", HomeData.sAppVersion);
							//	request.addParam("deviceVersion", HomeData.sAppVersion);
							request.ProccessRequest(Login.this, "getTeacherInfo");
						}
						else
						{
							AlertDialogs("Information!!","Check The Internet Connection");
							return;
						}

					}
				});

				submitbtn.setOnClickListener(new OnClickListener() 
				{

					@Override
					public void onClick(View v)
					{


						UserName=userNameET.getText().toString();
						Password=passwordET.getText().toString();
						HomeData.UserID=UserName;
						HomeData.Password=Password;


						if(Password.equalsIgnoreCase(""))
						{

							passwordET.setError("Enter OTP");
							passwordET.requestFocus();
							return;
						}

						if(Password.equalsIgnoreCase(checkotp))
						{
							if(WebserviceCall.Schoolinfolist.get("ISLEAVE").equalsIgnoreCase("N"))
							{
								Intent i=new Intent(Login.this,LeaveAccount.class);
								startActivity(i);
								Login.this.finish();
							}
							else
							{
								Intent i=new Intent(Login.this,HomePage.class);
								startActivity(i);
								Login.this.finish();
							}


						}
						else
						{
							AlertDialogs("Information!!","Invalid OTP");
						}





					}
				});

			}
			else
			{
				// Permission Denied
				Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
				.show();
			}
		}
		break;
		default:
			super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		}
	}
	private boolean addPermission(List<String> permissionsList, String permission)
	{
		if (ContextCompat.checkSelfPermission(this,permission) != PackageManager.PERMISSION_GRANTED)
		{
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this,permission))
				return false;
		}
		return true;
	}
	public static boolean createDirIfNotExists(String path) 
	{
		boolean ret = true;

		File file = new File(path);
		if (!file.exists()) 
		{
			if (!file.mkdirs()) 
			{
				ret = false;
			}
		}
		return ret;
	}







	@Override
	public void Fail(String response, String methodName) 
	{
		if(response==null||response.equalsIgnoreCase(""))
		{
			AlertDialogs("Information!!","Data not found, Please try again !!");
		}
		else
		{
			AlertDialogs("Information!!",response);
		}

	}

	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information!!","Network not Available, Please check and try again!!");
	}

	@Override
	public void AppUpdate()
	{
		final Dialog dialog = new Dialog(Login.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					Login.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;

	}

	@Override
	public void Success(String response,String methodname) 
	{
		if(methodname.equalsIgnoreCase("getTeacherInfo"))
		{
			if(isNetworkAvailable(Login.this))
			{
				RequestServer request=new RequestServer(Login.this);
				//				request.addParam("teacherCode", UserName);
				//				request.addParam("deviceVersion", HomeData.sAppVersion);
				//	request.addParam("deviceVersion", HomeData.sAppVersion);
				request.ProccessRequest(Login.this, "holidayMaster");
				return;
			}
			else
			{
				AlertDialogs("Information!!","Check The Internet Connection");
				return;
			}
		}
		if(methodname.equalsIgnoreCase("holidayMaster"))
		{
			if(isNetworkAvailable(Login.this))
			{
				RequestServer request=new RequestServer(Login.this);
				//				request.addParam("teacherCode", UserName);
				//				request.addParam("deviceVersion", HomeData.sAppVersion);
				//	request.addParam("deviceVersion", HomeData.sAppVersion);
				request.ProccessRequest(Login.this, "leaveMaster");
				return;
			}
			else
			{
				AlertDialogs("Information!!","Check The Internet Connection");
				return;
			}
		}


		else
		{
			if(WebserviceCall.Schoolinfolist.get("ISLEAVE").equalsIgnoreCase("Y"))
			{
				Intent i=new Intent(Login.this,HomePage.class);
				startActivity(i);
				Login.this.finish();
			}
			else
			{
				Intent i=new Intent(Login.this,LeaveAccount.class);
				startActivity(i);
				//Login.this.finish();
			}
			
//			SectionMapping
			
			//			passwordET.setVisibility(0);
			//			submitbtn.setVisibility(0);
			//			getoptbtn.setVisibility(8);
			//			resendotp.setVisibility(0);
			//			userNameET.setEnabled(false);
			//			checkotp=WebserviceCall.Schoolinfolist.get("OTP");
		}

	}
	



}






