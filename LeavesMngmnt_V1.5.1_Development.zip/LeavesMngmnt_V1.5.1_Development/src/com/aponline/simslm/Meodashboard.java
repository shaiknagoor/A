package com.aponline.simslm;


import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.simslm.adapter.EmployeeListAdpter;
import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class Meodashboard extends AppCompatActivity implements ServerResponseListener
{

	Button  logoutbtnaccount;
	ListView employee_list;
	ArrayList<HashMap<String,String>> Employees;

	@SuppressWarnings("null")
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.meo_dashboard);
		try
		{
			Bundle b=	getIntent().getExtras();
			Employees=WebserviceCall.teacherlist;
			String tempcode = null;
			if(b!=null)
			{
				tempcode=b.getString("code");
				if(tempcode!=null )
				{
					if(!(tempcode.equalsIgnoreCase("")))
					{
						if(Employees!=null )
							for (int i = 0; i < Employees.size(); i++) 
							{
								HashMap<String,String>temp=	Employees.get(i);
								String code=temp.get("teacher_code");
								if(code.equalsIgnoreCase(tempcode))
								{
									Employees.remove(temp);
								}

							}
					}
				}
			}
			employee_list = (ListView)findViewById(R.id.employee_list);
			Spinner s=(Spinner)findViewById(R.id.school_list_spinner);
			String a=WebserviceCall.meologintype;
			if(a.equalsIgnoreCase("meologin"))
			{
				((LinearLayout)findViewById(R.id.employee_header)).setVisibility(0);
				((RelativeLayout)findViewById(R.id.listview_ll)).setVisibility(8);
				ArrayAdapter<String> empAdapter = new ArrayAdapter<String>(Meodashboard.this,android.R.layout.simple_spinner_item,WebserviceCall.schoollist);
				//empAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				s.setAdapter(empAdapter);
				if(tempcode!=null )
				{
					if( tempcode.equalsIgnoreCase(""))
					{
						((RelativeLayout)findViewById(R.id.listview_ll)).setVisibility(0);
//						((RelativeLayout)findViewById(R.id.meoschool_ll)).setVisibility(0);
						Employees=WebserviceCall.teacherlist;
						EmployeeListAdpter adapter = new EmployeeListAdpter(Meodashboard.this, Employees);
						employee_list.setAdapter(adapter);
						employee_list.setOnItemClickListener(new OnItemClickListener() {

							@Override
							public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
								String a=((TextView)view.findViewById(R.id.Employeetreasuryid)).getText().toString();
								Intent i=new Intent(Meodashboard.this,Meoconfirmation.class);
								i.putExtra("tresuryid",a);
								
								i.putExtra("TOTALCAS", ((TextView)view.findViewById(R.id.TOTALCAS)).getText().toString());
								i.putExtra("AVAILCAS", ((TextView)view.findViewById(R.id.AVAILCAS)).getText().toString());
								
								i.putExtra("TOTALCL", ((TextView)view.findViewById(R.id.TOTALCL)).getText().toString());
								i.putExtra("AVAILCL", ((TextView)view.findViewById(R.id.AVAILCL)).getText().toString());
								i.putExtra("TOTALEL", ((TextView)view.findViewById(R.id.TOTALEL)).getText().toString());
								i.putExtra("AVAILEL", ((TextView)view.findViewById(R.id.AVAILEL)).getText().toString());
								i.putExtra("TOTALPL", ((TextView)view.findViewById(R.id.TOTALPL)).getText().toString());
								i.putExtra("AVAILPL", ((TextView)view.findViewById(R.id.AVAILPL)).getText().toString());
								i.putExtra("TOTALHPL", ((TextView)view.findViewById(R.id.TOTALHPL)).getText().toString());
								i.putExtra("AVAILHPL", ((TextView)view.findViewById(R.id.AVAILHPL)).getText().toString());
								i.putExtra("TOTALML", ((TextView)view.findViewById(R.id.TOTALML)).getText().toString());
								i.putExtra("AVAILML", ((TextView)view.findViewById(R.id.AVAILML)).getText().toString());
								i.putExtra("TOTALCCL", ((TextView)view.findViewById(R.id.TOTALCCL)).getText().toString());
								i.putExtra("AVAILCCL", ((TextView)view.findViewById(R.id.AVAILCCL)).getText().toString());
								i.putExtra("AVAILCOMPENSACTION", ((TextView)view.findViewById(R.id.AVAILCOMPENSACTION)).getText().toString());
								i.putExtra("TOTALCOMPENSACTION", ((TextView)view.findViewById(R.id.TOTALCOMPENSACTION)).getText().toString());
								
								i.putExtra("GENDER", ((TextView)view.findViewById(R.id.gender)).getText().toString());
								i.putExtra("TOTALABO", ((TextView)view.findViewById(R.id.TOTALABO)).getText().toString());
								i.putExtra("AVAILABO", ((TextView)view.findViewById(R.id.AVAILABO)).getText().toString());
								i.putExtra("TOTALOH", ((TextView)view.findViewById(R.id.TOTALOH)).getText().toString());
								i.putExtra("AVAILOH", ((TextView)view.findViewById(R.id.AVAILOH)).getText().toString());
								i.putExtra("TOTALEOL", ((TextView)view.findViewById(R.id.TOTALEOL)).getText().toString());
								i.putExtra("AVAILEOL", ((TextView)view.findViewById(R.id.AVAILEOL)).getText().toString());
								i.putExtra("TOTALSTU", ((TextView)view.findViewById(R.id.TOTALSTU)).getText().toString());
								i.putExtra("AVAILSTU", ((TextView)view.findViewById(R.id.AVAILSTU)).getText().toString());
								i.putExtra("TOTALLH", ((TextView)view.findViewById(R.id.TOTALLH)).getText().toString());
								i.putExtra("AVAILLH", ((TextView)view.findViewById(R.id.AVAILLH)).getText().toString());
								i.putExtra("TOTALHYS", ((TextView)view.findViewById(R.id.TOTALHYS)).getText().toString());
								i.putExtra("AVAILHYS", ((TextView)view.findViewById(R.id.AVAILHYS)).getText().toString());
								i.putExtra("TOTALVAS", ((TextView)view.findViewById(R.id.TOTALVAS)).getText().toString());
								i.putExtra("AVAILVAS", ((TextView)view.findViewById(R.id.AVAILVAS)).getText().toString());
								i.putExtra("TOTALTUB", ((TextView)view.findViewById(R.id.TOTALTUB)).getText().toString());
								i.putExtra("AVAILTUB", ((TextView)view.findViewById(R.id.AVAILTUB)).getText().toString());
								i.putExtra("TOTALREC", ((TextView)view.findViewById(R.id.TOTALREC)).getText().toString());
								i.putExtra("AVAILREC", ((TextView)view.findViewById(R.id.AVAILREC)).getText().toString());
								
								
								startActivity(i);


							}
						});
					}
				}
			}
			else
			{
				((LinearLayout)findViewById(R.id.employee_header)).setVisibility(0);
				((RelativeLayout)findViewById(R.id.meoschool_ll)).setVisibility(8);


				EmployeeListAdpter adapter = new EmployeeListAdpter(Meodashboard.this, Employees);
				employee_list.setAdapter(adapter);
				employee_list.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
						String a=((TextView)view.findViewById(R.id.Employeetreasuryid)).getText().toString();
						Intent i=new Intent(Meodashboard.this,Meoconfirmation.class);
						i.putExtra("tresuryid",a);
						
						i.putExtra("TOTALCAS", ((TextView)view.findViewById(R.id.TOTALCAS)).getText().toString());
						i.putExtra("AVAILCAS", ((TextView)view.findViewById(R.id.AVAILCAS)).getText().toString());
						
						i.putExtra("TOTALCL", ((TextView)view.findViewById(R.id.TOTALCL)).getText().toString());
						i.putExtra("AVAILCL", ((TextView)view.findViewById(R.id.AVAILCL)).getText().toString());
						i.putExtra("TOTALEL", ((TextView)view.findViewById(R.id.TOTALEL)).getText().toString());
						i.putExtra("AVAILEL", ((TextView)view.findViewById(R.id.AVAILEL)).getText().toString());
						i.putExtra("TOTALPL", ((TextView)view.findViewById(R.id.TOTALPL)).getText().toString());
						i.putExtra("AVAILPL", ((TextView)view.findViewById(R.id.AVAILPL)).getText().toString());
						i.putExtra("TOTALHPL", ((TextView)view.findViewById(R.id.TOTALHPL)).getText().toString());
						i.putExtra("AVAILHPL", ((TextView)view.findViewById(R.id.AVAILHPL)).getText().toString());
						i.putExtra("TOTALML", ((TextView)view.findViewById(R.id.TOTALML)).getText().toString());
						i.putExtra("AVAILML", ((TextView)view.findViewById(R.id.AVAILML)).getText().toString());
						i.putExtra("TOTALCCL", ((TextView)view.findViewById(R.id.TOTALCCL)).getText().toString());
						i.putExtra("AVAILCCL", ((TextView)view.findViewById(R.id.AVAILCCL)).getText().toString());
						i.putExtra("AVAILCOMPENSACTION", ((TextView)view.findViewById(R.id.AVAILCOMPENSACTION)).getText().toString());
						i.putExtra("TOTALCOMPENSACTION", ((TextView)view.findViewById(R.id.TOTALCOMPENSACTION)).getText().toString());
						
						i.putExtra("GENDER", ((TextView)view.findViewById(R.id.gender)).getText().toString());
						i.putExtra("TOTALABO", ((TextView)view.findViewById(R.id.TOTALABO)).getText().toString());
						i.putExtra("AVAILABO", ((TextView)view.findViewById(R.id.AVAILABO)).getText().toString());
						i.putExtra("TOTALOH", ((TextView)view.findViewById(R.id.TOTALOH)).getText().toString());
						i.putExtra("AVAILOH", ((TextView)view.findViewById(R.id.AVAILOH)).getText().toString());
						i.putExtra("TOTALEOL", ((TextView)view.findViewById(R.id.TOTALEOL)).getText().toString());
						i.putExtra("AVAILEOL", ((TextView)view.findViewById(R.id.AVAILEOL)).getText().toString());
						i.putExtra("TOTALSTU", ((TextView)view.findViewById(R.id.TOTALSTU)).getText().toString());
						i.putExtra("AVAILSTU", ((TextView)view.findViewById(R.id.AVAILSTU)).getText().toString());
						i.putExtra("TOTALLH", ((TextView)view.findViewById(R.id.TOTALLH)).getText().toString());
						i.putExtra("AVAILLH", ((TextView)view.findViewById(R.id.AVAILLH)).getText().toString());
						i.putExtra("TOTALHYS", ((TextView)view.findViewById(R.id.TOTALHYS)).getText().toString());
						i.putExtra("AVAILHYS", ((TextView)view.findViewById(R.id.AVAILHYS)).getText().toString());
						
						i.putExtra("TOTALVAS", ((TextView)view.findViewById(R.id.TOTALVAS)).getText().toString());
						i.putExtra("AVAILVAS", ((TextView)view.findViewById(R.id.AVAILVAS)).getText().toString());
						i.putExtra("TOTALTUB", ((TextView)view.findViewById(R.id.TOTALTUB)).getText().toString());
						i.putExtra("AVAILTUB", ((TextView)view.findViewById(R.id.AVAILTUB)).getText().toString());
						i.putExtra("TOTALREC", ((TextView)view.findViewById(R.id.TOTALREC)).getText().toString());
						i.putExtra("AVAILREC", ((TextView)view.findViewById(R.id.AVAILREC)).getText().toString());
						
						
						startActivity(i);
						finish();

					}
				});
			}
			TextView scroll = (TextView) this.findViewById(R.id.marque_scrolling_text);
			scroll.setSelected(true);

			logoutbtnaccount=(Button)findViewById(R.id.logoutbtnaccount);
			logoutbtnaccount.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{
					logoutFunction();

				}
			});


			s.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub

					if(!(arg3==0))
					{
						String a=((TextView)arg1).getText().toString();
						HashMap<String,String> temp=WebserviceCall.schoollmap;
						String schoolcode=temp.get(a);
						RequestServer request=new RequestServer(Meodashboard.this);
						request.addParam("schoolCode", schoolcode);
						request.addParam("deviceVersion", HomeData.sAppVersion);
						//	request.addParam("deviceVersion", "1");
						//	request.addParam("deviceVersion", HomeData.sAppVersion);
						request.ProccessRequest(Meodashboard.this, "SchoolDetailsService");
					}
				}


				@Override
				public void onNothingSelected(AdapterView<?> arg0) {
					// TODO Auto-generated method stub

				}
			});
		}
		catch(Exception e)
		{

		}
	}

	@Override
	public void Success(String response, String methodName) 
	{

		((RelativeLayout)findViewById(R.id.listview_ll)).setVisibility(0);
		Employees=WebserviceCall.teacherlist;
		EmployeeListAdpter adapter = new EmployeeListAdpter(Meodashboard.this, Employees);
		employee_list.setAdapter(adapter);
		employee_list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				String a=((TextView)view.findViewById(R.id.Employeetreasuryid)).getText().toString();
				Intent i=new Intent(Meodashboard.this,Meoconfirmation.class);
				i.putExtra("tresuryid",a);
				
				i.putExtra("TOTALCAS", ((TextView)view.findViewById(R.id.TOTALCAS)).getText().toString());
				i.putExtra("AVAILCAS", ((TextView)view.findViewById(R.id.AVAILCAS)).getText().toString());
				
				i.putExtra("TOTALCL", ((TextView)view.findViewById(R.id.TOTALCL)).getText().toString());
				i.putExtra("AVAILCL", ((TextView)view.findViewById(R.id.AVAILCL)).getText().toString());
				i.putExtra("TOTALEL", ((TextView)view.findViewById(R.id.TOTALEL)).getText().toString());
				i.putExtra("AVAILEL", ((TextView)view.findViewById(R.id.AVAILEL)).getText().toString());
				i.putExtra("TOTALPL", ((TextView)view.findViewById(R.id.TOTALPL)).getText().toString());
				i.putExtra("AVAILPL", ((TextView)view.findViewById(R.id.AVAILPL)).getText().toString());
				i.putExtra("TOTALHPL", ((TextView)view.findViewById(R.id.TOTALHPL)).getText().toString());
				i.putExtra("AVAILHPL", ((TextView)view.findViewById(R.id.AVAILHPL)).getText().toString());
				i.putExtra("TOTALML", ((TextView)view.findViewById(R.id.TOTALML)).getText().toString());
				i.putExtra("AVAILML", ((TextView)view.findViewById(R.id.AVAILML)).getText().toString());
				i.putExtra("TOTALCCL", ((TextView)view.findViewById(R.id.TOTALCCL)).getText().toString());
				i.putExtra("AVAILCCL", ((TextView)view.findViewById(R.id.AVAILCCL)).getText().toString());
				i.putExtra("TOTALCOMPENSACTION", ((TextView)view.findViewById(R.id.TOTALCOMPENSACTION)).getText().toString());
				i.putExtra("AVAILCOMPENSACTION", ((TextView)view.findViewById(R.id.AVAILCOMPENSACTION)).getText().toString());
				i.putExtra("GENDER", ((TextView)view.findViewById(R.id.gender)).getText().toString());
				i.putExtra("TOTALABO", ((TextView)view.findViewById(R.id.TOTALABO)).getText().toString());
				i.putExtra("AVAILABO", ((TextView)view.findViewById(R.id.AVAILABO)).getText().toString());
				i.putExtra("TOTALOH", ((TextView)view.findViewById(R.id.TOTALOH)).getText().toString());
				i.putExtra("AVAILOH", ((TextView)view.findViewById(R.id.AVAILOH)).getText().toString());
				i.putExtra("TOTALEOL", ((TextView)view.findViewById(R.id.TOTALEOL)).getText().toString());
				i.putExtra("AVAILEOL", ((TextView)view.findViewById(R.id.AVAILEOL)).getText().toString());
				i.putExtra("TOTALSTU", ((TextView)view.findViewById(R.id.TOTALSTU)).getText().toString());
				i.putExtra("AVAILSTU", ((TextView)view.findViewById(R.id.AVAILSTU)).getText().toString());
				i.putExtra("TOTALLH", ((TextView)view.findViewById(R.id.TOTALLH)).getText().toString());
				i.putExtra("AVAILLH", ((TextView)view.findViewById(R.id.AVAILLH)).getText().toString());
				i.putExtra("TOTALHYS", ((TextView)view.findViewById(R.id.TOTALHYS)).getText().toString());
				i.putExtra("AVAILHYS", ((TextView)view.findViewById(R.id.AVAILHYS)).getText().toString());
				
				
				i.putExtra("TOTALVAS", ((TextView)view.findViewById(R.id.TOTALVAS)).getText().toString());
				i.putExtra("AVAILVAS", ((TextView)view.findViewById(R.id.AVAILVAS)).getText().toString());
				i.putExtra("TOTALTUB", ((TextView)view.findViewById(R.id.TOTALTUB)).getText().toString());
				i.putExtra("AVAILTUB", ((TextView)view.findViewById(R.id.AVAILTUB)).getText().toString());
				i.putExtra("TOTALREC", ((TextView)view.findViewById(R.id.TOTALREC)).getText().toString());
				i.putExtra("AVAILREC", ((TextView)view.findViewById(R.id.AVAILREC)).getText().toString());
				startActivity(i);
				finish();

			}
		});

	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@SuppressLint("NewApi")
	private void logoutFunction() 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				Intent i=	new Intent(Meodashboard.this,Meologin.class);
				startActivity(i);
				Meodashboard.this.finish();
				finishAffinity();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}

	@Override
	public void Fail(String response, String methodName) {

		AlertDialogs("Information!!",response);
	}

	@Override
	public void NetworkNotAvail() {

		AlertDialogs("Information!!","Network not Available, Please check and try again!!");
	}

	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(Meodashboard.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					Meodashboard.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;

	}
	@Override
	public void onBackPressed()
	{
		confirmDialog("");
		return;
	}

	private void confirmDialog(final String type) 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do You Want To Logout ?");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{

				dialog.dismiss();
				Intent i = new Intent(Meodashboard.this,Meologin.class);
				startActivity(i);
				finish();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}
}
