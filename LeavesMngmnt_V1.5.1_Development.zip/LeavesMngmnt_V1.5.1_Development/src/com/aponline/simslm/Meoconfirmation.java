package com.aponline.simslm;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class Meoconfirmation extends AppCompatActivity implements ServerResponseListener 
{
	String Gender;
	Button  logoutbtnaccount;
	Bundle b;
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.meo_confirmation);
		try
		{
			b=	getIntent().getExtras();
			Gender=b.getString("GENDER");
			if(Gender.equalsIgnoreCase("Male"))
			{
				((LinearLayout)findViewById(R.id.con_maternity_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_pl_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_ccl_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_abortion_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_hys_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_comp_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_reco_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_vas_ll)).setVisibility(0);
//								((EditText)findViewById(R.id.con_cl_nodays)).setText("15");
				//				((EditText)findViewById(R.id.con_spcl_nodays)).setText("7");
				//				((EditText)findViewById(R.id.con_exto_nodays)).setText("1824");
				//				((EditText)findViewById(R.id.con_pl_nodays)).setText("15");
				//				((EditText)findViewById(R.id.con_opho_nodays)).setText("5");
				//				((EditText)findViewById(R.id.con_stu_nodays)).setText("730");
				//				((EditText)findViewById(R.id.con_loc_nodays)).setText("3");
				//				((EditText)findViewById(R.id.con_comp_nodays)).setText("10");
				//				((EditText)findViewById(R.id.con_vas_nodays)).setText("6");
				//				((EditText)findViewById(R.id.con_tub_nodays)).setText("7");
				//								((EditText)findViewById(R.id.con_unio_nodays)).setText("21");

			}
			else
			{
				((LinearLayout)findViewById(R.id.con_pl_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_maternity_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_ccl_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_abortion_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_hys_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_comp_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.con_reco_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.con_vas_ll)).setVisibility(8);
//								((EditText)findViewById(R.id.con_cl_nodays)).setText("20");
				//				((EditText)findViewById(R.id.con_spcl_nodays)).setText("7");
				//				((EditText)findViewById(R.id.con_exto_nodays)).setText("1824");
				//				((EditText)findViewById(R.id.con_ml_nodays)).setText("180");
				//				((EditText)findViewById(R.id.con_abor_nodays)).setText("42");
				//				((EditText)findViewById(R.id.con_opho_nodays)).setText("5");
				//				((EditText)findViewById(R.id.con_stu_nodays)).setText("730");
				//				((EditText)findViewById(R.id.con_ccl_nodays)).setText("60");
				//				((EditText)findViewById(R.id.con_loc_nodays)).setText("3");
				//				((EditText)findViewById(R.id.con_hys_nodays)).setText("45");
				//				((EditText)findViewById(R.id.con_tub_nodays)).setText("14");
				//				((EditText)findViewById(R.id.con_reco_nodays)).setText("21");
				//				((EditText)findViewById(R.id.con_unio_nodays)).setText("21");
			}
			((EditText)findViewById(R.id.con_cl_nodays)).setText(b.getString("TOTALCAS"));
			((EditText)findViewById(R.id.con_cl_avaidays)).setText(b.getString("AVAILCAS"));
			((EditText)findViewById(R.id.con_spcl_nodays)).setText(b.getString("TOTALCL"));
			((EditText)findViewById(R.id.con_spcl_avaidays)).setText(b.getString("AVAILCL"));
			((EditText)findViewById(R.id.con_el_nodays)).setText(b.getString("TOTALEL"));
			((EditText)findViewById(R.id.con_el_avaidays)).setText(b.getString("AVAILEL"));
			((EditText)findViewById(R.id.con_hpl_nodays)).setText(b.getString("TOTALHPL"));
			((EditText)findViewById(R.id.con_hpl_avaidays)).setText(b.getString("AVAILHPL"));
			((EditText)findViewById(R.id.con_pl_nodays)).setText(b.getString("TOTALPL"));
			((EditText)findViewById(R.id.con_pl_avaidays)).setText(b.getString("AVAILPL"));
			((EditText)findViewById(R.id.con_ml_nodays)).setText(b.getString("TOTALML"));
			((EditText)findViewById(R.id.con_ml_avaidays)).setText(b.getString("AVAILML"));
			((EditText)findViewById(R.id.con_ccl_nodays)).setText(b.getString("TOTALCCL"));
			((EditText)findViewById(R.id.con_ccl_avaidays)).setText(b.getString("AVAILCCL"));
			((EditText)findViewById(R.id.con_comp_nodays)).setText(b.getString("TOTALCOMPENSACTION"));
			((EditText)findViewById(R.id.con_comp_avaidays)).setText(b.getString("AVAILCOMPENSACTION"));			
			((EditText)findViewById(R.id.con_abor_nodays)).setText(b.getString("TOTALABO"));
			((EditText)findViewById(R.id.con_abor_avaidays)).setText(b.getString("AVAILABO"));
			((EditText)findViewById(R.id.con_opho_nodays)).setText(b.getString("TOTALOH"));
			((EditText)findViewById(R.id.con_opho_avaidays)).setText(b.getString("AVAILOH"));
			((EditText)findViewById(R.id.con_exto_nodays)).setText(b.getString("TOTALEOL"));
			((EditText)findViewById(R.id.con_exto_avaidays)).setText(b.getString("AVAILEOL"));
			((EditText)findViewById(R.id.con_stu_nodays)).setText(b.getString("TOTALSTU"));
			((EditText)findViewById(R.id.con_stu_avaidays)).setText(b.getString("AVAILSTU"));
			((EditText)findViewById(R.id.con_loc_nodays)).setText(b.getString("TOTALLH"));
			((EditText)findViewById(R.id.con_loc_avaidays)).setText(b.getString("AVAILLH"));
			((EditText)findViewById(R.id.con_hys_nodays)).setText(b.getString("TOTALHYS"));
			((EditText)findViewById(R.id.con_hys_avaidays)).setText(b.getString("AVAILHYS"));
			((EditText)findViewById(R.id.con_vas_nodays)).setText(b.getString("TOTALVAS"));
			((EditText)findViewById(R.id.con_vas_avaidays)).setText(b.getString("AVAILVAS"));
			((EditText)findViewById(R.id.con_tub_nodays)).setText(b.getString("TOTALTUB"));
			((EditText)findViewById(R.id.con_tub_avaidays)).setText(b.getString("AVAILTUB"));
			((EditText)findViewById(R.id.con_reco_nodays)).setText(b.getString("TOTALREC"));
			((EditText)findViewById(R.id.con_reco_avaidays)).setText(b.getString("AVAILREC"));



			TextView scroll = (TextView) this.findViewById(R.id.marque_scrolling_text);
			scroll.setSelected(true);
			((Button)findViewById(R.id.approve_btn_account)).setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v)
				{



					if(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Casual Leave's");
						((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();
						return;
					}

										if(!(Gender.equalsIgnoreCase("Male")))
										{
											if((Double.parseDouble(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString())>20))
											{
												AlertDialogs("Information!!", "No.of Casual Leave's should not be Greater than 20 Days");
												((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();
												return;
											}
											
										}
										
										if(!(Gender.equalsIgnoreCase("Male")))
										{
											if((Double.parseDouble(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString())==0))
											{
												AlertDialogs("Information!!", "No.of Casual Leave's should not be Equal to 0 Days");
												((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();
												return;
											}
											
										}
										
										if((Gender.equalsIgnoreCase("Male")))
										{
											if((Double.parseDouble(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString())>15))
											{
												AlertDialogs("Information!!", "No.of Casual Leave's should not be Greater than 15 Days");
												((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();
												return;
											}
											
										}
										
										if((Gender.equalsIgnoreCase("Male")))
										{
											if((Double.parseDouble(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString())==0))
											{
												AlertDialogs("Information!!", "No.of Casual Leave's should not be Equal to 0 Days");
												((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();
												return;
											}
											
										}

//					if((Double.parseDouble(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString())>15))
//					{
//						AlertDialogs("Information!!", "No.of Casual Leave's should not be Greater than 15 Days");
//						((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();
//						return;
//					}

					if(((EditText)findViewById(R.id.con_cl_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Casual Leave's");
						((EditText)findViewById(R.id.con_cl_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_cl_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_cl_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Casual Leave's Availed < Casual Leave's No.of Days");
						((EditText)findViewById(R.id.con_cl_avaidays)).requestFocus();
						return;
					}



					if(((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Spl. Casual Leave's");
						((EditText)findViewById(R.id.con_spcl_nodays)).requestFocus();
						return;
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString())>12))
						{
							AlertDialogs("Information!!", "No.of Spl. Casual Leave's should not be Greater than 12 Days");
							((EditText)findViewById(R.id.con_spcl_nodays)).requestFocus();
							return;
						}

					}
					
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Spl. Casual Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_spcl_nodays)).requestFocus();
							return;
						}

					}

					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString())>7))
						{
							AlertDialogs("Information!!", "No.of Spl. Casual Leave's should not be Greater than 7 Days");
							((EditText)findViewById(R.id.con_spcl_nodays)).requestFocus();
							return;
						}

					}
					
					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Spl. Casual Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_spcl_nodays)).requestFocus();
							return;
						}

					}
					

					if(((EditText)findViewById(R.id.con_spcl_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Spl. Casual Leave's");
						((EditText)findViewById(R.id.con_spcl_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_spcl_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Spl. Casual Leave's Availed < Spl. Casual Leave's No.of Days");
						((EditText)findViewById(R.id.con_spcl_avaidays)).requestFocus();
						return;
					}

					if(((EditText)findViewById(R.id.con_el_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Earned Leave's");
						((EditText)findViewById(R.id.con_el_nodays)).requestFocus();
						return;
					}
					
					if((Double.parseDouble(((EditText)findViewById(R.id.con_el_nodays)).getText().toString())==0))
					{
						AlertDialogs("Information!!", "No.of Earned Leave's should not be Equal to 0 Days");
						((EditText)findViewById(R.id.con_el_nodays)).requestFocus();
						return;
					}
					
					if(((EditText)findViewById(R.id.con_el_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Earned Leave's");
						((EditText)findViewById(R.id.con_el_avaidays)).requestFocus();
						return;
					}

					if((Double.parseDouble(((EditText)findViewById(R.id.con_el_avaidays)).getText().toString())>300))
					{
						AlertDialogs("Information!!", "No.of Earned Availed Leave's should not be Greater than 300 Days");
						((EditText)findViewById(R.id.con_el_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_el_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_el_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Earned Leave's Availed < Earned Leave's No.of Days");
						((EditText)findViewById(R.id.con_el_avaidays)).requestFocus();
						return;
					}


					if(((EditText)findViewById(R.id.con_hpl_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Half Pay Leave's");
						((EditText)findViewById(R.id.con_hpl_nodays)).requestFocus();
						return;
					}
					
					if((Double.parseDouble(((EditText)findViewById(R.id.con_hpl_nodays)).getText().toString())==0))
					{
						AlertDialogs("Information!!", "No.of Half Pay Leave's should not be Equal to 0 Days");
						((EditText)findViewById(R.id.con_hpl_nodays)).requestFocus();
						return;
					}
					
					if(((EditText)findViewById(R.id.con_hpl_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Half Pay Leave's");
						((EditText)findViewById(R.id.con_hpl_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_hpl_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_hpl_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Half Pay Leave's Availed < Half Pay Leave's No.of Days");
						((EditText)findViewById(R.id.con_hpl_avaidays)).requestFocus();
						return;
					}
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_ml_nodays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Maternity Leave's");
							((EditText)findViewById(R.id.con_ml_nodays)).requestFocus();
							return;
						}
					}
					
					
					if(((EditText)findViewById(R.id.con_exto_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Extra Ordinary Leave's");
						((EditText)findViewById(R.id.con_exto_nodays)).requestFocus();
						return;
					}

					if((Double.parseDouble(((EditText)findViewById(R.id.con_exto_nodays)).getText().toString())>1824))
					{
						AlertDialogs("Information!!", "No.of Extra Ordinary Leave's should not be Greater than 1824 Days");
						((EditText)findViewById(R.id.con_exto_nodays)).requestFocus();
						return;
					}
					
					if((Double.parseDouble(((EditText)findViewById(R.id.con_exto_nodays)).getText().toString())==0))
					{
						AlertDialogs("Information!!", "No.of Extra Ordinary Leave's should not be Equal to 0 Days");
						((EditText)findViewById(R.id.con_exto_nodays)).requestFocus();
						return;
					}

					

					if(((EditText)findViewById(R.id.con_exto_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Extra Ordinay Leave's");
						((EditText)findViewById(R.id.con_exto_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_exto_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_exto_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Extra Ordinary Leave's Availed < Extra Ordinary Leave's No.of Days");
						((EditText)findViewById(R.id.con_exto_avaidays)).requestFocus();
						return;
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_ml_nodays)).getText().toString())>180))
						{
							AlertDialogs("Information!!", "No.of Maternity Leave's should not be Greater than 180 Days");
							((EditText)findViewById(R.id.con_ml_nodays)).requestFocus();
							return;
						}

					}
					
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_ml_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Maternity Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_ml_nodays)).requestFocus();
							return;
						}

					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_ml_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Maternity Leave's");
							((EditText)findViewById(R.id.con_ml_avaidays)).requestFocus();
							return;
						}
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(Double.parseDouble(((EditText)findViewById(R.id.con_ml_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_ml_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Maternity Leave's Availed < Maternity Leave's No.of Days");
							((EditText)findViewById(R.id.con_ml_avaidays)).requestFocus();
							return;
						}
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_abor_nodays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Abortion Leave's");
							((EditText)findViewById(R.id.con_abor_nodays)).requestFocus();
							return;
						}
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_abor_nodays)).getText().toString())>42))
						{
							AlertDialogs("Information!!", "No.of Abortion Leave's should not be Greater than 42 Days");
							((EditText)findViewById(R.id.con_abor_nodays)).requestFocus();
							return;
						}

					}
					
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_abor_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Abortion Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_abor_nodays)).requestFocus();
							return;
						}

					}
					

//					if(!(Gender.equalsIgnoreCase("Male")))
//					{
//						if(((EditText)findViewById(R.id.con_abor_nodays)).getText().toString().equalsIgnoreCase(""))
//						{
//							AlertDialogs("Information!!", "Enter Number of Abortion Leave's");
//							((EditText)findViewById(R.id.con_abor_nodays)).requestFocus();
//							return;
//						}
//					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_abor_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Abortion Leave's");
							((EditText)findViewById(R.id.con_abor_avaidays)).requestFocus();
							return;
						}
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(Double.parseDouble(((EditText)findViewById(R.id.con_abor_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_abor_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Abortion Leave's Availed < Abortion Leave's No.of Days");
							((EditText)findViewById(R.id.con_abor_avaidays)).requestFocus();
							return;
						}
					}

					if(Gender.equalsIgnoreCase("Male"))
					{

						if(((EditText)findViewById(R.id.con_pl_nodays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Paternity Leave's");
							((EditText)findViewById(R.id.con_pl_nodays)).requestFocus();
							return;
						}
					}

					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_pl_nodays)).getText().toString())<15)||(Double.parseDouble(((EditText)findViewById(R.id.con_pl_nodays)).getText().toString())>15))
						{
							AlertDialogs("Information!!", "No.of Paternity Leave's should be Equal to 15 Days");
							((EditText)findViewById(R.id.con_pl_nodays)).requestFocus();
							return;
						}

					}
					
					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_pl_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Paternity Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_pl_nodays)).requestFocus();
							return;
						}

					}



					if(Gender.equalsIgnoreCase("Male"))
					{
						if(((EditText)findViewById(R.id.con_pl_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Paternity Leave's");
							((EditText)findViewById(R.id.con_pl_avaidays)).requestFocus();

							return;
						}
					}


					if(Gender.equalsIgnoreCase("Male"))
					{
						if(Double.parseDouble(((EditText)findViewById(R.id.con_pl_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_pl_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Paternity Leave's Availed < Paternity Leave's No.of Days");
							((EditText)findViewById(R.id.con_pl_avaidays)).requestFocus();
							return;
						}
					}

					if(((EditText)findViewById(R.id.con_opho_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Optional Holiday's");
						((EditText)findViewById(R.id.con_opho_nodays)).requestFocus();
						return;
					}

					if((Double.parseDouble(((EditText)findViewById(R.id.con_opho_nodays)).getText().toString())>5))
					{
						AlertDialogs("Information!!", "No.of Optional Holiday's should not be Greater than 5 Days");
						((EditText)findViewById(R.id.con_opho_nodays)).requestFocus();
						return;
					}
					
					if((Double.parseDouble(((EditText)findViewById(R.id.con_opho_nodays)).getText().toString())==0))
					{
						AlertDialogs("Information!!", "No.of Optional Holiday's should not be Equal to 0 Days");
						((EditText)findViewById(R.id.con_opho_nodays)).requestFocus();
						return;
					}
					
					if(((EditText)findViewById(R.id.con_opho_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Optional Holiday's");
						((EditText)findViewById(R.id.con_opho_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_opho_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_opho_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Optional Holiday's Availed < Optional Holiday's No.of Days");
						((EditText)findViewById(R.id.con_opho_avaidays)).requestFocus();
						return;
					}


					


					if(((EditText)findViewById(R.id.con_stu_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Study Leave's");
						((EditText)findViewById(R.id.con_stu_nodays)).requestFocus();
						return;
					}

					if((Double.parseDouble(((EditText)findViewById(R.id.con_stu_nodays)).getText().toString())>730))
					{
						AlertDialogs("Information!!", "No.of Study Leave's should not be Greater than 730 Days");
						((EditText)findViewById(R.id.con_stu_nodays)).requestFocus();
						return;
					}
					
					if((Double.parseDouble(((EditText)findViewById(R.id.con_stu_nodays)).getText().toString())==0))
					{
						AlertDialogs("Information!!", "No.of Study Leave's should not be Equal to 0 Days");
						((EditText)findViewById(R.id.con_stu_nodays)).requestFocus();
						return;
					}

					if(((EditText)findViewById(R.id.con_stu_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed of Study Leave's");
						((EditText)findViewById(R.id.con_stu_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_stu_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_stu_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Study Leave's Availed < Study Leave's No.of Days");
						((EditText)findViewById(R.id.con_stu_avaidays)).requestFocus();
						return;
					}


					if(((EditText)findViewById(R.id.con_ccl_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Child Care Leave's");
						((EditText)findViewById(R.id.con_ccl_nodays)).requestFocus();
						return;
					}


					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_ccl_nodays)).getText().toString())>60))
						{
							AlertDialogs("Information!!", "No.of Child Care Leave's should not be Greater than 60 Days");
							((EditText)findViewById(R.id.con_ccl_nodays)).requestFocus();
							return;
						}

					}
					
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_ccl_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Child Care Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_ccl_nodays)).requestFocus();
							return;
						}

					}
					

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_ccl_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Child Care Leave's");
							((EditText)findViewById(R.id.con_ccl_avaidays)).requestFocus();
							return;
						}
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(Double.parseDouble(((EditText)findViewById(R.id.con_ccl_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_ccl_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Child Care Leave's Availed < Child Care Leave's No.of Days");
							((EditText)findViewById(R.id.con_ccl_avaidays)).requestFocus();
							return;
						}
					}


					if(((EditText)findViewById(R.id.con_loc_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Local Holiday's");
						((EditText)findViewById(R.id.con_loc_nodays)).requestFocus();
						return;
					}


					if((Double.parseDouble(((EditText)findViewById(R.id.con_loc_nodays)).getText().toString())>3))
					{
						AlertDialogs("Information!!", "No.of Local Holiday's should not be Greater than 3 Days");
						((EditText)findViewById(R.id.con_loc_nodays)).requestFocus();
						return;
					}
					
					if((Double.parseDouble(((EditText)findViewById(R.id.con_loc_nodays)).getText().toString())==0))
					{
						AlertDialogs("Information!!", "No.of Local Holiday's should not be Equal to 0 Days");
						((EditText)findViewById(R.id.con_loc_nodays)).requestFocus();
						return;
					}

					if(((EditText)findViewById(R.id.con_loc_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed of Local Holiday's");
						((EditText)findViewById(R.id.con_loc_avaidays)).requestFocus();
						return;
					}

					if(Double.parseDouble(((EditText)findViewById(R.id.con_loc_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_loc_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Local Holiday's Availed < Local Holiday's No.of Days");
						((EditText)findViewById(R.id.con_loc_avaidays)).requestFocus();
						return;
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_hys_nodays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Hysterectomy Leave's");
							((EditText)findViewById(R.id.con_hys_nodays)).requestFocus();
							return;
						}
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_hys_nodays)).getText().toString())>45))
						{
							AlertDialogs("Information!!", "No.of Hysterectomy Leave's should not be Greater than 45 Days");
							((EditText)findViewById(R.id.con_hys_nodays)).requestFocus();
							return;
						}

					}
					
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_hys_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Hysterectomy Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_hys_nodays)).requestFocus();
							return;
						}

					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_hys_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed of Hysterectomy Leave's");
							((EditText)findViewById(R.id.con_hys_avaidays)).requestFocus();
							return;
						}
					}
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(Double.parseDouble(((EditText)findViewById(R.id.con_hys_nodays)).getText().toString()) < Double.parseDouble(((EditText)findViewById(R.id.con_hys_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Hysterectomy Leave's Availed < Hysterectomy Leave's No.of Days");
							((EditText)findViewById(R.id.con_hys_avaidays)).requestFocus();
							return;
						}
					}
					if(((EditText)findViewById(R.id.con_comp_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Compensatory leave's");
						((EditText)findViewById(R.id.con_comp_nodays)).requestFocus();
						return;
					}
					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_comp_nodays)).getText().toString())>10))
						{
							AlertDialogs("Information!!", "No.of Compensatory Leave's should not be Greater than 10 Days");
							((EditText)findViewById(R.id.con_comp_nodays)).requestFocus();
							return;
						}

					}
					
					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_comp_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Compensatory Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_comp_nodays)).requestFocus();
							return;
						}

					}

					if(Gender.equalsIgnoreCase("Male"))
					{
						if(((EditText)findViewById(R.id.con_comp_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Compensatory Casual leave's");
							((EditText)findViewById(R.id.con_comp_avaidays)).requestFocus();
							return;
						}
					}
					if(Gender.equalsIgnoreCase("Male"))
					{
						if(Double.parseDouble(((EditText)findViewById(R.id.con_comp_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_comp_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Compensatory Casual leave's  Availed < Compensatory Casual leave's  No.of Days");
							((EditText)findViewById(R.id.con_comp_avaidays)).requestFocus();
							return;
						}
					}

					if(Gender.equalsIgnoreCase("Male"))
					{
						if(((EditText)findViewById(R.id.con_vas_nodays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Vasectomy leave's");
							((EditText)findViewById(R.id.con_vas_nodays)).requestFocus();
							return;
						}
					}


					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_vas_nodays)).getText().toString())>6))
						{
							AlertDialogs("Information!!", "No.of Vasectomy Leave's should not be Greater than 6 Days");
							((EditText)findViewById(R.id.con_vas_nodays)).requestFocus();
							return;
						}

					}
					
					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_vas_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Vasectomy Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_vas_nodays)).requestFocus();
							return;
						}

					}


					if(Gender.equalsIgnoreCase("Male"))
					{
						if(((EditText)findViewById(R.id.con_vas_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Vasectomy leave's");
							((EditText)findViewById(R.id.con_vas_avaidays)).requestFocus();
							return;
						}
					}
					if(Gender.equalsIgnoreCase("Male"))
					{
						if(Double.parseDouble(((TextView)findViewById(R.id.con_vas_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_vas_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Vasectomy leave's  Availed < Vasectomy leave's  No.of Days");
							((EditText)findViewById(R.id.con_vas_avaidays)).requestFocus();
							return;
						}
					}


					if(((EditText)findViewById(R.id.con_tub_nodays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter number of Tubectomy leave's");
						((EditText)findViewById(R.id.con_tub_nodays)).requestFocus();
						return;
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_tub_nodays)).getText().toString())>14))
						{
							AlertDialogs("Information!!", "No.of Tubectomy Leave's should not be Greater than 14 Days");
							((EditText)findViewById(R.id.con_tub_nodays)).requestFocus();
							return;
						}

					}
					
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_tub_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Tubectomy Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_tub_nodays)).requestFocus();
							return;
						}

					}

					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_tub_nodays)).getText().toString())>7))
						{
							AlertDialogs("Information!!", "No.of Tubectomy Leave's should not be Greater than 7 Days");
							((EditText)findViewById(R.id.con_tub_nodays)).requestFocus();
							return;
						}

					}
					
					if((Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_tub_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Tubectomy Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_tub_nodays)).requestFocus();
							return;
						}

					}



					if(((EditText)findViewById(R.id.con_tub_avaidays)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Tubectomy leave's");
						((EditText)findViewById(R.id.con_tub_avaidays)).requestFocus();
						return;
					}


					if(Double.parseDouble(((TextView)findViewById(R.id.con_tub_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_tub_avaidays)).getText().toString()))
					{
						AlertDialogs("Information!!", "Tubectomy leave's  Availed < Tubectomy leave's  No.of Days");
						((EditText)findViewById(R.id.con_tub_avaidays)).requestFocus();
						return;
					}

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_reco_nodays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Reconalisation leave's");
							((EditText)findViewById(R.id.con_reco_nodays)).requestFocus();
							return;
						}
					}


					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_reco_nodays)).getText().toString())>21))
						{
							AlertDialogs("Information!!", "No.of Reconalisation Leave's should not be Greater than 21 Days");
							((EditText)findViewById(R.id.con_reco_nodays)).requestFocus();
							return;
						}

					}
					

					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if((Double.parseDouble(((EditText)findViewById(R.id.con_reco_nodays)).getText().toString())==0))
						{
							AlertDialogs("Information!!", "No.of Reconalisation Leave's should not be Equal to 0 Days");
							((EditText)findViewById(R.id.con_reco_nodays)).requestFocus();
							return;
						}

					}




					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(((EditText)findViewById(R.id.con_reco_avaidays)).getText().toString().equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Reconalisation leave's");
							((EditText)findViewById(R.id.con_reco_avaidays)).requestFocus();
							return;
						}
					}
					if(!(Gender.equalsIgnoreCase("Male")))
					{
						if(Double.parseDouble(((TextView)findViewById(R.id.con_reco_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_reco_avaidays)).getText().toString()))
						{
							AlertDialogs("Information!!", "Reconalisation leave's  Availed < Reconalisation leave's  No.of Days");
							((EditText)findViewById(R.id.con_reco_avaidays)).requestFocus();
							return;
						}
					}

					//					if(((EditText)findViewById(R.id.con_unio_avaidays)).getText().toString().equalsIgnoreCase(""))
					//					{
					//						AlertDialogs("Information!!", "Enter Availed Unionbearers leave's");
					//						((EditText)findViewById(R.id.con_unio_avaidays)).requestFocus();
					//						return;
					//					}
					//					
					//					
					//					if(Double.parseDouble(((TextView)findViewById(R.id.con_unio_nodays)).getText().toString())<Double.parseDouble(((EditText)findViewById(R.id.con_unio_avaidays)).getText().toString()))
					//					{
					//						AlertDialogs("Information!!", "Unionbearers leave's Availed < Unionbearers leave's  No.of Days");
					//						((EditText)findViewById(R.id.con_unio_avaidays)).requestFocus();
					//						return;
					//					}
					//					

					if(((LinearLayout)findViewById(R.id.con_pl_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_pl_nodays)).setText("0");
						((EditText)findViewById(R.id.con_pl_avaidays)).setText("0");

					}
					if(((LinearLayout)findViewById(R.id.con_maternity_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_ml_nodays)).setText("0");
						((EditText)findViewById(R.id.con_ml_avaidays)).setText("0");
					}
					if(((LinearLayout)findViewById(R.id.con_ccl_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_ccl_nodays)).setText("0");
						((EditText)findViewById(R.id.con_ccl_avaidays)).setText("0");
					}
					if(((LinearLayout)findViewById(R.id.con_abortion_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_abor_nodays)).setText("0");
						((EditText)findViewById(R.id.con_abor_avaidays)).setText("0");
					}
					if(((LinearLayout)findViewById(R.id.con_hys_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_hys_nodays)).setText("0");
						((EditText)findViewById(R.id.con_hys_avaidays)).setText("0");
					}
					if(((LinearLayout)findViewById(R.id.con_comp_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_comp_nodays)).setText("0");
						((EditText)findViewById(R.id.con_comp_avaidays)).setText("0");
					}
					if(((LinearLayout)findViewById(R.id.con_vas_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_vas_nodays)).setText("0");
						((EditText)findViewById(R.id.con_vas_avaidays)).setText("0");
					}
					if(((LinearLayout)findViewById(R.id.con_reco_ll)).getVisibility()==View.GONE)
					{
						((EditText)findViewById(R.id.con_reco_nodays)).setText("0");
						((EditText)findViewById(R.id.con_reco_avaidays)).setText("0");
					}

					
					confirmDialog("Authenticate");

				}
			});
			logoutbtnaccount=(Button)findViewById(R.id.logoutbtnaccount);
			logoutbtnaccount.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{
					logoutFunction();

				}
			});
		}
		catch(Exception e)
		{

		}
		((EditText)findViewById(R.id.con_cl_nodays)).requestFocus();

	}

	@SuppressLint("NewApi")
	private void logoutFunction() 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				Intent i=	new Intent(Meoconfirmation.this,Meologin.class);
				startActivity(i);
				Meoconfirmation.this.finish();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}
	private void confirmDialog(final String type) 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do You Want To "+type+"?");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				//				StringBuilder	LeavesAccountData=new StringBuilder();
				//				LeavesAccountData.append("<LIST>");
				//				//	LeavesAccountData.append("<HighestClass>"+highestclass.getText().toString()+"</HighestClass>");
				//				LeavesAccountData.append("<TREASURYID>"+b.getString("tresuryid")+"</TREASURYID>");
				//				//LeavesAccountData.append("<TOTALCL>"+((TextView)findViewById(R.id.con_cl_nodays)).getText().toString()+"</TOTALCL>");
				//				LeavesAccountData.append("<AVAILCL>"+((EditText)findViewById(R.id.con_cl_avaidays)).getText().toString()+"</AVAILCL>");
				//				//LeavesAccountData.append("<TOTALEL>"+((TextView)findViewById(R.id.con_el_nodays)).getText().toString()+"</TOTALEL>");
				//				LeavesAccountData.append("<AVAILEL>"+((EditText)findViewById(R.id.con_el_avaidays)).getText().toString()+"</AVAILEL>");
				//				LeavesAccountData.append("<AVAILPL>"+((EditText)findViewById(R.id.con_pl_avaidays)).getText().toString()+"</AVAILPL>");
				//				//LeavesAccountData.append("<TOTALHPL>"+((TextView)findViewById(R.id.con_hpl_nodays)).getText().toString()+"</TOTALHPL>");
				//				LeavesAccountData.append("<AVAILHPL>"+((EditText)findViewById(R.id.con_hpl_avaidays)).getText().toString()+"</AVAILHPL>");
				//				//LeavesAccountData.append("<TOTALML>"+((TextView)findViewById(R.id.con_ml_nodays)).getText().toString()+"</TOTALML>");
				//				LeavesAccountData.append("<AVAILML>"+((EditText)findViewById(R.id.con_ml_avaidays)).getText().toString()+"</AVAILML>");
				//				//LeavesAccountData.append("<TOTALPL>"+((TextView)findViewById(R.id.con_pl_nodays)).getText().toString()+"</TOTALPL>");
				//
				//				LeavesAccountData.append("<TOTALCCL>"+((EditText)findViewById(R.id.con_ccl_nodays)).getText().toString()+"</TOTALCCL>");
				//				LeavesAccountData.append("<AVAILCCL>"+((EditText)findViewById(R.id.con_ccl_avaidays)).getText().toString()+"</AVAILCCL>");
				//
				//				LeavesAccountData.append("<AVAILCOMPENSACTION>"+((EditText)findViewById(R.id.con_comp_avaidays)).getText().toString()+"</AVAILCOMPENSACTION>");
				//				LeavesAccountData.append("<TOTALCOMPENSACTION>"+((EditText)findViewById(R.id.con_comp_nodays)).getText().toString()+"</TOTALCOMPENSACTION>");

				RequestServer request=new RequestServer(Meoconfirmation.this);
				request.addParam("TreasuryID", b.getString("tresuryid"));

				request.addParam("TotalCasual", ((EditText)findViewById(R.id.con_cl_nodays)).getText().toString());
				request.addParam("AvailCasual", ((EditText)findViewById(R.id.con_cl_avaidays)).getText().toString());

				request.addParam("TotalCL", ((EditText)findViewById(R.id.con_spcl_nodays)).getText().toString());
				request.addParam("AvailCL", ((EditText)findViewById(R.id.con_spcl_avaidays)).getText().toString());

				request.addParam("TotalEL", ((EditText)findViewById(R.id.con_el_nodays)).getText().toString());
				request.addParam("AvailEL", ((EditText)findViewById(R.id.con_el_avaidays)).getText().toString());

				request.addParam("TotalHPL", ((EditText)findViewById(R.id.con_hpl_nodays)).getText().toString());
				request.addParam("AvailHPL", ((EditText)findViewById(R.id.con_hpl_avaidays)).getText().toString());

				request.addParam("TotalML", ((EditText)findViewById(R.id.con_ml_nodays)).getText().toString());
				request.addParam("AvailML", ((EditText)findViewById(R.id.con_ml_avaidays)).getText().toString());

				request.addParam("TotalAbortion", ((EditText)findViewById(R.id.con_abor_nodays)).getText().toString());
				request.addParam("AvailAbortion", ((EditText)findViewById(R.id.con_abor_avaidays)).getText().toString());

				request.addParam("TotalPL",((EditText)findViewById(R.id.con_pl_nodays)).getText().toString());
				request.addParam("AvailPL",((EditText)findViewById(R.id.con_pl_avaidays)).getText().toString());

				request.addParam("TotalOH", ((EditText)findViewById(R.id.con_opho_nodays)).getText().toString());
				request.addParam("AvailOH", ((EditText)findViewById(R.id.con_opho_avaidays)).getText().toString());

				request.addParam("TotalEOL", ((EditText)findViewById(R.id.con_exto_nodays)).getText().toString());
				request.addParam("AvailEOL", ((EditText)findViewById(R.id.con_exto_avaidays)).getText().toString());

				request.addParam("TotalStudy", ((EditText)findViewById(R.id.con_stu_nodays)).getText().toString());
				request.addParam("AvailStudy", ((EditText)findViewById(R.id.con_stu_avaidays)).getText().toString());

				request.addParam("TotalCCL", ((EditText)findViewById(R.id.con_ccl_nodays)).getText().toString());
				request.addParam("AvailCCL", ((EditText)findViewById(R.id.con_ccl_avaidays)).getText().toString());

				request.addParam("TotalLH", ((EditText)findViewById(R.id.con_loc_nodays)).getText().toString());
				request.addParam("AvailLH", ((EditText)findViewById(R.id.con_loc_avaidays)).getText().toString());

				request.addParam("TotalHysterectomy", ((EditText)findViewById(R.id.con_hys_nodays)).getText().toString());
				request.addParam("AvailHysterectomy", ((EditText)findViewById(R.id.con_hys_avaidays)).getText().toString());

				request.addParam("TotalCompensation", ((EditText)findViewById(R.id.con_comp_nodays)).getText().toString());
				request.addParam("AvailCompensation", ((EditText)findViewById(R.id.con_comp_avaidays)).getText().toString());

				request.addParam("TotalVasectomy", ((EditText)findViewById(R.id.con_vas_nodays)).getText().toString());
				request.addParam("AvailVasectomy", ((EditText)findViewById(R.id.con_vas_avaidays)).getText().toString());

				request.addParam("TotalTubectomy", ((EditText)findViewById(R.id.con_tub_nodays)).getText().toString());
				request.addParam("AvailTubectomy", ((EditText)findViewById(R.id.con_tub_avaidays)).getText().toString());

				request.addParam("TotalReconalisation", ((EditText)findViewById(R.id.con_reco_nodays)).getText().toString());
				request.addParam("AvailReconalisation", ((EditText)findViewById(R.id.con_reco_avaidays)).getText().toString());



				if(type.equalsIgnoreCase("Approve"))
				{

					request.addParam("status", "Approved");
					request.addParam("deviceVersion", HomeData.sAppVersion);
					request.addParam("LoginID", Meologin.meouserid);
					//					LeavesAccountData.append("<STATUS>"+"Approved"+"</STATUS>");
					//					LeavesAccountData.append("<LOGINID>"+Meologin.meouserid+"</LOGINID>");
					//					LeavesAccountData.append("</LIST>");
					//					RequestServer request=new RequestServer(Meoconfirmation.this);
					//					request.addParam("xmlData", LeavesAccountData.toString());
					//	request.addParam("deviceVersion", "1");
					//	request.addParam("deviceVersion", HomeData.sAppVersion);
					request.ProccessRequest(Meoconfirmation.this, "approvalLeaveDetails");

				}
				else
				{
					request.addParam("status", "Rejected");
					request.addParam("LoginID", Meologin.meouserid);
					//					LeavesAccountData.append("<STATUS>"+"Rejected"+"</STATUS>");
					//					LeavesAccountData.append("<LOGINID>"+Meologin.meouserid+"</LOGINID>");
					//					LeavesAccountData.append("</LIST>");
					//					RequestServer request=new RequestServer(Meoconfirmation.this);
					//					request.addParam("leaveXML", LeavesAccountData.toString());
					//	request.addParam("deviceVersion", "1");
					//	request.addParam("deviceVersion", HomeData.sAppVersion);
					request.ProccessRequest(Meoconfirmation.this, "approvalLeaveDetails");
				}
				dialog.dismiss();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}


	@Override
	public void Success(String response, String methodName) 
	{
		AlertDialogs1("Information","Successfully Submitted");

	}

	@Override
	public void Fail(String response, String methodName) 
	{

		AlertDialogs("Information!!",response);
	}

	@Override
	public void NetworkNotAvail() 
	{

		AlertDialogs("Information!!","Network not Available, Please check and try again!!");
	}

	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(Meoconfirmation.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					Meoconfirmation.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;


	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	public void AlertDialogs1(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i=new Intent(Meoconfirmation.this,Meodashboard.class);
				i.putExtra("code",b.getString("tresuryid"));
				startActivity(i);
				finish();
				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
	@Override
	public void onBackPressed()
	{
		Intent i=new Intent(Meoconfirmation.this,Meodashboard.class);

		startActivity(i);
		finish();
	}
}
