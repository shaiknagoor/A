package com.aponline.simslm.server;

public interface ServerResponseListener 
{
	public void Success(String response, String methodName);
	public void Fail(String response, String methodName);
	public void NetworkNotAvail();
	public void AppUpdate();
}
