package com.aponline.simslm.server;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import com.aponline.simslm.HomeData;
import com.aponline.simslm.database.DBAdapter;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class WebserviceCall implements ErrorCodes
{

	String TransDate;
	String TotalTrans;
	public static String Error,Resultstr,Distid,Distname;
	StringBuilder stringBuilder;
	String namespace = "http://service.apo.tcs.com/";


	//   test1
	//	private String url="http://125.20.160.195:8090/TeacherLeaveApp/TeacherLeaveApp?wsdl" ;
	//   test 2
	//	private String url="http://125.20.160.197:8090/TeacherLeaveAppUAT/TeacherLeaveApp?wsdl" ;

	// Staging
	private String url="http://125.20.160.197:8090/TeacherLeaveAppTest/TeacherLeaveApp?wsdl" ;
	
	// LIVE
//		private String url="http://125.20.160.197:8090/TeacherLeaveApp/TeacherLeaveApp?wsdl" ;


	public static ArrayList<String> classlist;
	String SOAP_ACTION;
	SoapObject request = null, objMessages = null;
	SoapSerializationEnvelope envelope;
	HttpTransportSE androidHttpTransport;  
	Context paramContext; 
	public static String serverResponse;
	public static int serverUploadcount;
	public static ArrayList<String> holidaylist,leavetypearray,schoollist;
	public static HashMap<String, String> Schoolinfolist,Aadharstudentlist,Studentlist,Studentlistawc,StudentlistOss,Meodetails,schoollmap,BalanceLeave;
	public static ArrayList<HashMap<String, String>> Schooldata,Studentdata,Studentdataawc,StudentdataOss,spleavedata,spduty,spholiday,teacherlist;
	public static String meologintype; 

	DBAdapter db;

	public WebserviceCall(Context paraContext)
	{
		this.paramContext=paraContext;
		db=new DBAdapter(paraContext);
	}



	public int getSchoolInfo(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="getSchoolInfo";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,80000);
			androidHttpTransport.debug = true;
			//  <SchoolData><list><SchoolName>MPPS KADAKELLA</SchoolName><DistName>SRIKAKULAM</DistName><MandalName>VEERAGHATTAM</MandalName><VillageName>KADAKELLA</VillageName></list></SchoolData>
			//	<SchoolData><list><SchoolName>ZPHS Nathavaram</SchoolName><DistName>VISAKHAPATNAM</DistName><MandalName>NATHAVARAM</MandalName><VillageName>NATHAVARAM</VillageName><MinClass>6</MinClass><MaxClass>10</MaxClass></list></SchoolData>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			// <Result>Sorry No Records Available</Result>   <Result>This Sub Center is Tagged With Other District</Result>
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);

			Schooldata =new ArrayList<HashMap<String, String>>();
			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("No Records Available"))
				{
					Error= Resultstr;
					return mFailure;

				}
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else if(jObject.has("SchoolData"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("SchoolData");
				try 
				{
					int count=0;
					JSONArray jArray=jDeviceData.getJSONArray("list");
					for(int i=0;i<jArray.length();i++)
					{
						//						Schoollist=new HashMap<String, String>();
						//						JSONObject jObject2=jArray.getJSONObject(i);
						//						Schoollist.put("sno", Integer.toString(count+1));
						//						Schoollist.put("SchoolName",jObject2.optString("SchoolName"));  
						//						Schoollist.put("DistName",jObject2.optString("DistName"));     
						//						Schoollist.put("MandalName",jObject2.optString("MandalName"));
						//						Schoollist.put("VillageName",jObject2.optString("VillageName"));
						//						Schoollist.put("MinClass",jObject2.optString("MinClass"));
						//						Schoollist.put("MaxClass",jObject2.optString("MaxClass"));
						//	Schooldata.add(Schoollist);
						count++;
					}
					//return updateChildStatus(stuIds.toString());
					return mSuccess;
				} 
				catch(JSONException e) 
				{
					//					Schoollist=new HashMap<String, String>();
					//					//JSONObject jObject2=jArray.getJSONObject(i);
					//					JSONObject jDeviceData1=jDeviceData.getJSONObject("list");
					//
					//					Schoollist.put("sno", Integer.toString(1));
					//					Schoollist.put("SchoolName",jDeviceData1.optString("SchoolName"));  
					//					Schoollist.put("DistName",jDeviceData1.optString("DistName"));     
					//					Schoollist.put("MandalName",jDeviceData1.optString("MandalName"));
					//					Schoollist.put("VillageName",jDeviceData1.optString("VillageName"));
					//					Schoollist.put("MinClass",jDeviceData1.optString("MinClass"));
					//					Schoollist.put("MaxClass",jDeviceData1.optString("MaxClass"));
					//Schooldata.add(Schoollist);
					return mSuccess;
				}
			}
			else
			{
				Error= "Data Not Found,Please try again!!";
				return mFailure;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}








	public int holidayMaster(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="holidayMaster";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//			for ( String key : paramList.keySet() )
			//			{
			//				request.addProperty(key,paramList.get(key));
			//				Log.e(key, paramList.get(key));
			//			}
			//			request.addProperty("deviceId", HomeData.sDeviceId); 
			//			request.addProperty("deviceVersion",HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,80000);
			androidHttpTransport.debug = true;

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			Studentdataawc =new ArrayList<HashMap<String, String>>();

			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}

			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("No Records Available"))
				{
					Error= Resultstr;
					return mFailure;

				}
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else if(jObject.has("HOLIDAYLIST"))
			{

				JSONObject jDeviceData=jObject.getJSONObject("HOLIDAYLIST");
				JSONArray temp=	jDeviceData.getJSONArray("DATES");
				holidaylist=new ArrayList<String>();
				if(temp.length()>0)
				{
					for (int j = 0; j < temp.length(); j++)
					{
						holidaylist.add(temp.getString(j));	
					}				
				}

				//	holidaylist.add(jDeviceData.optString("DATES"));
				//String a=jDeviceData.optString("DATES");
				//a=a.replace("\"","");
				//a=a.replace("[","");
				//a=a.replace("]","");
				//a=a.replace("\\","");
				//String as[]=	a.split(",");
				//				for (int i = 0; i < as.length; i++) 
				//				{
				//					holidaylist.add(as[i]);
				//				}


				//				int count=0;
				//		//		JSONArray jArray=jObject.getJSONArray("HOLIDAYLIST");
				//				for(int i=0;i<jDeviceData.length();i++)
				//				{
				//					Studentlist=new HashMap<String, String>();
				//			//		JSONObject jObject2=jArray.getJSONObject(i);
				//					Studentlist.put("sno", Integer.toString(count+1));
				//					Studentlist.put("DATES",jDeviceData.optString("DATES"));  
				//
				//					Studentdataawc.add(Studentlist);
				//					count++;
				//				}
				//return updateChildStatus(stuIds.toString());
				return mSuccess;
			}


			else
			{
				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}

	public int leaveMaster(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="leaveMaster";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			//			for ( String key : paramList.keySet() )
			//			{
			//				request.addProperty(key,paramList.get(key));
			//				Log.e(key, paramList.get(key));
			//			}
			//			request.addProperty("deviceId", HomeData.sDeviceId); 
			//			request.addProperty("deviceVersion",HomeData.sAppVersion);
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,80000);
			androidHttpTransport.debug = true;

			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			spduty =new ArrayList<HashMap<String, String>>();
			spholiday =new ArrayList<HashMap<String, String>>();
			spleavedata =new ArrayList<HashMap<String, String>>();

			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}

			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("No Records Available"))
				{
					Error= Resultstr;
					return mFailure;

				}
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else if(jObject.has("LEAVEMASTERDATA"))//LEAVEMASTERDATA
			{
				JSONObject jobj=jObject.getJSONObject("LEAVEMASTERDATA");
				JSONArray jArray=jobj.getJSONArray("LIST");
				if(jArray.length()>0)
				{

					for(int i=0;i<jArray.length();i++)
					{
						HashMap<String,String> a=new HashMap<String, String>();
						HashMap<String,String> b=new HashMap<String, String>();
						HashMap<String,String> c=new HashMap<String, String>();

						JSONObject jObject2=jArray.getJSONObject(i);
						if(jObject2.optString("LEAVETYPEID").equalsIgnoreCase("1"))
						{
							a.put("SUBLEAVETYPEID",jObject2.optString("SUBLEAVETYPEID"));
							a.put("SUBLEAVETYPENAME",jObject2.optString("SUBLEAVETYPENAME"));
							//	leavetypearray.add(jObject2.optString("SUBLEAVETYPENAME"));
							spleavedata.add(a);
						}
						if(jObject2.optString("LEAVETYPEID").equalsIgnoreCase("2"))
						{
							b.put("SUBLEAVETYPEID",jObject2.optString("SUBLEAVETYPEID"));
							b.put("SUBLEAVETYPENAME",jObject2.optString("SUBLEAVETYPENAME"));
							spduty.add(b);
						}
						if(jObject2.optString("LEAVETYPEID").equalsIgnoreCase("3"))
						{
							c.put("SUBLEAVETYPEID",jObject2.optString("SUBLEAVETYPEID"));
							c.put("SUBLEAVETYPENAME",jObject2.optString("SUBLEAVETYPENAME"));
							spholiday.add(c);
						}
						//						a.put("LEAVETYPEID", jObject2.optString("LEAVETYPEID"));
						//						a.put("LEAVETYPENAME",jObject2.optString("LEAVETYPENAME"));
						//						a.put("SUBLEAVETYPEID",jObject2.optString("SUBLEAVETYPEID"));
						//						a.put("SUBLEAVETYPENAME",jObject2.optString("SUBLEAVETYPENAME"));

						// Studentdataawc.add(a);
					}
					Log.d("qqq", spleavedata.toString());
					Log.d("qqq", spduty.toString());
					Log.d("qqq", spholiday.toString());
				}

				return mSuccess;
			}


			else
			{
				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}
	@SuppressLint("NewApi") 
	public int insertChildDetails(HashMap<String, String> paramList)
	{
		try 
		{

			String methodName="insertChildDetails";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			//			request.addProperty("deviceId", HomeData.sDeviceId);
			//			request.addProperty("deviceVersion", HomeData.sAppVersion);

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			androidHttpTransport = new HttpTransportSE(url,120000); 
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result=envelope.getResponse().toString();
			//    <SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS>
			String result1= result.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result1);

			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("No Records Available"))
				{
					Error= Resultstr;
					return mFailure;

				}
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Fail"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("SUCCESS"))
			{
				Resultstr=jObject.optString("SUCCESS");

				return mSuccess;

			}


			else
			{
				Error= "Data Not Updated,Please try again!!";
				return mFailure;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}

	@SuppressLint("NewApi") 
	public int insertLeaveData(HashMap<String, String> paramList)
	{
		try 
		{

			String methodName="insertLeaveData";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			androidHttpTransport = new HttpTransportSE(url,120000); 
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result=envelope.getResponse().toString();
			//    <SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS>
			//	<ERROR>Error Occured!!! While Inserting Student Data For Enrollment</ERROR>
			//	<SUCCESSMESSAGE>SUCCESS</SUCCESSMESSAGE>
			//  <Result>Teacher data already there </Result><ERROR>FAIL</ERROR>
			String result1= result.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result1);
			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("No Records Available"))
				{
					Error= Resultstr;
					return mFailure;

				}
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("ERROR"))
			{
				WebserviceCall.Resultstr=jObject.optString("ERROR");
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Fail"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("SUCCESSMESSAGE"))
			{
				Resultstr=jObject.optString("SUCCESSMESSAGE");

				return mSuccess;

			}


			else
			{
				Error= "Data Not Updated,Please try again!!";
				return mFailure;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}


	@SuppressLint("NewApi") 
	public int ApplyLeave(HashMap<String, String> paramList)
	{
		try 
		{

			String methodName="applyLeave";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			androidHttpTransport = new HttpTransportSE(url,120000); 
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result=envelope.getResponse().toString();
			//    <SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS>
			//	<ERROR>Error Occured!!! While Inserting Student Data For Enrollment</ERROR>
			//	<SUCCESSMESSAGE>SUCCESS</SUCCESSMESSAGE>   <SUCCESS>SUCCESS</SUCCESS>
			//  <Result>Teacher data already there </Result><ERROR>FAIL</ERROR>
			String result1= result.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result1);
			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				Error= result;
				return mErrorResFromWebServices;
				//				Resultstr=jObject.optString("RESULT");
				//				Error= Resultstr;
				//				return mFailure;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Fail"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("SUCCESS"))
			{
				Resultstr=jObject.optString("SUCCESS");

				return mSuccess;

			}


			else
			{
				Error= result;
				return mFailure;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}

	@SuppressLint("NewApi") 
	public int InsertNewChildVaccination(HashMap<String, String> paramList)
	{
		try 
		{

			String methodName="insertNewChildVaccination";
			Log.e("Method Name", methodName);
			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			//			request.addProperty("deviceId", HomeData.sDeviceId);
			//			request.addProperty("deviceVersion", HomeData.sAppVersion);

			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request);
			androidHttpTransport = new HttpTransportSE(url,120000); 
			androidHttpTransport.debug = true;
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result=envelope.getResponse().toString();
			//    <SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS><SUCCESS>DATA INSERTED SUCCESSFULLY</SUCCESS>
			String result1= result.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result1);

			if(jObject.length()<=0)
			{

				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("No Records Available"))
				{
					Error= Resultstr;
					return mFailure;

				}
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Fail"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}
			else if(jObject.has("SUCCESS"))
			{
				Resultstr=jObject.optString("SUCCESS");

				return mSuccess;

			}


			else
			{
				Error= "Data Not Updated,Please try again!!";
				return mFailure;
			}
		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}



	public int getOtp(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="getOtp";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Error>Connection timed out: connect</Error>
			//				<SUCCESSRESULT>Successfully loged In</SUCCESSRESULT><DistCode>2813</DistCode><DistName>Visakhapatnam District</DistName>
			//				<Result>Please Update Your Device Version</Result>  <SUCCESSRESULT>Success fully loged In</SUCCESSRESULT>
			//			 <SchoolResult>In Valid SchoolCode</SchoolResult>  <SchoolResult>Successfully loged In With School Code</SchoolResult>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}

			else if(jObject.has("OTP"))
			{
				Resultstr=jObject.optString("OTP").trim();
				return mSuccess;
			}


			else if(jObject.has("Error"))
			{
				Resultstr=jObject.optString("Result");
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}

			else
			{
				Error= result;
				return mFailure;
			}

			//	return mSuccess;
		} 

		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}




	public int getTeacherInfo(HashMap<String, String> paramList)
	{
		try 
		{
			String methodName="getTeacherInfo";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				HomeData.rErrorMsgFromServer="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("TEACHERDATA"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("TEACHERDATA");
				Schoolinfolist=new HashMap<String, String>();
				Schoolinfolist.put("OTP",jDeviceData.optString("OTP"));
				Schoolinfolist.put("MOBILENO",jDeviceData.optString("MOBILENO"));
				Schoolinfolist.put("TEACHERCODE",jDeviceData.optString("TEACHERCODE"));
				Schoolinfolist.put("TEACHERNAME",jDeviceData.optString("TEACHERNAME"));
				Schoolinfolist.put("SCHOOLCODE",jDeviceData.optString("SCHOOLCODE"));
				Schoolinfolist.put("SCHOOLNAME",jDeviceData.optString("SCHOOLNAME"));
				Schoolinfolist.put("DESIGNATION",jDeviceData.optString("DESIGNATION"));
				Schoolinfolist.put("GENDER",jDeviceData.optString("GENDER"));
				Schoolinfolist.put("ISLEAVE",jDeviceData.optString("ISLEAVE"));
				Schoolinfolist.put("SectionMapping",jDeviceData.optString("SectionMapping"));
				String teaId=jDeviceData.optString("TEACHERCODE");

				String zeroDigit="";
				for(int j=teaId.length();j < 7;j++)
				{
					zeroDigit=zeroDigit+"0";
				}
				teaId=zeroDigit+teaId;
				Schoolinfolist.put("TEACHERCODE",teaId);
				return mSuccess;
			}
			else if(jObject.has("Error"))
			{
				HomeData.rErrorMsgFromServer=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}



	public int loginService(HashMap<String, String> paramList) {
		try 
		{
			String methodName="loginService";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				WebserviceCall.Resultstr=result;
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("SCHOOLMASTER"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("SCHOOLMASTER");
				try 
				{
					meologintype="meologin";
					JSONArray jArray=jDeviceData.getJSONArray("SCHOOLLIST");
					schoollist=new ArrayList<String>();
					schoollist.add("-Select-");
					schoollmap=new HashMap<String, String>();
					for(int i=0;i<jArray.length();i++)
					{
						JSONObject jObject2=jArray.getJSONObject(i);
						schoollist.add(jObject2.optString("scname"));
						schoollmap.put(jObject2.optString("scname"),jObject2.optString("sccode"));
					}


					return mSuccess;
				}
				catch(JSONException e) 
				{
					JSONObject jObject2=jDeviceData.getJSONObject("SCHOOLLIST");
					schoollist=new ArrayList<String>();
					schoollist.add("-Select-");
					schoollmap=new HashMap<String, String>();
					
					schoollist.add(jObject2.optString("scname"));
					schoollmap.put(jObject2.optString("scname"),jObject2.optString("sccode"));

				}
			}

			else if(jObject.has("LIST"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("LIST");
				try 
				{

					JSONArray jArray=jDeviceData.getJSONArray("TEACHERDATA");
					teacherlist=new ArrayList<HashMap<String,String>>();
					meologintype="schoolcodelogin";
					for(int i=0;i<jArray.length();i++)
					{
						HashMap<String, String> a=new HashMap<String, String>();

						JSONObject jObject2=jArray.getJSONObject(i);
						a.put("school_name",jObject2.optString("school_name")) ;
						a.put("teacher_name", jObject2.optString("teacher_name"));
						a.put("gender", jObject2.optString("gender"));
						
						a.put("Total_Casual", jObject2.optString("Total_Casual"));
						a.put("Avail_Casual",jObject2.optString("Avail_Casual"));
						a.put("balance_Casual",jObject2.optString("balance_Casual"));
						a.put("total_cl", jObject2.optString("total_cl"));
						a.put("availed_cl",jObject2.optString("availed_cl"));
						a.put("total_el", jObject2.optString("total_el"));
						a.put("availed_el",jObject2.optString("availed_el"));
						a.put("total_hpl",jObject2.optString("total_hpl"));
						a.put("availed_hpl",jObject2.optString("availed_hpl"));
						a.put("total_ml",jObject2.optString("total_ml"));
						a.put("availed_ml",jObject2.optString("availed_ml"));
						a.put("total_paternity",jObject2.optString("total_paternity"));
						a.put("availed_paternity",jObject2.optString("availed_paternity"));
						a.put("total_childcare",jObject2.optString("total_childcare"));
						a.put("availed_childcare",jObject2.optString("availed_childcare"));
						a.put("total_compensation",jObject2.optString("total_compensation"));
						a.put("availed_compensation",jObject2.optString("availed_compensation"));
						a.put("balance_cl",jObject2.optString("balance_cl"));
						a.put("balance_el",jObject2.optString("balance_el"));
						a.put("balance_hpl",jObject2.optString("balance_hpl"));
						a.put("balance_ml",jObject2.optString("balance_ml"));
						a.put("balance_paternity",jObject2.optString("balance_paternity"));
						a.put("balance_childcare",jObject2.optString("balance_childcare"));
						a.put("balance_compensation",jObject2.optString("balance_compensation"));
						a.put("Total_Abortion",jObject2.optString("Total_Abortion"));
						a.put("Avail_Abortion",jObject2.optString("Avail_Abortion"));
						a.put("balance_Abortion",jObject2.optString("balance_Abortion"));
						a.put("Total_OH",jObject2.optString("Total_OH"));
						a.put("Avail_OH",jObject2.optString("Avail_OH"));
						a.put("balance_OH",jObject2.optString("balance_OH"));
						a.put("Tot_EOL",jObject2.optString("Tot_EOL"));
						a.put("Avail_EOL",jObject2.optString("Avail_EOL"));
						a.put("Balance_EOL",jObject2.optString("Balance_EOL"));
						a.put("Total_Study",jObject2.optString("Total_Study"));
						a.put("Avail_Study",jObject2.optString("Avail_Study"));
						a.put("balance_Study",jObject2.optString("balance_Study"));
						a.put("Total_LH",jObject2.optString("Total_LH"));
						a.put("Avail_LH",jObject2.optString("Avail_LH"));
						a.put("Balance_LH",jObject2.optString("Balance_LH"));
						a.put("Total_Hysterectomy",jObject2.optString("Total_Hysterectomy"));
						a.put("Avail_Hysterectomy",jObject2.optString("Avail_Hysterectomy"));
						a.put("balance_Hysterectomy",jObject2.optString("balance_Hysterectomy"));
						
						a.put("Total_Vasectomy",jObject2.optString("Total_Vasectomy"));
						a.put("Avail_Vasectomy",jObject2.optString("Avail_Vasectomy"));
						a.put("balance_Vasectomy",jObject2.optString("balance_Vasectomy"));
						
						a.put("Total_Tubectomy",jObject2.optString("Total_Tubectomy"));
						a.put("Avail_Tubectomy",jObject2.optString("Avail_Tubectomy"));
						a.put("balance_Tubectomy",jObject2.optString("balance_Tubectomy"));
						
						a.put("Total_Reconalisation",jObject2.optString("Total_Reconalisation"));
						a.put("Avail_Reconalisation",jObject2.optString("Avail_Reconalisation"));
						a.put("balance_Reconalisation",jObject2.optString("balance_Reconalisation"));
						
						
						

						String teaId=jObject2.optString("teacher_code");

						String zeroDigit="";
						for(int j=teaId.length();j < 7;j++)
						{
							zeroDigit=zeroDigit+"0";
						}
						teaId=zeroDigit+teaId;
						a.put("teacher_code", teaId);

						teacherlist.add(a);
					}
					return mSuccess;
				} 
				catch(JSONException e) 
				{
					meologintype="schoolcodelogin";
					JSONObject jObject2=jDeviceData.getJSONObject("TEACHERDATA");
					teacherlist=new ArrayList<HashMap<String,String>>();
					HashMap<String, String> a=new HashMap<String, String>();
					//JSONObject jObject2=jArray.getJSONObject(i);
					a.put("school_name",jObject2.optString("school_name")) ;
					a.put("teacher_name", jObject2.optString("teacher_name"));
					a.put("gender", jObject2.optString("gender"));
					
					a.put("Total_Casual", jObject2.optString("Total_Casual"));
					a.put("Avail_Casual",jObject2.optString("Avail_Casual"));
					a.put("balance_Casual",jObject2.optString("balance_Casual"));
					a.put("total_cl", jObject2.optString("total_cl"));
					a.put("availed_cl",jObject2.optString("availed_cl"));
					a.put("total_el", jObject2.optString("total_el"));
					a.put("availed_el",jObject2.optString("availed_el"));
					a.put("total_hpl",jObject2.optString("total_hpl"));
					a.put("availed_hpl",jObject2.optString("availed_hpl"));
					a.put("total_ml",jObject2.optString("total_ml"));
					a.put("availed_ml",jObject2.optString("availed_ml"));
					a.put("total_paternity",jObject2.optString("total_paternity"));
					a.put("availed_paternity",jObject2.optString("availed_paternity"));
					a.put("total_childcare",jObject2.optString("total_childcare"));
					a.put("availed_childcare",jObject2.optString("availed_childcare"));
					a.put("total_compensation",jObject2.optString("total_compensation"));
					a.put("availed_compensation",jObject2.optString("availed_compensation"));
					a.put("balance_cl",jObject2.optString("balance_cl"));
					a.put("balance_el",jObject2.optString("balance_el"));
					a.put("balance_hpl",jObject2.optString("balance_hpl"));
					a.put("balance_ml",jObject2.optString("balance_ml"));
					a.put("balance_paternity",jObject2.optString("balance_paternity"));
					a.put("balance_childcare",jObject2.optString("balance_childcare"));
					a.put("balance_compensation",jObject2.optString("balance_compensation"));
					a.put("Total_Abortion",jObject2.optString("Total_Abortion"));
					a.put("Avail_Abortion",jObject2.optString("Avail_Abortion"));
					a.put("balance_Abortion",jObject2.optString("balance_Abortion"));
					a.put("Total_OH",jObject2.optString("Total_OH"));
					a.put("Avail_OH",jObject2.optString("Avail_OH"));
					a.put("balance_OH",jObject2.optString("balance_OH"));
					a.put("Tot_EOL",jObject2.optString("Tot_EOL"));
					a.put("Avail_EOL",jObject2.optString("Avail_EOL"));
					a.put("Balance_EOL",jObject2.optString("Balance_EOL"));
					a.put("Total_Study",jObject2.optString("Total_Study"));
					a.put("Avail_Study",jObject2.optString("Avail_Study"));
					a.put("balance_Study",jObject2.optString("balance_Study"));
					a.put("Total_LH",jObject2.optString("Total_LH"));
					a.put("Avail_LH",jObject2.optString("Avail_LH"));
					a.put("Balance_LH",jObject2.optString("Balance_LH"));
					a.put("Total_Hysterectomy",jObject2.optString("Total_Hysterectomy"));
					a.put("Avail_Hysterectomy",jObject2.optString("Avail_Hysterectomy"));
					a.put("balance_Hysterectomy",jObject2.optString("balance_Hysterectomy"));
					
					
					a.put("Total_Vasectomy",jObject2.optString("Total_Vasectomy"));
					a.put("Avail_Vasectomy",jObject2.optString("Avail_Vasectomy"));
					a.put("balance_Vasectomy",jObject2.optString("balance_Vasectomy"));
					
					a.put("Total_Tubectomy",jObject2.optString("Total_Tubectomy"));
					a.put("Avail_Tubectomy",jObject2.optString("Avail_Tubectomy"));
					a.put("balance_Tubectomy",jObject2.optString("balance_Tubectomy"));
					
					a.put("Total_Reconalisation",jObject2.optString("Total_Reconalisation"));
					a.put("Avail_Reconalisation",jObject2.optString("Avail_Reconalisation"));
					a.put("balance_Reconalisation",jObject2.optString("balance_Reconalisation"));
					
					String teaId=jObject2.optString("teacher_code");

					String zeroDigit="";
					for(int j=teaId.length();j < 7;j++)
					{
						zeroDigit=zeroDigit+"0";
					}
					teaId=zeroDigit+teaId;
					a.put("teacher_code", teaId);

					teacherlist.add(a);

					return mSuccess;

				}
			}
			else if(jObject.has("Error"))
			{
				WebserviceCall.Resultstr=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		return mSuccess;
	}



	public int leaveApproval(HashMap<String, String> paramList) {
		try 
		{
			String methodName="leaveApproval";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				WebserviceCall.Resultstr=result;
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}

			//			else if(jObject.has("TEACHERDATA"))
			//			{
			//				JSONObject jDeviceData=jObject.getJSONObject("TEACHERDATA");
			//				Schoolinfolist=new HashMap<String, String>();
			//				Schoolinfolist.put("OTP",jDeviceData.optString("OTP"));
			//
			//				Schoolinfolist.put("MOBILENO",jDeviceData.optString("MOBILENO"));
			//				Schoolinfolist.put("TEACHERCODE",jDeviceData.optString("TEACHERCODE"));
			//				Schoolinfolist.put("TEACHERNAME",jDeviceData.optString("TEACHERNAME"));
			//				Schoolinfolist.put("SCHOOLCODE",jDeviceData.optString("SCHOOLCODE"));
			//				Schoolinfolist.put("SCHOOLNAME",jDeviceData.optString("SCHOOLNAME"));
			//				Schoolinfolist.put("DESIGNATION",jDeviceData.optString("DESIGNATION"));
			//				Schoolinfolist.put("GENDER",jDeviceData.optString("GENDER"));
			//				Schoolinfolist.put("ISLEAVE",jDeviceData.optString("ISLEAVE"));
			//				return mSuccess;
			//			}
			else if(jObject.has("Error"))
			{
				WebserviceCall.Resultstr=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}



	public int SchoolDetailsService(HashMap<String, String> paramList) {
		// TODO Auto-generated method stub
		try 
		{
			String methodName="SchoolDetailsService";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{

				WebserviceCall.Resultstr=result;
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			//			else if(jObject.has("SCHOOLMASTER"))
			//			{
			//				JSONObject jDeviceData=jObject.getJSONObject("SCHOOLMASTER");
			//				try 
			//				{
			//					meologintype="meologin";
			//				JSONArray jArray=jDeviceData.getJSONArray("SCHOOLLIST");
			//				schoollist=new ArrayList<String>();
			//				schoollist.add("-Select-");
			//				schoollmap=new HashMap<String, String>();
			//				for(int i=0;i<jArray.length();i++)
			//				{
			//					JSONObject jObject2=jArray.getJSONObject(i);
			//					schoollist.add(jObject2.optString("scname"));
			//					schoollmap.put(jObject2.optString("scname"),jObject2.optString("sccode"));
			//				}
			//				
			//				
			//				return mSuccess;
			//				}
			//				catch(JSONException e) 
			//				{
			//					e.printStackTrace();
			//
			//					
			//				}
			//			}

			else if(jObject.has("LIST"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("LIST");
				try 
				{

					JSONArray jArray=jDeviceData.getJSONArray("TEACHERDATA");
					teacherlist=new ArrayList<HashMap<String,String>>();
					meologintype="schoolcodelogin";
					for(int i=0;i<jArray.length();i++)
					{
						HashMap<String, String> a=new HashMap<String, String>();

						JSONObject jObject2=jArray.getJSONObject(i);
						a.put("school_name",jObject2.optString("school_name")) ;
						a.put("teacher_name", jObject2.optString("teacher_name"));
						a.put("gender", jObject2.optString("gender"));
						
						a.put("Total_Casual", jObject2.optString("Total_Casual"));
						a.put("Avail_Casual",jObject2.optString("Avail_Casual"));
						
						a.put("total_cl", jObject2.optString("total_cl"));
						a.put("availed_cl",jObject2.optString("availed_cl"));
						a.put("total_el", jObject2.optString("total_el"));
						a.put("availed_el",jObject2.optString("availed_el"));
						a.put("total_hpl",jObject2.optString("total_hpl"));
						a.put("availed_hpl",jObject2.optString("availed_hpl"));
						a.put("total_ml",jObject2.optString("total_ml"));
						a.put("availed_ml",jObject2.optString("availed_ml"));
						a.put("total_paternity",jObject2.optString("total_paternity"));
						a.put("availed_paternity",jObject2.optString("availed_paternity"));
						a.put("total_childcare",jObject2.optString("total_childcare"));
						a.put("availed_childcare",jObject2.optString("availed_childcare"));
						a.put("total_compensation",jObject2.optString("total_compensation"));
						a.put("availed_compensation",jObject2.optString("availed_compensation"));
						a.put("balance_cl",jObject2.optString("balance_cl"));
						a.put("balance_el",jObject2.optString("balance_el"));
						a.put("balance_hpl",jObject2.optString("balance_hpl"));
						a.put("balance_ml",jObject2.optString("balance_ml"));
						a.put("balance_paternity",jObject2.optString("balance_paternity"));
						a.put("balance_childcare",jObject2.optString("balance_childcare"));
						a.put("balance_compensation",jObject2.optString("balance_compensation"));
						a.put("Total_Abortion",jObject2.optString("Total_Abortion"));
						a.put("Avail_Abortion",jObject2.optString("Avail_Abortion"));
						a.put("balance_Abortion",jObject2.optString("balance_Abortion"));
						a.put("Total_OH",jObject2.optString("Total_OH"));
						a.put("Avail_OH",jObject2.optString("Avail_OH"));
						a.put("balance_OH",jObject2.optString("balance_OH"));
						a.put("Tot_EOL",jObject2.optString("Tot_EOL"));
						a.put("Avail_EOL",jObject2.optString("Avail_EOL"));
						a.put("Balance_EOL",jObject2.optString("Balance_EOL"));
						a.put("Total_Study",jObject2.optString("Total_Study"));
						a.put("Avail_Study",jObject2.optString("Avail_Study"));
						a.put("balance_Study",jObject2.optString("balance_Study"));
						a.put("Total_LH",jObject2.optString("Total_LH"));
						a.put("Avail_LH",jObject2.optString("Avail_LH"));
						a.put("Balance_LH",jObject2.optString("Balance_LH"));
						a.put("Total_Hysterectomy",jObject2.optString("Total_Hysterectomy"));
						a.put("Avail_Hysterectomy",jObject2.optString("Avail_Hysterectomy"));
						a.put("balance_Hysterectomy",jObject2.optString("balance_Hysterectomy"));
						
						a.put("Total_Vasectomy",jObject2.optString("Total_Vasectomy"));
						a.put("Avail_Vasectomy",jObject2.optString("Avail_Vasectomy"));
						a.put("balance_Vasectomy",jObject2.optString("balance_Vasectomy"));
						
						a.put("Total_Tubectomy",jObject2.optString("Total_Tubectomy"));
						a.put("Avail_Tubectomy",jObject2.optString("Avail_Tubectomy"));
						a.put("balance_Tubectomy",jObject2.optString("balance_Tubectomy"));
						
						a.put("Total_Reconalisation",jObject2.optString("Total_Reconalisation"));
						a.put("Avail_Reconalisation",jObject2.optString("Avail_Reconalisation"));
						a.put("balance_Reconalisation",jObject2.optString("balance_Reconalisation"));
						
						String teaId=jObject2.optString("teacher_code");

						String zeroDigit="";
						for(int j=teaId.length();j < 7;j++)
						{
							zeroDigit=zeroDigit+"0";
						}
						teaId=zeroDigit+teaId;
						a.put("teacher_code", teaId);

						teacherlist.add(a);
					}
					return mSuccess;
				} 
				catch(JSONException e) 
				{
					JSONObject jObject2=jDeviceData.getJSONObject("TEACHERDATA");
					teacherlist=new ArrayList<HashMap<String,String>>();
					HashMap<String, String> a=new HashMap<String, String>();
					//JSONObject jObject2=jArray.getJSONObject(i);
					a.put("school_name",jObject2.optString("school_name")) ;
					a.put("teacher_name", jObject2.optString("teacher_name"));
					a.put("gender", jObject2.optString("gender"));
					
					a.put("Total_Casual", jObject2.optString("Total_Casual"));
					a.put("Avail_Casual",jObject2.optString("Avail_Casual"));
					
					a.put("total_cl", jObject2.optString("total_cl"));
					a.put("availed_cl",jObject2.optString("availed_cl"));
					a.put("total_el", jObject2.optString("total_el"));
					a.put("availed_el",jObject2.optString("availed_el"));
					a.put("total_hpl",jObject2.optString("total_hpl"));
					a.put("availed_hpl",jObject2.optString("availed_hpl"));
					a.put("total_ml",jObject2.optString("total_ml"));
					a.put("availed_ml",jObject2.optString("availed_ml"));
					a.put("total_paternity",jObject2.optString("total_paternity"));
					a.put("availed_paternity",jObject2.optString("availed_paternity"));
					a.put("total_childcare",jObject2.optString("total_childcare"));
					a.put("availed_childcare",jObject2.optString("availed_childcare"));
					a.put("total_compensation",jObject2.optString("total_compensation"));
					a.put("availed_compensation",jObject2.optString("availed_compensation"));
					a.put("balance_cl",jObject2.optString("balance_cl"));
					a.put("balance_el",jObject2.optString("balance_el"));
					a.put("balance_hpl",jObject2.optString("balance_hpl"));
					a.put("balance_ml",jObject2.optString("balance_ml"));
					a.put("balance_paternity",jObject2.optString("balance_paternity"));
					a.put("balance_childcare",jObject2.optString("balance_childcare"));
					a.put("balance_compensation",jObject2.optString("balance_compensation"));
					a.put("Total_Abortion",jObject2.optString("Total_Abortion"));
					a.put("Avail_Abortion",jObject2.optString("Avail_Abortion"));
					a.put("balance_Abortion",jObject2.optString("balance_Abortion"));
					a.put("Total_OH",jObject2.optString("Total_OH"));
					a.put("Avail_OH",jObject2.optString("Avail_OH"));
					a.put("balance_OH",jObject2.optString("balance_OH"));
					a.put("Tot_EOL",jObject2.optString("Tot_EOL"));
					a.put("Avail_EOL",jObject2.optString("Avail_EOL"));
					a.put("Balance_EOL",jObject2.optString("Balance_EOL"));
					a.put("Total_Study",jObject2.optString("Total_Study"));
					a.put("Avail_Study",jObject2.optString("Avail_Study"));
					a.put("balance_Study",jObject2.optString("balance_Study"));
					a.put("Total_LH",jObject2.optString("Total_LH"));
					a.put("Avail_LH",jObject2.optString("Avail_LH"));
					a.put("Balance_LH",jObject2.optString("Balance_LH"));
					a.put("Total_Hysterectomy",jObject2.optString("Total_Hysterectomy"));
					a.put("Avail_Hysterectomy",jObject2.optString("Avail_Hysterectomy"));
					a.put("balance_Hysterectomy",jObject2.optString("balance_Hysterectomy"));
					
					a.put("Total_Vasectomy",jObject2.optString("Total_Vasectomy"));
					a.put("Avail_Vasectomy",jObject2.optString("Avail_Vasectomy"));
					a.put("balance_Vasectomy",jObject2.optString("balance_Vasectomy"));
					
					a.put("Total_Tubectomy",jObject2.optString("Total_Tubectomy"));
					a.put("Avail_Tubectomy",jObject2.optString("Avail_Tubectomy"));
					a.put("balance_Tubectomy",jObject2.optString("balance_Tubectomy"));
					
					a.put("Total_Reconalisation",jObject2.optString("Total_Reconalisation"));
					a.put("Avail_Reconalisation",jObject2.optString("Avail_Reconalisation"));
					a.put("balance_Reconalisation",jObject2.optString("balance_Reconalisation"));
					
					String teaId=jObject2.optString("teacher_code");

					String zeroDigit="";
					for(int j=teaId.length();j < 7;j++)
					{
						zeroDigit=zeroDigit+"0";
					}
					teaId=zeroDigit+teaId;
					a.put("teacher_code", teaId);

					teacherlist.add(a);

					return mSuccess;


				}
			}
			else if(jObject.has("Error"))
			{
				WebserviceCall.Resultstr=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}

	}



	public int deputationSchools(HashMap<String, String> paramList) 
	{

		try 
		{
			String methodName="deputationSchools";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				WebserviceCall.Resultstr="Data not found,Please try again later!";
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("SUCCESS"))
			{
				return mSuccess;
			}			
			else if(jObject.has("ERROR"))
			{
				WebserviceCall.Resultstr=jObject.optString("ERROR");
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}



	public int approvalLeaveDetails(HashMap<String, String> paramList) 
	{
		
		try 
		{
			String methodName="approvalLeaveDetails";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{
				WebserviceCall.Resultstr=result;
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}
			else if(jObject.has("SUCCESSMESSAGE"))
			{
//				JSONObject jDeviceData=jObject.getJSONObject("TEACHERDATA");
//				Schoolinfolist=new HashMap<String, String>();
//				Schoolinfolist.put("OTP",jDeviceData.optString("OTP"));
//				Schoolinfolist.put("MOBILENO",jDeviceData.optString("MOBILENO"));
//				Schoolinfolist.put("TEACHERCODE",jDeviceData.optString("TEACHERCODE"));
//				Schoolinfolist.put("TEACHERNAME",jDeviceData.optString("TEACHERNAME"));
//				Schoolinfolist.put("SCHOOLCODE",jDeviceData.optString("SCHOOLCODE"));
//				Schoolinfolist.put("SCHOOLNAME",jDeviceData.optString("SCHOOLNAME"));
//				Schoolinfolist.put("DESIGNATION",jDeviceData.optString("DESIGNATION"));
//				Schoolinfolist.put("GENDER",jDeviceData.optString("GENDER"));
//				Schoolinfolist.put("ISLEAVE",jDeviceData.optString("ISLEAVE"));
//				Error= Resultstr;
				return mSuccess;
			}
			else if(jObject.has("ERROR"))
			{
				WebserviceCall.Resultstr=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
		
		
	}



	public int leaveBalanceCount(HashMap<String, String> paramList) {
		try 
		{
			String methodName="leaveBalanceCount";
			Log.e("Method Name", methodName); 

			SOAP_ACTION = namespace + methodName;
			request = new SoapObject(namespace, methodName);
			for ( String key : paramList.keySet() )
			{
				request.addProperty(key,paramList.get(key));
				Log.e(key, paramList.get(key));
			}
			envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
			//envelope.dotNet=true;
			envelope.setOutputSoapObject(request); 
			androidHttpTransport = new HttpTransportSE(url,120000);
			androidHttpTransport.debug = true;
			//	<Result>Invalid Sub Center / Password</Result>
			//	<OTP>G7364R</OTP>
			androidHttpTransport.call(SOAP_ACTION, envelope);
			String result1 = envelope.getResponse().toString();
			String result= result1.replaceAll("&", "&amp;");
			JSONObject jObject = XML.toJSONObject(result);
			if(jObject.length()<=0)
			{

				WebserviceCall.Resultstr=result;
				return mErrorResFromWebServices;
			}
			else if(jObject.has("Result"))
			{
				Resultstr=jObject.optString("Result");
				if(Resultstr.equalsIgnoreCase("Please Update Your Device Version"))
				{

					return mUpdateVersion;

				}
				Error= Resultstr;
				return mFailure;
			}


			else if(jObject.has("LIST"))
			{
				JSONObject jDeviceData=jObject.getJSONObject("LIST");
				

					JSONObject jObject2=jDeviceData.getJSONObject("TEACHERDATA");
					
					BalanceLeave=new HashMap<String, String>();
					//JSONObject jObject2=jArray.getJSONObject(i);
					
				
					BalanceLeave.put(jObject2.optString("cl_ID"), jObject2.optString("balance_cl"));
					BalanceLeave.put(jObject2.optString("Casual_ID"),jObject2.optString("Balance_Casual"));
					BalanceLeave.put(jObject2.optString("el_ID"),jObject2.optString("balance_el"));
					BalanceLeave.put(jObject2.optString("hpl_ID"), jObject2.optString("balance_hpl"));
					BalanceLeave.put(jObject2.optString("ml_ID"),jObject2.optString("balance_ml"));
					BalanceLeave.put(jObject2.optString("paternity_ID"),jObject2.optString("balance_paternity"));
					BalanceLeave.put(jObject2.optString("childcare_ID"),jObject2.optString("balance_childcare"));
					BalanceLeave.put(jObject2.optString("compensation_ID"),jObject2.optString("balance_compensation"));
					BalanceLeave.put(jObject2.optString("OH_ID"),jObject2.optString("balance_OH"));
					BalanceLeave.put(jObject2.optString("EOL_ID"),jObject2.optString("Balance_EOL"));
					BalanceLeave.put(jObject2.optString("Study_ID"),jObject2.optString("balance_Study"));
					BalanceLeave.put(jObject2.optString("LH_ID"),jObject2.optString("Balance_LH"));
					BalanceLeave.put(jObject2.optString("Hysterectomy_ID"),jObject2.optString("balance_Hysterectomy"));
					BalanceLeave.put(jObject2.optString("Abortion_ID"),jObject2.optString("balance_Abortion"));
					BalanceLeave.put(jObject2.optString("Vasectomy_ID"),jObject2.optString("balance_Vasectomy"));
					BalanceLeave.put(jObject2.optString("Reconalisation_ID"),jObject2.optString("balance_Reconalisation"));
					BalanceLeave.put(jObject2.optString("Tubectomy_ID"),jObject2.optString("balance_Tubectomy"));
					
					    
					
						
					String teaId=jObject2.optString("teacher_code");

					String zeroDigit="";
					for(int j=teaId.length();j < 7;j++)
					{
						zeroDigit=zeroDigit+"0";
					}
					teaId=zeroDigit+teaId;
					BalanceLeave.put("teacher_code", teaId);

				

					return mSuccess;
				} 
				
			
			else if(jObject.has("Error"))
			{
				WebserviceCall.Resultstr=jObject.optString(Error);
				return mErrorResFromWebServices;
			}

			else
			{
				Error= result;
				return mFailure;
			}


		} 
		catch (SocketTimeoutException e)
		{
			e.printStackTrace();
			return mSocketTimeoutException;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			return mIOException;
		}
		catch (XmlPullParserException e) 
		{
			e.printStackTrace();
			return mXmlPullParserException;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return mException;
		}
	}

}
