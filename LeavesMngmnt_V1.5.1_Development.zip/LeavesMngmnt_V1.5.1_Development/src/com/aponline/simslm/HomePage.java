package com.aponline.simslm;


import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class HomePage extends Activity implements ServerResponseListener 
{
	Button  logoutbtnhome;
	ProgressDialog progressDialog;
	Handler mHandler;
	RelativeLayout ll_leave,ll_duty,ll_holiday,ll_balance;
	LinearLayout ll_types,ll_types1;
	TextView treasuryidtv,Teachernametv,schooltv,schoolcodetv,designationtv,mobiletv;
	String methodnames;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu_home);
		try
		{

			ll_leave = (RelativeLayout) findViewById(R.id.ll_leave);
			ll_duty = (RelativeLayout) findViewById(R.id.ll_duty);
			ll_holiday=(RelativeLayout) findViewById(R.id.ll_holiday);
			ll_balance = (RelativeLayout)findViewById(R.id.ll_balance);
			ll_types=(LinearLayout) findViewById(R.id.ll_types);
			ll_types1=(LinearLayout) findViewById(R.id.ll_types1);

			treasuryidtv=(TextView) findViewById(R.id.treasuryidtv);
			Teachernametv=(TextView) findViewById(R.id.Teachernametv);
			schooltv=(TextView) findViewById(R.id.schooltv);
			schoolcodetv=(TextView) findViewById(R.id.schoolcodetv);
			designationtv=(TextView) findViewById(R.id.designationtv);
			mobiletv=(TextView) findViewById(R.id.mobiletv);
			TextView scroll = (TextView) this.findViewById(R.id.marque_scrolling_text);
			scroll.setSelected(true);
			treasuryidtv.setText(WebserviceCall.Schoolinfolist.get("TEACHERCODE").toString());
			Teachernametv.setText(WebserviceCall.Schoolinfolist.get("TEACHERNAME").toString());
			schooltv.setText(WebserviceCall.Schoolinfolist.get("SCHOOLNAME").toString());
			schoolcodetv.setText(WebserviceCall.Schoolinfolist.get("SCHOOLCODE").toString());
			designationtv.setText(WebserviceCall.Schoolinfolist.get("DESIGNATION").toString());
			String temp="";
			if(WebserviceCall.Schoolinfolist.get("MOBILENO").toString()==null||WebserviceCall.Schoolinfolist.get("MOBILENO").toString().length()<10)
			{
				mobiletv.setText("NA");
				ll_types.setVisibility(8);
				ll_types1.setVisibility(0);
			}
			else
			{
				ll_types.setVisibility(0);
				ll_types1.setVisibility(8);
				temp= WebserviceCall.Schoolinfolist.get("MOBILENO").toString().substring(6, 10);
				mobiletv.setText("******"+temp);
			}
			//    mobiletv.setText(WebserviceCall.Schoolinfolist.get("MOBILENO").toString());
			logoutbtnhome=(Button)findViewById(R.id.logoutbtnhome);
			logoutbtnhome.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{
					logoutFunction();

				}
			});


			ll_leave.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					if(isNetworkAvailable(HomePage.this))
					{
						methodnames="typeofleave";
						RequestServer request=new RequestServer(HomePage.this);
						request.addParam("teacherCode", HomeData.UserID);
						request.addParam("deviceVersion", HomeData.sAppVersion);
						request.ProccessRequest(HomePage.this, "leaveBalanceCount");
						return;



					}
					else
					{
						AlertDialogs("Information!!","Check The Internet Connection");
						return;
					}



				}
			});

			ll_duty.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{
					Intent ins = new Intent();
					ins.setClass(HomePage.this, Typeofduty.class);
					startActivity(ins);


				}
			});

			ll_holiday.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{
					Intent ins = new Intent();
					ins.setClass(HomePage.this, TypeofHoliday.class);
					startActivity(ins);


				}
			});

			ll_balance.setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{
					RequestServer request=new RequestServer(HomePage.this);
					request.addParam("teacherCode", HomeData.UserID);
					request.addParam("deviceVersion", HomeData.sAppVersion);
					request.ProccessRequest(HomePage.this, "leaveBalanceCount");
					methodnames="balancecount";
					return;

				}
			});
		}
		catch(Exception e)
		{

		}


	}


	@SuppressLint("NewApi")
	private void logoutFunction() 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				Intent i=	new Intent(HomePage.this,Login.class);
				startActivity(i);
				HomePage.this.finish();
				finishAffinity();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}

	@Override
	public void onBackPressed()
	{
		logoutFunction();
		return;
	}


	@Override
	public void Success(String response, String methodName) 
	{
		if(methodnames.equalsIgnoreCase("typeofleave"))
		{
			Intent ing = new Intent();
			ing.setClass(HomePage.this, Typeofleave.class);
			startActivity(ing);
		}
		else if(methodnames.equalsIgnoreCase("balancecount"))
		{
			Intent ing = new Intent();
			ing.setClass(HomePage.this, Balanceleave.class);
			startActivity(ing);
		}

	}


	@Override
	public void Fail(String response, String methodName) 
	{
		AlertDialogs("Information!!",response);

	}


	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information!!","Network not Available, Please check and try again!!");

	}


	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(HomePage.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					HomePage.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;

	}

	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}
	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}
}
