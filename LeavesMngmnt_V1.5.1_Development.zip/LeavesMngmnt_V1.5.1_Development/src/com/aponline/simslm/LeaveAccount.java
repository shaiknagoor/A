package com.aponline.simslm;




import com.aponline.simslm.server.RequestServer;
import com.aponline.simslm.server.ServerResponseListener;
import com.aponline.simslm.server.WebserviceCall;

import android.R.string;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class LeaveAccount extends Activity implements ServerResponseListener, SmsListener
{
	Button  logoutbtnaccount,submit_btn_account;
	ProgressDialog progressDialog;
	Handler mHandler;
	RelativeLayout ll_leave,ll_duty,ll_holiday;
	LinearLayout ll_peternity,ll_maternity;
	//	EditText cl_et,el_et,hpl_et,ccl_et;
	EditText hplno_et,cclno_et,compno_et;
	EditText elava_et,hplava_et,plava_et,mlava_et,cclava_et,compava_et,splcl_et,aborava_et,elno_et;
	String splclno_str,el_str,hpl_str,ccl_str;
	String aborno_str,aborava_str; 
	StringBuilder LeavesAccountData;
	TextView splclno_tv,plno_tv,ophono_tv,mlno_tv,aborno_tv;
	String temp ="",otpcheck;
	LinearLayout ll_types,ll_types1;
	EditText el_tv,hpl_tv,ccl_tv,ophoava_et;
	String elno_str,hplno_str,plno_str,mlno_str,cclno_str,compno_str,elava_str,hplava_str,plava_str,mlava_str,cclava_str,compava_str,splcl_ava_str,ophono_str,ophoava_str;
	SmsReceiver receiver=new SmsReceiver();
	public static boolean isNetworkAvailable(Context paramContext)
	{
		Log.d("network", "checking if network available");
		ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
		if (localConnectivityManager == null);
		NetworkInfo localNetworkInfo;
		do
		{

			localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
			Log.d("network", "net object is............." + localNetworkInfo);
			if(localNetworkInfo==null)
				return false;

		}while (localNetworkInfo == null);
		return localNetworkInfo.isConnected();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.leavesaccount);

		try
		{
			TextView scroll = (TextView) this.findViewById(R.id.marque_scrolling_text);
			scroll.setSelected(true);

			ll_types=(LinearLayout) findViewById(R.id.ll_types);
			ll_types1=(LinearLayout) findViewById(R.id.ll_types1);



			//		cl_et=(EditText) findViewById(R.id.cl_et);
			//		el_et=(EditText) findViewById(R.id.el_et);
			//		hpl_et=(EditText) findViewById(R.id.hpl_et);
			//	ccl_et=(EditText) findViewById(R.id.ccl_et);
			//		maternity_et=(EditText) findViewById(R.id.maternity_et);
			//		paternity_et=(EditText) findViewById(R.id.paternity_et);
			submit_btn_account=(Button)findViewById(R.id.submit_btn_account);
			//		ll_maternity=(LinearLayout)findViewById(R.id.ll_maternity);
			//		ll_peternity=(LinearLayout)findViewById(R.id.ll_peternity);

			//			splclno_et = (TextView)findViewById(R.id.splcl_nodays);

			splclno_tv = (TextView)findViewById(R.id.splcl_nodays);
			splcl_et = (EditText)findViewById(R.id.splcl_avaidays);
			elno_et= (EditText)findViewById(R.id.el_nodays);
			elava_et= (EditText)findViewById(R.id.el_avaidays);
			hplno_et= (EditText)findViewById(R.id.hpl_nodays);
			hplava_et= (EditText)findViewById(R.id.hpl_avaidays);

			//			plno_et= (TextView)findViewById(R.id.pl_nodays);

			plno_tv= (TextView)findViewById(R.id.pl_nodays);

			plava_et= (EditText)findViewById(R.id.pl_avaidays);
			mlno_tv= (TextView)findViewById(R.id.ml_nodays);
			mlava_et= (EditText)findViewById(R.id.ml_avaidays);
			aborno_tv = (TextView)findViewById(R.id.abor_nodays);
			aborava_et = (EditText)findViewById(R.id.abor_avaidays);

			ophono_tv = (TextView)findViewById(R.id.opho_nodays);


			ophoava_et = (EditText)findViewById(R.id.opho_avaidays);
			//		cclno_et= (EditText)findViewById(R.id.ccl_nodays);
			//		compno_et= (EditText)findViewById(R.id.comp_nodays);
			//		cclava_et= (EditText)findViewById(R.id.ccl_avaidays);
			//		compava_et= (EditText)findViewById(R.id.comp_avaidays);



			//		cl_tv=(TextView) findViewById(R.id.cl_tv);
			//		el_tv=(TextView) findViewById(R.id.el_tv);
			//		hpl_tv=(TextView) findViewById(R.id.hpl_tv);
			//	ccl_tv=(TextView) findViewById(R.id.ccl_tv);
			//		materity_tv=(TextView) findViewById(R.id.materity_tv);
			//		paternity_tv=(TextView) findViewById(R.id.paternity_tv);

			if(WebserviceCall.Schoolinfolist.get("MOBILENO").toString()==null||WebserviceCall.Schoolinfolist.get("MOBILENO").toString().length()<10)
			{
				//			mobiletv.setText("NA");
				ll_types.setVisibility(8);
				ll_types1.setVisibility(0);
			}
			else
			{
				ll_types.setVisibility(0);
				ll_types1.setVisibility(8);
				//			temp= WebserviceCall.Schoolinfolist.get("MOBILENO").toString().substring(6, 10);
				//			mobiletv.setText("******"+temp);
			}



			if(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M"))
			{
				//			ll_peternity.setVisibility(0);
				//
				//			ll_maternity.setVisibility(8);
				((LinearLayout)findViewById(R.id.pl_ll)).setVisibility(0);
				((LinearLayout)findViewById(R.id.abor_ll)).setVisibility(8);
				((TextView)findViewById(R.id.pl_nodays)).setText("15");
				((LinearLayout)findViewById(R.id.maternity_ll)).setVisibility(8);
				(findViewById(R.id.splcl_nodays)).setVisibility(0);
				((TextView)findViewById(R.id.splcl_nodays)).setText("7");
				((TextView)findViewById(R.id.opho_nodays)).setText("5");
//				((TextView)findViewById(R.id.el_nodays)).setText("300");
				//			((TextView)findViewById(R.id.el_nodays)).setText("6");

				//			((LinearLayout)findViewById(R.id.ccl_ll)).setVisibility(8);

			}
			else
			{
				//			ll_peternity.setVisibility(8);
				//cl_tv.setText("27");
				((LinearLayout)findViewById(R.id.pl_ll)).setVisibility(8);
				((LinearLayout)findViewById(R.id.abor_ll)).setVisibility(0);
				((TextView)findViewById(R.id.ml_nodays)).setText("180");
				((LinearLayout)findViewById(R.id.maternity_ll)).setVisibility(0);
				((TextView)findViewById(R.id.opho_nodays)).setText("5");
				(findViewById(R.id.splcl_nodays)).setVisibility(0);
				((TextView)findViewById(R.id.splcl_nodays)).setText("12");
				((TextView)findViewById(R.id.abor_nodays)).setText("42");
//				((TextView)findViewById(R.id.el_nodays)).setText("300");
				//			((LinearLayout)findViewById(R.id.ccl_ll)).setVisibility(8);
				//			((TextView)findViewById(R.id.el_nodays)).setText("6");
			}		
			//			ll_maternity.setVisibility(0);

			//        treasuryidtv.setText(WebserviceCall.Schoolinfolist.get("TEACHERCODE").toString());
			//        Teachernametv.setText(WebserviceCall.Schoolinfolist.get("TEACHERNAME").toString());
			//        schooltv.setText(WebserviceCall.Schoolinfolist.get("SCHOOLNAME").toString());
			//        schoolcodetv.setText(WebserviceCall.Schoolinfolist.get("SCHOOLCODE").toString());
			//        designationtv.setText(WebserviceCall.Schoolinfolist.get("DESIGNATION").toString());
			logoutbtnaccount=(Button)findViewById(R.id.logoutbtnaccount);
			logoutbtnaccount.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{
					logoutFunction();

				}
			});
			((Button)findViewById(R.id.user_submit_btn_otp_leaveaccount)).setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v) 
				{

					if(((EditText)findViewById(R.id.otpet_leaveaccount)).getText().toString().equalsIgnoreCase(""))
					{
						AlertDialogs("", "Enter OTP");
						((EditText)findViewById(R.id.otpet_leaveaccount)).requestFocus();
						return;
					}
					if(!(((EditText)findViewById(R.id.otpet_leaveaccount)).getText().toString().trim().equalsIgnoreCase(otpcheck)))
					{
						AlertDialogs("", "OTP is Invalid");
						((EditText)findViewById(R.id.otpet_leaveaccount)).requestFocus();
						return;
					}
					RequestServer request=new RequestServer(LeaveAccount.this);
					request.addParam("xmlData", LeavesAccountData.toString());
					//	request.addParam("deviceVersion", "1");
					request.addParam("deviceVersion", HomeData.sAppVersion);
					request.ProccessRequest(LeaveAccount.this, "insertLeaveData");

				}
			});
			submit_btn_account.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v) 
				{


					splclno_str=splclno_tv.getText().toString();
					splcl_ava_str= splcl_et.getText().toString();
					elno_str = elno_et.getText().toString();
					elava_str = elava_et.getText().toString();
					hplno_str = hplno_et.getText().toString();
					hplava_str = hplava_et.getText().toString();
					plno_str = plno_tv.getText().toString();
					plava_str = plava_et.getText().toString();
					mlno_str = mlno_tv.getText().toString();
					mlava_str = mlava_et.getText().toString();
					//				cclno_str = cclno_et.getText().toString();
					//				cclava_str = cclava_et.getText().toString();
					//				compno_str = compno_et.getText().toString();
					//				compava_str = compava_et.getText().toString();
					aborno_str = aborno_tv.getText().toString(); 
					aborava_str = aborava_et.getText().toString();
					ophono_str = ophono_tv.getText().toString();
					ophoava_str = ophoava_et.getText().toString();


					Log.d("qqq", splclno_str);
					Log.d("qqq", splcl_ava_str);
					Log.d("qqq", elno_str);
					Log.d("qqq", elava_str);
					Log.d("qqq", hplno_str);
					Log.d("qqq", hplava_str);
					Log.d("qqq", plno_str);
					Log.d("qqq", plava_str);
					Log.d("qqq", mlno_str);
					Log.d("qqq", mlava_str);
					//				Log.d("qqq", cclno_str);
					//				Log.d("qqq", cclava_str);
					//				Log.d("qqq", compno_str);
					//				Log.d("qqq", compava_str);
					Log.d("qqq", ophono_str);
					Log.d("qqq", ophoava_str);


					//					if(splclno_str.equalsIgnoreCase(""))
					//					{
					//						AlertDialogs("Information!!", "Enter Number of Spl. Casual Leave's");
					//						splclno_et.requestFocus();
					//						return;
					//					}
					if(splcl_ava_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Spl. Casual Leave's");
						splcl_et.requestFocus();
						return;
					}
					
					if(Double.parseDouble(splclno_str) < Double.parseDouble(splcl_ava_str))
					{
						AlertDialogs("Information!!", "Spl. Casual Leave's Availed < Spl. Casual Leave's No.of Days");
						splcl_et.requestFocus();
						return;
					}

					if(elno_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Earned Leave's");
						elno_et.requestFocus();
						return;
					}
					
					if(Double.parseDouble(elno_str)==0)
					{
						AlertDialogs("Information!!", "Number of Earned Leave's should not be Equal to 0 days");
						elno_et.requestFocus();
						return;
					}
					
					if(elava_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Earned Leave's");
						elava_et.requestFocus();
						return;
					}
					
					if((Double.parseDouble(elava_str)>300))
					{
						AlertDialogs("Information!!", "No.of Earned Availed Leave's should not be Greater than 300 Days");
						elava_et.requestFocus();
						return;
					}
					if(Double.parseDouble(elno_str) < Double.parseDouble(elava_str))
					{
						AlertDialogs("Information!!", "Earned Leave's Availed < Earned Leave's No.of Days");
						elava_et.requestFocus();
						return;
					}
					
					if(hplno_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Half Pay Leave's");
						hplno_et.requestFocus();
						return;
					}
					
					if(Double.parseDouble(hplno_str)==0)
					{
						AlertDialogs("Information!!", "Number of Half Pay Leave's should not be Equal to 0 days");
						hplno_et.requestFocus();
						return;
					}
					if(hplava_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Half Pay Leave's");
						hplava_et.requestFocus();
						return;
					}
					
					if(Double.parseDouble(hplno_str) < Double.parseDouble(hplava_str))
					{
						AlertDialogs("Information!!", "Half Pay Leave's Availed < Half Pay Leave's No.of Days");
						hplava_et.requestFocus();
						return;
					}

					if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					{
						if(mlno_str.equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Maternity Leave's");
							mlno_tv.requestFocus();
							return;
						}
					}
					if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					{
						if(mlava_str.equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Maternity Leave's");
							mlava_et.requestFocus();
							return;
						}
					}
					if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					{
						if(Double.parseDouble(mlno_str)<Double.parseDouble(mlava_str))
						{
							AlertDialogs("Information!!", "Maternity Leave's Availed < Maternity Leave's No.of Days");
							mlava_et.requestFocus();
							return;
						}
					}

					if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					{

						if(aborno_str.equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Abortion Leave's");
							aborno_tv.requestFocus();
							return;
						}
					}
					if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					{
						if(aborava_str.equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Abortion Leave's");
							aborava_et.requestFocus();
							return;
						}
					}
					
					if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					{
						if(Double.parseDouble(aborno_str)<Double.parseDouble(aborava_str))
						{
							AlertDialogs("Information!!", "Abortion Leave's Availed < Abortion Leave's No.of Days");
							aborava_et.requestFocus();
							return;
						}
					}

					if(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M"))
					{

						if(plno_str.equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Number of Paternity Leave's");
							plno_tv.requestFocus();
							return;
						}
					}
					if(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M"))
					{
						if(plava_str.equalsIgnoreCase(""))
						{
							AlertDialogs("Information!!", "Enter Availed Paternity Leaves's");
							plava_et.requestFocus();

							return;
						}
					}
					
					if(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M"))
					{
						if(Double.parseDouble(plno_str)<Double.parseDouble(plava_str))
						{
							AlertDialogs("Information!!", "Paternity Leave's Availed < Paternity Leave's No.of Days");
							plava_et.requestFocus();
							return;
						}
					}

					if(ophono_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Number of Optional Holiday's");
						ophono_tv.requestFocus();
						return;
					}
					
					if(ophoava_str.equalsIgnoreCase(""))
					{
						AlertDialogs("Information!!", "Enter Availed Optional Holiday's");
						ophoava_et.requestFocus();
						return;
					}
					
					if(Double.parseDouble(ophono_str)<Double.parseDouble(ophoava_str))
					{
						AlertDialogs("Information!!", "Optional Holiday's Availed < Optional Holiday's No.of Days");
						ophoava_et.requestFocus();
						return;
					}
					
					//				if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					//				{
					//					if(cclno_str.equalsIgnoreCase(""))
					//					{
					//						AlertDialogs("Information!!", "Enter Number of Child Care Leave's");
					//						cclno_et.requestFocus();
					//						return;
					//					}
					//				}
					//				if(compno_str.equalsIgnoreCase(""))
					//				{
					//					AlertDialogs("Information!!", "Enter Number of Compensatory leave's");
					//					compno_et.requestFocus();
					//					return;
					//				}



					//				if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					//				{
					//
					//
					//					if(cclava_str.equalsIgnoreCase(""))
					//					{
					//						AlertDialogs("Information!!", "Enter Availed Child Care Leave's");
					//						cclava_et.requestFocus();
					//						return;
					//					}
					//				}


					//				if(compava_str.equalsIgnoreCase(""))
					//				{
					//					AlertDialogs("Information!!", "Enter Availed Compensatory leave's");
					//					compava_et.requestFocus();
					//					return;
					//				}
//					System.out.println("---"+splclno_str+"--"+splcl_ava_str);
					

					//				if(!(WebserviceCall.Schoolinfolist.get("GENDER").equalsIgnoreCase("M")))
					//				{
					//					if(Double.parseDouble(cclno_str)<Double.parseDouble(cclava_str))
					//					{
					//						AlertDialogs("Information!!", "Child Care Leave's Availed < Child Care Leave's No.of Days");
					//						cclava_et.requestFocus();
					//						return;
					//					}
					//				}
					//				if(Double.parseDouble(compno_str)<Double.parseDouble(compava_str))
					//				{
					//					AlertDialogs("Information!!", "Compensatory leave's Availed < Compensatory leave's No.of Days");
					//					compava_et.requestFocus();
					//					return;
					//				}
					
					if(((LinearLayout)findViewById(R.id.pl_ll)).getVisibility()==View.GONE)
					{
						plno_str="0";
						plava_str="0";
					}
					if(((LinearLayout)findViewById(R.id.maternity_ll)).getVisibility()==View.GONE)
					{
						mlno_str="0";
						mlava_str="0";
					}
					//				if(((LinearLayout)findViewById(R.id.ccl_ll)).getVisibility()==View.GONE)
					//				{
					//					cclno_str="0";
					//					cclava_str="0";
					//				}
					if(((LinearLayout)findViewById(R.id.abor_ll)).getVisibility()==View.GONE)
					{
						aborno_str="0";
						aborava_str="0";
					}
					LeavesAccountData=new StringBuilder();
					LeavesAccountData.append("<LEAVEDATA>");
					//	LeavesAccountData.append("<HighestClass>"+highestclass.getText().toString()+"</HighestClass>");
					LeavesAccountData.append("<TREASURYID>"+Login.UserName+"</TREASURYID>");
					LeavesAccountData.append("<TOTALCL>"+splclno_str+"</TOTALCL>");
					LeavesAccountData.append("<AVAILCL>"+splcl_ava_str+"</AVAILCL>");
					LeavesAccountData.append("<TOTALEL>"+elno_str+"</TOTALEL>");
					LeavesAccountData.append("<AVAILEL>"+elava_str+"</AVAILEL>");
					LeavesAccountData.append("<TOTALHPL>"+hplno_str+"</TOTALHPL>");
					LeavesAccountData.append("<AVAILHPL>"+hplava_str+"</AVAILHPL>");
					LeavesAccountData.append("<TOTALML>"+mlno_str+"</TOTALML>");
					LeavesAccountData.append("<AVAILML>"+mlava_str+"</AVAILML>");
					LeavesAccountData.append("<TOTALABORTION>"+aborno_str+"</TOTALABORTION>");
					LeavesAccountData.append("<AVAILABORTION>"+aborava_str+"</AVAILABORTION>");
					LeavesAccountData.append("<TOTALPL>"+plno_str+"</TOTALPL>");
					LeavesAccountData.append("<AVAILPL>"+plava_str+"</AVAILPL>");
					LeavesAccountData.append("<TOTALOH>"+ophono_str+"</TOTALOH>");
					LeavesAccountData.append("<AVAILOH>"+ophoava_str+"</AVAILOH>");
					//				LeavesAccountData.append("<TOTALCOMPENSACTION>"+compno_str+"</TOTALCOMPENSACTION>");
					//				LeavesAccountData.append("<AVAILCOMPENSACTION>"+compava_str+"</AVAILCOMPENSACTION>");
					LeavesAccountData.append("<GENDER>"+WebserviceCall.Schoolinfolist.get("GENDER")+"</GENDER>");
					LeavesAccountData.append("<STATUS>"+"Y"+"</STATUS>");

					LeavesAccountData.append("</LEAVEDATA>");
					if(isNetworkAvailable(LeaveAccount.this))
					{


						RequestServer request=new RequestServer(LeaveAccount.this);
						request.addParam("teacherCode", Login.UserName);
						request.ProccessRequest(LeaveAccount.this, "getOtp");


					}
					else
					{
						AlertDialogs("Information!!","Check The Internet Connection");
						return;
					}


				}
			});

			((TextView)findViewById(R.id.resendotp_leaveaccount)).setOnClickListener(new OnClickListener() 
			{

				@Override
				public void onClick(View v)
				{

					if(isNetworkAvailable(LeaveAccount.this))
					{

						((EditText)findViewById(R.id.otpet_leaveaccount)).setText("");
						RequestServer request=new RequestServer(LeaveAccount.this);
						request.addParam("teacherCode", Login.UserName);
						request.ProccessRequest(LeaveAccount.this, "getOtp");
					}
				}
			});

			splcl_et.requestFocus();
		}
		catch(Exception e)
		{

		}
	}

	public void AlertDialogs(String title, String msg)
	{
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
		dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText(msg);
		Button yes =(Button)dialog.findViewById(R.id.ok_button); 
		yes.startAnimation(shake);

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();

				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
	}


	@SuppressLint("NewApi")
	private void logoutFunction() 
	{
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setCancelable(false);
		builder1.setTitle("Information");
		builder1.setMessage("Do you want to Logout??");
		builder1.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.dismiss();
				Intent i=	new Intent(LeaveAccount.this,Login.class);
				startActivity(i);
				LeaveAccount.this.finish();
				finishAffinity();
			}
		});
		builder1.setNegativeButton("No",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();


		return ;
	}

	@Override
	public void Success(String response, String methodName)
	{
		if(methodName.equalsIgnoreCase("getOtp"))
		{
			submit_btn_account.setVisibility(8);
			((LinearLayout)findViewById(R.id.ll_opt_leaveaccount)).setVisibility(0);
			temp= WebserviceCall.Schoolinfolist.get("MOBILENO").toString().substring(6, 10);
			((TextView)findViewById(R.id.mob_tv_leaveaccount)).setText("Registered Mobile Number :  "+"******"+temp);
			((Button)findViewById(R.id.user_submit_btn_otp_leaveaccount)).setVisibility(0);



			((TextView)findViewById(R.id.resendotp_leaveaccount)).setVisibility(0);
			otpcheck=response;
			IntentFilter filter = new IntentFilter();
			filter.addAction("android.provider.Telephony.SMS_RECEIVED");
			registerReceiver(receiver, filter); 
			SmsReceiver.bindListener(LeaveAccount.this,"");

			//			IntentFilter mainFilter = new IntentFilter();
			//			receiver = new SmsReceiver();
			//			registerReceiver(receiver, mainFilter);
			// receiver = new Intent(Typeofleave.this,SmsReceiver.class);
			//sendBroadcast(receiver);


			//	 LocalBroadcastManager.getInstance(this).registerReceiver(request, new IntentFilter("OTP"));

		}
		else
		{
			final Dialog dialog = new Dialog(this);
			dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);
			dialog.getWindow().getAttributes().windowAnimations =R.style.exitdialog_animation1;
			dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
			dialog.setContentView(R.layout.alert_dialog);
			dialog.setCancelable(false);
			Animation shake = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
			TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
			msgTv.setText("Successfully Submitted");
			Button yes =(Button)dialog.findViewById(R.id.ok_button); 
			yes.startAnimation(shake);

			yes.setOnClickListener(new View.OnClickListener() 
			{
				@Override
				public void onClick(View v)
				{
					dialog.dismiss();
					Intent ins = new Intent();
					ins.setClass(LeaveAccount.this, HomePage.class);
					startActivity(ins);
					return;
				}
			});        
			if(!dialog.isShowing())
				dialog.show();
		}

	}

	@Override
	public void Fail(String response, String methodName)
	{

		AlertDialogs("Information!!",response);

	}

	@Override
	public void NetworkNotAvail() 
	{
		AlertDialogs("Information!!","Network not Available, Please check and try again!!");

	}

	@Override
	public void AppUpdate() 
	{
		final Dialog dialog = new Dialog(LeaveAccount.this);
		dialog.setCancelable(false);
		dialog.requestWindowFeature((int) Window.FEATURE_NO_TITLE);		
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setContentView(R.layout.alert_dialog);		
		TextView msgTv=(TextView)dialog.findViewById(R.id.message_textView);
		msgTv.setText("New Version Available. Please Click Ok to Continue");
		Button yes =(Button)dialog.findViewById(R.id.ok_button);	

		yes.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
				try
				{
					Intent viewIntent =
							new Intent("android.intent.action.VIEW",
									Uri.parse("https://play.google.com/store/apps/details?id=com.aponline.simslm"));
					startActivity(viewIntent);
					LeaveAccount.this.finish();
				}
				catch(Exception e) 
				{
					Toast.makeText(getApplicationContext(),"Unable to Connect Try Again...",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				return;
			}
		});        
		if(!dialog.isShowing())
			dialog.show();
		return;

	}

	@Override
	public void messageReceived(String messageText) {
		LeaveAccount.this.unregisterReceiver(receiver);
		String msg=messageText;
		msg=msg.replaceAll("[^\\d.]", "");
		((EditText)findViewById(R.id.otpet_leaveaccount)).setText(msg);

	}


}
