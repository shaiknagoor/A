package com.aponline.simslm.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.simslm.R;

import android.R.string;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class EmployeeListAdpter2 extends BaseAdapter 
{
	ArrayList<HashMap<String,String>> localArrayList = new ArrayList<HashMap<String,String>>();
	Context mcontext;
	private LayoutInflater mInflater;
	Holder mHolder;
	public EmployeeListAdpter2(Context applicationContext,ArrayList<HashMap<String,String>> data) 
	{
		this.mcontext=applicationContext;
		this.mInflater=LayoutInflater.from(applicationContext);
		this.localArrayList=data;
	}


	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{

		if(convertView==null)
		{
			convertView = this.mInflater.inflate(R.layout.balancelistrow, null);
			this.mHolder = new Holder();

			this.mHolder.balancecount = ((TextView)convertView.findViewById(R.id.balancecounttv));
			this.mHolder.leavename = ((TextView)convertView.findViewById(R.id.balancenametv));
		
			convertView.setTag(this.mHolder);


		}
		else

			this.mHolder=(Holder)convertView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));
		HashMap<String,String> data=this.localArrayList.get(position);
		
		this.mHolder.leavename.setText(data.get("name"));
		this.mHolder.balancecount.setText(data.get("balance"));
		





		return convertView;
	}



	private class Holder
	{

		TextView leavename;	
		TextView balancecount;
		

		private Holder()
		{

		}

	}

}
