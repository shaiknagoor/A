package com.aponline.simslm.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import com.aponline.simslm.R;

import android.R.string;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class EmployeeListAdpter extends BaseAdapter 
{
	ArrayList<HashMap<String,String>> localArrayList = new ArrayList<HashMap<String,String>>();
	Context mcontext;
	private LayoutInflater mInflater;
	Holder mHolder;
	public EmployeeListAdpter(Context applicationContext,ArrayList<HashMap<String,String>> data) 
	{
		this.mcontext=applicationContext;
		this.mInflater=LayoutInflater.from(applicationContext);
		this.localArrayList=data;
	}


	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return localArrayList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return Integer.valueOf(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{

		if(convertView==null)
		{
			convertView = this.mInflater.inflate(R.layout.details_list, null);
			this.mHolder = new Holder();

			this.mHolder.EmployeeListSno = ((TextView)convertView.findViewById(R.id.EmployeeSno));
			this.mHolder.EmployeeListId = ((TextView)convertView.findViewById(R.id.Employeetreasuryid));
			this.mHolder.EmployeeListName = ((TextView)convertView.findViewById(R.id.Employeename));
			
			this.mHolder.TOTALCAS = ((TextView)convertView.findViewById(R.id.TOTALCAS));
			this.mHolder.AVAILCAS = ((TextView)convertView.findViewById(R.id.AVAILCAS));

			this.mHolder.TOTALCL = ((TextView)convertView.findViewById(R.id.TOTALCL));
			this.mHolder.AVAILCL = ((TextView)convertView.findViewById(R.id.AVAILCL));
			this.mHolder.TOTALEL = ((TextView)convertView.findViewById(R.id.TOTALEL));
			this.mHolder.AVAILEL = ((TextView)convertView.findViewById(R.id.AVAILEL));
			this.mHolder.TOTALPL = ((TextView)convertView.findViewById(R.id.TOTALPL));
			this.mHolder.AVAILPL = ((TextView)convertView.findViewById(R.id.AVAILPL));
			this.mHolder.TOTALHPL = ((TextView)convertView.findViewById(R.id.TOTALHPL));
			this.mHolder.AVAILHPL = ((TextView)convertView.findViewById(R.id.AVAILHPL));
			this.mHolder.TOTALML = ((TextView)convertView.findViewById(R.id.TOTALML));
			this.mHolder.AVAILML = ((TextView)convertView.findViewById(R.id.AVAILML));
			this.mHolder.TOTALCCL = ((TextView)convertView.findViewById(R.id.TOTALCCL));
			this.mHolder.AVAILCCL = ((TextView)convertView.findViewById(R.id.AVAILCCL));
			this.mHolder.AVAILCOMPENSACTION = ((TextView)convertView.findViewById(R.id.AVAILCOMPENSACTION));
			this.mHolder.TOTALCOMPENSACTION = ((TextView)convertView.findViewById(R.id.TOTALCOMPENSACTION));
			this.mHolder.GENDER = ((TextView)convertView.findViewById(R.id.gender));
			this.mHolder.TOTALABO = ((TextView)convertView.findViewById(R.id.TOTALABO));
			this.mHolder.AVAILABO = ((TextView)convertView.findViewById(R.id.AVAILABO));
			this.mHolder.TOTALOH = ((TextView)convertView.findViewById(R.id.TOTALOH));
			this.mHolder.AVAILOH = ((TextView)convertView.findViewById(R.id.AVAILOH));
			this.mHolder.TOTALEOL = ((TextView)convertView.findViewById(R.id.TOTALEOL));
			this.mHolder.AVAILEOL = ((TextView)convertView.findViewById(R.id.AVAILEOL));
			this.mHolder.TOTALSTU = ((TextView)convertView.findViewById(R.id.TOTALSTU));
			this.mHolder.AVAILSTU = ((TextView)convertView.findViewById(R.id.AVAILSTU));
			this.mHolder.TOTALLH = ((TextView)convertView.findViewById(R.id.TOTALLH));
			this.mHolder.AVAILLH = ((TextView)convertView.findViewById(R.id.AVAILLH));
			this.mHolder.TOTALHYS = ((TextView)convertView.findViewById(R.id.TOTALHYS));
			this.mHolder.AVAILHYS = ((TextView)convertView.findViewById(R.id.AVAILHYS));
			this.mHolder.TOTALVAS = ((TextView)convertView.findViewById(R.id.TOTALVAS));
			this.mHolder.AVAILVAS = ((TextView)convertView.findViewById(R.id.AVAILVAS));
			this.mHolder.TOTALTUB = ((TextView)convertView.findViewById(R.id.TOTALTUB));
			this.mHolder.AVAILTUB = ((TextView)convertView.findViewById(R.id.AVAILTUB));
			this.mHolder.TOTALREC = ((TextView)convertView.findViewById(R.id.TOTALREC));
			this.mHolder.AVAILREC = ((TextView)convertView.findViewById(R.id.AVAILREC));
			convertView.setTag(this.mHolder);


		}
		else

			this.mHolder=(Holder)convertView.getTag();
		Log.d("INSIDE ADAPTER", Integer.toString(position));
		HashMap<String,String> data=this.localArrayList.get(position);
		this.mHolder.EmployeeListSno.setText(Integer.toString(position+1));
		this.mHolder.EmployeeListId.setText(data.get("teacher_code"));
		this.mHolder.EmployeeListName.setText(data.get("teacher_name"));
		
		this.mHolder.TOTALCAS.setText(data.get("Total_Casual"));
		this.mHolder.AVAILCAS.setText(data.get("Avail_Casual"));
		
		this.mHolder.TOTALCL.setText(data.get("total_cl"));
		this.mHolder.AVAILCL.setText(data.get("availed_cl"));
		this.mHolder.TOTALEL.setText(data.get("total_el"));
		this.mHolder.AVAILEL.setText(data.get("availed_el"));
		this.mHolder.TOTALPL.setText(data.get("total_paternity"));
		this.mHolder.AVAILPL.setText(data.get("availed_paternity"));
		this.mHolder.TOTALHPL.setText(data.get("total_hpl"));
		this.mHolder.AVAILHPL.setText(data.get("availed_hpl"));
		this.mHolder.TOTALML.setText(data.get("total_ml"));
		this.mHolder.AVAILML.setText(data.get("availed_ml"));
		this.mHolder.TOTALCCL.setText(data.get("total_childcare"));
		this.mHolder.AVAILCCL.setText(data.get("availed_childcare"));
		this.mHolder.TOTALCOMPENSACTION.setText(data.get("total_compensation"));
		this.mHolder.AVAILCOMPENSACTION.setText(data.get("availed_compensation"));
		this.mHolder.GENDER.setText(data.get("gender"));
		this.mHolder.TOTALABO.setText(data.get("Total_Abortion"));
		this.mHolder.AVAILABO.setText(data.get("Avail_Abortion"));
		this.mHolder.TOTALOH.setText(data.get("Total_OH"));
		this.mHolder.AVAILOH.setText(data.get("Avail_OH"));
		this.mHolder.TOTALEOL.setText(data.get("Tot_EOL"));
		this.mHolder.AVAILEOL.setText(data.get("Avail_EOL"));
		this.mHolder.TOTALSTU.setText(data.get("Total_Study"));
		this.mHolder.AVAILSTU.setText(data.get("Avail_Study"));
		this.mHolder.TOTALLH.setText(data.get("Total_LH"));
		this.mHolder.AVAILLH.setText(data.get("Avail_LH"));
		this.mHolder.TOTALHYS.setText(data.get("Total_Hysterectomy"));
		this.mHolder.AVAILHYS.setText(data.get("Avail_Hysterectomy"));
		this.mHolder.TOTALVAS.setText(data.get("Total_Vasectomy"));
		this.mHolder.AVAILVAS.setText(data.get("Avail_Vasectomy"));
		this.mHolder.TOTALTUB.setText(data.get("Total_Tubectomy"));
		this.mHolder.AVAILTUB.setText(data.get("Avail_Tubectomy"));
		this.mHolder.TOTALREC.setText(data.get("Total_Reconalisation"));
		this.mHolder.AVAILREC.setText(data.get("Avail_Reconalisation"));
		

		return convertView;
	}



	private class Holder
	{

		TextView EmployeeListSno;	
		TextView EmployeeListId;
		TextView EmployeeListName;
		
		TextView TOTALCAS;
		TextView AVAILCAS;
		TextView AVAILCL;
		TextView TOTALCL;
		TextView AVAILEL; 
		TextView TOTALEL;
		TextView AVAILPL; 
		TextView TOTALPL;
		TextView AVAILHPL; 
		TextView TOTALHPL;
		TextView AVAILML; 
		TextView TOTALML;
		TextView TOTALCCL;
		TextView AVAILCCL;
		TextView AVAILCOMPENSACTION;		
		TextView TOTALCOMPENSACTION;
		TextView GENDER;
		TextView TOTALABO;
		TextView AVAILABO;
		TextView TOTALOH;
		TextView AVAILOH;
		TextView TOTALEOL;
		TextView AVAILEOL;
		TextView TOTALSTU;
		TextView AVAILSTU;
		TextView TOTALLH;
		TextView AVAILLH;
		TextView TOTALHYS;
		TextView AVAILHYS;
		
		TextView TOTALVAS;
		TextView AVAILVAS;
		TextView TOTALTUB;
		TextView AVAILTUB;
		TextView TOTALREC;
		TextView AVAILREC;
		
	
		private Holder()
		{

		}

	}

}
