 package com.aponline.simslm.database;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

public class DBAdapter 
{
	private static final String TAG = "DBAdapter";

	private static final String DATABASE_NAME = "APGER.db";   
	private static final int DATABASE_VERSION = 1;
	private static String DB_PATH = Environment.getExternalStorageDirectory()+"/DCIM/.APGER/"+DATABASE_NAME; 
	private final Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase db;
//	private static final String FILE_NAME = "new_villages_mandals2.txt";
//	private static String TXTFILE_PATH = Environment.getExternalStorageDirectory()+"/FMDCP/"+FILE_NAME; 

	public DBAdapter(Context ctx)   
	{
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}

	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		DatabaseHelper(Context context)
		{
			super(context, DB_PATH, null, DATABASE_VERSION);
			Log.d(TAG, "DATABASE Successfully Created");
			//			if(android.os.Build.VERSION.SDK_INT >= 17)
			//			{
			//				DB_PATH = context.getApplicationInfo().dataDir + "/databases/";         
			//			}
			//			else
			//			{
			//				DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
			//			}
		}
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			try
			{

				Log.d(TAG, "Table Successfully Created");
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{
			Log.w(TAG, oldVersion + " to " + newVersion+ ", which will destroy all old data");
			//			db.execSQL("DROP TABLE IF EXISTS contacts");
			onCreate(db);
		}
	}
	public void createNewTable() 
	{
		Log.w(TAG, "::::::Inside Create New Table::::::");
	}
	public DBAdapter open() throws SQLException 
	{ 
		//if(!db.isOpen())
		db = DBHelper.getWritableDatabase();
		return this;
	}

	public void close()
	{
		//if(db.isOpen())
		DBHelper.close();
	}

	public synchronized long insertTableDate(String TableName, ContentValues contentValues)
	{
		//Log.d(TAG, "DATA INSERTED");
		return db.insert(TableName, null, checkIsThereAnyNullVallues(contentValues));
	}
	public void AlterTable(String query)
	{
		db.execSQL(query);
	}
	//	public long updateTableDate(String TableName, ContentValues contentValues,String whereClause)
	//	{	
	//		return db.update(TableName, contentValues, whereClause, null);
	//	}
	public synchronized boolean deleteTableData(String tableName,String whereClause) 
	{
		return db.delete(tableName, whereClause, null) > 0;
	}

	public Cursor getAllTableData(String tableName,String[] columnNames) 
	{
		return db.query(tableName,columnNames, null, null, null, null, null);
	}

	public Cursor getAllTableData(String tableName,String[] columnNames,String whereCondition) throws SQLException
	{
		Cursor mCursor = db.query(true, tableName,columnNames, whereCondition,null, null, null, null, null);
		if (mCursor != null)
		{
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	public synchronized boolean updateTableData(String tableName,ContentValues values,String whereCondition)
	{
		return db.update(tableName, values,whereCondition, null) > 0;
	}
	public ArrayList<String> getSpinnerData(String query)
	{
		ArrayList<String> data = new ArrayList<String>();
		data.add("--Select--");
		// Select All Query
		System.out.println(query);
		Cursor cursor = db.rawQuery(query, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst())
		{

			do {
				data.add(cursor.getString(0));
			} while (cursor.moveToNext());
		}
		db.close();
		// closing connection
		cursor.close();
		// returning lables
		return data;
	}
	public List<String> getSingleColumnData(String query)
	{
		List<String> data = new ArrayList<String>();

		// Select All Query
		System.out.println(query);
		Cursor cursor = db.rawQuery(query, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst())
		{
			do 
			{
				data.add(cursor.getString(0));
			} while (cursor.moveToNext());
		}

		// closing connection
		cursor.close();
		db.close();
		// returning lables
		return data;
	}
	public Cursor getTableDataCursor(String query)
	{
		Cursor cursor = null;
		try
		{
			System.out.println("*****Query::::"+query);
			cursor = db.rawQuery(query, null);
			cursor.getCount();
		}
		catch(Exception localException)
		{
			localException.printStackTrace();
			cursor.close();
			db.close();
		}
		return cursor; 
	}

	public int getRowCount(String query)
	{
		int value = 0;
		System.out.println(query);
		Cursor cursor = db.rawQuery(query, null);
		try
		{
			cursor.moveToFirst();
			value=cursor.getInt(0);
		} catch (Exception e) {
		} finally {

			cursor.close();
		}
		return value;
	}
	public String getSingleValue(String query)
	{
		String value = "0";
		System.out.println(query);
		Cursor cursor = db.rawQuery(query, null);
		try
		{
			cursor.moveToFirst();
			value=cursor.getString(0);
		} catch (Exception e) {
		} finally {

			cursor.close();
		}
		return value;
	}

	public synchronized void execSQL(String query)
	{
		db.execSQL(query);
	}
	public void createDataBase() throws IOException
	{
		boolean mDataBaseExist = checkDataBase();
//		if(!mDataBaseExist)
//		{
//			exportDB();
//		}
//		mDataBaseExist = checkDataBase();
		if(!mDataBaseExist)
		{
			db = DBHelper.getWritableDatabase();
			this.close();
			try 
			{
				//Copy the database from assests
				copyDataBase();
				Log.e(TAG, "createDatabase database created");
			} 
			catch (IOException mIOException) 
			{
				throw new Error("ErrorCopyingDataBase");
			}
		}
	}
	//Check that the database exists here: /data/data/your package/databases/Da Name
	private boolean checkDataBase()
	{
		//DB_PATH = Environment.getExternalStorageDirectory()          + File.separator + "SMSMS"          + File.separator + DATABASE_NAME;
		File dbFile = new File(DB_PATH);
		Log.v("dbFile", dbFile + "   "+ dbFile.exists());
		return dbFile.exists();
	}


	//Copy the database from assets
	private void copyDataBase() throws IOException
	{
		//	DB_PATH = Environment.getExternalStorageDirectory()     + File.separator + "SMSMS"     + File.separator + DATABASE_NAME;
		InputStream mInput = context.getAssets().open(DATABASE_NAME);
		String outFileName = DB_PATH;
		OutputStream mOutput = new FileOutputStream(outFileName);
		byte[] mBuffer = new byte[1024];
		int mLength;
		while ((mLength = mInput.read(mBuffer))>0)
		{
			mOutput.write(mBuffer, 0, mLength);
		}
		mOutput.flush();
		mOutput.close();
		mInput.close();
	}

//	public void exportDB()
//	{
//		String DB_PATH="",DATABASE_NAME="AHFMDVP.db";
//		if(android.os.Build.VERSION.SDK_INT >= 17)
//		{
//			DB_PATH = context.getApplicationInfo().dataDir + "/databases/";         
//		}
//		else
//		{
//			DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
//		}
//		//		File sd = Environment.getExternalStorageDirectory();
//		//		File data = Environment.getDataDirectory();
//		FileChannel source=null;
//		FileChannel destination=null;
//		String currentDBPath = DB_PATH+DATABASE_NAME;
//		String backupDBPath = Environment.getExternalStorageDirectory()+"/AHFMDVP/"+DATABASE_NAME;
//		File currentDB = new File(currentDBPath);
//		createDirIfNotExists(Environment.getExternalStorageDirectory()+"/AHFMDVP/");
//		File backupDB = new File(backupDBPath);
//
//		try 
//		{
//			source = new FileInputStream(currentDB).getChannel();
//			destination = new FileOutputStream(backupDB).getChannel();
//			destination.transferFrom(source, 0, source.size());
//			source.close();
//			destination.close(); //Toast.makeText(this, "DB Exported!", Toast.LENGTH_LONG).show();
//		}
//		catch(IOException e) 
//		{
//			e.printStackTrace();
//		}
//	}
	public static boolean createDirIfNotExists(String path) 
	{
		boolean ret = true;

		File file = new File(path);
		if (!file.exists()) 
		{
			if (!file.mkdirs()) 
			{
				ret = false;
			}
		}
		return ret;

	}
	private ContentValues checkIsThereAnyNullVallues(ContentValues contentValues)
	{
		ContentValues fileteredData=new ContentValues();
		Set<Entry<String, Object>> s=contentValues.valueSet();
		Iterator<Entry<String, Object>> itr = s.iterator();
		while(itr.hasNext())
		{
			Map.Entry me = itr.next(); 
			String key = me.getKey().toString();
//			Object value =  me.getValue();
			Object value=me.getValue();
			if(value==null)
			{
				value="";
			}
			else if(value.toString().equalsIgnoreCase("null"))
			{
				value="";
			}
			fileteredData.put(key, value.toString());
		}

		return fileteredData;
	}
//	public void checkDBMaster() throws IOException
//	{
//		createDirIfNotExists(Environment.getExternalStorageDirectory()+"/FMDCP/");
//	//	String newFileName =TXTFILE_PATH;
//		File file=new File(TXTFILE_PATH);
//		FileReader file1;
//		if(!file.exists())
//		{
//
//			AssetManager assetManager =context.getAssets();
//			InputStream in = null;
//			OutputStream out = null;
//			try 
//			{
//				in = assetManager.open(FILE_NAME);
//				out = new FileOutputStream(TXTFILE_PATH);
//
//				byte[] buffer = new byte[1024];
//				int read;
//				while ((read = in.read(buffer)) != -1) 
//				{
//					out.write(buffer, 0, read);
//				}
//				in.close();
//				in = null;
//				out.flush();
//				out.close();
//				out = null;
//			} 
//			catch (Exception e) 
//			{
//				Log.e("tag", e.getMessage());
//			}
//			file1 = new FileReader(file);
//
//			BufferedReader buffer = new BufferedReader(file1);
//			String line = "";
//
//
//			db.beginTransaction();
//
//			while ((line = buffer.readLine()) != null) 
//			{
//				db.execSQL(line);
//			}
//			db.setTransactionSuccessful();
//			db.endTransaction();
//		}
//			
//			
//		
//	}
}
